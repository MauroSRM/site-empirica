# AuditLine

Linha do tempo semântica (`<ol>`/`<li>`) para trilha de auditoria: cada evento mostra
timestamp, ator, ação realizada, estágio (`done`/`active`/`pending`) e uma Tag de status
opcional. Puramente apresentacional — a ordem de exibição é a ordem fornecida em `items`.
Construído com `Tag` para o selo de status; sem dependência de `react-aria-components`.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/AuditLine/`
- **Export:** `import { AuditLine } from '@srm/diamond';`
- **Relacionados:** [Tag](./Tag.md) (selo de status por evento)

---

## Quando usar

- Histórico/trilha de auditoria de uma operação (aprovações, envios, liquidação) em ordem
  cronológica, com indicação visual de qual etapa já concluiu, qual está em andamento e
  quais ainda estão pendentes.
- Detalhe de uma solicitação/processo onde cada passo tem um responsável (`actor`) e uma
  descrição textual da ação (`action`).

## Quando **não** usar

- Progresso de um fluxo/wizard controlado pelo próprio usuário (etapas de cadastro,
  onboarding) → use `Stepper`/`MobileStepper`, não `AuditLine` (que é só leitura/histórico).
- Lista de documentos ou permissões → [`DocumentRow`](./DocumentRow.md) /
  [`PermissionRow`](./PermissionRow.md).
- Necessidade de itens clicáveis/expansíveis → `AuditLine` não expõe `onPress` por item;
  é puramente informativo.

---

## Interface

```ts
import type { ComponentPropsWithoutRef } from 'react';
import type { TagVariant } from '../DataDisplay/Tag';

type AuditLineState = 'done' | 'active' | 'pending';

interface AuditLineTag {
  variant: TagVariant;   // variante visual do Tag de status
  label: string;         // texto do Tag
}

interface AuditLineItem {
  id: string | number;   // identificador único — usado como key
  timestamp: string;     // carimbo de tempo exibido acima do evento
  actor: string;         // quem realizou a ação
  action: string;        // descrição da ação realizada
  state: AuditLineState;  // estágio do passo na linha do tempo
  tag?: AuditLineTag;     // Tag opcional de status, exibida ao lado da ação
}

interface AuditLineProps extends Omit<ComponentPropsWithoutRef<'ol'>, 'children'> {
  items: readonly AuditLineItem[]; // eventos, na ordem de exibição
  // Herdado de ComponentPropsWithoutRef<'ol'> (exceto children): id, className, aria-*, ...
}
```

### Notas de comportamento

- A raiz é um `<ol>` semântico; cada evento é um `<li data-state={item.state}>` — a ordem do
  array `items` é a ordem de renderização (o componente não ordena por timestamp).
- O marcador visual (`dot` + `connector`) é `aria-hidden="true"` — puramente decorativo; o
  último item não recebe `connector` (linha que liga ao próximo passo).
- `tag` é renderizado só quando presente no item; itens sem `tag` simplesmente não têm selo
  ao lado da ação — não há placeholder vazio reservando espaço (diferente do `ApprovalRow`).
- `state` só é exposto via atributo `data-state` no `<li>` — a cor/estilo do marcador por
  estágio (`done`/`active`/`pending`) vem do CSS Module, não de props adicionais.
- `key` de cada item vem de `item.id` — precisa ser único e estável entre renders.

---

## Exemplos

```tsx
import { AuditLine } from '@srm/diamond';
import type { AuditLineItem } from '@srm/diamond';

const ITEMS: AuditLineItem[] = [
  { id: 1, timestamp: '30/06 14:32', actor: 'Ana Souza', action: 'aprovou a operação', state: 'done', tag: { variant: 'success', label: 'Aprovado' } },
  { id: 2, timestamp: '30/06 14:20', actor: 'Carlos Lima', action: 'enviou para análise', state: 'done' },
  { id: 3, timestamp: 'agora', actor: 'Sistema', action: 'aguardando liquidação', state: 'active' },
  { id: 4, timestamp: '—', actor: 'Custódia', action: 'liquidação', state: 'pending' },
];

// Básico, com rótulo acessível na lista
<AuditLine items={ITEMS} aria-label="Trilha de auditoria" />

// Sem Tags de status (só o texto da ação)
<AuditLine items={ITEMS.map(({ tag, ...rest }) => rest)} />
```

---

## Acessibilidade

- Use `<ol>`/`<li>` (já garantido pelo componente) para que leitores de tela anunciem
  "lista, N itens" e a posição de cada item — prefira passar `aria-label` descritivo
  (ex.: `"Trilha de auditoria"`) via `{...rest}` quando houver mais de uma lista na página.
- O marcador visual (`dot`/`connector`) é `aria-hidden`; a informação de estágio (`state`)
  não é anunciada por texto — se o estágio for informação crítica além da cor/posição do
  marcador, inclua-o no próprio `action` ou em um `tag` textual.
- Cada evento já expõe texto (`timestamp`, `actor`, `action`) suficiente para leitura fora
  de contexto visual — evite `action` genérico demais (ex.: apenas "atualizou").

## Armadilhas comuns

- `items` não é reordenado pelo componente — se a origem dos dados não vier ordenada
  cronologicamente, ordene antes de passar para `AuditLine`.
- `id` duplicado ou instável entre renders quebra a identidade dos itens no React
  (`key={item.id}`) — gere IDs estáveis (ex.: ID do evento no backend, não índice do array).
- Omitir `tag` não reserva espaço — se a consistência visual entre linhas com/sem Tag for
  importante, decida isso no nível dos dados (todas com Tag ou nenhuma), não no componente.
- `state` fora do enum (`'done' | 'active' | 'pending'`) não é aceito pelo TypeScript — não
  há fallback visual para valores inválidos.
