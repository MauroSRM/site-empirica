# Icon

Glifo [lucide-react](https://lucide.dev) opcionalmente envolto em um badge circular colorido.
Cobre dois usos: **feedback** (`success` / `error` / `warning` / `info`, com glifo fixo por
semântica) e **livre** (`default` / `accent` / `neutral`, escolhendo qualquer glifo do catálogo
interno via prop `icon`). Em qualquer `type` — inclusive feedback — a prop `icon` **sobrepõe** o
glifo mantendo a cor semântica do `type`; é assim que `KPICard` usa um ícone temático (`wallet`,
`piggy-bank`, ...) com a cor de um `variant` de feedback. Por padrão é decorativo
(`aria-hidden="true"`); vira semântico (`role="img"`) com `decorative={false}` ou `aria-label`.

- **Categoria:** Icons
- **Fonte:** `src/components/Icons/Icon/`
- **Export:** `import { Icon } from '@srm/diamond';`
- **Relacionados:** usado internamente por `KPICard`, `TrendIndicator`, `RequirementsChecklist`,
  `Tag`, `Callout` e outros componentes de feedback/dado; para ação clicável só-ícone use
  `IconButton` (Forms).

---

## Quando usar

- Indicar o estado semântico de um bloco (alerta, mensagem de sucesso/erro, banner informativo)
  com `type="success" | "error" | "warning" | "info"`.
- Ilustrar um item de lista, card, KPI ou cabeçalho de seção com um glifo do catálogo
  (`type="default" | "accent" | "neutral"` + `icon="wallet"`, `icon="piggy-bank"` etc.).
- Reaproveitar a cor de um estado de feedback com um glifo customizado (`type="success"
  icon="wallet"`) — o `icon` troca só o desenho, a cor semântica do `type` é preservada.
- Compor com texto ao lado (o ícone é decorativo por padrão — não deve ser o único portador da
  informação, exceto quando explicitamente marcado como semântico via `decorative={false}` /
  `aria-label`).

## Quando **não** usar

- Ícone clicável/interativo (botão só-ícone) → use `IconButton`, que já cuida de foco,
  `aria-label` e estado de pressed.
- Ícone dentro de um `Button` (`icon="left"`/`icon="right"`/`icon="only"`) → passe o glifo direto
  via prop `iconEl` do `Button`; não envolva em `Icon`.
- Necessidade de um glifo fora do catálogo (`ICON_GLYPH_NAMES`) → importe o ícone do
  `lucide-react` diretamente (o componente é uma camada de estilo/tamanho/cor sobre um subconjunto
  curado).

---

## Interface

```ts
type IconType = 'success' | 'error' | 'warning' | 'info' | 'default' | 'accent' | 'neutral';

/** sm 18 · md 24 · lg 32 · xl 40 · 2xl 56 (px do glifo, não do círculo). */
type IconSize = 'sm' | 'md' | 'lg' | 'xl' | '2xl';

type IconTint = 'chip' | 'well';

interface IconProps {
  type?: IconType;                // default: 'default'
  circle?: boolean;                // fundo circular com tint da cor semântica; default: true
  tint?: IconTint;                 // 'chip' sobre surface neutra · 'well' dentro de container de feedback; default: 'chip'
  size?: IconSize | number;        // preset ou px arbitrário do glifo; default: 'md'
  circleSize?: number;             // override do diâmetro do círculo (px); só com circle=true; default: round(glyphSize / 0.46)
  icon?: string;                   // nome do glifo (ver ICON_GLYPH_NAMES); sobrepõe o glifo em QUALQUER type
  strokeWidth?: number;            // default: 2
  spin?: boolean;                  // animação de rotação contínua (loading spinners); default: false
  decorative?: boolean;            // false → role="img" em vez de aria-hidden; default: true
  'aria-label'?: string;           // presente → torna o ícone semântico, sobrepondo `decorative`
  'aria-hidden'?: boolean | 'true' | 'false'; // valor usado no modo decorativo; default: true
  className?: string;
}
```

### Notas de comportamento

- **`type` define a cor; `icon` define o glifo — são eixos independentes.** Sem `icon`, os tipos
  de feedback (`success`/`error`/`warning`/`info`) usam seu glifo semântico fixo
  (`CheckCircle2`/`AlertCircle`/`AlertTriangle`/`Info`). Com `icon`, **qualquer** `type` (inclusive
  feedback) troca o desenho para `ICON_MAP[icon]`, mantendo a cor do `type` — é o contrato usado
  por `KPICard` (`<Icon type={iconType} icon={iconName} .../>` onde `iconType` pode ser um
  variant de feedback como `'error'` e `iconName` um glifo temático como `'wallet'`).
- Sem `icon` e com `type="default" | "accent" | "neutral"` (os três tipos **não-semânticos**), o
  glifo cai no fallback `ICON_MAP.info` (o mesmo desenho do `Info` do feedback) — ou seja, esses
  três `type`s **sempre precisam de `icon`** na prática; sem ele o resultado visual é um ícone de
  informação genérico, provavelmente não intencional.
- `type="neutral"` é o terceiro tipo não-semântico (junto de `default`/`accent`): usa `ICON_MAP`
  como os outros dois, **não** é tratado como feedback. `KPICard` o deriva de um variant `'info'`
  (`iconType = variant === 'info' ? 'neutral' : variant`) para diferenciar "estado neutro" de
  "feedback informativo azul".
- `ICON_MAP` é um subconjunto curado (~90 glifos) do catálogo `lucide-react` + ícones de marca
  (`brandIcons`, ex. `'pix'`), com chaves em kebab-case: `'chevron-right'`, `'check'`, `'search'`,
  `'wallet'`, `'piggy-bank'`, `'credit-card'`, `'trending-up'`, `'shield-check'`, `'receipt'`,
  `'dollar-sign'`, `'bar-chart'`, `'pie-chart'`, `'pix'`, entre outros (`ICON_GLYPH_NAMES` exporta
  a lista completa ordenada). Um `icon` não encontrado no mapa cai no fallback `Info`.
- `size` mapeia para px do **glifo**: `sm=18 · md=24 · lg=32 · xl=40 · 2xl=56`. Também aceita um
  `number` arbitrário em px.
- Quando `circle=true` (default), o diâmetro do círculo é derivado do tamanho do glifo:
  `circleSize = Math.round(glyphSize / 0.46)` — o glifo ocupa ~46% do diâmetro. `circleSize` é uma
  prop de **override explícito** desse valor derivado; sem efeito quando `circle=false`.
- `tint` só faz sentido com `circle=true` e tem exatamente dois valores: `'chip'` (bg sutil sobre
  superfície neutra — default) e `'well'` (bg mais saturado, para uso dentro de um container já
  colorido de feedback, ex. dentro de um `Callout`). Não existe mais um terceiro valor `'surface'`
  (removido — era classe morta).
- Cores por `type` (CSS Modules, tokens do tema): `success` → `--success-default`; `error` →
  `--error-strong`; `warning` → `--warning-strong`; `info` → `--feedback-info`; `default` →
  `--text-brand`; `accent` → `--brand-accent`; `neutral` → `--text-secondary`. Os bgs de
  `tint="chip"`/`tint="well"` variam por `type` via `--feedback-chip-*` / `--feedback-tint-*`
  (ex.: `neutral` usa `--surface-muted` no chip e `--feedback-tint-neutral` no well).
- Quando `circle=false`, o ícone é renderizado "bare" (`<span>` inline, sem fundo nem padding) — só
  o glifo, na cor do `type`, herdando `currentColor` do pai quando aplicável.
- `strokeWidth` (default `2`) e `spin` (default `false`, animação de rotação contínua respeitando
  `prefers-reduced-motion: reduce`) são configuráveis via prop.
- **Acessibilidade é controlada por dois eixos combinados**: `decorative` (default `true`) e
  `aria-label`. O ícone fica semântico (`role="img"`) quando `decorative={false}` **ou** quando
  `aria-label` é fornecido (isso sobrepõe `decorative`, mesmo que ele não tenha sido setado para
  `false`). Caso contrário permanece decorativo, com `aria-hidden={ariaHiddenProp ?? true}`.

---

## Exemplos

```tsx
import { Icon } from '@srm/diamond';

// Feedback — glifo fixo por semântica
<Icon type="success" />
<Icon type="error" />
<Icon type="warning" />
<Icon type="info" />

// Feedback com glifo customizado — icon sobrepõe o desenho, mantém a cor do type
<Icon type="error" icon="wallet" tint="well" />

// Livre — tipos não-semânticos, sempre com icon explícito
<Icon type="default" icon="wallet" />
<Icon type="accent" icon="piggy-bank" />
<Icon type="neutral" icon="layers" />

// Tamanhos
<Icon type="info" size="sm" />
<Icon type="info" size="2xl" />
<Icon type="default" icon="star" size={64} /> {/* px arbitrário */}

// Override do diâmetro do círculo, independente do size do glifo
<Icon type="default" icon="wallet" size="md" circleSize={36} />

// Sem círculo (glifo puro, sem badge)
<Icon type="success" circle={false} />
<Icon type="default" icon="credit-card" circle={false} />

// Loading spinner
<Icon type="info" icon="loader-circle" spin />

// Semântico: decorative=false (sem aria-label — cuidado, ver Armadilhas)
<Icon type="info" decorative={false} />

// Semântico: aria-label sobrepõe o modo decorativo
<Icon type="error" aria-label="Erro no formulário" />

// Composição real: banner de feedback com texto ao lado (ícone decorativo)
function ErrorBanner({ message }: { message: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <Icon type="error" size="sm" />
      <span>{message}</span>
    </div>
  );
}
```

### Uso real no design system — `KPICard`

```tsx
// src/components/Cards/KPICard/KPICard.tsx
const iconType = variant === 'info' ? 'neutral' : variant;

<Icon type={iconType} circle tint="chip" icon={iconName} size={ICON_SIZE} circleSize={36} />
```

---

## Acessibilidade

- **Default (`decorative={true}`, sem `aria-label`)**: `aria-hidden="true"`, sem `role` — nunca use
  `Icon` isolado como único portador de uma informação nesse modo; sempre acompanhe de texto
  visível ou garanta que o elemento pai (`button`, `link`) tenha nome acessível próprio.
- **Semântico (`decorative={false}` ou `aria-label` definido)**: `role="img"` + `aria-label`
  (quando fornecido). Use quando o glifo **é** a informação (ex.: ícone de status isolado em uma
  célula de tabela, sem texto ao lado).
- Em banners/alertas de feedback, o glifo reforça visualmente o `type`, mas a semântica de
  "erro"/"sucesso" deve estar no texto (ou em `role="alert"`/`aria-live` no container), não
  apenas no ícone.

## Armadilhas comuns

- Usar `type="default" | "accent" | "neutral"` **sem** `icon` — cai silenciosamente no glifo
  genérico `Info`, quase nunca o resultado desejado. Sempre passe `icon` com esses três `type`s.
- Assumir que `icon` só funciona em `type="default"/"accent"` (comportamento antigo) — hoje `icon`
  sobrepõe o glifo em **qualquer** `type`, inclusive feedback, mantendo a cor semântica.
- Passar `decorative={false}` sem `aria-label` — o ícone fica `role="img"` mas **sem nome
  acessível** (leitor de tela anuncia "imagem" sem descrição). Sempre acompanhe `decorative={false}`
  de um `aria-label`, ou simplesmente use `aria-label` isolado (já implica semântico).
- Usar um nome fora de `ICON_GLYPH_NAMES` (ex.: PascalCase do lucide, como `"Wallet"`) — o mapa
  espera **kebab-case** (`"wallet"`); nomes não encontrados caem no fallback `Info`.
- Tentar usar `tint="surface"` — removido; os únicos valores válidos são `'chip'` e `'well'`.
- Ajustar `circleSize` esperando que o glifo acompanhe — não acompanha; `circleSize` só redimensiona
  o **círculo**, o `size` do glifo é independente.
- Usar `Icon` como botão (envolvendo em `onClick`) — o elemento raiz não tem semântica de botão nem
  foco por padrão; use `IconButton` para ícones clicáveis.
