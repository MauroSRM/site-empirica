# IaSRMChatEmbed

Container do slot `embed` de um [`IaSRMChatBubble`](./IaSRMChatBubble.md) (`type='iaSRM'`).
Intencionalmente mínimo: só o shell — borda, radius, background, overflow e margin-top.
Sem header, footer, estado ou layout interno prescritos.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMChatEmbed/`
- **Export:** `import { IaSRMChatEmbed } from '@srm/diamond';`
- **Relacionados:** [IaSRMChatBubble](./IaSRMChatBubble.md) (host via prop `embed`), [Card](../Cards/Card.md) (card de página, não de bolha), [OTPInput](../Forms/Inputs/OTPInput.md) e [Button](../Forms/Button.md) (átomos comuns no miolo)

---

## Por que existe

Para sair do chat convencional. Cada resposta do assistente pode virar um **card visual**
— confirmação de pagamento, OTP, comprovante, upload, chart, tabs — sem que o DS engesse
o formato. Quem compõe o miolo é UX + Dev, combinando átomos do DS. O container não
decide layout interno.

> **Regra mental:** se o miolo é só texto, use `IaSRMChatBubble.main`/`.text`/`.hint`.
> `IaSRMChatEmbed` é para respostas que se beneficiam de forma visual.

---

## Quando usar

- Sempre dentro de `IaSRMChatBubble` via prop `embed`.
- Quando a resposta pede ações, campos ou dados estruturados (lista de detalhes, preview, gráfico).

## Quando **não** usar

- Solto na página — não é um card de layout; use [`Card`](../Cards/Card.md).
- Para bloco de texto simples → props de texto do `IaSRMChatBubble`.
- Para componentes largos (`Table`, `Modal`, `Drawer`) — a bolha tem largura máxima.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactNode, Ref } from 'react';

interface IaSRMChatEmbedProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  children: ReactNode;
  ref?: Ref<HTMLDivElement>;
  // + atributos nativos de <div>: id, className, role, aria-*, data-*, …
}
```

### Notas de comportamento

- Não aplica **padding** de propósito: permite imagem ou faixa full-bleed no topo. Defina o padding no seu próprio wrapper interno.
- `className` é aplicada **por último** — dá para sobrescrever a borda (ex.: borda de sucesso) sem fork.
- Aceita `...rest`, então `role="group"` + `aria-label` são possíveis quando o embed forma uma unidade semântica.
- O que o container garante:

| Aspecto | Como |
|---|---|
| Borda | `var(--border-width-sm) solid var(--border-default)` |
| Radius | `var(--radius-lg)` |
| Background | `var(--surface-default)` |
| Overflow | `hidden` (clipa full-bleed) |
| Spacing pré-card | `margin-top: var(--space-3)` |
| Tipografia base | `font-family: var(--font-sans)` |

Todo o resto (padding, layout, header, ações, estados) é do consumidor.

---

## Eventos: quem emite é o seu miolo

O container é puro e **não** tem callbacks. Os controles que você põe dentro precisam
emitir o que o usuário fez, **com os dados** — é o contrato que permite tratar a
interação na aplicação. As receitas de referência em
`IaSRMChatEmbed.examples.tsx` seguem isso:

| Receita | Emite |
|---|---|
| `ChatConfirmCard` | `onConfirm()`, `onCancel()` |
| `ChatOTP` | `onChange(code)`, `onComplete(code)`, `onConfirm(code)`, `onResend()` |
| `ChatTransactionPin` | `onChange(pin)`, `onConfirm(pin)` |
| `ChatReceipt` | `onDownload()` |
| `ChatUploadCard` | `onFiles(files)` |

Note que OTP e PIN **entregam o código digitado** — sem isso o consumidor receberia um
clique sem saber o que validar. Use isso como referência ao montar seus próprios embeds.

> As receitas vivem em `IaSRMChatEmbed.examples.tsx`, **não são exportadas do index** e
> podem mudar sem aviso. São ponto de partida, não API pública.

---

## Exemplos

```tsx
import { IaSRMChatBubble, IaSRMChatEmbed } from '@srm/diamond';

// Composição livre com átomos do DS
<IaSRMChatBubble
  main="Confirme o pagamento"
  embed={
    <IaSRMChatEmbed>
      <MeuHeader />
      <MeuMiolo />
      <MinhasAcoes onConfirm={confirm} onCancel={cancel} />
    </IaSRMChatEmbed>
  }
/>

// Padding no seu wrapper (o container não aplica)
<IaSRMChatEmbed>
  <img src={preview} alt="" style={{ width: '100%' }} />
  <div style={{ padding: 'var(--space-4)' }}>
    <p>Comprovante gerado.</p>
  </div>
</IaSRMChatEmbed>

// Override de borda por estado
<IaSRMChatEmbed className={styles.bordaSucesso}>…</IaSRMChatEmbed>

// Unidade semântica para leitor de tela
<IaSRMChatEmbed role="group" aria-label="Comprovante de TED">…</IaSRMChatEmbed>

// Embed que emite o que foi digitado
<IaSRMChatEmbed>
  <OTPInput length={6} value={code} onChange={setCode} />
  <Button isDisabled={code.length < 6} onPress={() => verify(code)}>Verificar</Button>
</IaSRMChatEmbed>
```

---

## Acessibilidade

- O container é um `div` neutro sem role — correto, porque o significado está no miolo.
- Quando o embed forma uma unidade (comprovante, formulário), passe `role="group"` + `aria-label`.
- Cada controle interno é responsável pelo próprio nome acessível: a bolha e o container não os descrevem.
- Só **uma** ação primária por card, para não competir visualmente nem confundir a ordem de foco.

## Armadilhas comuns

- Não use fora de `IaSRMChatBubble`.
- Não espere padding do container — é ausente de propósito.
- Não hardcode cor, borda ou radius no miolo; use tokens.
- **Não deixe controles internos sem callback com dados.** Um botão "Verificar" que não entrega o código digitado é inútil para o consumidor — foi exatamente o bug corrigido nas receitas de OTP e PIN.
- Não trate as receitas de `*.examples.tsx` como API pública.
