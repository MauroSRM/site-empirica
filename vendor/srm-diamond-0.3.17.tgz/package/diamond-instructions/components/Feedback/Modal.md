# Modal

Shell mínimo de modal/diálogo: overlay + painel branco, sem título, ícone, corpo ou
footer fixos — o consumidor compõe livremente dentro de `children` usando os átomos
do DS (`Icon`, `IconButton`, `Callout`, `Button`, `Heading`). Todo o comportamento
(focus trap, fechamento por `Escape`, `aria-modal`, dismiss ao clicar fora, animação
de entrada/saída) vem de `ModalOverlay` + `Modal` + `Dialog` do `react-aria-components`
— nada disso é reimplementado à mão.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Modal/`
- **Export:** `import { Modal } from '@srm/diamond';`
- **Relacionados:** `ContentModal` (preset pronto de header + corpo + footer, componente
  irmão em `src/components/Feedback/ContentModal/`, fora do escopo deste doc)

---

## Quando usar

- Precisa de um diálogo modal genérico e quer compor o conteúdo (título, corpo, ações)
  livremente, sem se prender a um layout fixo de header/footer.
- Fluxos internos de composição — por exemplo, montar variações visuais próprias
  (confirmação, alerta, formulário curto) reaproveitando `Icon`/`Callout`/`Button` do DS.
- Base para construir presets próprios quando `ContentModal` não atende o layout desejado.

## Quando **não** usar

- Precisa de um modal de confirmação/alerta com header + ícone + corpo + footer já
  prontos, seguindo o padrão visual do DS → use `ContentModal`.
- Mensagem inline, não bloqueante, dentro do fluxo da página → use `Callout` ou `Toast`,
  não um modal.
- Menu contextual/popover de escolha rápida → use `Popover`/`Menu` do DS, não `Modal`.

---

## Interface

```ts
import type { ReactNode } from 'react';

type ModalSize = 'sm' | 'md' | 'lg';

interface ModalProps {
  isOpen: boolean;                 // controla montagem/exibição do overlay+painel
  onClose: () => void;             // chamado quando o modal deve fechar (Escape, clique fora, X custom)
  size?: ModalSize;                // default: 'md'
  dismissible?: boolean;           // default: true
  ariaLabel?: string;              // default: 'Modal'
  children?: ReactNode;
}
```

### Notas de comportamento

- **Controlado por `isOpen`**: com `isOpen={false}`, nada é renderizado no DOM (nenhum
  `role="dialog"`) — não é apenas `display: none`.
- **`onClose`**: o próprio componente não fecha nada sozinho; ele delega a decisão de
  "deveria fechar" ao `ModalOverlay` (via `onOpenChange`) e chama seu `onClose` quando
  `open` vira `false`. Cabe a **você** atualizar o estado que controla `isOpen`.
- **`dismissible` (default `true`)** controla **duas coisas ao mesmo tempo**:
  `isDismissable` (clique fora fecha) e `isKeyboardDismissDisabled` (tecla `Escape`
  fecha). Com `dismissible={false}`, nem clique fora nem `Escape` fecham o modal —
  só uma ação explícita dentro de `children` (ex.: um `Button` chamando `onClose`) o faz.
  Use isso para fluxos que exigem uma decisão explícita do usuário (ex.: confirmação
  de operação financeira irreversível).
- **`size`** apenas troca a largura do painel via CVA (`modalPanelVariants`):
  `sm` → `400px`, `md` → `var(--modal-width)` (token do tema), `lg` → `720px`. Em todos
  os tamanhos, `max-width: calc(100vw - 32px)` garante respiro em telas pequenas.
- **`ariaLabel` (default `'Modal'`)**: nome acessível do `Dialog`. Como o componente
  **não** renderiza um título fixo, se o seu `children` não incluir um
  `<Heading slot="title">` visível, forneça um `ariaLabel` descritivo — senão leitores
  de tela anunciarão apenas "Modal".
- **Sem header/body/footer prontos**: diferente de `ContentModal`, este componente não
  tem noção de variante semântica (`success`/`warning`/`error`/...) nem exibe ícone,
  título ou botões de ação automaticamente — não há prop de `variant`, e não existem
  mais constantes/tipos de variante associados a este módulo (foram removidos do
  refactor); qualquer preset visual desse tipo vive só em `ContentModal`.
- **Animações**: entrada/saída do overlay (fade) e do painel (fade + scale) são
  puramente CSS via atributos de estado do react-aria (`data-entering`/`data-exiting`),
  e são desligadas automaticamente em `prefers-reduced-motion: reduce`.
- **Overlay**: cobre a viewport inteira (`position: fixed; inset: 0`), com
  `backdrop-filter: blur(2px)` e `z-index: var(--z-modal)`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { Modal, Button, Icon } from '@srm/diamond';

// Básico — composição livre no children
function ExemploBasico() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onPress={() => setIsOpen(true)}>Abrir modal</Button>
      <Modal isOpen={isOpen} onClose={() => setIsOpen(false)} ariaLabel="Detalhes da operação">
        <h2>Detalhes da operação</h2>
        <p>Conteúdo livre aqui — texto, formulário, tabela, o que precisar.</p>
        <Button onPress={() => setIsOpen(false)}>Fechar</Button>
      </Modal>
    </>
  );
}

// Tamanho pequeno
<Modal isOpen={isOpen} onClose={onClose} size="sm" ariaLabel="Confirmação">
  <p>Deseja continuar?</p>
</Modal>

// Tamanho grande, para conteúdo denso (tabela, formulário longo)
<Modal isOpen={isOpen} onClose={onClose} size="lg" ariaLabel="Editar carteira">
  <FormularioLongo />
</Modal>

// Não-dismissível — só fecha por ação explícita (ex.: confirmação de resgate)
function ConfirmacaoResgate({ isOpen, onClose, onConfirm }: Props) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} dismissible={false} ariaLabel="Confirmar resgate">
      <h2>Confirmar resgate</h2>
      <p>Esta ação não pode ser desfeita. Deseja prosseguir com o resgate de R$ 10.000,00?</p>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
        <Button variant="ghost" onPress={onClose}>Cancelar</Button>
        <Button variant="destructive" onPress={onConfirm}>Confirmar resgate</Button>
      </div>
    </Modal>
  );
}

// Composição com Heading nomeado por slot (dispensa ariaLabel custom)
import { Heading } from 'react-aria-components';

<Modal isOpen={isOpen} onClose={onClose}>
  <Heading slot="title">Atualizar cadastro</Heading>
  <p>Revise os dados antes de salvar.</p>
</Modal>
```

---

## Acessibilidade

- O painel é exposto como `role="dialog"` (via `Dialog` do react-aria) somente quando
  `isOpen` é `true` — verificável em testes por `getByRole('dialog')`.
- Foco é automaticamente preso dentro do modal (focus trap) e devolvido ao elemento que
  o abriu quando ele fecha — comportamento herdado do react-aria, não precisa de código
  adicional.
- `Escape` fecha o modal por padrão (`dismissible=true`); com `dismissible={false}`,
  garanta que `children` ofereça uma forma explícita e clara de fechar (botão de
  cancelar/fechar visível), já que o usuário perde os dois atalhos costumeiros.
- Sempre defina um nome acessível: ou via `ariaLabel` descritivo, ou incluindo um
  `<Heading slot="title">` visível dentro de `children`. Não deixe o default genérico
  `'Modal'` em produção.

## Armadilhas comuns

- Achar que `Modal` sozinho fecha ao clicar em algum botão interno — ele **não** tem
  lógica de fechamento própria além do que o react-aria já oferece (clique fora/Escape);
  qualquer botão de "fechar"/"cancelar" dentro de `children` precisa chamar `onClose`
  (ou a função equivalente) explicitamente.
- Esperar título, ícone ou footer automáticos — este componente é só o **shell**; para
  o preset visual completo (ícone por variante, título e corpo padrão, footer com
  botões), use `ContentModal`.
- Passar uma prop `variant` esperando trocar cor/ícone — `ModalProps` **não tem** essa
  prop; não há mais tipo/constantes de variante neste módulo (foram removidos), então
  não há nada equivalente para importar aqui.
- Deixar `dismissible={false}` sem nenhum controle de fechamento visível em `children`
  — o usuário fica preso no modal sem saída aparente.
- Não sincronizar `isOpen` com estado externo (ex.: renderizar condicionalmente o
  próprio `<Modal>` no lugar de controlar `isOpen`) — prefira sempre manter o `Modal`
  montado e alternar `isOpen`, deixando a montagem/desmontagem do `role="dialog"` a
  cargo do próprio componente (assim as animações de entrada/saída funcionam).
