# NavBalanceChip

Chip de saldo exibido tipicamente no `AppHeader`. Mostra um rótulo (default `"SALDO"`) e um
valor monetário livre (texto), com um botão de olho para alternar visibilidade (mascarar/revelar
o saldo). Quando `balance` está ausente, exibe um texto neutro (`emptyText`, default `"—"`) —
**nunca** um valor monetário forjado (ex.: `"R$ 0,00"`). Suporta modo **não-controlado**
(`defaultHidden`, estado interno) e modo **controlado** (`masked` + `onToggleVisibility`,
estado externo). Construído sobre `Button` do `react-aria-components` (para o toggle) e o
componente interno `Icon` (glifos `eye`/`eye-off`).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/NavBalanceChip/`
- **Export:** `import { NavBalanceChip } from '@srm/diamond';`
- **Relacionados:** usado dentro do `AppHeader` (área de saldo do usuário logado).

---

## Quando usar

- Exibir o saldo/patrimônio do cliente no cabeçalho do app, com opção de ocultar por privacidade
  (ex.: em ambientes compartilhados, apresentações de tela, home office).
- Cenários onde o valor precisa ficar visualmente mascarado sem desmontar o layout (o espaço
  ocupado pelo texto é preservado — apenas fica com `visibility: hidden` sob uma máscara visual).
- Cenários onde o saldo ainda não chegou (loading, erro, conta sem saldo) — omita `balance` e o
  chip exibe `emptyText` sem inventar um valor.
- Tanto sobre fundo escuro (`theme="dark"`, default, ex. header brand navy) quanto sobre fundo
  claro (`theme="light"`).

## Quando **não** usar

- Valores monetários **editáveis** em formulário → use `CurrencyInput`.
- Exibição de saldo sem necessidade de ocultar/revelar → um simples texto/label é suficiente,
  não force o uso deste chip.
- Múltiplos valores/saldos lado a lado com hierarquia complexa → componha vários `NavBalanceChip`
  ou avalie um componente de card dedicado.

---

## Interface

```ts
type NavBalanceChipTheme = 'light' | 'dark';

interface NavBalanceChipProps {
  balance?: string;                     // valor já formatado (texto livre, ex.: "R$ 1.245.860,32")
  emptyText?: string;                   // default: '—' — exibido quando balance está ausente
  label?: string;                       // default: 'SALDO'
  theme?: NavBalanceChipTheme;          // default: 'dark'
  defaultHidden?: boolean;              // default: false — estado inicial (modo não-controlado)
  masked?: boolean;                     // modo controlado — quando definido, substitui o estado interno
  onToggleVisibility?: () => void;      // chamado ao clicar no botão de olho
  showBalanceLabel?: string;            // aria-label do toggle quando oculto. default: 'Exibir saldo'
  hideBalanceLabel?: string;            // aria-label do toggle quando visível. default: 'Ocultar saldo'
}
```

### Notas de comportamento

- **Não há herança de `InputBaseProps`** — este não é um Input, é um componente de exibição.
- `balance` é **texto livre**: o componente não formata nem valida o valor. Formate o valor
  como string antes de passar (ex.: `"R$ 1.245.860,32"`).
- **`balance` ausente → `emptyText`, nunca um valor forjado.** Quando `balance` é `undefined`,
  o componente renderiza `emptyText` (default `"—"`) no lugar do valor. Isso é deliberado: o
  componente nunca exibe algo como `"R$ 0,00"` para representar "sem dado" — essa ambiguidade
  (saldo zero real vs. dado ausente/carregando) é resolvida explicitamente por `emptyText`.
- `label` agora tem um default **neutro** (`"SALDO"`), sem a marca embutida (`"SALDO SRM"` na
  versão anterior) — passe `label="SALDO SRM"` explicitamente se precisar do texto de marca.
- **Modo controlado vs. não-controlado**: se `masked` for passado (mesmo `false`), o componente
  entra em modo controlado — o estado interno (`useState`) é ignorado e a visibilidade passa a
  depender inteiramente da prop `masked`. Nesse modo, `onToggleVisibility` é responsável por
  atualizar `masked` externamente; o componente **não** alterna o próprio estado.
  ```ts
  const isControlled = masked !== undefined;
  const isHidden = isControlled ? masked : hidden;
  ```
- No modo **não-controlado** (`masked` omitido), o clique no olho alterna um estado interno
  iniciado por `defaultHidden`, e `onToggleVisibility` (se fornecido) é chamado apenas como
  notificação — sem precisar gerenciar estado externo.
- Quando oculto (`isHidden`), o texto do saldo/`emptyText` recebe `visibility: hidden` (não
  `display: none`), preservando o espaço ocupado, e uma máscara visual (`balanceMask`, um
  retângulo sólido) é sobreposta por cima via `position: absolute`.
- O ícone do botão alterna automaticamente: `EyeOff` quando oculto, `Eye` quando visível — e o
  `aria-label` do botão troca entre `showBalanceLabel` (default `"Exibir saldo"`) e
  `hideBalanceLabel` (default `"Ocultar saldo"`) de acordo com o estado. Os textos são
  sobrescrevíveis via props — útil para i18n.
- `theme="dark"` (default) usa fundo semitransparente branco (`--white-a08`) e texto do saldo em
  `--surface-default`; `theme="light"` usa fundo `--surface-default` e texto em `--text-primary`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { NavBalanceChip } from '@srm/diamond';

// Básico — não-controlado, tema escuro (uso típico em AppHeader)
<NavBalanceChip
  label="SALDO SRM"
  balance="R$ 1.245.860,32"
  theme="dark"
/>

// Sem saldo disponível (loading/erro) — exibe emptyText, nunca "R$ 0,00"
<NavBalanceChip label="SALDO SRM" />

// emptyText customizado
<NavBalanceChip label="SALDO SRM" emptyText="Indisponível" />

// Iniciando já oculto (não-controlado)
<NavBalanceChip
  label="SALDO SRM"
  balance="R$ 1.245.860,32"
  defaultHidden
/>

// Tema claro
<NavBalanceChip
  label="Saldo disponível"
  balance="R$ 890.400,00"
  theme="light"
/>

// Controlado — estado de visibilidade gerenciado externamente
// (ex.: para sincronizar com preferência do usuário salva em outro lugar)
function ControlledBalance() {
  const [masked, setMasked] = useState(false);

  return (
    <NavBalanceChip
      label="SALDO SRM"
      balance="R$ 1.245.860,32"
      masked={masked}
      onToggleVisibility={() => setMasked((m) => !m)}
    />
  );
}

// Labels de acessibilidade customizados (i18n)
<NavBalanceChip
  balance="R$ 1.245.860,32"
  showBalanceLabel="Show balance"
  hideBalanceLabel="Hide balance"
/>
```

> Não é um campo de formulário — não há integração com React Hook Form.

---

## Acessibilidade

- O botão de alternância já recebe `aria-label` dinâmico (`showBalanceLabel`/`hideBalanceLabel`,
  customizáveis via props) — não é necessário compor manualmente o rótulo por estado.
- Os ícones (`eye`/`eye-off`, via `Icon`) são visuais; o nome acessível do botão vem do
  `aria-label`, não do ícone.
- O botão é um `Button` do `react-aria-components`, portanto já cobre ativação por teclado
  (Enter/Espaço) e foco visível.
- O rótulo (`label`) e o valor (`balance`/`emptyText`) são apenas texto visual — se precisar de
  um nome acessível para o chip como um todo (ex.: leitores de tela anunciando o grupo), envolva-o
  externamente com `aria-label`/`role` conforme o contexto de uso.

## Armadilhas comuns

- Passar `masked={false}` sem `onToggleVisibility` trava o componente em modo controlado, mas
  o clique no olho não fará nada visível — o `handleToggle` chama `onToggleVisibility?.()` e,
  por estar em modo controlado, **não** atualiza o estado interno. Sempre implemente
  `onToggleVisibility` quando usar `masked`.
- Confundir `defaultHidden` (modo não-controlado, aplicado só na montagem) com `masked` (modo
  controlado, aplicado a cada render). Misturar os dois é inútil — se `masked` está definido,
  `defaultHidden` é ignorado.
- Esperar que `balance` aceite `number` — a prop é `string`; formate o valor antes (moeda,
  separadores) já que o componente não aplica máscara nenhuma.
- Forjar um valor (ex.: passar `balance="R$ 0,00"`) para representar "sem dado" — isso é
  ambíguo com saldo zero real. Omita `balance` e use/customize `emptyText` para esse caso.
- Assumir que `label` ainda tem a marca embutida (`"SALDO SRM"`) por default — agora o default é
  neutro (`"SALDO"`); passe o texto de marca explicitamente quando precisar dele.
- Usar este componente para saldo **editável** — ele não tem campo de input; é somente exibição
  com toggle de visibilidade.
