# Checkbox

Caixa de seleção binária (ou tri-estado via `isIndeterminate`) com rótulo opcional embutido,
dois tamanhos e tema claro/escuro. Construída sobre `CheckboxField` + `CheckboxButton` do
`react-aria-components`, com ícones `Check`/`Minus` (lucide-react) desenhados via CSS Module
(sem `<input type="checkbox">` estilizado diretamente — o input nativo fica visualmente oculto
e acessível). Exporta também `CheckboxGroup`, o agregador de múltiplos `Checkbox` por `value`,
construído sobre `CheckboxGroup` do `react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Checkbox/`
- **Export:** `import { Checkbox, CheckboxGroup } from '@srm/diamond';`
- **Relacionados:** [RadioGroup](./RadioGroup.md) (seleção única exclusiva), [Switch](./Switch.md) (toggle on/off imediato), [MultiSelect](./MultiSelect.md) (seleção múltipla em dropdown, para listas longas)

---

## Quando usar

- Aceite de termos, políticas ou consentimentos (ex.: "Aceito os termos de uso").
- Seleção múltipla e independente de opções (produtos de interesse: FIDC, CRI, Debêntures).
- Estado tri-estado (`isIndeterminate`) para representar "seleção parcial" em uma lista
  hierárquica (ex.: "selecionar todos" quando só parte dos itens filhos está marcada).
- Agrupar várias opções relacionadas sob um único rótulo e uma única mensagem de erro/ajuda
  → use `CheckboxGroup` envolvendo vários `Checkbox` com `value`.

## Quando **não** usar

- Seleção única entre opções mutuamente exclusivas → [`RadioGroup`](./RadioGroup.md).
- Ação de ligar/desligar que produz efeito imediato (não é parte de um formulário submetido)
  → [`Switch`](./Switch.md).
- Um único checkbox solto para representar "ativo/inativo" de uma configuração instantânea
  → prefira `Switch`, que comunica melhor a semântica de toggle imediato.
- Seleção múltipla sobre uma lista **longa** (mais de ~8 opções), que exigiria rolagem ou
  busca para o usuário achar o item → [`MultiSelect`](./MultiSelect.md), que colapsa a lista
  num dropdown com busca, contador no gatilho e "selecionar todos"/"limpar".

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { CheckboxFieldProps as AriaCheckboxFieldProps } from 'react-aria-components';

type CheckboxSize = 'sm' | 'md';
type CheckboxTheme = 'default' | 'dark';

interface CheckboxProps extends Omit<AriaCheckboxFieldProps, 'className' | 'children'> {
  size?: CheckboxSize;        // default: 'md' — sm: box 16px · md: box 20px
  theme?: CheckboxTheme;      // default: 'default' — 'dark' aplica data-theme="dark"
  label?: ReactNode;          // rótulo (alternativa a `children`)
  children?: ReactNode;       // rótulo (tem prioridade sobre `label` quando ambos definidos)
  className?: string;         // aplicado ao CheckboxButton (não ao wrapper CheckboxField)
}
```

### Props herdadas de `AriaCheckboxFieldProps` (react-aria-components)

Passthrough direto — sem processamento adicional no componente Diamond:

| Prop              | Tipo                              | Descrição                                                             |
|-------------------|------------------------------------|------------------------------------------------------------------------|
| `isSelected`      | `boolean`                          | Modo controlado — quando definido, o Checkbox não alterna sozinho.    |
| `defaultSelected` | `boolean`                          | Estado inicial no modo não-controlado.                                |
| `isIndeterminate` | `boolean`                          | Estado tri-estado visual (ícone `Minus`); não afeta `isSelected`.     |
| `onChange`        | `(isSelected: boolean) => void`    | Chamado a cada alternância (clique ou tecla Espaço).                   |
| `isDisabled`      | `boolean`                          | Desabilita interação; aplica opacidade reduzida via `[data-disabled]`. |
| `isReadOnly`      | `boolean`                          | Bloqueia alternância mas mantém foco/leitura; `onChange` não dispara. |
| `isRequired`      | `boolean`                          | Marca o campo como obrigatório para validação.                        |
| `isInvalid`       | `boolean`                          | Aplica estilo de erro (`[data-invalid]`, borda vermelha).             |
| `value`           | `string`                           | Identificador usado quando o Checkbox está dentro de um `CheckboxGroup`. |
| `name`, `form`    | `string`                           | Integração com submissão nativa de formulário.                        |
| `autoFocus`       | `boolean`                          | Foco automático na montagem.                                          |
| `aria-label`, `aria-labelledby`, `aria-describedby` | `string`         | Nomeação acessível quando não há `label`/`children` visível.           |

> `AriaCheckboxFieldProps` cobre o conjunto completo de `useCheckbox`/`useCheckboxGroupItem`
> do react-aria — os itens acima são os mais usados no dia a dia; qualquer outro prop de
> validação/foco do react-aria-components também é aceito.

### Notas de comportamento

- `content = children ?? label`: **`children` tem prioridade** sobre `label` quando ambos
  são passados. Se nenhum for informado, o Checkbox renderiza **sem texto visível** — nesse
  caso `aria-label` é obrigatório.
- O ícone exibido depende do estado: `isIndeterminate` → `Minus`; senão, `Check` com
  `opacity` condicionada a `isSelected` (sempre renderizado no DOM, só fica invisível).
- `theme="dark"` aplica `data-theme="dark"` no `CheckboxField` — use sobre fundos escuros
  (headers brand, sidebars).
- Tamanhos: `sm` → caixa 16×16px / ícone 10px; `md` (default) → caixa 20×20px / ícone 13px
  (`CHECK_ICON_SIZE` em `Checkbox.constants.ts`).
- `className` é aplicado ao `CheckboxButton` (a caixa+label), não ao `CheckboxField` — o
  wrapper externo é `display: contents` e não aceita estilização direta.

---

## `CheckboxGroup`

Agrega múltiplos `Checkbox` (cada um com `value`) sob um único `label`, `helperText` e
`errorMessage`. Constrói sobre `CheckboxGroup` do `react-aria-components`.

```ts
import type { ReactNode } from 'react';
import type { CheckboxGroupProps as AriaCheckboxGroupProps } from 'react-aria-components';

interface CheckboxGroupProps extends Omit<AriaCheckboxGroupProps, 'className' | 'children'> {
  label?: ReactNode;
  helperText?: ReactNode;     // some quando `errorMessage` está presente
  errorMessage?: ReactNode;   // substitui helperText; força isInvalid
  children?: ReactNode;       // os Checkbox filhos
  className?: string;
}
```

Props herdadas relevantes de `AriaCheckboxGroupProps`: `value` / `defaultValue`
(`string[]`), `onChange: (value: string[]) => void`, `isDisabled`, `isReadOnly`,
`isRequired`, `isInvalid`, `name`.

### Notas de comportamento

- `errorMessage` presente força `isInvalid = true` no grupo (`Boolean(isInvalid) ||
  hasErrorMessage`), **independente** do `isInvalid` recebido via props.
- Quando há `errorMessage`, ele substitui completamente o `helperText` — nunca são
  exibidos juntos.
- `isDisabled` no grupo bloqueia **todos** os `Checkbox` filhos (herdado do contexto do
  react-aria-components).
- `onChange` do grupo entrega o array de `value`s selecionados, na ordem em que foram
  marcados (não a ordem de declaração dos filhos).

---

## Exemplos

```tsx
import { useState } from 'react';
import { Checkbox, CheckboxGroup } from '@srm/diamond';

// Básico, não-controlado
<Checkbox defaultSelected>Aceito os termos de uso</Checkbox>

// Controlado
function TermosField() {
  const [aceito, setAceito] = useState(false);
  return (
    <Checkbox isSelected={aceito} onChange={setAceito}>
      Li e aceito a política de privacidade
    </Checkbox>
  );
}

// Tamanho pequeno
<Checkbox size="sm">Lembrar minha escolha</Checkbox>

// Estado indeterminate ("selecionar todos" parcial)
<Checkbox isIndeterminate>Selecionar todos</Checkbox>

// Desabilitado / somente leitura
<Checkbox isDisabled defaultSelected>Opção indisponível</Checkbox>
<Checkbox isReadOnly isSelected>Confirmado (não editável)</Checkbox>

// Inválido
<Checkbox isInvalid>É necessário aceitar para continuar</Checkbox>

// Tema escuro (sobre header brand)
<Checkbox theme="dark" defaultSelected>Notificar por e-mail</Checkbox>

// Somente ícone, sem texto visível — aria-label obrigatório
<Checkbox aria-label="Selecionar linha" />

// Grupo de opções (seleção múltipla por value)
function InteressesField() {
  const [selecionados, setSelecionados] = useState<string[]>([]);
  return (
    <CheckboxGroup
      label="Interesses"
      helperText="Selecione um ou mais produtos."
      value={selecionados}
      onChange={setSelecionados}
    >
      <Checkbox value="fidc">FIDC</Checkbox>
      <Checkbox value="cri">CRI</Checkbox>
      <Checkbox value="debentures">Debêntures</Checkbox>
    </CheckboxGroup>
  );
}

// Grupo com erro
<CheckboxGroup label="Interesses" errorMessage="Selecione ao menos um produto" isInvalid>
  <Checkbox value="fidc">FIDC</Checkbox>
  <Checkbox value="cri">CRI</Checkbox>
</CheckboxGroup>
```

### Integração com React Hook Form

```tsx
// Checkbox único (boolean)
<Controller
  name="aceiteTermos"
  control={control}
  render={({ field }) => (
    <Checkbox isSelected={field.value} onChange={field.onChange}>
      Aceito os termos de uso
    </Checkbox>
  )}
/>

// CheckboxGroup (array de strings)
<Controller
  name="interesses"
  control={control}
  render={({ field, fieldState }) => (
    <CheckboxGroup
      label="Interesses"
      value={field.value}
      onChange={field.onChange}
      errorMessage={fieldState.error?.message}
    >
      <Checkbox value="fidc">FIDC</Checkbox>
      <Checkbox value="cri">CRI</Checkbox>
      <Checkbox value="debentures">Debêntures</Checkbox>
    </CheckboxGroup>
  )}
/>
```

---

## Acessibilidade

- O input nativo `role="checkbox"` fica presente e acessível; o rótulo vem de `children`/
  `label` (associado automaticamente pelo react-aria) ou de `aria-label` quando não há
  texto visível — **sempre forneça um dos dois**.
- O ícone da caixa (`span.box`) é `aria-hidden="true"`: puramente decorativo, o estado
  marcado/desmarcado/indeterminado é comunicado pelos atributos ARIA nativos do checkbox
  (`aria-checked="mixed"` para indeterminate), não pelo ícone.
- `CheckboxGroup` expõe `role="group"` com nome acessível vindo de `label` — sempre informe
  `label` no grupo (mesmo que visualmente discreto) para leitores de tela anunciarem o
  conjunto corretamente.
- `isIndeterminate` é **puramente visual** — não impede alternância nem altera
  `isSelected`; a lógica de "todos/parcial/nenhum" deve ser controlada pela aplicação.
- Navegação por teclado (Tab para focar, Espaço para alternar) é tratada nativamente pelo
  react-aria-components — não é necessário `onKeyDown` customizado.

## Armadilhas comuns

- Passar `label` **e** `children` ao mesmo tempo: `children` sempre vence — evite ambiguidade
  usando só um dos dois.
- Não passar `aria-label` num `Checkbox` sem texto visível — resulta em checkbox sem nome
  acessível.
- Tratar `isIndeterminate` como um terceiro valor de `isSelected`: são independentes; ao
  clicar num checkbox indeterminate, ele alterna `isSelected` normalmente e o
  `isIndeterminate` **não** se limpa sozinho — a aplicação deve recalculá-lo.
- Em `CheckboxGroup`, esquecer o `value` em cada `Checkbox` filho: sem `value`, o item não
  participa corretamente do array agregado pelo grupo.
- Não confundir `onChange` do `Checkbox` (`(isSelected: boolean) => void`) com o do
  `CheckboxGroup` (`(value: string[]) => void`) — assinaturas diferentes.
- `className` no `Checkbox` estiliza o `CheckboxButton`, não o wrapper `CheckboxField`
  (que é `display: contents`) — não espere efeito de `className` em propriedades de layout
  externo (ex.: `margin` no wrapper).
