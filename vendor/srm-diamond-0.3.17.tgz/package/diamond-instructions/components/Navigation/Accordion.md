# Accordion

Lista colapsável de itens, cada um com um cabeçalho clicável (título, subtítulo opcional,
badge opcional e asset à esquerda opcional — ícone ou avatar) e um corpo que expande/recolhe
com animação de grid (`grid-template-rows`). Não é construído sobre `react-aria-components`
diretamente: usa `useState`/`useId` do React puro e compõe internamente `Button`, `Avatar`
(para o asset à esquerda) e `Icon` (para o chevron, decorativo). O gatilho de cada item é um
**único** `<button type="button" aria-expanded aria-controls>` — não há mais um
`<div onClick>` com um `IconButton` interativo aninhado dentro dele. Três variantes visuais,
suporte a abertura única ou múltipla, e textos acessíveis (`expandLabel`/`collapseLabel`)
configuráveis via props. Estilização via CVA (`Accordion.variants.ts`: `itemVariants`,
`triggerVariants`, `panelContentVariants`, `gapVariants`).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/Accordion/`
- **Export:** `import { Accordion } from '@srm/diamond';` (também exporta os tipos
  `AccordionVariant`, `AccordionButtonItem`, `AccordionItemData`, `AccordionProps`)
- **Relacionados/Base:** usa [Button](../Forms/Button.md) e Avatar internamente (sem doc próprio nesta pasta — componentes de outras categorias).

---

## Quando usar

- FAQ e perguntas frequentes (planos, produtos, políticas de resgate/tributação).
- Detalhamento de itens de uma lista onde cada item tem um resumo (título/subtítulo) e um
  corpo expansível (texto explicativo, ou texto + ações via botões).
- Painéis de configuração/seções onde só um bloco por vez precisa ficar visível
  (`multiOpen={false}`, padrão) ou onde vários podem ficar abertos simultaneamente
  (`multiOpen={true}`).
- Listagens compactas com badge de status por item (variante `compact-accent`), por exemplo
  um resumo de movimentações ou notificações agrupadas.

## Quando **não** usar

- Alternância entre seções/abas do mesmo nível hierárquico, sempre visível uma por vez sem
  empilhamento vertical → use [`TabBar`](./TabBar.md).
- Navegação estrutural do site/produto (trilha de páginas) → use [`Breadcrumb`](./Breadcrumb.md)
  ou `MegaMenu`.
- Uma única seção colapsável isolada (não uma lista) — o `Accordion` sempre renderiza um
  array de `items`; para 1 item, ainda funciona, mas avalie se um simples estado local com
  um `<button>` de chevron não é mais direto.
- Conteúdo que precisa ficar sempre visível e sem interação de abrir/fechar → renderize o
  conteúdo diretamente, sem envolver em `Accordion`.

---

## Interface

```ts
import type { ReactNode } from 'react';

export type AccordionVariant = 'boxed' | 'line' | 'compact-accent';

export interface AccordionButtonItem {
  label: string;
}

export interface AccordionItemData {
  title:      string;
  subtitle?:  string;
  badge?:     string;
  body?:      string;
  leftBar?:   boolean;                              // barra vertical de destaque à esquerda do trigger
  icon?:      ReactNode;                             // asset à esquerda (ícone); ignorado se compact
  initials?:  string;                                // asset à esquerda (avatar) — tem precedência sobre `icon`
  avatarBg?:  string;                                 // cor de fundo do avatar; default: 'var(--brand-primary)'
  content?:   'text-only' | 'text-with-buttons';      // default efetivo: 'text-only'
  buttons?:   AccordionButtonItem[];                  // usado quando content === 'text-with-buttons'
}

export interface AccordionProps {
  items:          AccordionItemData[];
  defaultOpen?:   number | null;   // default: null — índice do item inicialmente aberto
  multiOpen?:     boolean;         // default: false — permite múltiplos itens abertos
  compact?:       boolean;         // default: false — reduz padding, esconde asset à esquerda e subtítulo
  variant?:       AccordionVariant; // default: 'boxed'
  expandLabel?:   string;          // default: 'Abrir' — prefixo do aria-label quando o item está fechado
  collapseLabel?: string;          // default: 'Fechar' — prefixo do aria-label quando o item está aberto
}
```

### Notas de comportamento

- **Trigger é um único elemento interativo.** Cada item renderiza exatamente um
  `<button type="button" aria-expanded={isOpen} aria-controls={panelId} aria-label={...}
  onClick={onToggle}>` — barra lateral, asset, título/subtítulo/badge e chevron são todos
  conteúdo **dentro** do próprio `<button>`, não elementos clicáveis separados. Não há
  interatividade aninhada (sem `IconButton`/`div onClick` duplicado).
- `aria-label` do trigger é `` `${isOpen ? collapseLabel : expandLabel}: ${item.title}` `` —
  totalmente derivado das props `expandLabel`/`collapseLabel` (defaults `'Abrir'`/`'Fechar'`),
  não mais hardcoded no componente.
- **Não há `onChange`/callback de abertura** — o estado de aberto/fechado é 100% interno
  (um único `useState<Set<number>>`, usado tanto para `multiOpen={true}` quanto para
  `multiOpen={false}`), controlado apenas por índice (`i` no array `items`). Não há forma de
  controlar o accordion externamente (componente não-controlado).
- `defaultOpen` define o índice aberto **apenas na montagem inicial**; mudanças posteriores na
  prop não reabrem/fecham nada (não há `useEffect` sincronizando).
- Em `multiOpen={false}` (padrão), clicar no item já aberto **fecha** (toggle) e o `Set` some
  para vazio; clicar em outro item substitui o `Set` por um novo `Set` com apenas aquele
  índice — no máximo um item aberto por vez.
- Em `multiOpen={true}`, cada clique adiciona/remove o índice clicado do mesmo `Set`,
  permitindo qualquer combinação de itens abertos.
- **Precedência do asset à esquerda**: se `initials` estiver presente, renderiza `Avatar`
  (`size="lg"`, `bg={avatarBg ?? 'var(--brand-primary)'}`); senão, se `icon` estiver presente,
  renderiza dentro de um círculo (`IconCircle`); senão, nada. Esse asset **não aparece** quando
  `compact` (ou a variante `compact-accent`, que força compact) está ativo.
- **Variante `compact-accent`** força `compact = true` internamente, sempre mostra a barra
  lateral (`leftBar`) e usa a superfície `boxed` por baixo dos panos (`surface = variant ===
  'line' ? 'line' : 'boxed'`).
- `leftBar` (prop por item) só tem efeito visual de fato combinado com a variante `line`/`boxed`
  normal — em `compact-accent` a barra já é sempre exibida independentemente do valor da prop.
- **`content`**: se omitido ou `'text-only'`, renderiza `<p>{item.body}</p>`. Se
  `'text-with-buttons'`, renderiza um grid de `Button` (`variant="secondary"`, `size="md"`,
  `fullWidth`) com um botão por entrada de `item.buttons` — **os botões não têm `onPress`
  conectado por padrão**; o array `buttons` só define os `label`s exibidos. Para ações reais,
  seria necessário estender o componente ou tratar fora dele (limitação atual da API pública).
- O chevron (`Icon` `chevron-down`) é puramente decorativo — vive num `<span aria-hidden="true">`
  dentro do próprio `<button>` do trigger, não é mais um `IconButton` separado com seu próprio
  `aria-label`/`onPress`.
- O painel usa `role="region"` + `aria-labelledby` apontando para o título — mesmo fechado, ele
  permanece no DOM (a animação é via `grid-template-rows: 0fr → 1fr`, não `display:none`).
- Sem `key` estável nos itens: o componente usa o índice do array como `key` — evite reordenar
  `items` dinamicamente sem também resetar o estado de abertura (índices trocam de item).

---

## Exemplos

```tsx
import { Accordion } from '@srm/diamond';

// Básico — variante boxed (default), abertura única
<Accordion
  items={[
    { title: 'Como funciona o resgate?', body: 'O resgate é processado em D+0 para fundos de liquidez diária.' },
    { title: 'Qual a tributação?',        body: 'Segue a tabela regressiva de IR para renda fixa.' },
    { title: 'Há taxa de administração?', body: 'Sim, 0,5% a.a., já descontada da rentabilidade exibida.' },
  ]}
/>

// Com item inicialmente aberto e múltiplos abertos ao mesmo tempo
<Accordion
  defaultOpen={0}
  multiOpen
  items={items}
/>

// Variante "line" (divisórias, sem caixa) em modo compacto
<Accordion variant="line" compact items={items} />

// Variante "compact-accent" — barra lateral de destaque sempre visível
<Accordion
  variant="compact-accent"
  items={[
    { title: 'Como funciona o resgate?', body: 'O resgate é processado em D+0.' },
    { title: 'Qual a tributação?',        body: 'Tabela regressiva de IR.' },
    { title: 'Há taxa de administração?', body: 'Sim, 0,5% a.a.' },
  ]}
/>

// Rótulos acessíveis customizados (ex.: outro idioma ou texto mais específico)
<Accordion
  expandLabel="Expandir"
  collapseLabel="Recolher"
  items={items}
/>

// Item com subtítulo, badge e avatar à esquerda
<Accordion
  items={[
    {
      title: 'Fundo XPTO Multimercado',
      subtitle: 'Renda variável',
      badge: 'Atualizado hoje',
      initials: 'XP',
      avatarBg: 'var(--avatar-teal)',
      body: 'Detalhes completos do fundo, política de investimento e histórico.',
    },
  ]}
/>

// Item com ícone (lucide-react) à esquerda
import { HelpCircle } from 'lucide-react';

<Accordion
  items={[
    { title: 'Dúvida frequente', icon: <HelpCircle size={20} aria-hidden="true" />, body: 'Resposta detalhada.' },
  ]}
/>

// Item com corpo em texto + botões (apenas rótulos — sem ação conectada)
<Accordion
  items={[
    {
      title: 'Precisa de ajuda?',
      content: 'text-with-buttons',
      buttons: [{ label: 'Falar com suporte' }, { label: 'Ver FAQ completo' }],
    },
  ]}
/>
```

---

## Acessibilidade

- Cada trigger é um `<button type="button">` nativo com `aria-expanded`, `aria-controls` e
  `aria-label` (`` `${expandLabel|collapseLabel}: {title}` ``) — foco e ativação por teclado
  (Tab + Enter/Espaço) funcionam nativamente no elemento inteiro do cabeçalho, sem depender de
  um sub-elemento interativo específico.
- O painel de conteúdo usa `role="region"` associado via `aria-labelledby` ao `id` do título —
  leitores de tela anunciam a região nomeada pelo título do item.
- `expandLabel`/`collapseLabel` (defaults `'Abrir'`/`'Fechar'`) permitem adaptar o texto
  acessível ao contexto (idioma, tom, domínio) sem alterar o componente.
- O chevron é `aria-hidden="true"` — o estado semântico (aberto/fechado) é comunicado só pelo
  `aria-expanded` e pelo `aria-label` do `<button>`, não pelo ícone isoladamente.
- Ícones passados via prop `icon` devem ser marcados como decorativos pelo consumidor
  (`aria-hidden="true"`), como nos exemplos do Storybook — o componente não faz isso por você.

## Armadilhas comuns

- Não espere um `onChange`/`onToggle` externo — o estado de abertura é interno; para "ler" qual
  item está aberto de fora, o `Accordion` não expõe essa informação.
- `defaultOpen` só funciona na montagem — trocar a prop em re-renders subsequentes **não**
  reabre outro item.
- `buttons` (em `content: 'text-with-buttons'`) só define `label`; não há `onPress` — não assuma
  que os botões disparam alguma ação por padrão.
- Usar `icon` **e** `initials` juntos no mesmo item: `initials` tem precedência — o `icon` é
  ignorado silenciosamente.
- Ativar `compact` mas ainda esperar ver `subtitle`/asset à esquerda — ambos somem em modo
  compacto (incluindo `compact-accent`, que força compact internamente).
- Esperar poder customizar apenas um dos dois rótulos (`expandLabel` **ou** `collapseLabel`) e
  deixar o outro "como estava antes" em outro idioma — os dois têm defaults independentes em
  português (`'Abrir'`/`'Fechar'`); se for localizar, defina ambos.
- Usar índice do array (`key`) implícito para itens dinâmicos: reordenar/filtrar `items` sem
  resetar o componente pode fazer o "item aberto" corresponder a um item diferente do esperado.
