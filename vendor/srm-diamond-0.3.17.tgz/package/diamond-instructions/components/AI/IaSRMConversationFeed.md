# IaSRMConversationFeed

Container scrollável que mapeia um array de `messages` em
[`IaSRMChatBubble`](./IaSRMChatBubble.md). Puramente apresentacional: não busca dados,
não conhece transporte nem estado remoto.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMConversationFeed/`
- **Export:** `import { IaSRMConversationFeed } from '@srm/diamond';`
- **Relacionados:** [IaSRMChatBubble](./IaSRMChatBubble.md) (cada item), [IaSRMDrawer](./IaSRMDrawer.md) e [IaSRMOverlay](./IaSRMOverlay.md) (hospedam o feed), [IaSRMTray](./IaSRMTray.md) (o input, abaixo do feed)

---

## Quando usar

- Renderizar uma conversa completa dentro de um `IaSRMDrawer`, `IaSRMOverlay` ou tela dedicada.
- Quando precisa de auto-scroll com comportamento correto de chat e de `role="log"` para leitores de tela.
- Quando quer paginação de histórico (scroll infinito para cima) → use `onScroll` + `ref`.

## Quando **não** usar

- Uma mensagem só → [`IaSRMChatBubble`](./IaSRMChatBubble.md) direto.
- Sem um parent que dê **altura limitada** e `display: flex; flex-direction: column` — o feed usa `flex: 1` + `overflow-y: auto` e não vai scrollar.
- Como lista genérica de itens → componentes de `DataDisplay`.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactNode, Ref } from 'react';
import type { IaSRMChatBubbleProps } from '@srm/diamond';

type IaSRMChatMessage = IaSRMChatBubbleProps & { id: string };

interface IaSRMConversationFeedProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  messages: readonly IaSRMChatMessage[];
  thinking?: boolean;                 // default: false
  thinkingLabel?: string;             // aria-label do TypingIndicator; default 'Gerando resposta'
  thinkingAvatar?: ReactNode | null;  // null remove o slot
  userInitials?: string;              // fallback p/ mensagens type='user' sem initials
  autoScroll?: boolean;               // default: true
  autoScrollThreshold?: number;       // px; default: 48
  empty?: ReactNode;                  // exibido sem mensagens e sem thinking
  ref?: Ref<HTMLDivElement>;          // o nó scrollável
  onScroll?: (event: UIEvent<HTMLDivElement>) => void;
  // + atributos nativos de <div>: id, className, role (override), aria-*, …
}
```

### Notas de comportamento

- **Auto-scroll com comportamento de chat**: só rola pro fim se o usuário **já estiver próximo do fim** (dentro de `autoScrollThreshold`). Quem subiu para ler o histórico não é interrompido por mensagem nova. A posição é rastreada num `ref` — não provoca re-render.
- `autoScroll={false}` desliga por completo; combine com `ref` + `onScroll` para assumir o controle (botão "voltar ao fim", âncoras, etc.).
- `onScroll` é **repassado** ao consumidor além de alimentar a lógica interna — use para paginação de histórico.
- `ref` aponta para o nó scrollável, permitindo controle imperativo (`scrollTo`, medições).
- Expõe **`role="log"`**, que implica `aria-live="polite"`: leitores de tela anunciam mensagens novas sem que você configure nada. Pode ser sobrescrito via `...rest`.
- `id` de cada mensagem é usado como `key` do map e **não** é repassado como prop pro bubble.
- `IaSRMChatMessage` é uma **intersecção** (`IaSRMChatBubbleProps & { id }`), não `extends` — a intersecção distribui sobre a union discriminada e preserva a exclusividade de props por `type`.
- `userInitials` é apenas fallback: `initials` da própria mensagem tem precedência. Sem nenhum dos dois, o avatar do usuário renderiza vazio.
- `thinking` renderiza o átomo `TypingIndicator` ao final, numa linha com avatar — nunca no meio da lista.

---

## Exemplos

```tsx
import { IaSRMConversationFeed, type IaSRMChatMessage } from '@srm/diamond';

const messages: IaSRMChatMessage[] = [
  { id: '1', type: 'iaSRM', main: 'Olá', hint: 'Como posso ajudar?', time: '10:30' },
  { id: '2', type: 'user', text: 'Quero fazer uma TED', time: '10:31', initials: 'LO' },
];

// Dentro de um parent com altura (o Drawer/Overlay já provê)
<IaSRMConversationFeed messages={messages} userInitials="LO" />

// Estado "pensando" com label próprio
<IaSRMConversationFeed messages={messages} thinking={isPending} thinkingLabel="Analisando dados" />

// Estado vazio
<IaSRMConversationFeed
  messages={[]}
  empty={<EmptyState title="Nenhuma conversa ainda" />}
/>

// Paginação de histórico + controle de scroll
const feedRef = useRef<HTMLDivElement>(null);
<IaSRMConversationFeed
  ref={feedRef}
  messages={messages}
  onScroll={(event) => {
    if (event.currentTarget.scrollTop === 0) loadOlderMessages();
  }}
/>

// Scroll totalmente sob controle do pai
<IaSRMConversationFeed ref={feedRef} messages={messages} autoScroll={false} />

// Folga maior para considerar "no fim"
<IaSRMConversationFeed messages={messages} autoScrollThreshold={120} />

// Parent obrigatório quando não é Drawer/Overlay
<div style={{ height: '60vh', display: 'flex', flexDirection: 'column' }}>
  <IaSRMConversationFeed messages={messages} />
</div>
```

---

## Acessibilidade

- `role="log"` faz o leitor de tela anunciar mensagens novas conforme chegam, sem interromper a leitura em curso.
- O auto-scroll condicional é também uma decisão de acessibilidade: sequestrar o scroll de quem está lendo o histórico é uma falha de usabilidade séria em leitores de tela e em navegação por teclado.
- `thinkingLabel` deve descrever o que está acontecendo ("Gerando resposta", "Analisando dados") — é o que será anunciado.
- Passe um `aria-label` via `...rest` se houver mais de um feed na mesma tela.

## Armadilhas comuns

- **Parent sem altura** é o erro mais comum: sem `display: flex; flex-direction: column` + altura limitada no ancestral, o `flex: 1` não expande e o `overflow-y: auto` nunca scrolla.
- Não gerencie `messages` dentro do feed — ele é apresentacional. Estado vem de fora (useState, TanStack Query, store).
- Não insira o estado "pensando" como item do array; use a prop `thinking`.
- `id` precisa ser **estável** entre renders. Índice de array como `id` causa remount e perde foco/estado dos embeds.
- Se o último item é atualizado por streaming sem mudar `messages.length`, o auto-scroll ainda dispara (o efeito depende do array), mas em cenários de streaming agressivo prefira `autoScroll={false}` + controle próprio.
