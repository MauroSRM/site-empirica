# FieldGroup

Agrupador semântico de campos de formulário. Renderiza um `<fieldset>` nativo com
`<legend>` opcional e organiza os `children` em um **grid CSS** com 1, 2 ou 3 colunas
e espaçamento configurável. Não é um input — é um container de layout/semântica para
outros campos (`TextInput`, `CurrencyInput`, `DatePicker` etc.). Construído com HTML
nativo (`fieldset`/`legend`) e CSS Grid puro via CSS Modules — **sem** dependência de
`react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/FieldGroup/`
- **Export:** `import { FieldGroup } from '@srm/diamond';`
- **Relacionados:** [TextInput](./Inputs/TextInput.md), [CurrencyInput](./Inputs/CurrencyInput.md),
  [PercentInput](./Inputs/PercentInput.md), [DatePicker](./Inputs/DatePicker.md) — qualquer
  campo de formulário pode ser filho de um `FieldGroup`.

---

## Quando usar

- Agrupar campos relacionados de um formulário sob um título comum (ex.: "Dados pessoais",
  "Endereço", "Dados bancários").
- Criar layouts em grade (2 ou 3 colunas) para campos curtos lado a lado
  (Nome/Sobrenome, CPF/RG, Valor mínimo/Valor máximo).
- Dar semântica de agrupamento (`fieldset`/`legend`) para leitores de tela em seções
  de formulários longos (cadastro de cliente, formulário de aporte, KYC).
- Compor faixas de valor com dois inputs (ex.: dois `CurrencyInput` para mín/máx de um filtro).

## Quando **não** usar

- Um único campo isolado, sem necessidade de título de seção → use o input diretamente,
  sem envolver em `FieldGroup`.
- Layout genérico de página/seção sem semântica de formulário → use um container de
  layout comum (`div`, grid da aplicação), não um `fieldset`.
- Grupo de **opções mutuamente exclusivas** (radio/checkbox) — `FieldGroup` não gerencia
  seleção nem estado de grupo, apenas organiza layout; se precisar de semântica de
  grupo de opções, isso é responsabilidade do componente de radio/checkbox correspondente.

---

## Interface

```ts
import type { ReactNode } from 'react';

export type FieldGroupGap = 'sm' | 'md' | 'lg';

export interface FieldGroupProps {
  label?: ReactNode;          // renderizado como <legend>; se ausente, <legend> não é renderizado
  columns?: 1 | 2 | 3;        // default: 1 — número de colunas do grid
  gap?: FieldGroupGap;        // default: 'md' — espaçamento entre células do grid
  children?: ReactNode;       // os campos a serem organizados em grid
  className?: string;         // classe extra mesclada ao <fieldset>
}
```

### Notas de comportamento

- `label` é renderizado dentro de um `<legend>` **somente se truthy** — sem `label`,
  nenhum `<legend>` é criado (o `fieldset` fica sem título visível/acessível).
- `columns` define `grid-template-columns: repeat(n, 1fr)` — todas as colunas têm
  largura igual; **não há breakpoint responsivo embutido**: em telas estreitas o grid
  continua com `n` colunas fixas (cabe ao consumidor aplicar `className`/CSS adicional
  para colapsar em telas pequenas, se necessário).
- `gap` mapeia para tokens de espaçamento (`--space-2` / `--space-4` / `--space-6`);
  não aceita valor numérico livre.
- O `<fieldset>` em si não tem borda/padding (resetados via CSS) — o visual vem
  inteiramente do `legend` (título em negrito) e do `grid` interno.
- Não gerencia estado, validação ou foco dos campos filhos — cada campo filho
  (`TextInput`, `CurrencyInput` etc.) continua responsável por seu próprio `state`,
  `errorText` e acessibilidade.
- Não há prop `theme` própria: o tema (claro/escuro) de cada campo filho deve ser
  passado individualmente a cada input, como nos exemplos abaixo.

---

## Exemplos

```tsx
import { FieldGroup, TextInput, CurrencyInput } from '@srm/diamond';

// Básico — 1 coluna (default)
<FieldGroup label="Contato">
  <TextInput label="E-mail" />
  <TextInput label="Telefone" />
</FieldGroup>

// 2 colunas
<FieldGroup label="Dados pessoais" columns={2}>
  <TextInput label="Nome" />
  <TextInput label="Sobrenome" />
</FieldGroup>

// 3 colunas com gap pequeno
<FieldGroup label="Documento" columns={3} gap="sm">
  <TextInput label="CPF" />
  <TextInput label="RG" />
  <TextInput label="Órgão emissor" />
</FieldGroup>

// Faixa de valores (mín/máx) com CurrencyInput
<FieldGroup label="Faixa de aporte" columns={2} gap="lg">
  <CurrencyInput label="Valor mínimo" />
  <CurrencyInput label="Valor máximo" />
</FieldGroup>

// Sem legend (apenas agrupamento visual/layout)
<FieldGroup columns={2}>
  <TextInput label="Cidade" />
  <TextInput label="Estado" />
</FieldGroup>

// Tema escuro — aplicado a cada campo filho individualmente
<div data-theme="dark">
  <FieldGroup label="Dados bancários" columns={2}>
    <TextInput label="Banco" theme="dark" />
    <TextInput label="Agência" theme="dark" />
  </FieldGroup>
</div>
```

### Integração com React Hook Form

`FieldGroup` é apenas layout — a integração com formulário acontece nos campos filhos,
cada um com seu próprio `Controller`:

```tsx
<FieldGroup label="Dados pessoais" columns={2}>
  <Controller
    name="nome"
    control={control}
    render={({ field, fieldState }) => (
      <TextInput
        label="Nome"
        value={field.value}
        onChange={field.onChange}
        state={fieldState.error ? 'error' : 'default'}
        errorText={fieldState.error?.message}
      />
    )}
  />
  <Controller
    name="sobrenome"
    control={control}
    render={({ field, fieldState }) => (
      <TextInput
        label="Sobrenome"
        value={field.value}
        onChange={field.onChange}
        state={fieldState.error ? 'error' : 'default'}
        errorText={fieldState.error?.message}
      />
    )}
  />
</FieldGroup>
```

---

## Acessibilidade

- Usa `<fieldset>`/`<legend>` nativos — leitores de tela anunciam o `label` como
  título do grupo ao entrar em qualquer campo filho, reforçando o contexto.
- Sem `label`, o grupo perde esse anúncio de contexto — prefira sempre fornecer um
  título quando o agrupamento tiver significado semântico (não apenas visual).
- A ordem de leitura segue a ordem do DOM dos `children`, não a ordem visual do grid
  (que pode divergir em layouts customizados) — mantenha a ordem dos `children`
  alinhada à ordem de leitura desejada.

## Armadilhas comuns

- Não use `FieldGroup` esperando responsividade automática: `columns={3}` permanece
  3 colunas em qualquer largura de tela; para colapsar em mobile, trate isso via
  `className` externo ou componha grupos diferentes por breakpoint.
- Não confunda com um grupo de **seleção** (radio/checkbox) — `FieldGroup` não expõe
  `value`/`onChange` nem gerencia seleção; é puramente estrutural.
- `theme` não se propaga dos filhos automaticamente — cada input dentro do grupo
  precisa receber `theme="dark"` individualmente quando o grupo estiver sobre fundo escuro.
- Omitir `label` quando o grupo tem múltiplos campos correlatos remove contexto
  semântico útil tanto visualmente quanto para tecnologia assistiva.
