# TabBar

Barra de abas horizontal para alternar entre seções de conteúdo na mesma página (ex.: Resumo /
Extrato / Documentos / Configurações de uma conta). Suporta dois estilos visuais — `pill`
(cápsulas com fundo sólido na aba ativa) e `line` (sublinhado, **default**) —, três tamanhos e
tema claro/escuro. Construído sobre `Tabs` + `TabList` + `Tab` do `react-aria-components`, que
cuidam de navegação por teclado (setas, Home/End) e do modelo de seleção
(controlado/não-controlado).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/TabBar/`
- **Export:** `import { TabBar } from '@srm/diamond';`
- **Relacionados:** nenhum outro componente de navegação por abas no barrel atual.

---

## Quando usar

- Alternar entre visões de uma mesma entidade sem trocar de rota: Resumo / Extrato / Documentos /
  Configurações de uma conta ou carteira.
- Segmentar conteúdo relacionado dentro de um card, modal ou página de detalhe.
- `variant="pill"` para navegação secundária dentro de uma superfície clara (cards, painéis).
- `variant="line"` (default) para uma aparência mais discreta, tipo "sub-navegação" abaixo de um
  cabeçalho.
- `theme="dark"` quando a barra estiver sobre um fundo navy/brand (ex.: dentro de um `AppHeader`
  com variante escura).

## Quando **não** usar

- Navegação estrutural entre páginas/rotas distintas do produto → use o componente de navegação
  principal (menu lateral, `AppHeader`) em vez de `TabBar`.
- Alternância binária simples (ligado/desligado, dois modos) → prefira um `Toggle`/`Switch` ou
  `DoubleButton` em vez de forçar duas abas.
- Muitas opções que não cabem em uma linha — `TabBar` não tem overflow/scroll embutido; nesse
  caso avalie um menu dropdown ou redesenhe a navegação.

---

## Interface

```ts
import type { ReactNode } from 'react';

interface TabItem {
  id: string;
  label: string;
  icon?: ReactNode;
}

type TabBarVariant = 'line' | 'pill';
type TabBarSize = 'sm' | 'md' | 'lg';
type TabBarTheme = 'light' | 'dark';

interface TabBarProps {
  variant?: TabBarVariant;              // default: 'line'
  tabs: TabItem[];                      // obrigatório — lista de abas, na ordem de exibição
  size?: TabBarSize;                    // default: 'md'
  value?: string;                       // controlado: id da aba selecionada
  defaultActive?: string;               // não-controlado: id inicialmente selecionada (default: tabs[0]?.id)
  onChange?: (id: string) => void;      // chamado com o id da aba ao trocar seleção
  theme?: TabBarTheme;                  // default: 'light'
  className?: string;                   // aplicado ao <TabList>, não ao root
}
```

> `TabBarProps` **não** estende props do react-aria — não há passthrough de `aria-label`,
> `aria-labelledby` ou outros atributos para o `Tabs`/`TabList` internos. O componente não aceita
> `ref`.

### Notas de comportamento

- **Controlado vs. não-controlado**: se `value` for passado (mesmo `undefined` explícito não
  conta — a checagem é `value !== undefined`), o componente vira controlado e delega a seleção ao
  react-aria via `selectedKey={value}`. Caso contrário, é não-controlado e usa
  `defaultSelectedKey={defaultActive ?? tabs[0]?.id}`.
- **`defaultActive` só é lido na montagem.** O react-aria gerencia o estado de seleção
  internamente a partir de `defaultSelectedKey`; mudar a prop `defaultActive` em re-renders
  subsequentes **não** move a aba ativa. Para resetar a aba selecionada a partir de fora, force
  remount do componente (ex.: `key={defaultActive}` — é exatamente o que o Storybook faz).
- `onChange` recebe sempre uma `string` (o `id` da aba), mesmo que internamente o react-aria
  trabalhe com `Key` (`string | number`) — o componente já faz `String(key)`.
- Se `tabs` estiver vazio e `defaultActive` não for informado, nenhuma aba inicia selecionada
  (`tabs[0]?.id` é `undefined`).
- Cada `Tab` renderiza `icon` (se houver, dentro de um wrapper `inline-flex`) seguido de `label`
  como texto simples — `label` não aceita nós ricos, é sempre a `string` exibida.
- `variant`, `size` e `theme` afetam apenas estilo (fonte, padding, cores) via variantes CVA
  (`tabListVariants` em `TabBar.variants.ts`, com `defaultVariants: { variant: 'line', size: 'md',
  theme: 'light' }`); não alteram comportamento.

---

## Exemplos

```tsx
import { useState } from 'react';
import { TabBar } from '@srm/diamond';

const TABS = [
  { id: 'resumo',  label: 'Resumo' },
  { id: 'extrato', label: 'Extrato' },
  { id: 'docs',    label: 'Documentos' },
  { id: 'config',  label: 'Configurações' },
];

// Básico — não-controlado, sem variant explícita (usa 'line')
<TabBar tabs={TABS} defaultActive="resumo" />

// Estilo pill
<TabBar variant="pill" tabs={TABS} defaultActive="resumo" />

// Controlado — a camada acima decide qual aba está ativa
function ContaTabs() {
  const [aba, setAba] = useState('resumo');
  return (
    <>
      <TabBar variant="pill" tabs={TABS} value={aba} onChange={setAba} />
      {aba === 'resumo'  && <ResumoPanel />}
      {aba === 'extrato' && <ExtratoPanel />}
      {aba === 'docs'    && <DocumentosPanel />}
      {aba === 'config'  && <ConfiguracoesPanel />}
    </>
  );
}

// Tamanho pequeno
<TabBar variant="pill" size="sm" tabs={TABS} defaultActive="resumo" />

// Com ícones
import { FileText, Settings } from 'lucide-react';
<TabBar
  variant="line"
  tabs={[
    { id: 'docs',   label: 'Documentos',    icon: <FileText size={16} /> },
    { id: 'config', label: 'Configurações', icon: <Settings size={16} /> },
  ]}
  defaultActive="docs"
/>

// Tema escuro (sobre header brand)
<TabBar variant="pill" theme="dark" tabs={TABS} defaultActive="resumo" />

// Resetando a aba ativa a partir de fora (força remount)
<TabBar key={contaSelecionada.id} variant="pill" tabs={TABS} defaultActive="resumo" />
```

---

## Acessibilidade

- Navegação por teclado (setas esquerda/direita, Home, End) e semântica de `tablist`/`tab` vêm
  prontas do `react-aria-components` — nenhuma configuração adicional é necessária.
- Foco visível (`data-focus-visible`) usa `outline` com `--focus-ring-color`, respeitando
  `prefers-reduced-motion` (transições são removidas nesse caso).
- **Não há prop para `aria-label`/`aria-labelledby` no `Tabs`.** Se a página tiver mais de uma
  `TabBar`, garanta contexto suficiente ao redor (título de seção antes da barra) para que
  usuários de leitor de tela distingam qual conjunto de abas está sendo anunciado.
- `label` de cada `TabItem` é o único texto acessível da aba — não use `icon` sem `label`
  (o componente não tem um modo "somente ícone" com `aria-label` próprio).

## Armadilhas comuns

- Trocar `defaultActive` em um componente já montado **não** move a seleção — é preciso
  `key={...}` para forçar remount (ver exemplo acima) ou migrar para o modo controlado
  (`value` + `onChange`).
- Passar `value={undefined}` explicitamente ainda ativa o modo controlado do ponto de vista do
  TypeScript, mas a checagem interna (`value !== undefined`) trata isso como não-controlado —
  não misture: ou sempre passe `value` com um id válido, ou nunca passe `value`.
- Não confunda o default (`variant="line"`) com o antigo comportamento sem fallback — hoje
  omitir `variant` é seguro e produz o sublinhado; use `variant="pill"` explicitamente quando
  precisar das cápsulas.
- `className` é aplicado ao `TabList` (a barra), não ao container das abas individualmente — para
  estilizar uma aba específica não há hook exposto além de CSS global via `data-selected`/
  `data-hovered` do react-aria.
- Sem overflow/scroll embutido: com muitas abas ou labels longos a barra pode quebrar o layout —
  valide o número de itens antes de usar em telas estreitas.
