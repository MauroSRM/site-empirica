# OptionCard

Cartão selecionável de opção única, no estilo "radio card": em vez do círculo pequeno
tradicional, toda a área do cartão (rótulo + descrição) é clicável e exibe estado visual
de seleção, hover e foco. Sempre representa uma opção dentro de um grupo de escolha única
— é construído sobre `Radio` do `react-aria-components`, e seu par `OptionCardGroup` é
construído sobre `RadioGroup` da mesma biblioteca.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/OptionCard/`
- **Export:** `import { OptionCard, OptionCardGroup } from '@srm/diamond';`
- **Relacionados:** nenhum doc de `RadioGroup`/`Checkbox` simples publicado ainda neste índice.

---

## Quando usar

- Escolha excludente entre poucas opções (2–4) onde cada opção se beneficia de um
  rótulo curto **+** uma descrição de apoio — ex.: tipo de conta (`Pessoa física` /
  `Pessoa jurídica`), tipo de aporte (`Único` / `Recorrente`), perfil de investidor.
- Telas de onboarding, wizards e formulários onde a opção precisa de mais destaque
  visual do que um radio button tradicional inline.
- Qualquer cenário de seleção única em que a área de toque grande (todo o cartão)
  melhora a usabilidade em mobile/tablet.

## Quando **não** usar

- Lista longa de opções (mais de ~4–5) → prefira um `Select`/`RadioGroup` compacto
  tradicional; cartões grandes demais poluem a tela.
- Seleção múltipla (não excludente) → use `Checkbox`/`CheckboxGroup`, não `OptionCard`.
- Opção sem necessidade de descrição de apoio e sem exigência de área de toque grande
  → um radio button simples é mais leve.
- `OptionCard` fora de um `OptionCardGroup` (ou de outro `RadioGroup` do react-aria)
  perde a semântica de grupo — veja a nota de comportamento abaixo.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { RadioGroupProps as AriaRadioGroupProps } from 'react-aria-components';

interface OptionCardProps {
  label?: ReactNode;
  description?: ReactNode;
  value?: string;         // default: '' — valor entregue ao RadioGroup quando selecionado
  disabled?: boolean;     // default: false
}

interface OptionCardGroupProps
  extends Omit<AriaRadioGroupProps, 'children' | 'className'> {
  children?: ReactNode;
  className?: string;
  ref?: Ref<HTMLDivElement>;
  // Herdado de AriaRadioGroupProps: value, defaultValue, onChange, name,
  // isDisabled, isRequired, orientation, aria-label, aria-labelledby, ...
}
```

### Notas de comportamento

- `OptionCard` **não recebe** `onChange`/`isSelected` diretamente — o estado de seleção
  é inteiramente controlado pelo `RadioGroup` ancestral (via `value`/`onChange` do
  `OptionCardGroup`), exatamente como um `<Radio>` comum do react-aria.
- Internamente, `OptionCard` detecta via `useContext(RadioGroupStateContext)` se já
  existe um grupo react-aria por perto. **Se não existir**, ele se auto-envolve em um
  `RadioGroup` interno sem `aria-label` — isso é um fallback de conveniência para
  renderizar um cartão isolado (ex.: em uma story), **não deve ser usado em produção**
  sem um `OptionCardGroup` explícito, pois o grupo fallback fica sem rótulo acessível.
- `label` e `description` são opcionais e só renderizam `<span>`/`<p>` quando truthy —
  passar ambos vazios produz um cartão apenas com o indicador radio (`.radio`/`.dot`).
- O indicador visual (círculo + ponto) é **decorativo** (`aria-hidden="true"`); a
  semântica de rádio real vem do elemento `Radio` do react-aria por baixo.
- `OptionCardGroup` é um `RadioGroup` estilizado em coluna (`display: flex; flex-direction: column`)
  — não há variante de layout horizontal/grid embutida; para isso, sobrescreva via `className`.
- Estados visuais (`data-hovered`, `data-pressed`, `data-selected`, `data-disabled`) são
  atributos de dados do react-aria aplicados automaticamente ao `Radio`, controlados
  via CSS em `OptionCard.module.scss` — não há props de tema (`light`/`dark`) expostas.

---

## Exemplos

```tsx
import { OptionCard, OptionCardGroup } from '@srm/diamond';
import { useState } from 'react';

// Básico — grupo controlado
function TipoDeConta() {
  const [tipo, setTipo] = useState('pj');
  return (
    <OptionCardGroup aria-label="Tipo de conta" value={tipo} onChange={setTipo}>
      <OptionCard label="Empresa" description="Conta PJ" value="pj" />
      <OptionCard label="Pessoa física" description="Conta PF" value="pf" />
    </OptionCardGroup>
  );
}

// Não controlado, com valor padrão
<OptionCardGroup aria-label="Tipo de aporte" defaultValue="unico">
  <OptionCard label="Único" description="Aporte pontual" value="unico" />
  <OptionCard label="Recorrente" description="Débito mensal automático" value="recorrente" />
</OptionCardGroup>

// Opção desabilitada dentro do grupo
<OptionCardGroup aria-label="Perfil de investidor" defaultValue="moderado">
  <OptionCard label="Conservador" description="Baixo risco" value="conservador" />
  <OptionCard label="Moderado" description="Risco balanceado" value="moderado" />
  <OptionCard label="Agressivo" description="Indisponível no momento" value="agressivo" disabled />
</OptionCardGroup>

// Grupo inteiro desabilitado
<OptionCardGroup aria-label="Tipo de resgate" defaultValue="total" isDisabled>
  <OptionCard label="Total" value="total" />
  <OptionCard label="Parcial" value="parcial" />
</OptionCardGroup>

// Largura customizada via className
<OptionCardGroup aria-label="Modalidade" className="minha-classe" style={{ width: 320 }} defaultValue="a">
  <OptionCard label="Modalidade A" value="a" />
  <OptionCard label="Modalidade B" value="b" />
</OptionCardGroup>
```

### Integração com React Hook Form

```tsx
<Controller
  name="tipoConta"
  control={control}
  render={({ field }) => (
    <OptionCardGroup aria-label="Tipo de conta" value={field.value} onChange={field.onChange}>
      <OptionCard label="Empresa" description="Conta PJ" value="pj" />
      <OptionCard label="Pessoa física" description="Conta PF" value="pf" />
    </OptionCardGroup>
  )}
/>
```

---

## Acessibilidade

- **Sempre** forneça `aria-label` (ou `aria-labelledby`) no `OptionCardGroup` — o grupo
  é um `RadioGroup` do react-aria e precisa de nome acessível para leitores de tela
  anunciarem "grupo de rádio, N opções".
- Não confie no fallback automático de `OptionCard` isolado (auto-`RadioGroup` sem
  label) para telas reais — ele existe só para não quebrar quando renderizado fora de
  contexto (ex.: testes/stories triviais).
- Navegação por teclado (setas para mover entre opções, espaço/enter para selecionar)
  já vem pronta do react-aria `Radio`/`RadioGroup` — nenhuma implementação adicional é
  necessária.
- `disabled` em um `OptionCard` individual usa `isDisabled` do `Radio` (foca-desviável,
  `aria-disabled`); `isDisabled` no `OptionCardGroup` desabilita todas as opções de uma vez.
- O indicador círculo/ponto é puramente decorativo (`aria-hidden`); certifique-se de que
  `label` comunique a opção sozinho, sem depender de cor/preenchimento do indicador.

## Armadilhas comuns

- Esquecer o `aria-label` no `OptionCardGroup` — o grupo funciona visualmente mas fica
  sem nome para tecnologia assistiva.
- Usar `OptionCard` fora de um `OptionCardGroup` esperando que `onChange` funcione —
  não há prop `onChange` no `OptionCard`; o estado sempre vem do grupo ancestral.
- Confundir com seleção múltipla: `OptionCard`/`OptionCardGroup` é radio (única escolha).
  Para múltipla escolha, não force vários `OptionCardGroup` independentes fingindo ser
  checkboxes — use um componente de `Checkbox`/`CheckboxGroup`.
- Adicionar muitas opções (5+) no mesmo grupo — o layout em coluna com cartões grandes
  fica extenso; para listas longas prefira um controle mais compacto.
- Tentar passar `theme="dark"` ou props de tamanho — `OptionCard` não expõe essas props
  (diferente de `Button`/`CurrencyInput`); a estilização é fixa via CSS Modules.
