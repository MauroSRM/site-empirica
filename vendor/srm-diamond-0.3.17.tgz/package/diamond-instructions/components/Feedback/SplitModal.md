# SplitModal

Modal de duas colunas lado a lado, pensado para revisão de documento + formulário/detalhes
simultâneos (ex.: visualizar um PDF de contrato à esquerda enquanto o usuário confere/assina
campos à direita). Cada coluna tem rótulo próprio e rolagem independente. O footer resolve
sozinho entre um `DoubleButton` (par primário+ghost) ou botões avulsos, conforme as props de
ação informadas. Construído sobre `ModalOverlay` + `Modal` + `Dialog` + `Heading` do
`react-aria-components`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/SplitModal/`
- **Export:** `import { SplitModal } from '@srm/diamond';`
- **Relacionados/Base:** [ContentModal](./ContentModal.md) (modal de conteúdo único),
  [Button](../Forms/Button.md), `DoubleButton`, `IconButton` (usados internamente)

---

## Quando usar

- Revisão de documento com confirmação: PDF/contrato/termo à esquerda + formulário de
  assinatura, campos de conferência ou detalhes da operação à direita.
- Qualquer fluxo em que o usuário precise **comparar duas fontes de informação lado a lado**
  dentro de um único diálogo modal (ex.: extrato original vs. ajuste proposto).
- Telas largas (desktop) onde vale a pena usar o espaço horizontal em vez de empilhar
  conteúdo verticalmente em um modal comum.

## Quando **não** usar

- Conteúdo único (aviso, confirmação, formulário simples) sem necessidade de duas colunas →
  use [`ContentModal`](./ContentModal.md).
- Telas estreitas/mobile como público principal — o layout é uma grade de duas colunas
  (`1fr 1fr`) sem breakpoint para empilhar em telas pequenas; avalie `ContentModal` nesses casos.
- Notificação transitória sem bloqueio de tela → não é um modal, use um Toast/Snackbar.

---

## Interface

```ts
import type { ReactNode } from 'react';

type SplitModalSize = 'lg' | 'xl' | 'full';

interface SplitModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;              // default: '' (sem Heading visível quando vazio)
  leftPanel?: ReactNode;
  rightPanel?: ReactNode;
  leftLabel?: string;          // default: '' (sem rótulo de coluna quando vazio)
  rightLabel?: string;         // default: '' (sem rótulo de coluna quando vazio)
  primaryLabel?: string;       // default: '' (sem botão primário quando vazio)
  ghostLabel?: string;         // default: '' (sem botão ghost quando vazio)
  onConfirm?: () => void;
  size?: SplitModalSize;       // default: 'xl'
  /** Nome acessível do dialog, usado quando `title` está vazio. @default 'Conteúdo' */
  dialogAriaLabel?: string;
}
```

Não há `className` nem `theme` na assinatura pública — a aparência é 100% controlada pelas
props acima; cores/espaçamentos vêm de tokens CSS (`var(--surface-*)`, `var(--space-*)`) e se
adaptam automaticamente ao tema global, sem prop de toggle.

### Notas de comportamento

- **Todos os defaults de domínio são neutros/vazios**: `title`, `leftLabel`, `rightLabel`,
  `primaryLabel` e `ghostLabel` default para `''` (string vazia), não para um texto em
  português pronto para produção. Este componente é agnóstico de copy — cabe a **você**
  fornecer título, rótulos e labels de botão explicitamente em cada uso.
- **Nome acessível do dialog**: `aria-label={title || dialogAriaLabel}` — quando `title` é
  vazio (`''`, o default), o `Dialog` usa `dialogAriaLabel` (default `'Conteúdo'`) como
  fallback. Passe `title` **ou** `dialogAriaLabel` sempre que o conteúdo não for óbvio pelo
  `leftPanel`/`rightPanel`.
- **Tamanhos (`size`)**: controlam apenas a `max-width` do painel — `lg` (≤900px), `xl`
  (≤1100px, default) e `full` (ocupa a viewport menos `48px` de margem). Diferente do
  `ContentModal`, não existem `sm`/`md`; a menor opção aqui (`lg`) já é larga porque o
  componente pressupõe duas colunas lado a lado.
- **Fechamento sempre habilitado**: o `ModalOverlay` interno usa `isDismissable` fixo (não há
  prop `dismissible`) — clique fora do painel e tecla `Esc` **sempre** disparam `onClose`. Não
  há como travar o modal aberto (diferente do `ContentModal`).
- **Botão de fechar (`X`)**: `IconButton` fixo no header (`size="sm"`, `variant="ghost"`,
  `aria-label="Fechar"` fixo, não configurável) que chama `onClose`.
- **Colunas**: grid `1fr 1fr` de altura igual; cada coluna tem rolagem própria
  (`overflow: auto` no corpo), então o conteúdo de `leftPanel` e `rightPanel` pode ter alturas
  diferentes sem quebrar o layout. A coluna esquerda tem uma borda divisória à direita.
- **Rótulos das colunas (`leftLabel`/`rightLabel`)**: com o default `''`, o cabeçalho da coluna
  correspondente simplesmente não é renderizado — só o `colBody` aparece. Passe uma string
  para exibir o rótulo.
- **Footer — resolução automática, e agora condicional na íntegra**:
  - A barra do footer só é renderizada quando `ghostLabel` é truthy **ou** (`primaryLabel`
    **e** `onConfirm`) são truthy — com todos os defaults vazios, `<SplitModal>` sem nenhuma
    dessas props **não renderiza footer nenhum** (nem a faixa vazia).
  - `ghostLabel` **e** `primaryLabel` **e** `onConfirm` todos presentes/truthy → renderiza um
    único `DoubleButton` (`layout="horizontal"`, `pair="primary-ghost"` **fixo**, `size="md"`),
    com `onPrimary={onConfirm}` e `onSecondary={onClose}`. Diferente do `ContentModal`, o
    `pair` **não** é inferido — é sempre `primary-ghost`, não há como obter um par
    `destructive-ghost` por essa via.
  - Caso contrário, cada ação é avaliada isoladamente: `ghostLabel` truthy renderiza um
    `Button` avulso (`variant="ghost"`) chamando `onClose`; `primaryLabel` **e** `onConfirm`
    truthy renderizam um `Button` avulso (`variant="primary"`) chamando `onConfirm`. Por
    exemplo, passar apenas `primaryLabel` + `onConfirm` (sem `ghostLabel`) produz **só** o
    botão primário.

---

## Exemplos

```tsx
import { useState } from 'react';
import { SplitModal, Button } from '@srm/diamond';

// Básico — revisão de PDF com formulário de assinatura ao lado
function RevisarContrato() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setIsOpen(true)}>Revisar contrato</Button>
      <SplitModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Revisar contrato de câmbio"
        leftLabel="Documento"
        rightLabel="Assinatura"
        leftPanel={<VisualizadorPdf src={contratoUrl} />}
        rightPanel={<FormularioAssinatura />}
        primaryLabel="Assinar"
        ghostLabel="Cancelar"
        onConfirm={handleAssinar}
      />
    </>
  );
}

// Tamanho "full" — conteúdo extenso, ocupa quase toda a viewport
<SplitModal
  isOpen={isOpen}
  onClose={onClose}
  size="full"
  title="Comparar extrato original e ajuste proposto"
  leftLabel="Extrato original"
  rightLabel="Ajuste proposto"
  leftPanel={<ExtratoOriginal />}
  rightPanel={<ExtratoAjustado />}
  primaryLabel="Aprovar ajuste"
  onConfirm={handleAprovar}
/>

// Somente ação de confirmação (sem cancelar) — ghostLabel omitido/vazio
<SplitModal
  isOpen={isOpen}
  onClose={onClose}
  title="Termo de ciência"
  leftPanel={<TextoDoTermo />}
  rightPanel={<ResumoDosPontos />}
  primaryLabel="Estou ciente"
  onConfirm={handleCiencia}
/>

// Sem coluna de rótulos (leftLabel/rightLabel omitidos — já são '' por default)
<SplitModal
  isOpen={isOpen}
  onClose={onClose}
  dialogAriaLabel="Revisão de documento"
  leftPanel={<VisualizadorPdf src={docUrl} />}
  rightPanel={<DetalhesDaOperacao />}
  primaryLabel="Confirmar"
  onConfirm={handleConfirmar}
/>
```

### Integração com formulário (React Hook Form) no painel direito

```tsx
import { useForm, Controller } from 'react-hook-form';
import { SplitModal, CurrencyInput } from '@srm/diamond';

function ModalConfirmarAporte({ isOpen, onClose, onSubmitAporte }: Props) {
  const { control, handleSubmit } = useForm({ defaultValues: { valor: '' } });

  return (
    <SplitModal
      isOpen={isOpen}
      onClose={onClose}
      title="Confirmar aporte"
      leftLabel="Documento"
      rightLabel="Valor do aporte"
      leftPanel={<VisualizadorPdf src={termoUrl} />}
      rightPanel={
        <Controller
          name="valor"
          control={control}
          render={({ field, fieldState }) => (
            <CurrencyInput
              label="Valor"
              value={field.value}
              onChange={field.onChange}
              state={fieldState.error ? 'error' : 'default'}
              errorText={fieldState.error?.message}
            />
          )}
        />
      }
      primaryLabel="Confirmar aporte"
      ghostLabel="Cancelar"
      onConfirm={handleSubmit(onSubmitAporte)}
    />
  );
}
```

---

## Acessibilidade

- O `Dialog` interno é associado automaticamente ao título via `Heading slot="title"` quando
  `title` é informado (padrão do `react-aria-components`); sempre passe um `title` ou
  `dialogAriaLabel` descritivo do que está sendo revisado — sem nenhum dos dois, o dialog cai
  no fallback genérico `'Conteúdo'`, pouco descritivo para leitores de tela em produção.
- Foco é preso dentro do modal e retorna ao elemento disparador ao fechar — comportamento
  padrão do `Modal`/`Dialog` do react-aria, sem configuração adicional.
- O botão de fechar (`X`) já tem `aria-label="Fechar"` fixo.
- Como o modal é **sempre dismissível** (não há flag para bloquear `Esc`/clique-fora), não use
  `SplitModal` para fluxos que exigem confirmação obrigatória e irreversível antes de fechar —
  o usuário sempre pode sair sem confirmar nada.
- Garanta que `leftPanel`/`rightPanel` tenham sua própria hierarquia semântica interna (ex.:
  `<iframe title="...">` para PDFs, labels em campos de formulário) — o `SplitModal` não injeta
  semântica nenhuma no conteúdo das colunas.

## Armadilhas comuns

- **Todos os textos de domínio são opt-in agora**: esquecer de passar `title`, `leftLabel`,
  `rightLabel`, `primaryLabel` ou `ghostLabel` não produz mais um texto padrão em português —
  produz **ausência** do elemento (sem título visível, sem rótulo de coluna, sem botão). Não
  assuma nenhum texto de fallback amigável nessas props; forneça-as explicitamente.
- Esperar um `DoubleButton` "destructive-ghost" ao usar `variant` na ação não existe aqui — não
  há prop de `variant` por ação como no `ContentModal`; o par do `DoubleButton` é sempre
  `primary-ghost` quando as três condições (ghost + primary + onConfirm) são atendidas.
- A barra do footer só aparece quando há pelo menos um botão a exibir (`ghostLabel` ou
  `primaryLabel`+`onConfirm`) — diferente de versões anteriores deste componente, não há mais
  uma faixa de footer vazia sempre visível.
- Sem breakpoint responsivo: em telas estreitas as duas colunas continuam lado a lado
  (`1fr 1fr`), apenas espremidas — não use este componente como modal principal de fluxos
  mobile-first.
- `onClose` é chamado tanto pelo `X` quanto por `Esc`/clique-fora **quanto** pelo botão
  ghost/cancelar — não assuma que `onClose` só dispara por interação explícita do rodapé.
- `size="full"` ainda respeita a margem de `48px` da viewport (`calc(100vw - 48px)` /
  `calc(100vh - 48px)`) — não é um modal "edge-to-edge" verdadeiro.
- `dialogAriaLabel` só tem efeito quando `title` está vazio — passar os dois ao mesmo tempo faz
  o `title` prevalecer como nome acessível (`title || dialogAriaLabel`).
