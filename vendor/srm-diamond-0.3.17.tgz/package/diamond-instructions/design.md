# Diamond Design System — Guia de Design Tokens e Estilos

**Pacote:** `@srm/diamond` | **Versão mínima:** `0.3.0`

> Este guia cobre todos os tokens CSS disponíveis após importar `@srm/diamond/styles` e como utilizá-los para construir layouts consistentes com o Design System da SRM Asset.

---

## Índice

- [Como usar os tokens](#como-usar-os-tokens)
- [Cores — Primitivas](#cores--primitivas)
- [Cores — Semânticas](#cores--semânticas)
- [Tipografia](#tipografia)
- [Espaçamento](#espaçamento)
- [Bordas e Raios](#bordas-e-raios)
- [Sombras](#sombras)
- [Z-Index](#z-index)
- [Animações e Transições](#animações-e-transições)
- [Dimensões de Componentes](#dimensões-de-componentes)
- [Sistema de Temas](#sistema-de-temas)
- [Breakpoints e Layout](#breakpoints-e-layout)

---

## Como usar os tokens

Após importar os estilos da lib, todos os tokens ficam disponíveis como CSS custom properties no `:root`. Use-os diretamente em qualquer CSS/SCSS do seu projeto:

```tsx
// main.tsx — uma única vez
import '@srm/diamond/styles';
```

```css
/* Seu CSS */
.my-card {
  background: var(--surface-subtle);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-xl);
  padding: var(--padding-card);
  box-shadow: var(--shadow-card);
  color: var(--text-primary);
}

.my-heading {
  font-size: var(--text-heading-md);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary);
  line-height: var(--leading-tight);
}
```

```tsx
// Inline styles em React
<div style={{ color: 'var(--text-secondary)', fontSize: 'var(--text-body)' }}>
  Texto secundário
</div>
```

**SCSS:** se você importar via `@srm/diamond/scss`, os tokens são variáveis SCSS nativas e podem ser usados com interpolação:

```scss
@use '@srm/diamond/scss' as ds;

.card {
  background: ds.$surface-subtle; // alternativa SCSS
  // ou com CSS custom properties (recomendado):
  color: var(--text-primary);
}
```

---

## Cores — Primitivas

Paleta base. Prefira os **tokens semânticos** para código de produto — as primitivas existem para construir tokens customizados.

### Brand Primary (navy blue)

```css
--primary-50   /* #f0f5fd — background extra-suave */
--primary-100  /* azul muito claro — background de seleção leve */
--primary-200
--primary-300
--primary-400
--primary-500  /* azul médio */
--primary-600
--primary-700
--primary-800  /* #1d3f80 — brand primário */
--primary-900  /* #081e47 — azul mais escuro */
```

### Brand Accent (laranja)

O accent é exclusivamente de preenchimento — **nunca use laranja em textos**.

```css
--accent-100   /* #ffe6cc */
--accent-200   /* #ffd4a3 */
--accent-500   /* #ff8200 — accent principal */
--accent-700   /* #cc6600 */
--accent-900   /* #7a3d00 */
```

### Neutros

```css
--neutral-0    /* #ffffff */
--neutral-50   /* quase branco */
--neutral-100
--neutral-200
--neutral-300
--neutral-400
--neutral-500  /* #6b7280 — cinza médio */
--neutral-700
--neutral-900
--neutral-950  /* #0c0c0c — quase preto */
```

### Feedback (Green, Red, Amber, Teal)

Escala de 50 a 900 para cada cor semântica:
- **Green** → `--green-50` a `--green-900`
- **Error/Red** → `--error-50` a `--error-900`
- **Amber/Warning** → `--amber-50` a `--amber-900`
- **Teal/Info** → `--teal-50`, `--teal-100`, `--teal-200`, `--teal-300`, `--teal-500`, `--teal-700`, `--teal-900`

### Alpha (transparências)

```css
/* Branco alpha */
--white-a08  /* rgba(255,255,255, 0.08) */
--white-a16
--white-a24
--white-a32
--white-a48
--white-a64
--white-a88

/* Error alpha */
--error-a07
--error-a12
--error-a18
--error-a35

/* Accent alpha */
--accent-a07
--accent-a12
--accent-a35
```

---

## Cores — Semânticas

Estes são os tokens que você deve usar no código de produto. Eles mudam automaticamente no dark mode e nos temas de marca.

### Brand

```css
--brand-primary          /* #1d3f80 — azul principal */
--brand-primary-hover    /* #163268 */
--brand-primary-light    /* var(--primary-100) */
--brand-secondary        /* #122b5c */
--brand-accent           /* #ff8200 — laranja */
--brand-accent-hover
--brand-accent-light
--brand-accent-strong

/* Transparências do brand */
--brand-primary-a10
--brand-primary-a15
--brand-primary-a20
--brand-primary-a35
--brand-primary-a45

/* Overlay */
--overlay-dark-a45
--overlay-dark-a60
--overlay-dark-a80
```

### Texto

```css
--text-primary           /* cor padrão de texto — use em títulos e corpo */
--text-secondary         /* cinza médio — use em subtítulos, labels */
--text-tertiary          /* ainda mais sutil */
--text-on-brand          /* branco — texto sobre fundo brand */
--text-on-accent         /* branco — texto sobre fundo accent */
--text-disabled          /* cinza claro — estado desabilitado */
--text-brand             /* azul brand — links, destaques em fundo branco */
--text-on-image          /* texto sobre imagem/fotografia */
--text-on-image-subtle
```

```css
/* Exemplos de uso */
.page-title    { color: var(--text-primary); }
.helper-text   { color: var(--text-secondary); }
.link          { color: var(--text-brand); }
.disabled-text { color: var(--text-disabled); }
```

### Ícones

```css
--icon-default           /* cor padrão de ícones */
--icon-primary           /* azul brand para ícones de destaque */
--icon-success           /* verde */
--icon-warning           /* âmbar */
--icon-error             /* vermelho */
--icon-inverse           /* branco — ícone sobre fundo escuro */
```

### Superfícies (backgrounds)

```css
--surface-default        /* branco — background de cards e modais */
--surface-subtle         /* quase branco — background de páginas */
--surface-muted          /* #e2e6ef — background de seções destacadas */
--surface-brand          /* azul brand — header, CTAs */
--surface-inverse        /* #1e2b44 — dark card em contexto claro */
--surface-canvas         /* #f8f9fb — background geral da aplicação */
--surface-hover          /* hover sobre item clicável */
--surface-selected       /* item selecionado em lista */
```

```css
/* Padrão de uso */
body           { background: var(--surface-canvas); }
.card          { background: var(--surface-default); }
.section-bg    { background: var(--surface-subtle); }
.header        { background: var(--surface-brand); }
```

### Bordas

```css
--border-default         /* borda sutil padrão */
--border-medium          /* borda mais visível */
--border-strong          /* borda destacada */
--border-brand           /* borda azul brand */
--border-error           /* borda de erro */
--border-selected        /* borda de item selecionado */
--border-subtle          /* borda mínima */
```

### Feedback

```css
--feedback-success       /* verde — cor do texto de sucesso */
--feedback-success-bg    /* verde claro — background de callout sucesso */
--feedback-success-text  /* texto sobre background de sucesso */

--feedback-warning       /* âmbar */
--feedback-warning-bg

--feedback-error         /* vermelho */
--feedback-error-bg

--feedback-info          /* teal/azul info */
--feedback-info-bg

--status-pending         /* âmbar de pendente */
```

### AI/Concierge

```css
--ai-surface
--ai-accent
--ai-muted
--ai-color
--ai-bg
```

### Avatar (paleta de 10 cores)

Usada para gerar automaticamente a cor de fundo dos avatars com base no nome do usuário.

```css
--avatar-blue    --avatar-green     --avatar-purple
--avatar-amber   --avatar-crimson   --avatar-teal
--avatar-navy    --avatar-rose      --avatar-slate
--avatar-indigo
```

### Interação (estados hover/active/focus)

```css
/* Botão primário */
--interactive-primary-active

/* Botão secundário */
--interactive-secondary
--interactive-secondary-hover
--interactive-secondary-active
--interactive-on-secondary

/* Accent */
--interactive-accent-hover
--interactive-accent-active
--interactive-accent-light

/* Danger/Destructive */
--interactive-danger
--interactive-danger-hover
--interactive-danger-active

/* Ghost */
--interactive-ghost-hover
--interactive-ghost-active
```

### Focus rings (acessibilidade)

```css
--focus-ring              /* ring padrão */
--focus-ring-brand        /* ring azul brand */
--focus-ring-error        /* ring vermelho */
--focus-ring-error-input  /* ring de erro em inputs */
--focus-ring-accent       /* ring laranja */
```

### Navegação dark (elementos sobre fundo brand)

```css
--nav-dark-bg
--nav-dark-bg-hover
--nav-dark-bg-active
--nav-dark-border
--nav-dark-text
--nav-dark-text-label
```

### Gradientes

```css
--grad-btn        /* gradiente do botão primário */
--grad-btn-hover
--grad-header     /* gradiente do header brand */
--grad-divider    /* linha divisória com fade */
--grad-overlay    /* overlay de imagem */
--grad-brand
--grad-ai         /* gradiente AI (roxo para azul) */
```

### Gráficos

```css
--chart-1   --chart-2   --chart-3
--chart-4   --chart-5   --chart-6
--chart-negative   /* vermelho para valores negativos */
--chart-grid       /* cor das linhas de grid */
```

---

## Tipografia

```css
/* Famílias */
--font-sans    /* 'Inter', system fallback — use em todo texto de UI */
--font-mono    /* 'JetBrains Mono' — use em código, CPF, CNPJ, valores */
```

```css
/* Escala de tamanhos */
--text-8:   8px
--text-10:  10px
--text-11:  11px
--text-12:  12px
--text-13:  13px
--text-14:  14px
--text-16:  16px
--text-18:  18px
--text-20:  20px
--text-24:  24px
--text-28:  28px
--text-32:  32px
--text-36:  36px
--text-40:  40px
--text-48:  48px
```

```css
/* Aliases semânticos — USE ESTES no código de produto */
--text-body:       14px   /* corpo de texto padrão */
--text-body-sm:    13px   /* texto menor */
--text-body-xs:    12px   /* texto mínimo */
--text-caption:    11px   /* legenda */
--text-label:      12px   /* label de formulário */
--text-label-sm:   11px
--text-heading-sm: 16px   /* título de seção */
--text-heading-md: 20px   /* título de card */
--text-heading-lg: 24px   /* título de página */
--text-display:    32px   /* display/hero */
--text-eyebrow:    10px   /* eyebrow uppercase */
--text-mono:       13px   /* valores numéricos */
```

```css
/* Pesos */
--font-weight-regular:  400
--font-weight-medium:   500
--font-weight-semibold: 600
--font-weight-bold:     700
```

```css
/* Estilos compostos (tamanho + peso) */
--ts-body-md       /* 14px / 400 */
--ts-body-sm       /* 13px / 400 */
--ts-label-md      /* 12px / 500 */
--ts-label-sm      /* 11px / 600 */
--ts-caption       /* 11px / 400 */
--ts-heading-sm    /* 16px / 700 */
--ts-heading-md    /* 20px / 700 */
--ts-heading-lg    /* 24px / 800 */
--ts-eyebrow       /* 10px / 700 */
--ts-mono          /* 13px / 500 */
```

```css
/* Line heights */
--leading-dense:   1.10
--leading-tight:   1.15
--leading-compact: 1.25
--leading-snug:    1.30
--leading-normal:  1.50
--leading-loose:   1.60
```

```css
/* Letter spacing */
--tracking-eyebrow:  0.5px
--tracking-nav:      0.33px
--tracking-tight:    0.01em
--tracking-widened:  0.06em
```

**Exemplo de uso:**
```css
.page-title {
  font-family: var(--font-sans);
  font-size: var(--text-heading-lg);
  font-weight: var(--font-weight-bold);
  line-height: var(--leading-tight);
  color: var(--text-primary);
  letter-spacing: var(--tracking-tight);
}

.eyebrow {
  font-size: var(--text-eyebrow);
  font-weight: var(--font-weight-bold);
  text-transform: uppercase;
  letter-spacing: var(--tracking-eyebrow);
  color: var(--text-secondary);
}

.amount {
  font-family: var(--font-mono);
  font-size: var(--text-heading-md);
  font-weight: var(--font-weight-semibold);
}
```

---

## Espaçamento

### Escala primitiva (base 4px)

```css
--space-1:   4px
--space-2:   8px
--space-3:   12px
--space-4:   16px
--space-5:   20px
--space-6:   24px
--space-7:   28px
--space-8:   32px
--space-9:   36px
--space-10:  40px
--space-11:  44px
--space-12:  48px
--space-13:  52px
--space-14:  56px
```

### Layout — Página

```css
--padding-page:        56px   /* padding horizontal de página desktop */
--padding-page-mobile: 20px   /* padding horizontal mobile */
--padding-section:     40px   /* padding interno de seções */
--gap-section:         32px   /* gap entre seções */
```

### Layout — Cards

```css
--padding-card:    24px   /* padding interno de card padrão */
--padding-card-sm: 16px   /* padding de card compacto */
--gap-card:        16px   /* gap entre cards em grid */
--gap-card-lg:     24px   /* gap maior entre cards */
```

### Layout — Formulários

```css
--gap-form:        16px   /* gap entre campos de formulário */
--gap-form-group:  24px   /* gap entre grupos de formulário */
--gap-form-inline: 8px    /* gap em campos inline */
```

### Dimensões de componentes de layout

```css
--modal-width:      540px
--drawer-width:     45vw
--drawer-width-sm:  30vw
--drawer-width-lg:  65vw

--nav-height:         80px  /* header desktop */
--nav-height-scroll:  64px  /* header compactado ao scroll */
--bottom-nav-height:  64px  /* nav mobile bottom */
--app-header-height:  56px  /* header mobile */
```

### Dimensões de tabelas

```css
--height-row-compact:   40px
--height-row-md:        56px
--height-table-header:  44px
--height-pagination:    52px
```

---

## Bordas e Raios

### Espessuras

```css
--border-width-sm:  1px
--border-width-md:  1.5px
--border-width-lg:  2px
--border-width-xl:  3px
```

### Raios de borda

```css
--radius-none:  0
--radius-xxs:   2px
--radius-xs:    2px
--radius-sm:    4px
--radius-md:    6px
--radius-lg:    8px
--radius-xl:    12px
--radius-2xl:   16px
--radius-3xl:   24px
--radius-full:  9999px  /* círculo / pill */
```

### Aliases de componentes

```css
--radius-button:  6px    /* var(--radius-md) */
--radius-input:   8px    /* var(--radius-lg) */
--radius-card:    20px
--radius-modal:   24px
```

---

## Sombras

### Elevação

```css
--shadow-sm:   0 1px 3px rgba(0,0,0,.08)
--shadow-md:   0 4px 12px rgba(0,0,0,.12)
--shadow-lg:   0 8px 24px rgba(0,0,0,.16)
--shadow-xl:   0 20px 40px rgba(0,0,0,...)
```

### Componentes

```css
--shadow-card    /* sombra de card */
--shadow-drawer  /* sombra do drawer lateral */
--shadow-nav     /* sombra do header */
--shadow-thumb   /* sombra do thumb do slider */
--shadow-modal   /* 0px 20px 30px rgba(0,8,30,.30) */
```

### Especial

```css
--shadow-brand-glow  /* 0 4px 16px rgba(39,88,181,.45) — glow azul brand */
```

---

## Z-Index

```css
--z-base:          0
--z-dropdown:     50
--z-select:      100
--z-sticky:      200
--z-overlay:     500
--z-modal:      1000
--z-drawer:     1100
--z-notification: 1200
--z-tooltip:    1500
--z-toast:      9999
```

Use sempre os tokens para garantir que o stack de sobreposição seja consistente com os componentes do Diamond:

```css
.my-dropdown {
  z-index: var(--z-dropdown);
}

.my-sticky-header {
  z-index: var(--z-sticky);
}
```

---

## Animações e Transições

```css
/* Durações */
--duration-fast:   100ms
--duration-normal: 150ms
--duration-slow:   200ms
--duration-slower: 300ms

/* Easings */
--easing-default:  ease
--easing-standard: cubic-bezier(0.4, 0, 0.2, 1)   /* Material-like */
--easing-spring:   cubic-bezier(0.16, 1, 0.3, 1)   /* Spring/bounce */
```

```css
/* Exemplo de transição consistente com o DS */
.my-element {
  transition: background var(--duration-normal) var(--easing-standard),
              transform  var(--duration-slow)   var(--easing-spring);
}
```

---

## Dimensões de Componentes

### Botões

```css
--height-button-sm:  32px
--height-button-md:  40px
--height-button-lg:  48px
```

### Inputs

```css
--height-input:      44px
--input-height-sm:   40px
--input-height-md:   48px
--dropdown-max-height: 240px
```

### Ícones

```css
--icon-xs:   10px
--icon-sm:   14px
--icon-md:   18px
--icon-lg:   24px
--icon-xl:   32px
```

### Avatars

```css
--avatar-size-xs:   20px
--avatar-size-sm:   24px
--avatar-size-md:   32px
--avatar-size-lg:   40px
--avatar-size-xl:   48px
--avatar-size-2xl:  80px
```

### Opacidades

```css
--opacity-disabled:  0.50   /* elementos desabilitados */
--opacity-subtle:    0.60
--opacity-overlay:   0.70   /* overlay de fundo */
```

---

## Sistema de Temas

### Dark Mode

Ativado via atributo HTML. Os tokens semânticos (surface, text, border, etc.) mudam automaticamente.

```ts
// Ativar dark mode
document.documentElement.setAttribute('data-theme', 'dark');

// Desativar (voltar para light)
document.documentElement.removeAttribute('data-theme');
// ou:
document.documentElement.setAttribute('data-theme', 'light');
```

```tsx
// Hook de exemplo
function useTheme() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  return { isDark, toggle: () => setIsDark(d => !d) };
}
```

**O que muda no dark mode:** `--surface-*`, `--text-*`, `--border-*`, `--icon-*`, `--feedback-*`, `--interactive-*`, `--focus-ring-*`, gradientes, sombras e estados de hover/active de todos os componentes.

### Multi-brand

O Diamond suporta múltiplas marcas. Ative sobrescrevendo os tokens de brand:

```ts
// SRM Trust (plataforma PF — navy mais escuro + accent azul)
document.documentElement.setAttribute('data-brand', 'trust');

// HB Digital (accent laranja quente)
document.documentElement.setAttribute('data-brand', 'hb-digital');

// SRM Asset padrão (nenhum atributo ou remover)
document.documentElement.removeAttribute('data-brand');
```

São três marcas disponíveis. A **SRM Asset** é o padrão — não requer nenhum atributo e usa navy `#1d3f80` com accent laranja `#ff8200`. A **SRM Trust** (`data-brand="trust"`) é voltada à plataforma PF e apresenta navy mais escuro `#1a5276` com accent azul `#2e86c1`. O **HB Digital** (`data-brand="hb-digital"`) mantém a estrutura SRM com accent laranja quente `#e67e22`.

---

## Breakpoints e Layout

### Breakpoints CSS

```css
--breakpoint-sm:   480px
--breakpoint-md:   768px
--breakpoint-lg:  1024px
--breakpoint-xl:  1280px
--breakpoint-2xl: 1440px
```

```css
/* Uso em media queries do seu projeto */
@media (max-width: 768px) {
  .page-content {
    padding: var(--padding-page-mobile);
  }
}

@media (min-width: 1024px) {
  .sidebar {
    width: var(--drawer-width);
  }
}
```

### Padrão de layout de página recomendado

```css
.app-layout {
  min-height: 100vh;
  background: var(--surface-canvas);
  display: flex;
  flex-direction: column;
}

.page-content {
  flex: 1;
  padding: var(--padding-section) var(--padding-page);
  max-width: var(--breakpoint-2xl);
  margin: 0 auto;
  width: 100%;
}

@media (max-width: 768px) {
  .page-content {
    padding: var(--space-6) var(--padding-page-mobile);
  }
}
```

### Grid de cards padrão

```css
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: var(--gap-card-lg);
}
```

### Card padrão

```css
.card {
  background: var(--surface-default);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-card);
  padding: var(--padding-card);
  box-shadow: var(--shadow-card);
}

.card:hover {
  background: var(--surface-hover);
}
```

---

## Referência rápida — tokens mais usados

```css
/* Backgrounds */
var(--surface-canvas)         /* fundo da página */
var(--surface-default)        /* cards, modais */
var(--surface-subtle)         /* seções destacadas */
var(--surface-brand)          /* header, CTAs */

/* Texto */
var(--text-primary)           /* texto principal */
var(--text-secondary)         /* texto auxiliar, labels */
var(--text-brand)             /* links, destaques */

/* Bordas */
var(--border-default)         /* borda padrão */
var(--border-brand)           /* borda de foco/seleção */
var(--border-error)           /* borda de erro */

/* Raios */
var(--radius-lg)              /* inputs */
var(--radius-xl)              /* cards compactos */
var(--radius-card)            /* cards */
var(--radius-modal)           /* modais */
var(--radius-full)            /* chips, badges */

/* Sombras */
var(--shadow-card)            /* card em repouso */
var(--shadow-modal)           /* modal/drawer */

/* Espaçamento */
var(--gap-form)               /* entre campos */
var(--padding-card)           /* dentro do card */
var(--padding-page)           /* página desktop */
var(--padding-page-mobile)    /* página mobile */

/* Tipografia */
var(--text-body)              /* 14px — corpo */
var(--text-heading-md)        /* 20px — título de card */
var(--font-weight-bold)       /* 700 */
var(--leading-normal)         /* 1.5 — corpo */
var(--font-mono)              /* JetBrains Mono — valores numéricos */

/* Animação */
var(--duration-normal)        /* 150ms */
var(--easing-standard)        /* cubic-bezier padrão */
```
