# PhoneInput

Campo de entrada para números de telefone brasileiros. Aplica máscara dinâmica que alterna
automaticamente entre o formato fixo (`(00) 0000-0000`, 8 dígitos) e o formato celular
(`(00) 00000-0000`, 9 dígitos) conforme a quantidade de dígitos digitados. Construído sobre
`InputBase` (herda label, estados, temas e mensagens) e sobre a ponte de máscara
`IMaskBridge` (imask / react-imask).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/PhoneInput/`
- **Export:** `import { PhoneInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [TextInput](./TextInput.md)

---

## Quando usar

- Captura de telefone/celular de cliente, contato de referência, procurador ou beneficiário
  em cadastros e formulários de onboarding.
- Sempre que o número deva ser exibido/digitado já formatado com DDD entre parênteses,
  sem o usuário precisar digitar parênteses, espaço ou hífen.
- Aceita tanto telefone fixo (8 dígitos) quanto celular (9 dígitos) no mesmo campo, sem
  necessidade de um seletor de tipo.

## Quando **não** usar

- Números internacionais (com código de país, `+55` etc.) — este componente é fixo para o
  padrão brasileiro de 10/11 dígitos; para telefone internacional monte um `TextInput` com
  máscara própria.
- Documentos ou códigos numéricos sem semântica telefônica → use [`TextInput`](./TextInput.md)
  com `inputMode="numeric"`.
- Valores monetários ou percentuais → [`CurrencyInput`](./CurrencyInput.md) /
  [`PercentInput`](./PercentInput.md).

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface PhoneInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string mascarada, ex.: "(11) 90000-0000")
  placeholder?: string;                    // default: '(11) 90000-0000'
  onChange?: (value: string) => void;      // recebe a string SEM máscara (apenas dígitos, unmask=true)
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por imask com uma máscara **dinâmica** (array de duas opções),
definida em `PhoneInput.constants.ts`:

```ts
{ mask: [{ mask: '(00) 0000-0000' }, { mask: '(00) 00000-0000' }] }
```

- O `IMaskBridge` alterna automaticamente entre as duas máscaras conforme o número de
  dígitos digitados: até 10 dígitos usa `(00) 0000-0000` (fixo); ao digitar o 11º dígito,
  passa a usar `(00) 00000-0000` (celular). O usuário não escolhe o formato — ele emerge
  da quantidade de dígitos digitados.
- O `IMaskBridge` é configurado com **`unmask={true}`**: diferente de `CurrencyInput` e
  `PercentInput`, `onChange` (mapeado internamente para `onAccept`) recebe **apenas os
  dígitos**, sem parênteses/espaço/hífen (ex.: digitando `(11) 90000-0000` na tela,
  `onChange` recebe `"11900000000"`).
- O `value` controlado, no entanto, deve ser passado **sem máscara** (só dígitos) pelo
  mesmo motivo — é o mesmo formato que `onChange` entrega, então o ciclo controlado
  funciona diretamente com dígitos puros (ex.: `value="11900000000"` é exibido como
  `(11) 90000-0000`).
- Não há prefixo/sufixo decorativo (diferente de `CurrencyInput`/`PercentInput`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { PhoneInput } from '@srm/diamond';

// Básico (controlado)
function TelefoneField() {
  const [telefone, setTelefone] = useState('');
  return <PhoneInput label="Telefone" value={telefone} onChange={setTelefone} />;
}

// Com ajuda e obrigatório
<PhoneInput label="Celular" required helperText="Usaremos para confirmar operações." />

// Estado de erro
<PhoneInput
  label="Telefone de contato"
  state="error"
  errorText="Informe um telefone válido."
  value={telefone}
  onChange={setTelefone}
/>

// Somente leitura
<PhoneInput label="Telefone cadastrado" state="read-only" value="11900000000" />

// Tema escuro (sobre header brand)
<PhoneInput label="WhatsApp" theme="dark" value={telefone} onChange={setTelefone} />
```

### Integração com React Hook Form

```tsx
<Controller
  name="telefone"
  control={control}
  render={({ field, fieldState }) => (
    <PhoneInput
      label="Telefone"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- O placeholder padrão (`(11) 90000-0000`) demonstra o formato celular — não é anunciado
  como valor pelos leitores de tela; mantenha `label`/`helperText` descritivos sobre o
  formato esperado quando necessário.

## Armadilhas comuns

- **Não** trate `value`/`onChange` como a string formatada visualmente — por causa de
  `unmask={true}`, ambos trafegam **só dígitos** (`"11900000000"`, não `"(11) 90000-0000"`).
  Isso é diferente de `CurrencyInput`/`PercentInput`, que entregam a string mascarada.
- **Não** tente forçar formato fixo ou celular manualmente — a máscara escolhe sozinha
  com base na quantidade de dígitos; não há prop para fixar um dos dois formatos.
- Ao popular `value` a partir de dados vindos da API, envie apenas os dígitos (remova
  qualquer `(`, `)`, espaço ou `-` que já venha salvo no backend).
- Este componente não faz validação de DDD ou de número válido — se precisar validar,
  faça isso na camada de schema (ex.: Zod) usando o valor de dígitos entregue por `onChange`.
