# AvatarSRM

Círculo de marca: exibe o ícone da logo SRM (`LogoIcon` de `@srm/diamond` Brand/Logo)
centralizado sobre um fundo circular, em vez de iniciais de pessoa. Usado para representar
"a SRM" (colaborador interno, conta institucional, remetente do sistema) em contraste com
`Avatar`, que representa pessoas/empresas por iniciais. `AvatarSRM` é um wrapper de
conveniência sobre `ColabCircle`, que também é exportado publicamente para controle fino
de tamanho.

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/Avatar/AvatarSRM.tsx`, `src/components/Identity/Avatar/ColabCircle.tsx`
- **Export:** `import { AvatarSRM, ColabCircle } from '@srm/diamond';`
- **Relacionados:** [Avatar](./Avatar.md) (iniciais de pessoa/empresa), [AvatarDropdown](./AvatarDropdown.md) (`AvatarColaborador` usa `ColabCircle` internamente), [AvatarStatic](./AvatarStatic.md) (`AvatarColaboradorStatic` usa `ColabCircle` internamente)

---

## Quando usar

- Indicar que uma ação, mensagem ou registro parte da **SRM como instituição** (não de
  um colaborador nomeado) — ex.: notificações do sistema, comentários automáticos, rodapé
  de e-mail transacional renderizado em tela.
- Compor cabeçalhos/menus de "conta do colaborador" quando o padrão pronto
  (`AvatarColaborador` em [AvatarDropdown](./AvatarDropdown.md), ou `AvatarColaboradorStatic`
  em [AvatarStatic](./AvatarStatic.md)) não se aplica e você precisa só do círculo isolado.
- Usar `ColabCircle` diretamente quando precisar de um tamanho em pixels que não é um dos
  seis steps de `AvatarSize` (`AvatarSRM` só aceita os steps nomeados).

## Quando **não** usar

- Representar uma pessoa ou empresa por iniciais → [`Avatar`](./Avatar.md).
- Precisa de um trigger com menu dropdown → use `AvatarColaborador` em
  [AvatarDropdown](./AvatarDropdown.md) (já inclui `ColabCircle` + texto + chevron + menu).
- Precisa de avatar + duas linhas de texto sem menu → use `AvatarColaboradorStatic` em
  [AvatarStatic](./AvatarStatic.md).

---

## Interface

```ts
type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'collab';
type ColaboradorAppearance = 'circular' | 'sutil';

interface AvatarSRMProps {
  size?: AvatarSize;                  // default: 'md' — mapeado para px via AVATAR_SRM_PX
  appearance?: ColaboradorAppearance; // default: 'circular'
}

interface ColabCircleProps {
  appearance?: ColaboradorAppearance; // default: 'circular'
  size?: number;                      // default: 32 (COLAB_CIRCLE_SIZE) — em pixels, livre
  isDark?: boolean;                   // default: false
}
```

### Notas de comportamento

- `AvatarSRM` **não** tem prop `isDark` nem `className` — é somente `ColabCircle` com
  tamanho pré-calculado. Se precisar de `isDark` ou tamanho arbitrário, use `ColabCircle`
  diretamente.
- Mapeamento de `AvatarSRM.size` → pixels (`AVATAR_SRM_PX`, em `Avatar.constants.ts`):
  `xs: 20, sm: 24, md: 32, lg: 40, xl: 48, collab: 36`.
- `appearance="circular"` (default): fundo `var(--brand-primary)`, logo preenchida com
  `var(--surface-default)` (contraste claro sobre o brand).
- `appearance="sutil"`: fundo `var(--brand-primary-light)`, logo preenchida com
  `var(--brand-primary)` — visual mais discreto, para contextos onde o círculo cheio
  chamaria atenção demais.
- O tamanho do ícone da logo dentro do círculo é sempre `size * 0.52` (`COLAB_LOGO_RATIO`),
  arredondado — não é configurável separadamente do círculo.
- `isDark` (só em `ColabCircle`) adiciona o mesmo anel de contraste inset usado por `Avatar`.
- Passar `size` igual ao default (`32`) em `ColabCircle` **não** aplica `width`/`height`
  inline (deixa o CSS module cuidar); qualquer valor diferente de `32` aplica
  `style={{ width, height }}` inline.

---

## Exemplos

```tsx
import { AvatarSRM, ColabCircle } from '@srm/diamond';

// Padrão, tamanho md
<AvatarSRM />

// Tamanho grande, aparência sutil
<AvatarSRM size="lg" appearance="sutil" />

// Sobre fundo escuro — precisa de ColabCircle para ter isDark
<div style={{ background: '#32353E', padding: 16 }}>
  <ColabCircle isDark />
</div>

// Tamanho livre em pixels (fora dos steps de AvatarSize)
<ColabCircle size={64} appearance="circular" />
```

---

## Acessibilidade

- Nenhum dos dois componentes aceita `aria-label`/`name` — o círculo é puramente
  decorativo (a logo já é reconhecível visualmente). Se o círculo for a única identificação
  de "remetente: SRM" em um contexto sem texto ao lado, envolva-o com um elemento que
  forneça um nome acessível (ex.: `<div role="img" aria-label="SRM Asset">`).
- O ícone interno (`LogoIcon`) é renderizado como SVG decorativo; não carrega `alt` próprio.

## Armadilhas comuns

- Tentar passar `isDark` ou `className` para `AvatarSRM` — a prop não existe na interface;
  use `ColabCircle` diretamente nesses casos.
- Confundir com `Avatar`: `AvatarSRM`/`ColabCircle` sempre mostram a **logo da SRM**, nunca
  iniciais de pessoa — não use como avatar genérico de usuário.
- Esperar que `size` de `ColabCircle` aceite os nomes de `AvatarSize` (`'md'`, `'lg'`...) —
  é um `number` em pixels, diferente da prop `size` de `AvatarSRM`.
