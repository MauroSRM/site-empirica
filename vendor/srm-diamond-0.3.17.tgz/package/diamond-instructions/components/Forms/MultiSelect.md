# MultiSelect

Campo de seleção **múltipla** (dropdown) sobre uma lista fixa de strings, com busca
client-side, resumo/contador no gatilho e ações em massa no rodapé do popover. Reproduz a
anatomia de campo do [`Select`](./Select.md) — quando fechados e vazios, os dois são
visualmente indistinguíveis. Construído sobre `DialogTrigger`, `Popover`, `Dialog`,
`Autocomplete`, `SearchField` e `ListBox` (`selectionMode="multiple"`) do
`react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/MultiSelect/`
- **Export:** `import { MultiSelect } from '@srm/diamond';`
- **Relacionados:** [Select](./Select.md) (mesma anatomia, seleção única),
  [Chip](./Chip.md) (para exibir a seleção **fora** do campo, ver Armadilhas comuns)

---

## Quando usar

- Escolha de **várias** opções textuais conhecidas — ex.: categorias de lançamento,
  classes de ativo, filtros de um relatório, permissões de um perfil.
- Quando a lista é grande o bastante para exigir filtro por texto (padrão: busca ligada).
- Quando a seleção precisa caber num campo de altura fixa, sem o campo crescer conforme
  o usuário marca itens.
- Filtros de dashboard/tabela em que "selecionar tudo o que casa com a busca" é um fluxo
  frequente.

## Quando **não** usar

- Escolha única → use [`Select`](./Select.md).
- Poucas opções (até ~5) todas visíveis ao mesmo tempo, sem economia de espaço → use
  um grupo de [`Checkbox`](./Checkbox.md), que evita o clique extra de abrir o popover.
- Opções que o usuário digita livremente (criar valores novos) — não há modo "creatable";
  `options` é uma lista fechada.
- Opções não-textuais (ícone + descrição, avatar, preço) — `options` é `string[]`; não há
  slot de render por item.
- Seleção que precisa ficar permanentemente visível como chips removíveis → renderize um
  [`ChipGroup`](./ChipGroup.md) **abaixo** do campo, alimentado por `value`.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';

type MultiSelectState = 'default' | 'error' | 'disabled' | 'open';
type MultiSelectSize  = 'sm' | 'md';
type MultiSelectTheme = 'default' | 'dark';

interface MultiSelectProps {
  state?: MultiSelectState;              // default: 'default'
  size?: MultiSelectSize;                // default: 'md'
  theme?: MultiSelectTheme;              // default: 'default'
  label?: ReactNode;
  placeholder?: string;                  // default: 'Selecione...' — gatilho vazio
  helperText?: ReactNode;
  errorText?: ReactNode;
  options?: string[];                    // default: []

  withSearch?: boolean;                  // default: true  ← difere do Select (false)
  searchPlaceholder?: string;            // default: 'Buscar...'
  searchAriaLabel?: string;              // default: 'Buscar opção'
  emptyText?: ReactNode;                 // default: 'Nenhuma opção encontrada'

  value?: string[];                      // controlado
  defaultValue?: string[];               // default: [] — não-controlado
  onChange?: (value: string[]) => void;  // sempre na ordem de `options`

  summaryThreshold?: number;             // default: 2
  summaryLabel?: (count: number) => string;  // default: (n) => `${n} selecionados`

  showSelectAll?: boolean;               // default: true
  showClear?: boolean;                   // default: true
  selectAllLabel?: string;               // default: 'Selecionar todos'
  clearLabel?: string;                   // default: 'Limpar'

  listAriaLabel?: string;                // aria-label do popover quando não há `label`
  fullWidth?: boolean;                   // default: false
  ref?: Ref<HTMLDivElement>;
}
```

### Notas de comportamento

- **O popover não fecha ao selecionar.** Diferente do `Select`, marcar um item mantém o
  painel aberto para o usuário continuar marcando. Fecha por `Esc`, clique fora ou clique
  no gatilho.
- **Cada opção tem uma caixa de seleção à esquerda**, não o check à direita do `Select` —
  é o que comunica "dá para marcar vários" antes mesmo do primeiro clique. A caixa é
  **visual**, não o componente [`Checkbox`](./Checkbox.md): ele renderiza um `<button>`
  próprio, e aninhá-lo na opção criaria dois alvos de clique disputando a mesma seleção.
  Os tokens são espelhados do `Checkbox` no tamanho `sm` (16px) — ao alterar a aparência
  do `Checkbox`, replique em `MultiSelect.module.scss`.
- **`onChange` emite na ordem de `options`, não na ordem de clique.** Selecionar "Gama" e
  depois "Alfa" emite `['Alfa', 'Gama']`. Isso torna o valor estável e comparável entre
  sessões — não use a ordem do array para inferir o que o usuário escolheu primeiro.
- **Resumo do gatilho**: vazio → `placeholder`; até `summaryThreshold` itens → rótulos
  concatenados por `, ` (truncados com ellipsis se não couberem); acima do threshold →
  `summaryLabel(n)`. O gatilho tem altura fixa (`size`), nunca cresce com a seleção.
- **A largura também é fixa: 240px**, ou 100% do container com `fullWidth`. É o que impede
  o campo de "pular" enquanto o usuário marca itens — o resumo muda de comprimento a cada
  clique, então uma largura elástica moveria o campo e, com ele, o popover (que segue
  `--trigger-width`). Para outra medida, use `fullWidth` e dimensione o container.
- **"Selecionar todos" opera apenas sobre a lista filtrada.** Com uma busca ativa, o botão
  adiciona só as opções visíveis, preservando o que já estava marcado fora do filtro. Sem
  busca, adiciona todas. O botão fica desabilitado quando tudo que está visível já foi
  selecionado.
- **"Limpar" sempre remove tudo**, inclusive itens que o filtro atual esconde — é um reset
  do campo, não do que está na tela. Desabilitado quando nada está selecionado.
- **A busca é resetada ao fechar o popover.** Reabrir sempre começa com a lista completa;
  o texto digitado não persiste entre aberturas.
- **`withSearch` é `true` por padrão** (no `Select` é `false`) — a busca é a razão de ser
  deste componente. Passe `withSearch={false}` para listas curtas.
- **Semi-controlado**: sem `value`, o componente mantém estado interno inicializado por
  `defaultValue`. Passando `value`, ele passa a ser a única fonte de verdade — atualize-o
  dentro de `onChange` ou a seleção não muda.
- **`state="open"`** define apenas o estado **inicial** de abertura (útil para docs/demo);
  mudanças posteriores na prop não reabrem o popover.
- **`errorText` sozinho já coloca o campo em erro** — `state="error"` é redundante quando há
  mensagem. Útil com validação: basta passar `errorText={fieldState.error?.message}` e o
  campo alterna sozinho conforme a mensagem existe ou não.
- **Erro e ajuda não coexistem**: havendo erro, `errorText` (com ícone `alert-circle`)
  substitui o `helperText`; só uma mensagem é renderizada, e é ela que responde pelo
  `aria-describedby` do gatilho.
- **Rodapé condicional**: com `showSelectAll={false}` e `showClear={false}` nenhum rodapé é
  renderizado e o popover fica idêntico ao do `Select`.
- **Busca e opções compartilham a mesma altura de linha** (`--multiselect-row-height`,
  44px = `--height-input`, a altura do gatilho `md`). As duas abrem mão do padding vertical
  e centralizam o conteúdo — a igualdade não depende de somar padding + `line-height` de
  conteúdos diferentes (ícone de 14px na busca, caixa de 16px + texto na opção).
- **`emptyText` é um bloco centrado**, não uma linha de texto: ícone `inbox` (mesmo default
  do [`EmptyState`](../Feedback/EmptyState.md)) sobre o texto, com piso de 132px de altura.
  Sem isso, o painel sem resultados exibia um parágrafo solto no topo, que lê como falha de
  carregamento em vez de "nenhum resultado".
- **`--dropdown-max-height` limita a lista, não o painel.** Busca e rodapé somam altura por
  cima do teto — diferente do `Select`, onde o token cobre o popover inteiro. Sem isso, a
  moldura consumiria ~85px dos 240px e sobrariam ~3 opções visíveis. Consequência: o painel
  do `MultiSelect` é mais alto que o do `Select` para o mesmo número de opções.
- **Scrollbar da lista tem estilo próprio**, sobrescrevendo o global de `_reset.scss`: trilha
  transparente (a cinza encostava na borda arredondada do painel) e polegar de 4px visíveis
  numa faixa de 10px de arraste, via `border` transparente + `background-clip: content-box`.
  O hover é um degrau só (`--border-default` → `--border-medium`) com transição, em vez do
  salto direto para `--border-strong` do global.
- **Rótulo acessível do gatilho**: composto por `aria-labelledby` apontando para o `label`
  **e** para o próprio botão — o leitor de tela anuncia "Categorias, Receita, Despesa".
  Sem `label`, use `listAriaLabel` para nomear o popover.

---

## Exemplos

```tsx
import { MultiSelect } from '@srm/diamond';

// Básico — não-controlado, com busca
<MultiSelect
  label="Categorias"
  options={['Receita', 'Despesa', 'Transferência', 'Investimento']}
  onChange={(value) => console.log(value)}
/>

// Com seleção inicial
<MultiSelect
  label="Categorias"
  options={CATEGORIAS}
  defaultValue={['Receita']}
  onChange={setCategorias}
/>

// Controlado
<MultiSelect
  label="Classes de ativo"
  options={CLASSES}
  value={classes}
  onChange={setClasses}
/>

// Lista curta, sem busca e sem rodapé — equivalente ao Select com seleção múltipla
<MultiSelect
  label="Status"
  options={['Ativo', 'Pendente', 'Cancelado']}
  withSearch={false}
  showSelectAll={false}
  showClear={false}
/>

// Contador a partir do 1º item (gatilho estreito)
<MultiSelect
  label="Filtros"
  options={FILTROS}
  summaryThreshold={1}
  summaryLabel={(n) => (n === 1 ? '1 filtro' : `${n} filtros`)}
/>

// Estado de erro
<MultiSelect
  label="Categorias"
  options={CATEGORIAS}
  state="error"
  errorText="Selecione ao menos uma categoria"
/>

// Largura total dentro de um formulário
<MultiSelect label="Categorias" options={CATEGORIAS} fullWidth />

// Seleção visível como chips removíveis abaixo do campo
<>
  <MultiSelect label="Categorias" options={CATEGORIAS} value={sel} onChange={setSel} />
  <ChipGroup>
    {sel.map((item) => (
      <Chip
        key={item}
        label={item}
        removable
        onRemove={() => setSel(sel.filter((s) => s !== item))}
      />
    ))}
  </ChipGroup>
</>
```

### Integração com React Hook Form

```tsx
<Controller
  name="categorias"
  control={control}
  defaultValue={[]}
  render={({ field, fieldState }) => (
    <MultiSelect
      label="Categorias"
      options={CATEGORIAS}
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

> Com Zod, valide como `z.array(z.string()).min(1, 'Selecione ao menos uma categoria')` —
> o valor **sempre** chega como array (vazio quando nada está marcado), nunca `undefined`.

---

## Acessibilidade

- O gatilho é um `<button>` do react-aria: abertura por `Enter`/`Espaço`, `Esc` fecha e
  devolve o foco. Seu nome acessível combina o `label` com o resumo da seleção.
- A lista é um `ListBox` com `aria-multiselectable`: setas navegam, `Espaço` alterna o item
  sob o foco, e cada opção anuncia seu estado via `aria-selected`.
- **A caixa de seleção à esquerda de cada opção é decorativa** (`aria-hidden`), não um
  `<input type="checkbox">`. Leitores de tela anunciam "opção, marcada" a partir do
  `aria-selected` do item — a caixa existe só para o afford visual.
- Com `withSearch`, o campo de busca recebe o foco assim que o popover abre (`autoFocus`):
  o usuário digita para filtrar sem nenhum `Tab`. O `Autocomplete` do RAC encaminha as setas
  do campo direto para a lista — dá para digitar e descer para os resultados.
- Enquanto o popover está aberto, o RAC aplica `aria-hidden` no restante da página
  (comportamento padrão de `Popover` + `Dialog`). Em testes, capture a referência do gatilho
  **antes** de abrir: consultas por `role` não o encontram com o painel aberto.
- `helperText`/`errorText` são associados ao gatilho via `aria-describedby`.
- O popover e a lista herdam o nome do `label` quando ele é uma **string**. Se `label` for
  um `ReactNode` (ou não existir), passe `listAriaLabel` — sem isso o nome cai no genérico
  "Opções".

## Armadilhas comuns

- Esperar que "Selecionar todos" marque **todas** as opções com uma busca ativa — ele marca
  só as visíveis. Limpe a busca antes se a intenção for selecionar a lista inteira.
- Esperar que "Limpar" respeite o filtro — ele zera a seleção inteira, sempre.
- Usar `value` sem atualizar o estado dentro de `onChange` — a seleção fica travada, igual
  a qualquer input controlado.
- Depender da ordem de clique em `onChange` — o array vem reordenado conforme `options`.
- Passar `options` recriado a cada render (`options={['A','B']}` inline dentro de um
  componente que re-renderiza muito) — a lista e o `Set` de seleção são memoizados por
  identidade de `options`; declare o array fora do componente ou em `useMemo`.
- Esperar chips removíveis dentro do gatilho — não é suportado (botão dentro de botão é
  HTML inválido). Renderize um `ChipGroup` abaixo do campo, como no exemplo acima.
- Esperar que o tema `dark` chegue ao popover por herança de um wrapper — o popover é
  renderizado em portal; o componente propaga `data-theme="dark"` explicitamente quando
  `theme="dark"`, então **passe a prop**, não confie na cascata do container.
- Duplicatas em `options` — as chaves do `ListBox` são as próprias strings; valores
  repetidos colidem. Deduplique antes de passar.
- Trocar a caixa visual pelo componente [`Checkbox`](./Checkbox.md) "para reaproveitar" —
  ele é um `<button>`; dentro do `ListBoxItem` viraria controle aninhado, com o clique na
  caixa e o clique na linha alternando a seleção duas vezes. Há teste cobrindo a ausência
  de `role="checkbox"` dentro da lista.
