# ListLabel

Par tipográfico `label` + `caption`, base para pares chave/valor em listas de detalhe,
extratos e resumos. Dois `format`s (empilhado/horizontal), três `size`s e destaque
semântico opcional (`highlight`) para o caption. `caption` aceita `string` (texto simples)
ou `ReactNode` (composição com outros átomos, ex.: `Tag`, `TrendIndicator`) — puramente
apresentacional, sem interatividade própria.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/ListLabel/`
- **Export:** `import { ListLabel } from '@srm/diamond';`
- **Relacionados:** [ListLabelGroup](./ListLabelGroup.md) (agrupador de vários `ListLabel`
  a partir de `items[]`), [Tag](./Tag.md) e [TrendIndicator](./TrendIndicator.md) (átomos
  comuns dentro do slot de `caption`)

---

## Quando usar

- Par label + valor em detalhe de operação, extrato ou resumo (ex.: "Origem" / "Conta
  Corrente · 12345-6").
- Quando o caption precisa de composição visual — ex.: um `TrendIndicator` ou `Tag` no
  lugar de texto simples (`caption` aceita `ReactNode`).
- Destaque semântico de um valor específico (protocolo, saldo positivo/negativo, alerta)
  via `highlight`, sem sair do padrão tipográfico do par.

## Quando **não** usar

- Múltiplos pares label/value que sempre aparecem juntos, em lista → use
  [`ListLabelGroup`](./ListLabelGroup.md) em vez de renderizar vários `ListLabel` manualmente
  (evita repetir o loop e o espaçamento entre itens).
- Rótulo isolado sem valor associado → um `<span>`/`<p>` simples é suficiente; `ListLabel`
  sempre assume a semântica de par.

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';

type ListLabelSize = 'sm' | 'md' | 'lg';
type ListLabelAlign = 'left' | 'right';
type ListLabelFormat = 'stacked' | 'horizontal';
type ListLabelHighlight = 'brand' | 'success' | 'warning' | 'error' | 'info';

interface ListLabelProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  label: ReactNode;              // obrigatório — texto principal (destaque primary)
  caption?: ReactNode;           // string (texto) ou ReactNode (Tag, TrendIndicator, ...)
  format?: ListLabelFormat;      // default: 'stacked'
  align?: ListLabelAlign;        // default: 'left' — só aplica em format='stacked'
  size?: ListLabelSize;          // default: 'md'
  highlight?: ListLabelHighlight; // sem default — só aplica em caption textual
  className?: string;
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children): id, aria-*, data-*, ...
}
```

### Notas de comportamento

- `format="stacked"` (default) empilha label acima do caption, verticalmente; `format="horizontal"`
  coloca label à esquerda e caption à direita, na mesma linha (`space-between`).
- `align` (`'left' | 'right'`) só tem efeito em `format="stacked"` — em `horizontal` o
  alinhamento já é definido pelo layout (label esquerda / caption direita).
- `size` define o preset tipográfico do par: `sm` (label `--text-11` semibold / caption
  `--text-10`), `md` (label `--text-13` / caption `--text-11`, default), `lg` (label
  `--text-14` / caption `--text-12`).
- `caption` é verificado com `isValidElement` para decidir a renderização: se for um
  elemento React válido, é envolvido em `styles.captionSlot` (sem estilo tipográfico
  próprio); caso contrário (string/number), é renderizado como `<p className={styles.caption}>`.
- `highlight` só tem efeito quando `caption` é **textual** — um `ReactNode` (ex.: `Tag`,
  `TrendIndicator`) ignora `highlight`, pois o próprio átomo já define sua cor.
- `highlight` aplica cor semântica (`brand`/`success`/`warning`/`error`/`info`) **e** peso
  semibold ao caption textual, reforçando a hierarquia visual acima do peso regular padrão.
- `caption` ausente (`undefined`/`null`) renderiza só o `label` — nenhum espaço reservado
  para o caption.

---

## Exemplos

```tsx
import { ListLabel } from '@srm/diamond';
import { Tag } from '@srm/diamond';
import { TrendIndicator } from '@srm/diamond';

// Básico, stacked (default)
<ListLabel label="Itaú Unibanco" caption="Ag. 1234 · CC 56789-0" />

// Horizontal (chave-valor em detalhe)
<ListLabel label="Origem" caption="Conta Corrente · 12345-6" format="horizontal" />

// Com highlight (protocolo em destaque)
<ListLabel label="Protocolo" caption="PIX20260718142732" format="horizontal" highlight="brand" />

// Caption composto com TrendIndicator
<ListLabel
  label="R$ 1.250.000"
  align="right"
  caption={<TrendIndicator direction="up" size="md" layout="inline" label="+2,1%" suffix="vs. mês anterior" />}
/>

// Caption composto com Tag
<ListLabel
  label="Banco Inter"
  caption={<Tag variant="info" size="sm">Desconectada</Tag>}
/>

// Só label, sem caption
<ListLabel label="Sem informação adicional" />
```

---

## Acessibilidade

- `label` e `caption` são conteúdo textual/visual normal — sem `role` ou `aria-*` próprios;
  a leitura por leitores de tela segue a ordem visual do DOM (label antes de caption em
  `stacked`, na ordem de children em `horizontal`).
- Quando `caption` é um átomo interativo (não é o caso hoje — `Tag`/`TrendIndicator` são
  apresentacionais), garanta que ele mesmo exponha a semântica de acessibilidade correta;
  `ListLabel` não adiciona nem remove nada do `caption`.
- `highlight` reforça a semântica **visualmente** (cor + peso) — não é a única forma de
  comunicar a informação: o texto do `caption` já deve ser autoexplicativo sem depender
  da cor (ex.: "Protocolo: PIX2026..." e não apenas um número colorido).

## Armadilhas comuns

- Esperar que `highlight` funcione com `caption` em `ReactNode` — só se aplica a caption
  textual; para destacar um átomo, ajuste a variante do próprio átomo (ex.: `Tag
  variant="warning"`).
- Usar `align="right"` esperando efeito em `format="horizontal"` — a prop é ignorada nesse
  format (o alinhamento já é fixo pelo layout).
- Empilhar vários `ListLabel` manualmente para formar uma lista de pares — considere
  [`ListLabelGroup`](./ListLabelGroup.md), que já resolve espaçamento e variações de layout
  (`paired`, `vertical-left`, `vertical-right`) a partir de `items[]`.
