# AvatarDropdown

Trigger de menu de conta: um botão que combina `Avatar` (ou `ColabCircle`), nome/subtítulo
e um chevron, e abre um menu de ações ao ser ativado. Construído sobre `Button` do
`react-aria-components` como trigger e sobre [`Overlay`](../Feedback/Overlay.md)
(`type="menu"`) para o painel — herda navegação por teclado (setas, `Home`/`End`, `Esc`,
fechamento ao clicar fora) do `Menu`/`MenuTrigger` do react-aria. Exporta duas variantes de
uso: `AvatarDropdown` (usuário com cargo, ou empresa com CNPJ) e `AvatarColaborador`
(colaborador SRM, usa a logo em vez de iniciais).

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/Avatar/AvatarDropdown/`
- **Export:** `import { AvatarDropdown, AvatarColaborador } from '@srm/diamond';`
- **Relacionados:** [Avatar](./Avatar.md) (círculo de iniciais usado internamente por `AvatarDropdown`), [AvatarSRM](./AvatarSRM.md) (`ColabCircle` usado internamente por `AvatarColaborador`), [AvatarStatic](./AvatarStatic.md) (mesma composição visual, sem menu)

---

## Quando usar

- Cabeçalho/topbar da aplicação: menu de conta do usuário logado (perfil, configurações,
  sair) — `AvatarDropdown` com `variant="role"`.
- Seletor de empresa/entidade quando o usuário opera em nome de uma pessoa jurídica —
  `AvatarDropdown` com `variant="company"` (mostra CNPJ em vez de cargo).
- Menu de conta de um colaborador interno da SRM (e-mail + empresa) — `AvatarColaborador`.
- Qualquer lugar onde o padrão "avatar + texto + chevron que abre menu" precise ser
  totalmente clicável e acessível por teclado.

## Quando **não** usar

- Precisa só do avatar + texto, **sem** menu (ex.: item de lista, cabeçalho estático) →
  [`AvatarWithLabel` / `AvatarCompanyCNPJStatic` / `AvatarColaboradorStatic`](./AvatarStatic.md).
- O menu não é de "conta"/navegação, e sim um diálogo com formulário/conteúdo livre →
  use [`Overlay`](../Feedback/Overlay.md) com `type="dialog"` diretamente.
- Precisa só do círculo (sem trigger, sem texto) → [`Avatar`](./Avatar.md) ou [`ColabCircle`](./AvatarSRM.md).

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonProps as AriaButtonProps } from 'react-aria-components';

type ColaboradorAppearance = 'circular' | 'sutil';
type AvatarDropdownVariant = 'role' | 'company';
type AvatarDropdownAppearance = 'outlined' | 'ghost';

interface AvatarMenuOption {
  id: string;
  label: string;
  icon?: ReactNode;
  onSelect: () => void;
  danger?: boolean;   // aplica estilo destrutivo (vermelho) ao item
}

// Props do trigger herdadas do Button do react-aria-components,
// omitindo `children` (estrutura interna fixa) e `className` (CVA já compõe).
type InheritedTriggerProps = Omit<AriaButtonProps, 'children' | 'className'>;

interface AvatarDropdownProps extends InheritedTriggerProps {
  variant?: AvatarDropdownVariant;         // default: 'role'
  initials: string;                        // obrigatório — iniciais do Avatar interno
  bg?: string;                             // cor de fundo do Avatar (ignorada se isDark)
  userName: string;                        // exibido quando variant='role'
  userRole: string;                        // exibido quando variant='role'
  companyName: string;                     // exibido quando variant='company'
  companyCnpj: string;                     // exibido quando variant='company'
  appearance?: AvatarDropdownAppearance;   // default: 'outlined'
  isDark?: boolean;                        // default: false
  options?: AvatarMenuOption[];            // default: [] — itens do menu
  menuLabel?: string;                      // default: 'Menu do usuário' — aria-label do trigger
  defaultOpen?: boolean;                   // abre por padrão (uncontrolled) — uso em docs/demo
  isOpen?: boolean;                        // modo controlado — uso em docs/demo
  // Herdado: onPress, isDisabled, aria-*, ...
}

interface AvatarColaboradorProps extends InheritedTriggerProps {
  email: string;
  company: string;
  logoAppearance?: ColaboradorAppearance;  // default: 'circular'
  isDark?: boolean;                        // default: false
  options?: AvatarMenuOption[];            // default: []
  menuLabel?: string;                      // default: 'Menu do colaborador'
}
```

### Notas de comportamento

- **`variant` decide o par de campos exibido**, mas `userName`/`userRole` e
  `companyName`/`companyCnpj` são **todos obrigatórios** na interface, independente da
  variante ativa — a tipagem não torna os pares condicionais (limitação conhecida).
- `AvatarDropdown` sempre exige `initials` (não deriva de nome como `Avatar` faz) — o
  `Avatar` interno é chamado com `initials={initials}` diretamente.
- `bg` só é aplicado ao `Avatar` interno quando `isDark` é `false`; em tema escuro, `bg`
  é ignorado e o `Avatar` usa o estilo padrão de `isDark`.
- `AvatarColaborador` **não tem** prop `bg`/`initials` — sempre renderiza `ColabCircle`
  (a logo SRM), nunca iniciais.
- O menu é renderizado via `Overlay` com `type="menu"`: navegação por setas, seleção com
  Enter/Espaço, fechamento com `Esc` ou clique fora — tudo herdado do `Menu`/`MenuTrigger`
  do react-aria, sem código adicional no `AvatarDropdown`.
- `defaultOpen`/`isOpen` existem para permitir capturas de tela/demos com o menu já
  aberto — em produção, deixe o menu não controlado (nem `isOpen` nem `defaultOpen`).
- Sem itens em `options` (array vazio, default), o menu abre vazio — trate isso como
  estado de erro de integração, não como estado suportado da UI.
- **Foco**: o trigger só desenha anel em `[data-focus-visible]` (navegação por teclado).
  Clique/abertura por mouse não pintam nada além do estado `aria-expanded` — que muda o
  fundo para `--surface-subtle` e a borda para `--border-medium` (tom neutro, não brand).
- **Chevron**: vive numa caixa quadrada de `var(--space-5)` com o glifo centrado, então
  `rotate(180deg)` em `aria-expanded` gira no lugar, sem deslocar o ícone.

---

## Exemplos

```tsx
import { AvatarDropdown, AvatarColaborador } from '@srm/diamond';
import { LogOut, Settings, User } from 'lucide-react';

const menuOptions = [
  { id: 'profile',  label: 'Meu perfil',    icon: <User size={14} />,     onSelect: () => nav('/perfil') },
  { id: 'settings', label: 'Configurações', icon: <Settings size={14} />, onSelect: () => nav('/config') },
  { id: 'logout',   label: 'Sair',          icon: <LogOut size={14} />,   onSelect: handleLogout, danger: true },
];

// Menu de conta do usuário (cargo)
<AvatarDropdown
  variant="role"
  initials="CM"
  userName="Carlos Mendes"
  userRole="CEO · Master"
  companyName=""
  companyCnpj=""
  options={menuOptions}
/>

// Seletor de empresa (CNPJ)
<AvatarDropdown
  variant="company"
  initials="SRM"
  userName=""
  userRole=""
  companyName="SRM Asset Management"
  companyCnpj="12.345.678/0001-99"
  appearance="ghost"
  options={menuOptions}
/>

// Menu do colaborador SRM (logo em vez de iniciais)
<AvatarColaborador
  email="carlos.mendes@srmasset.com"
  company="SRM Asset Management"
  logoAppearance="circular"
  options={menuOptions}
/>

// Tema escuro (sobre header brand)
<AvatarDropdown
  variant="role"
  initials="CM"
  userName="Carlos Mendes"
  userRole="CEO · Master"
  companyName=""
  companyCnpj=""
  isDark
  options={menuOptions}
/>
```

---

## Acessibilidade

- `menuLabel` vira o `aria-label` do botão trigger — mantenha um valor descritivo
  (`'Menu do usuário'`/`'Menu do colaborador'` são os defaults; personalize se o contexto
  exigir, ex. `"Menu da conta de {userName}"`).
- Navegação por teclado é garantida pelo `Menu`/`MenuTrigger` do react-aria: `Enter`/`Espaço`
  abre, setas navegam pelos itens, `Enter` seleciona, `Esc` fecha e devolve o foco ao trigger.
- Itens com `danger: true` recebem estilo visual destrutivo, mas **não** um `aria-*`
  adicional — se a ação for irreversível, considere confirmar antes de chamar `onSelect`.

## Armadilhas comuns

- Passar apenas os campos da variante ativa e deixar os outros `undefined` — a interface
  exige todos; passe string vazia (`""`) para os não usados, como no exemplo acima.
- Usar `isOpen`/`defaultOpen` em produção — essas props existem para docs/demo; controlar
  o menu manualmente pode conflitar com o fechamento automático do react-aria.
- Esquecer que `AvatarColaborador` não aceita `initials`/`bg` — só existe a variante logo SRM.
