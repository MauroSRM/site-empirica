# ApprovalRow

Row tabular para fila de aprovação de operações financeiras. Colunas: Beneficiário |
Data de vencimento | Tag de prioridade | Valor | Ações. A row inteira (exceto ações) é
clicável via `onPress`; ações Aprovar/Reprovar ficam **fora** da área clicável (siblings,
sem interativos aninhados). Construído sobre `Button` do `react-aria-components` (área de
clique), `IconButton`, `Overlay` (menu) e `Tag` (prioridade).

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/ApprovalRow/`
- **Export:** `import { ApprovalRow } from '@srm/diamond';`
- **Relacionados:** [PermissionRow](./PermissionRow.md) (mesmo modelo de ações
  Aprovar/Reprovar `inline`/`menu`), [DocumentRow](./DocumentRow.md) (mesmo padrão de row
  clicável + ações como siblings), [Tag](./Tag.md) (usado internamente para a prioridade)

---

## Quando usar

- Fila de aprovação de operações (transferências, pagamentos, resgates) com beneficiário,
  vencimento, prioridade e valor visíveis de imediato.
- Listas onde cada linha precisa de uma ação binária Aprovar/Reprovar, além de abrir
  detalhes ao clicar no corpo da linha.
- Priorização visual por Tag (`baixa`/`normal`/`alta`/`critica`) sem exigir coluna extra
  quando a prioridade não se aplica (o slot fica vazio, preservando o alinhamento).

## Quando **não** usar

- Linha de documento (nome, tipo, tamanho, status) → [`DocumentRow`](./DocumentRow.md).
- Linha de permissão/perfil de acesso, com seleção em lote → [`PermissionRow`](./PermissionRow.md).
- Necessidade de mais de duas ações por linha → o modelo de ações do `ApprovalRow` é
  fixo em Aprovar/Reprovar; para ações arbitrárias use [`DocumentRow`](./DocumentRow.md)
  (`actions[]` genérico) como referência de padrão, ou componha um row customizado.

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';

type ApprovalRowPriority = 'baixa' | 'normal' | 'alta' | 'critica';
type ApprovalRowActionsMode = 'inline' | 'menu';
type ApprovalRowVariant = 'default' | 'compact';

interface ApprovalRowProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'onClick' | 'title'> {
  variant?: ApprovalRowVariant;         // default: 'default'
  beneficiary: string;                  // obrigatório — destaque principal
  dueDate: ReactNode;                   // obrigatório (ex.: "04/06/2026", "Hoje")
  priority?: ApprovalRowPriority;       // ausente = slot de Tag vazio (espaço preservado)
  value: ReactNode;                     // obrigatório — valor formatado, destaque
  onPress?: () => void;                 // clique na row (abre detalhes)
  onApprove?: () => void;               // ausente junto com onReject = slot de ações vazio
  onReject?: () => void;
  actionsMode?: ApprovalRowActionsMode; // default: 'menu'
  disabled?: boolean;                   // default: false — desabilita row e ações
  className?: string;
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children/onClick/title): id, aria-*, data-*, ...
}
```

### Notas de comportamento

- A área clicável (beneficiário, data, tag, valor) é sempre um `AriaButton` — existe mesmo
  quando `onPress` não é passado; nesse caso ela é focável mas não dispara nada ao ser
  ativada (`{...(onPress ? { onPress } : {})}`).
- As ações (Aprovar/Reprovar) são renderizadas em um `div` **sibling** ao `AriaButton`, fora
  da área clicável — evita interativo aninhado dentro de interativo.
- O slot de ações só é renderizado se `hasActions = Boolean(onApprove || onReject)` for
  verdadeiro; sem nenhum dos dois handlers, não há coluna de ações.
- `actionsMode="inline"` renderiza até dois `IconButton` (Reprovar `x`, Aprovar `check`),
  cada um condicionado à presença do respectivo handler.
- `actionsMode="menu"` (default) renderiza um `Overlay` tipo `menu` com trigger "Ações";
  os itens Aprovar/Reprovar só entram na lista se o handler correspondente existir.
- `priority` mapeia label + variante do `Tag` via `PRIORITY_CFG`:
  `baixa`/`normal` → `info` ("Baixa"/"Normal"), `alta` → `warning` ("Alta"),
  `critica` → `error` ("Crítica").
- `disabled` desabilita tanto a área clicável quanto os `IconButton`/`Overlay` de ações
  (via `isDisabled`) e marca `data-disabled` na raiz (usado para estilo de opacidade).
- `variant="compact"` reduz altura mínima e tipografia (`beneficiary`/`value` para
  `--text-13`, `dueDate` para `--text-12`); `variant="default"` usa `--height-row-md`.
- `data-has-actions` na raiz altera o grid para reservar 48px à coluna de ações quando
  `hasActions` é `true`.

---

## Exemplos

```tsx
import { ApprovalRow } from '@srm/diamond';

// Básico, sem ações (só clique)
<ApprovalRow
  beneficiary="Fornecedor MetalCo Ltda"
  dueDate="03/06/2026"
  value="R$ 45.000,00"
  priority="alta"
  onPress={() => abrirDetalhes(id)}
/>

// Com ações em menu (default)
<ApprovalRow
  beneficiary="Fornecedor MetalCo Ltda"
  dueDate="03/06/2026"
  value="R$ 45.000,00"
  priority="critica"
  onApprove={() => aprovar(id)}
  onReject={() => reprovar(id)}
/>

// Ações inline (check + x)
<ApprovalRow
  beneficiary="Fornecedor MetalCo Ltda"
  dueDate="03/06/2026"
  value="R$ 45.000,00"
  priority="alta"
  actionsMode="inline"
  onApprove={() => aprovar(id)}
  onReject={() => reprovar(id)}
/>

// Sem prioridade (slot de Tag vazio, layout preservado)
<ApprovalRow beneficiary="Fornecedor X" dueDate="Hoje" value="R$ 1.200,00" />

// Compact, desabilitada
<ApprovalRow
  variant="compact"
  beneficiary="Fornecedor Y"
  dueDate="10/07/2026"
  value="R$ 800,00"
  priority="normal"
  disabled
/>

// Lista de aprovações
function FilaAprovacao({ itens }: { itens: Operacao[] }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {itens.map((op) => (
        <ApprovalRow
          key={op.id}
          beneficiary={op.beneficiario}
          dueDate={op.vencimento}
          value={op.valorFormatado}
          priority={op.prioridade}
          onPress={() => abrirDetalhes(op.id)}
          onApprove={() => aprovar(op.id)}
          onReject={() => reprovar(op.id)}
        />
      ))}
    </div>
  );
}
```

---

## Acessibilidade

- O nome acessível da área clicável vem do conteúdo textual visível (beneficiário, data,
  tag, valor) — não é necessário `aria-label` adicional na maioria dos casos.
- Os botões de ação individuais (`inline`) já têm `aria-label` fixo ("Aprovar"/"Reprovar");
  o trigger do menu (`menu`) usa `aria-label="Ações"`.
- Itens do menu de ações incluem ícone `aria-hidden`; o item "Reprovar" é marcado `danger`
  no `Overlay`, reforçando a semântica destrutiva visualmente (cor), mas o texto do item já
  comunica a ação por si.
- `disabled` propaga `isDisabled` para a área clicável e para todas as ações — não é preciso
  desabilitar handlers manualmente no componente pai.

## Armadilhas comuns

- Não espere que a row seja clicável automaticamente: sem `onPress`, o `AriaButton` interno
  existe mas não faz nada — é comportamento intencional (preserva foco/teclado consistentes),
  não um bug.
- Passar `onApprove`/`onReject` sem also decidir `actionsMode` mantém o default `'menu'` —
  se o design pede os dois ícones lado a lado, defina `actionsMode="inline"` explicitamente.
- `priority` fora do enum (`'baixa' | 'normal' | 'alta' | 'critica'`) não é aceito pelo
  TypeScript — não há fallback visual para valores inválidos.
- `dueDate` e `value` aceitam `ReactNode`, mas evite conteúdo interativo neles — a área
  clicável já é um `AriaButton`; um interativo aninhado dentro dele é inválido em HTML.
