# PermissionRow

Row de permissão/perfil de acesso: `[Checkbox opcional]` + info stack (`label` +
`description`) + `Tag` opcional + ações Aprovar/Reprovar. Dois modos de uso: **single**
(ações `inline`/`menu` por linha) ou **multi-select** (`selectable`, esconde as ações
individuais e delega a ação em lote para `PermissionBulkActions`). `PermissionRowGroup`
compõe uma lista de `PermissionRow` selecionáveis + `PermissionBulkActions` com gestão de
seleção controlada ou interna. Construído sobre `Checkbox`, `IconButton`, `Overlay` (menu),
`Tag`, `DoubleButton`/`Button` (barra de ações em lote).

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/PermissionRow/`
- **Export:** `import { PermissionRow, PermissionBulkActions, PermissionRowGroup } from '@srm/diamond';`
- **Relacionados:** [ApprovalRow](./ApprovalRow.md) (mesmo modelo de ações
  Aprovar/Reprovar `inline`/`menu`), [DocumentRow](./DocumentRow.md) (mesmo padrão de row +
  ações como siblings), [Tag](./Tag.md), [Checkbox](../Forms/Checkbox.md)

---

## Quando usar

- Lista de permissões/perfis de acesso onde cada linha pode ser aprovada/reprovada
  individualmente (`PermissionRow` single mode).
- Revisão em lote de várias permissões: use `PermissionRowGroup` (gestão de seleção +
  `PermissionBulkActions` prontos) ou componha `PermissionRow selectable` +
  `PermissionBulkActions` manualmente se precisar de controle mais granular sobre o layout.
- Categorização de permissões por `tag` (ex.: "Financeiro", "Admin", "Consulta").

## Quando **não** usar

- Fila de aprovação de operações financeiras (beneficiário/vencimento/valor) →
  [`ApprovalRow`](./ApprovalRow.md).
- Linha de documento → [`DocumentRow`](./DocumentRow.md).
- Seleção múltipla sem semântica de aprovação/reprovação (ex.: apenas marcar itens para
  exportar) → use `Checkbox`/`CheckboxGroup` diretamente, sem o modelo de ações do
  `PermissionRow`.

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';
import type { TagVariant } from '../DataDisplay/Tag';

type PermissionRowTag = string | { label: string; variant?: TagVariant };
type PermissionRowActionsMode = 'inline' | 'menu';
type PermissionRowVariant = 'default' | 'compact';

interface PermissionRowProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'onClick'> {
  label: ReactNode;                       // obrigatório — nome da permissão
  variant?: PermissionRowVariant;         // default: 'default'
  description?: ReactNode;                // contexto/descrição (segundo slot, discreto)
  tag?: PermissionRowTag;                 // string (variante default) ou { label, variant? }
  disabled?: boolean;                     // default: false
  selectable?: boolean;                   // default: false — mostra Checkbox, esconde ações individuais
  selected?: boolean;                     // só com selectable
  onSelectChange?: (selected: boolean) => void; // só com selectable
  onApprove?: () => void;                 // só com selectable=false
  onReject?: () => void;                  // só com selectable=false
  actionsMode?: PermissionRowActionsMode; // default: 'menu'
  className?: string;
}

interface PermissionBulkActionsProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  count: number;               // quantidade selecionada — 0 = não renderiza (retorna null)
  onApproveAll?: () => void;
  onRejectAll?: () => void;
  className?: string;
}

interface PermissionRowGroupItem {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  tag?: PermissionRowTag;
  disabled?: boolean;
}

interface PermissionRowGroupProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'onChange'> {
  items: PermissionRowGroupItem[];
  selectedIds?: Record<string, boolean>;              // controlado; omitir = gerido internamente
  onSelectionChange?: (selectedIds: Record<string, boolean>) => void;
  onApproveAll?: (ids: string[]) => void;              // recebe os ids selecionados
  onRejectAll?: (ids: string[]) => void;
  className?: string;
}
```

### Notas de comportamento

**`PermissionRow`**
- `tag` aceita `string` (usa `DEFAULT_TAG_VARIANT = 'brandPrimary'`) ou objeto
  `{ label, variant? }` (variante explícita) — resolvido internamente antes de repassar ao
  `Tag`.
- `showActions = !selectable && Boolean(onApprove || onReject)` — em `selectable=true` as
  ações individuais **nunca** aparecem, independente de `onApprove`/`onReject` serem
  passados; multi-select e ações individuais são mutuamente exclusivos por design.
- Sem `selectable`, o Checkbox não é renderizado; `selected`/`onSelectChange` são ignorados.
- `actionsMode="inline"` renderiza até dois `IconButton` (Reprovar `x`, Aprovar `check`);
  `actionsMode="menu"` (default) renderiza `Overlay` tipo `menu` com trigger "Ações", com
  itens condicionados à presença de cada handler.
- `variant="compact"` reduz tipografia (`label` → `--text-13`, `description` → `--text-11`)
  e altura mínima (`--height-row-compact`); `variant="default"` usa `--height-row-md` e
  borda inferior entre linhas (`border-bottom`, removida no `:last-child`).
- `aria-label` do Checkbox usa `label` quando é `string`; caso contrário usa o fallback
  `"Selecionar permissão"`.

**`PermissionBulkActions`**
- Retorna `null` quando `count === 0` — não renderiza um contêiner vazio.
- Se **ambos** `onApproveAll` e `onRejectAll` forem passados, renderiza um `DoubleButton`
  (`pair="primary-ghost"`, `layout="horizontal"`); se só um dos dois for passado, renderiza
  um `Button` isolado (`ghost` para reprovar, `primary` para aprovar).
- Texto de contagem pluraliza automaticamente: `"1 permissão selecionada"` vs.
  `"N permissões selecionadas"`.

**`PermissionRowGroup`**
- Seleção pode ser controlada (`selectedIds` + `onSelectionChange`) ou não-controlada
  (estado interno via `useState`); a decisão é feita por `controlledSelected !== undefined`.
- Ao acionar `onApproveAll`/`onRejectAll`, o group chama o callback do consumidor **com os
  ids selecionados no momento** e limpa a seleção (`setSelected({})`) automaticamente.
- Cada item vira um `PermissionRow selectable`; `PermissionBulkActions` é sempre renderizado
  ao final da lista (mas só aparece visualmente quando `count > 0`, por conta do
  comportamento acima).

---

## Exemplos

```tsx
import { PermissionRow, PermissionBulkActions, PermissionRowGroup } from '@srm/diamond';
import { useState } from 'react';

// Single mode, com ações em menu (default)
<PermissionRow
  label="Aprovar transferências"
  description="Permite autorizar TEDs e PIX acima de R$ 50.000"
  tag={{ label: 'Financeiro', variant: 'brandPrimary' }}
  onApprove={() => aprovar(id)}
  onReject={() => reprovar(id)}
/>

// Ações inline
<PermissionRow label="Consultar extratos" actionsMode="inline" onApprove={() => {}} onReject={() => {}} />

// Multi-select manual (PermissionRow + PermissionBulkActions)
function BulkDemo() {
  const items = [
    { id: 'transfer', label: 'Aprovar transferências', description: 'TEDs e PIX acima de R$ 50.000' },
    { id: 'extract', label: 'Consultar extratos', description: 'Saldos e movimentações' },
  ];
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const count = Object.values(selected).filter(Boolean).length;
  return (
    <>
      {items.map((item) => (
        <PermissionRow
          key={item.id}
          label={item.label}
          description={item.description}
          selectable
          selected={!!selected[item.id]}
          onSelectChange={() => setSelected((s) => ({ ...s, [item.id]: !s[item.id] }))}
        />
      ))}
      <PermissionBulkActions
        count={count}
        onApproveAll={() => aprovarTodos(selected)}
        onRejectAll={() => reprovarTodos(selected)}
      />
    </>
  );
}

// PermissionRowGroup (composição pronta)
function StackedDemo() {
  const [selectedIds, setSelectedIds] = useState<Record<string, boolean>>({});
  return (
    <PermissionRowGroup
      items={[
        { id: 'transfer', label: 'Aprovar transferências', description: 'TEDs e PIX acima de R$ 50.000', tag: { label: 'Financeiro', variant: 'brandPrimary' } },
        { id: 'extract', label: 'Consultar extratos', description: 'Saldos e movimentações', tag: { label: 'Consulta', variant: 'info' } },
      ]}
      selectedIds={selectedIds}
      onSelectionChange={setSelectedIds}
      onApproveAll={(ids) => aprovarPorId(ids)}
      onRejectAll={(ids) => reprovarPorId(ids)}
    />
  );
}
```

---

## Acessibilidade

- O Checkbox em modo `selectable` usa `aria-label` derivado do `label` (quando string) —
  garanta que `label` seja descritivo mesmo quando renderizado como `ReactNode` composto
  (o fallback genérico "Selecionar permissão" perde contexto).
- Ações individuais e barra de ações em lote reutilizam os mesmos rótulos previsíveis
  ("Aprovar"/"Reprovar"/"Ações") — em telas com muitas linhas, o contexto (nome da
  permissão) vem só do agrupamento visual, não do `aria-label` do botão.
- `PermissionBulkActions` anuncia a contagem via texto visível (`"N permissões
  selecionadas"`) — não depende de `aria-live`; se a barra aparecer/desaparecer com
  frequência, considere envolvê-la com uma região `aria-live="polite"` no nível da página.

## Armadilhas comuns

- Passar `onApprove`/`onReject` junto com `selectable=true` não tem efeito — as ações
  individuais são suprimidas incondicionalmente nesse modo; não é um bug, é a regra de
  design (`showActions = !selectable && ...`).
- `PermissionRowGroup` limpa a seleção automaticamente após `onApproveAll`/`onRejectAll`,
  chamando `onSelectionChange?.({})` mesmo em modo controlado — se o consumidor ignora esse
  callback, o `selectedIds` externo fica desatualizado (linhas continuam marcadas
  visualmente mesmo após o bulk action).
- `tag` como `string` sempre usa `brandPrimary` — para outra cor, passe o objeto
  `{ label, variant }` explicitamente.
- `PermissionBulkActions` isolado (`count={0}`) retorna `null` — não assuma que o elemento
  sempre existe no DOM para animações de entrada/saída baseadas em CSS; trate a
  transição no nível do consumidor se precisar de animação.
