# PercentInput

Campo de entrada de percentual (0–100% ou acima, se `max` não for definido). Exibe sufixo/prefixo
visual **`%`** e usa um preenchimento **direita-para-esquerda** (estilo "calculadora de POS"):
cada dígito digitado entra pela casa decimal e empurra os anteriores para a esquerda — igual a
um campo de valor monetário de caixa eletrônico. Construído sobre `InputBase` (herda label,
estados, temas e mensagens) e sobre `react-imask` (hook `useIMask`), mas com uma ponte de
teclado **própria** (`PercentBridge`), diferente da `IMaskBridge` genérica usada por outros
inputs mascarados do Diamond.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/PercentInput/`
- **Export:** `import { PercentInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [CurrencyInput](./CurrencyInput.md), [TextInput](./TextInput.md)

---

## Quando usar

- Captura de taxas, percentuais de alocação, rentabilidade-alvo, taxa de administração,
  percentual de comissão ou qualquer campo cujo valor semântico seja um percentual.
- Quando o produto pede um comportamento de digitação "tipo POS/calculadora" — o usuário
  digita os dígitos em sequência e eles preenchem da casa decimal para a esquerda
  (ex.: digitar `3`, `3`, `3`, `3` produz `0,03` → `0,33` → `3,33` → `33,33`).
- Quando é necessário limitar o valor máximo aceito (ex.: percentual de alocação que não
  pode ultrapassar 100%) via prop `max`.

## Quando **não** usar

- Valores monetários em reais → use [`CurrencyInput`](./CurrencyInput.md).
- Digitação livre/tradicional da esquerda para a direita (usuário cola valor, usa setas,
  edita no meio do texto) → `PercentInput` **não** foi desenhado para isso: só aceita
  dígitos `0-9` e `Backspace` via `onKeyDown`, sem suporte a colar (paste) ou navegação
  por cursor. Se precisar de edição livre de um número com `%`, use `TextInput` com
  `inputMode="decimal"` e formate você mesmo.
- Faixas de percentual (mín–máx) → componha dois `PercentInput` em um `FieldGroup`.

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface PercentInputProps extends InputBaseProps {
  value?: string;                          // valor controlado; aceita "33.33" ou "33,33"
  placeholder?: string;                    // default: '0,00'
  max?: number;                            // limite superior (percentual, ex.: 100 = "100%")
  onChange?: (value: string) => void;      // entrega string decimal com PONTO, ex.: "0.05"
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|----------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                               |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                              |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                       |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                            |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                               |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).    |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).       |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).        |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                       |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `onBlur`, `onFocus` e atributos `aria-*`. Note que `PercentInput`
> **fixa** `inputMode="numeric"` internamente e ignora qualquer `onKeyDown`/`onChange`
> nativo que venha de fora (o valor é 100% controlado pelo componente).

### Contrato de máscara e digitação (não-óbvio — leia com atenção)

`PercentInput` **não** é um campo de texto tradicional. Ele mantém internamente uma string
de dígitos "crus" (`digits`) e reage apenas a teclas:

- **Dígitos `0-9`**: cada tecla é anexada à direita da string de dígitos, deslocando o valor
  exibido (preenchimento direita-para-esquerda, como um teclado numérico de PDV).
  `onKeyDown` chama `e.preventDefault()` — a digitação nativa do `<input>` é ignorada
  (`onChange={() => {}}` no elemento real).
- **`Backspace`**: remove o último dígito da string interna (não move o cursor — o campo
  não tem conceito de posição de cursor).
- **Qualquer outra tecla** (setas, colar, Delete, letras): não faz nada — não há suporte a
  edição por cursor nem a `paste`.
- **`max`** (opcional): se o próximo dígito fizer o valor numérico ultrapassar `max`
  (comparando `parseInt(next, 10) / 100`), a tecla é bloqueada e o valor permanece inalterado.
- Exibição usa `react-imask` (`useIMask`) apenas para **formatar** a string de dígitos como
  `Number` com `scale: 2`, `thousandsSeparator: '.'`, `radix: ','` (mesmas opções visuais do
  `CurrencyInput`), mas quem decide o valor é o estado `digits`, não o mask engine.

**Contrato de `value`/`onChange` diverge do `CurrencyInput`:**

| | Formato aceito em `value` | Formato entregue em `onChange` |
|---|---|---|
| `PercentInput` | `"33.33"` ou `"33,33"` (ambos aceitos — internamente troca `,` por `.`) | `"33.33"` — string decimal com **ponto**, via `toFixed(2)` |
| `CurrencyInput` | string mascarada com vírgula/milhar | string mascarada com vírgula/milhar |

- `onChange` **não** entrega o valor mascarado exibido (`"33,33"`), e sim um decimal simples
  com ponto (`"33.33"`), pronto para `Number(value)` sem tratamento adicional.
- Valores negativos ou inválidos passados em `value` são descartados (`valueToDigits` retorna
  `''` para `NaN` ou `n < 0`).
- Alterar `value` externamente (ex.: reset de formulário) sincroniza o estado interno via
  `useEffect` — útil para limpar o campo (`value=""`) após submit.

---

## Exemplos

```tsx
import { useState } from 'react';
import { PercentInput } from '@srm/diamond';

// Básico (controlado) — value/onChange usam formato decimal com ponto
function TaxaField() {
  const [taxa, setTaxa] = useState('');
  return <PercentInput label="Taxa de administração" value={taxa} onChange={setTaxa} />;
}

// Limitando o valor máximo a 100%
<PercentInput label="Alocação" max={100} value={alocacao} onChange={setAlocacao} />

// Com ajuda e obrigatório
<PercentInput label="Rentabilidade-alvo" required helperText="Percentual ao ano (a.a.)." />

// Estado de erro
<PercentInput label="Comissão" state="error" errorText="Percentual inválido." value={valor} onChange={setValor} />

// Somente leitura
<PercentInput label="Taxa atual" state="read-only" value="1.50" />

// Tema escuro (sobre header brand)
<PercentInput label="Percentual" theme="dark" value={valor} onChange={setValor} />

// Convertendo o valor recebido em onChange para número
function handleChange(value: string) {
  const numero = Number(value); // "33.33" → 33.33 (já é decimal com ponto)
}
```

### Integração com React Hook Form

```tsx
<Controller
  name="percentual"
  control={control}
  render={({ field, fieldState }) => (
    <PercentInput
      label="Percentual"
      max={100}
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- O símbolo `%` é `aria-hidden` (decorativo) — o rótulo semântico vem de `label`.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Como o campo não aceita edição por cursor nem colagem, avise o usuário (via `helperText`)
  que a entrada é apenas numérica sequencial quando o comportamento não for óbvio pelo contexto.

## Armadilhas comuns

- **Não** espere que `onChange` devolva a mesma string mascarada exibida (`"33,33"`) — ele
  entrega decimal com **ponto** (`"33.33"`), diferente do `CurrencyInput`.
- **Não** tente implementar seleção de texto, colar valor ou mover o cursor no meio do
  campo — o componente ignora essas interações por design (só digita da direita para a
  esquerda, como um valor de caixa).
- **Não** passe `onKeyDown`/`onChange` nativos esperando controlar o `<input>` diretamente —
  a lógica de tecla é interna e o `onChange` do DOM é neutralizado.
- Lembre-se de que `max` compara o valor **numérico** (ex.: `100` = `100,00%`), não a
  quantidade de dígitos — digitar além do limite simplesmente não tem efeito.
- Para exibir valores vindos da API, tanto `"33.33"` quanto `"33,33"` funcionam em `value`,
  mas padronize em `"33.33"` (ponto) para ficar simétrico ao que `onChange` devolve.
