# Overlay

Painel flutuante genérico ancorado a um trigger — a peça de base por trás de dropdowns,
popovers e menus contextuais do Diamond. Suporta dois modos de conteúdo (`dialog` livre e
`menu` navegável por teclado) e um modo "ancorado" totalmente controlado, usado internamente
por componentes como o DatePicker (âncora em `triggerRef` sem `children`). Construído sobre
`DialogTrigger` / `MenuTrigger` / `Popover` / `Dialog` / `Menu` / `MenuItem` do
`react-aria-components` — herda posicionamento inteligente (flip/collision), fechamento por
`Esc`/clique fora, foco preso e navegação por setas de graça.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Overlay/`
- **Export:** `import { Overlay } from '@srm/diamond';`
- **Relacionados/Base:** [Drawer](./Drawer.md) e [ContentModal](./ContentModal.md) (para
  conteúdo mais pesado ou fluxos com múltiplos passos); usado internamente por componentes
  como `AvatarDropdown`, `BalanceCard` (variante consolidated) e `DatePicker`/`DateRangePicker`
  (modo ancorado via `triggerRef`).

---

## Quando usar

- Menu de conta/usuário (avatar dropdown) com ações como "Meu perfil", "Configurações", "Sair".
- Lista contextual compacta: contas conectadas, saldo detalhado por conta, breakdown de um KPI.
- Seletor ou filtro rápido que não justifica um Modal (ex.: período, categoria, ordenação).
- Painel de calendário ancorado a um input (caso do DatePicker/DateRangePicker), via
  `triggerRef` + controle externo de `isOpen`.
- Qualquer conteúdo secundário/de suporte que o usuário só precisa **ver ou escolher** sem
  sair do contexto da tela atual.

## Quando **não** usar

- Conteúdo denso (mais de 6–8 linhas) ou formulário longo → use [`ContentModal`](./ContentModal.md).
- Fluxo com múltiplos passos ou painel lateral persistente → use [`Drawer`](./Drawer.md).
- Ação destrutiva isolada que precisa de confirmação explícita → use `ContentModal` com
  variante de confirmação, nunca um Overlay solto.
- **Nunca aninhe um Overlay dentro de outro Overlay** — quebra dismiss, foco e hierarquia de
  camadas (z-index único `--z-dropdown` para todos).

---

## Interface

```ts
import type { ReactNode, RefObject } from 'react';

type OverlayPlacement =
  | 'bottom start' | 'bottom end' | 'bottom'
  | 'top start'    | 'top end'    | 'top'
  | 'left'         | 'right';

type OverlayType = 'dialog' | 'menu';
// 'dialog' — conteúdo arbitrário (lista custom, formulário curto);
// 'menu'   — navegação por teclado com setas (menu de conta, ações).

interface OverlayMenuItem {
  id: string;
  label: string;
  icon?: ReactNode;
  onSelect: () => void;
  danger?: boolean;          // estilo destrutivo (vermelho) no item
}

interface OverlayProps {
  type?: OverlayType;                          // default: 'dialog'
  children?: ReactNode;                        // trigger (ex.: <Button>); opcional se triggerRef presente
  triggerRef?: RefObject<Element | null>;      // âncora externa — ver "Modo ancorado" abaixo
  onOpenChange?: (isOpen: boolean) => void;
  content?: ReactNode;                         // conteúdo do painel (apenas type='dialog')
  items?: OverlayMenuItem[];                   // itens do menu (apenas type='menu')
  placement?: OverlayPlacement;                // default: 'bottom end'
  offset?: number;                             // default: 4 (px entre trigger e painel)
  minWidth?: number | string;                  // default: 260 (px)
  maxWidth?: number | string;                  // sem default (sem limite)
  padding?: string;                             // default via CSS: var(--space-4) no dialog, 0 no menu
  defaultOpen?: boolean;                       // abre ao montar (uncontrolled) — útil p/ docs/demo
  isOpen?: boolean;                            // modo controlado
  shouldFlip?: boolean;                        // default: comportamento nativo do RAC (true)
  dataTheme?: 'dark';                          // aplica data-theme no <Popover> (portal)
  className?: string;
}
```

### Notas de comportamento

- **Controlado vs. não controlado**: passar `isOpen` (mesmo `undefined` explícito não conta)
  ativa o modo controlado — o componente monta `{ isOpen, onOpenChange }` no `DialogTrigger`/
  `MenuTrigger`. Sem `isOpen`, `defaultOpen: true` ativa o modo uncontrolled do RAC
  (`{ defaultOpen: true }`); sem nenhum dos dois, o trigger controla a abertura sozinho.
- **Modo ancorado** (`triggerRef` presente): o componente **ignora** `DialogTrigger`/`MenuTrigger`
  e renderiza o `<Popover>` sozinho, ancorado ao elemento referenciado. Nesse modo `children`
  é opcional e o Overlay é **totalmente controlado externamente** — requer `isOpen` +
  `onOpenChange` de fato funcionais (é o padrão usado pelo DatePicker/DateRangePicker: o
  input é a âncora real, o Overlay não renderiza nenhum trigger próprio).
  Quando `isOpen` está controlado mas **não** há `triggerRef` (caso de docs/demo), o Popover
  vira `isNonModal` — combinação usada só para exemplos, não pelo uso real ancorado.
- `minWidth`, `maxWidth` e `padding` são aplicados como **CSS custom properties** inline
  (`--overlay-min-width`, `--overlay-max-width`, `--overlay-padding`) consumidas pelo SCSS
  module — não são propriedades DOM diretas. `maxWidth` e `padding` só entram no `style` quando
  definidos; caso contrário o CSS usa seus próprios fallbacks (`none` e
  `var(--space-4)`/`0` conforme `type`).
- `dataTheme="dark"` seta `data-theme="dark"` no `<Popover>` — necessário porque o Popover é
  renderizado num portal e não herda automaticamente o `data-theme` de um ancestral; use
  quando o trigger estiver sobre um fundo/tema escuro.
- `shouldFlip` só é repassado ao `Popover` quando definido explicitamente — se omitido, usa o
  default nativo do react-aria (`true`, vira para o lado oposto quando não há espaço).
- No modo `menu`, cada `OverlayMenuItem` com `danger: true` recebe uma borda superior e cor
  `--feedback-error` (usado para itens tipo "Sair"/ações destrutivas dentro de um menu).

---

## Exemplos

```tsx
import { useState } from 'react';
import { Overlay, Button } from '@srm/diamond';
import { User, Settings, LogOut } from 'lucide-react';

// Dialog básico (conteúdo livre)
<Overlay
  placement="bottom end"
  content={
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <span>Item 1</span>
      <span>Item 2</span>
      <span>Item 3</span>
    </div>
  }
>
  <Button variant="link" size="md">Abrir overlay</Button>
</Overlay>

// Menu contextual com navegação por teclado
<Overlay
  type="menu"
  placement="bottom end"
  items={[
    { id: 'profile',  label: 'Meu perfil',    icon: <User size={16} />,     onSelect: () => {} },
    { id: 'settings', label: 'Configurações', icon: <Settings size={16} />, onSelect: () => {} },
    { id: 'signout',  label: 'Sair',          icon: <LogOut size={16} />,   onSelect: () => {}, danger: true },
  ]}
>
  <Button variant="link" size="md">Abrir menu</Button>
</Overlay>

// Controlado externamente (ex.: fechar após uma ação assíncrona)
function ContaMenu() {
  const [open, setOpen] = useState(false);
  return (
    <Overlay
      type="menu"
      isOpen={open}
      onOpenChange={setOpen}
      items={[{ id: 'refresh', label: 'Atualizar saldo', onSelect: () => setOpen(false) }]}
    >
      <Button variant="link">Ações</Button>
    </Overlay>
  );
}

// Modo ancorado (triggerRef) — padrão usado pelo DatePicker
function CampoComPainel() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  return (
    <>
      <input ref={inputRef} onFocus={() => setOpen(true)} />
      <Overlay
        triggerRef={inputRef}
        isOpen={open}
        onOpenChange={setOpen}
        placement="bottom start"
        content={<div>Calendário / conteúdo custom aqui</div>}
      />
    </>
  );
}

// Largura customizada e tema escuro (sobre header brand)
<Overlay
  minWidth={320}
  maxWidth={400}
  padding="var(--space-3)"
  dataTheme="dark"
  content={<span>Conteúdo compacto</span>}
>
  <Button variant="secondary" theme="dark">Detalhes</Button>
</Overlay>
```

---

## Acessibilidade

- `type="menu"` usa `Menu`/`MenuItem` do react-aria: navegação por setas, `Home`/`End`, seleção
  por `Enter`/`Espaço` e anúncio de `textValue` (derivado de `label`) para leitores de tela —
  tudo de graça, sem configuração extra.
- `type="dialog"` usa `Dialog` do react-aria: foco é movido para dentro do painel ao abrir e
  restaurado ao trigger ao fechar; `Esc` e clique fora fecham por padrão.
- No **modo ancorado** (`triggerRef`), a responsabilidade de expor um rótulo acessível para o
  elemento ancorado é do consumidor (ex.: o `label` do input no caso do DatePicker) — o Overlay
  em si não injeta `aria-label`.
- Ícones em `OverlayMenuItem.icon` são decorativos (`aria-hidden`); o nome acessível do item
  vem sempre de `label`/`textValue`.
- **Elevação**: o painel usa `--shadow-popover` (camada de contato curta + difusa longa), não
  `--shadow-card` — sobre superfícies claras a sombra de card praticamente sumia e o painel
  se confundia com o fundo. O token tem override próprio no tema dark.
- **Padding do menu**: `type="menu"` usa `var(--space-1) 0` por padrão (antes `0`), para os
  itens não encostarem na borda do painel. Sobrescreva via `padding` quando necessário.

## Armadilhas comuns

- **Não aninhe overlays** — abrir um `Overlay` dentro do `content`/`items` de outro quebra
  dismiss e foco.
- `content` e `items` são exclusivos por `type`: passar `items` com `type="dialog"` (ou
  vice-versa) é ignorado silenciosamente — confira o `type` antes de depurar "o painel não
  mostra o que passei".
- No modo ancorado (`triggerRef`), esquecer de passar `isOpen`/`onOpenChange` funcionais deixa
  o painel preso aberto ou fechado — esse modo **não** tem estado próprio de abertura.
- `minWidth`/`maxWidth`/`padding` não aceitam classes CSS externas para sobrescrever — use os
  próprios props (eles viram custom properties) em vez de mirar `.panel` via `className`.
- `shouldFlip={false}` mantém o `placement` fixo mesmo sem espaço na viewport — útil só quando
  o layout garante espaço suficiente; do contrário o painel pode cortar/vazar da tela.
