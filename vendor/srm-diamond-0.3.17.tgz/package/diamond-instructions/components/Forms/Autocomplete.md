# Autocomplete

Campo de busca com sugestões (padrão *combobox*): o usuário **digita** e a lista responde ao
texto. Serve tanto para filtrar uma lista já carregada quanto para exibir resultados que só
existem no servidor, com debounce, estado de carregamento e o registro cru da API preservado
em cada opção. Construído sobre `ComboBox`, `Group`, `Input`, `Popover` e `ListBox` do
`react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Autocomplete/`
- **Export:** `import { Autocomplete } from '@srm/diamond';`
- **Relacionados:** [Select](./Select.md) (lista fechada, sem digitação),
  [MultiSelect](./MultiSelect.md) (seleção múltipla),
  [SearchInput](./Inputs/SearchInput.md) (busca sem lista de sugestões)

---

## Quando usar

- Lista **grande** demais para um `Select` — o usuário sabe o que quer e digita para chegar lá.
- Dados que vêm de **API**: clientes, empresas, beneficiários, contas, produtos, endereços.
- Quando cada opção precisa de mais de uma linha de informação (nome + identificador) para o
  usuário distinguir itens parecidos.
- Quando o valor pode ser um texto livre além das sugestões (`allowsCustomValue`).

## Quando **não** usar

- Lista curta e fixa (até ~10 itens) → use [`Select`](./Select.md): sem digitação, menos
  chance de erro.
- Seleção de **vários** itens → use [`MultiSelect`](./MultiSelect.md). Este componente é de
  seleção única; não há modo múltiplo.
- Busca que filtra uma **tabela ou lista da página** (não escolhe um item) → use
  [`SearchInput`](./Inputs/SearchInput.md); um combobox anuncia "sugestões" a leitores de tela
  e sugere que a seleção leva a um valor de campo.
- Campo com máscara (CPF, telefone) → use o Input específico da família
  [`Inputs`](./Inputs/_shared.md).

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';

type AutocompleteState = 'default' | 'error' | 'disabled' | 'read-only';
type AutocompleteSize  = 'sm' | 'md';
type AutocompleteTheme = 'default' | 'dark';
type AutocompleteMenuTrigger = 'input' | 'focus' | 'manual';

interface AutocompleteOption<TData = unknown> {
  id: string;                 // chave estável; é o `value` e o que volta em onChange
  label: string;              // texto principal; escrito no input ao selecionar
  description?: string;       // segunda linha; também entra no filtro client-side
  icon?: string;              // glifo do `Icon`, à esquerda da opção
  isDisabled?: boolean;
  data?: TData;               // registro cru da API, devolvido intacto em onChange
}

interface AutocompleteProps<TData = unknown> {
  state?: AutocompleteState;             // default: 'default'
  size?: AutocompleteSize;               // default: 'md'
  theme?: AutocompleteTheme;             // default: 'default'
  label?: ReactNode;
  placeholder?: string;                  // default: 'Buscar...'
  helperText?: ReactNode;
  errorText?: ReactNode;
  required?: boolean;                    // default: false

  options?: readonly AutocompleteOption<TData>[];   // default: []

  value?: string | null;                 // controlado — id da opção
  defaultValue?: string | null;          // default: null
  onChange?: (option: AutocompleteOption<TData> | null) => void;

  inputValue?: string;                   // controlado — texto do campo
  defaultInputValue?: string;            // default: ''
  onInputChange?: (text: string) => void;   // a cada tecla, sem debounce

  onSearch?: (query: string) => void;    // com debounce — é aqui que se chama a API
  debounceMs?: number;                   // default: 300
  minChars?: number;                     // default: 0
  isLoading?: boolean;                   // default: false

  shouldFilter?: boolean;                // default: true  ← false quando o filtro é do servidor
  allowsCustomValue?: boolean;           // default: false
  menuTrigger?: AutocompleteMenuTrigger; // default: 'input'

  showClear?: boolean;                   // default: true
  showTrigger?: boolean;                 // default: true

  emptyText?: ReactNode;                 // default: 'Nenhum resultado encontrado'
  loadingText?: ReactNode;               // default: 'Buscando...'
  minCharsText?: (minChars: number) => ReactNode;  // default: `Digite ao menos N caracteres`

  renderOption?: (option: AutocompleteOption<TData>) => ReactNode;

  listAriaLabel?: string;                // nome da lista quando não há `label`
  triggerAriaLabel?: string;             // default: 'Mostrar opções'
  clearAriaLabel?: string;               // default: 'Limpar seleção'

  name?: string;
  autoFocus?: boolean;
  onBlur?: () => void;
  className?: string;
  ref?: Ref<HTMLDivElement>;
}
```

### Notas de comportamento

- **Dois modos, uma prop.** `options` é sempre a lista exibida. Com `shouldFilter` (padrão) o
  componente filtra `options` pelo texto digitado; com `shouldFilter={false}` ele exibe
  `options` como veio. Deixar o filtro ligado numa lista já filtrada pelo servidor faz a busca
  acontecer duas vezes e esconder resultados legítimos (a API casa por CNPJ, o filtro local não).
- **`onSearch` é o gancho de API, `onInputChange` é o gancho de tecla.** `onSearch` só dispara
  após `debounceMs` de inatividade e a partir de `minChars` caracteres; `onInputChange` dispara
  a cada tecla, sem filtro nenhum. Chamar API no `onInputChange` gera uma requisição por tecla.
- **Selecionar não conta como busca.** Ao escolher uma opção, o rótulo dela é escrito no campo;
  esse texto não dispara `onSearch`, senão toda seleção custaria uma requisição extra.
- **A busca fica "vazia" enquanto o campo mostra o item selecionado.** Reabrir a lista logo após
  selecionar mostra a lista inteira, não só o item escolhido — é o comportamento esperado de
  quem abriu de novo para trocar de item.
- **Apagar o campo desfaz a seleção**, emitindo `onChange(null)`. Vale tanto para o botão de
  limpar quanto para apagar o texto no teclado.
- **`isLoading` não esvazia a lista.** O spinner aparece no campo e o `loadingText` só ocupa o
  painel quando não há nada para mostrar; resultados anteriores continuam visíveis enquanto a
  próxima resposta não chega. Isso evita a lista piscando a cada pausa de digitação.
- **O painel não fecha quando a lista fica vazia** (`allowsEmptyCollection` do React Aria) —
  senão a mensagem de "buscando" ou "nenhum resultado" desapareceria justamente quando é
  necessária.
- **Semi-controlado**: sem `value`, o componente mantém a seleção internamente a partir de
  `defaultValue`; passando `value`, ele passa a ser a única fonte de verdade — atualize-o dentro
  de `onChange`. O mesmo vale para `inputValue`/`defaultInputValue`.
- **`data` volta inteiro em `onChange`.** Guarde nele o registro da API (id interno, CNPJ,
  saldo, o objeto todo) e leia direto no handler, em vez de procurar o item de novo pelo `id`.
- **Largura 100% do container** — como os [`Inputs`](./Inputs/_shared.md), não como o `Select`
  (que tem largura fixa de 240px). Dimensione pelo container ou por `className`.
- **`errorText` sozinho já coloca o campo em erro**; `state="error"` é redundante quando há
  mensagem. Erro e ajuda não coexistem: havendo erro, `errorText` substitui o `helperText`.
- **`allowsCustomValue`** mantém o texto digitado mesmo sem correspondência. `onChange` continua
  emitindo `null` nesse caso — o texto livre chega por `onInputChange`.
- **`menuTrigger`**: `'input'` (padrão) abre ao digitar, `'focus'` abre ao focar o campo,
  `'manual'` só abre pelo botão de chevron ou por seta para baixo.

---

## Exemplos

```tsx
import { Autocomplete } from '@srm/diamond';

// Lista local, filtro client-side
<Autocomplete
  label="Empresa"
  options={EMPRESAS}
  onChange={(option) => console.log(option?.id)}
/>

// Opção com segunda linha e ícone (a description também é buscável)
const BANCOS = [
  { id: '001', label: 'Banco do Brasil', description: 'Código 001', icon: 'building' },
  { id: '341', label: 'Itaú Unibanco', description: 'Código 341', icon: 'building' },
];
<Autocomplete label="Banco" options={BANCOS} placeholder="Nome ou código" />

// Selecionado inicialmente
<Autocomplete
  label="Empresa"
  options={EMPRESAS}
  defaultValue="42"
  defaultInputValue="Alfa Logística"
/>

// Estado de erro
<Autocomplete label="Empresa" options={EMPRESAS} errorText="Selecione uma empresa" />
```

### Busca no servidor

```tsx
function BuscaEmpresa() {
  const [options, setOptions] = useState<AutocompleteOption<Empresa>[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const requestId = useRef(0);

  const handleSearch = useCallback(async (query: string) => {
    const id = ++requestId.current;
    setIsLoading(true);
    const empresas = await api.buscarEmpresas(query);
    // Descarta respostas fora de ordem: sem isto, uma busca lenta antiga
    // sobrescreve o resultado da busca mais recente.
    if (requestId.current !== id) return;
    setOptions(empresas.map((empresa) => ({
      id: empresa.id,
      label: empresa.razaoSocial,
      description: empresa.cidade,
      data: empresa,
    })));
    setIsLoading(false);
  }, []);

  return (
    <Autocomplete
      label="Empresa"
      options={options}
      isLoading={isLoading}
      shouldFilter={false}   // a API já filtrou
      minChars={3}
      onSearch={handleSearch}
      onChange={(option) => selecionar(option?.data)}
    />
  );
}
```

> Com TanStack Query, o mesmo desenho fica: `onSearch` guarda o termo em estado, a query
> depende desse termo (`enabled: termo.length >= 3`), e `options`/`isLoading` saem do resultado
> da query — o descarte de respostas fora de ordem já vem resolvido pela lib.

### Integração com React Hook Form

```tsx
<Controller
  name="empresaId"
  control={control}
  defaultValue={null}
  render={({ field, fieldState }) => (
    <Autocomplete
      label="Empresa"
      options={options}
      value={field.value}
      onChange={(option) => field.onChange(option?.id ?? null)}
      onBlur={field.onBlur}
      onSearch={handleSearch}
      shouldFilter={false}
      isLoading={isLoading}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

> Com Zod, valide `z.string().min(1, 'Selecione uma empresa')` sobre o `id`, ou
> `z.string().nullable().refine(Boolean, 'Selecione uma empresa')` se o default for `null`.
> Para guardar o objeto inteiro no formulário, passe `field.onChange(option)` e valide com um
> `z.object({...}).nullable()`.

---

## Acessibilidade

- O campo é um `role="combobox"` do React Aria: setas navegam a lista, `Enter` confirma, `Esc`
  fecha e devolve o texto anterior, `Home`/`End` andam no texto. A contagem de resultados é
  anunciada automaticamente a cada mudança da lista.
- O botão de chevron e o de limpar são **irmãos** do input dentro do `Group`, nunca aninhados
  nele — controle dentro de controle quebraria a navegação por teclado e é HTML inválido.
- Ambos os botões são só-ícone e têm `aria-label` (`triggerAriaLabel`, `clearAriaLabel`);
  traduza-os junto com o resto da interface se o produto for multilíngue.
- Sem `label`, passe `listAriaLabel` — ele nomeia o campo e a lista; sem nenhum dos dois, o nome
  cai no genérico "Sugestões".
- `helperText`/`errorText` são associados ao input por `aria-describedby`, e `errorText` marca
  `aria-invalid`.
- O ícone de lupa, o spinner e o check da opção selecionada são decorativos (`aria-hidden`) — o
  estado de seleção é anunciado pelo `aria-selected` da opção.

## Armadilhas comuns

- **Chamar a API no `onInputChange`** — é uma requisição por tecla. Use `onSearch`.
- **Esquecer `shouldFilter={false}` no modo servidor** — o filtro local roda por cima do
  resultado da API e some com itens que a API achou por outro critério (código, CNPJ, apelido).
- **Ignorar o descarte de respostas fora de ordem** — sem um `requestId` (ou uma lib de query),
  a resposta de uma busca antiga chega depois e sobrescreve a lista atual.
- **Passar `options` recriado a cada render** (array literal inline) — a lista filtrada é
  memoizada pela identidade de `options`; declare o array fora do componente, em `useMemo` ou
  no estado.
- **`id` duplicado ou instável** entre respostas da API — as chaves do `ListBox` são os `id`;
  duplicatas colidem e um `id` que muda a cada resposta perde a seleção.
- **Usar `value` sem atualizar o estado dentro de `onChange`** — a seleção fica travada, igual a
  qualquer campo controlado.
- **Esperar seleção múltipla** — não existe; use [`MultiSelect`](./MultiSelect.md).
- **Esperar que o tema `dark` chegue ao painel por herança** — o popover é renderizado em
  portal; passe `theme="dark"` na prop, não confie na cascata do container.
