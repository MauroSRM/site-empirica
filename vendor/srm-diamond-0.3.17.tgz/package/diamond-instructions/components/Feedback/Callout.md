# Callout

Bloco de destaque inline para comunicar um aviso, status ou insight contextual dentro do
fluxo da tela (não é um overlay nem um toast). Suporta 6 variantes semânticas — `info`,
`success`, `warning`, `error`, `ai` (destaque de marca, com o glifo do diamante da SRM) e
`neutral` (destaque neutro, sem semântica de status) —, título opcional e um modo interativo
que transforma o Callout em `Button` do react-aria-components (`AriaButton`, focável e
ativável por teclado). Construído com `class-variance-authority` (CVA) para as variantes
visuais e ícones do `lucide-react` (exceto a variante `ai`, que usa `LogoIcon` de
`Brand/Logo`).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Callout/`
- **Export:** `import { Callout } from '@srm/diamond';`
- **Relacionados:** Toast (`Toastr/Toast`, notificação temporária flutuante) para eventos
  transitórios; `Callout` é para conteúdo persistente embutido no layout.

---

## Quando usar

- Avisos contextuais que fazem parte do conteúdo da tela (não desaparecem sozinhos):
  "extrato disponível", "novo produto elegível", "documento pendente de assinatura".
- Comunicar o resultado de uma operação que permanece visível na página (sucesso de
  cadastro, erro de sincronização, alerta de limite atingido).
- Destacar uma sugestão ou insight gerado por IA (`variant="ai"`) — ex.: recomendação de
  rebalanceamento, resumo automático de carteira.
- Destaque neutro, sem conotação de status (`variant="neutral"`) — ex.: anúncio de nova
  funcionalidade, dica de produto.
- Quando o aviso deve ser **acionável**: passe `onClick` para virar um atalho navegável
  (ex.: "Extrato disponível → toque para abrir").

## Quando **não** usar

- Notificação temporária que desaparece sozinha após uma ação (salvar, copiar, enviar) →
  use o Toast (`Toastr/Toast`).
- Bloqueio de fluxo que exige decisão do usuário antes de continuar → use `Modal` ou
  `ContentModal`.
- Texto de ajuda associado a um campo de formulário específico → use `helperText`/`errorText`
  do próprio `InputBase` (não envolva cada campo em um `Callout`).
- Estado vazio de lista/tela (sem dados) → use `EmptyState`.

---

## Interface

```ts
import type { CSSProperties } from 'react';

type CalloutVariant = 'info' | 'success' | 'warning' | 'error' | 'ai' | 'neutral';

interface CalloutProps {
  variant?: CalloutVariant;    // default: 'info'
  title?: string;               // opcional — quando ausente, mostra só o body
  body: string;                 // obrigatório
  /** Quando presente, o Callout renderiza como AriaButton do RAC (clicável, focável). */
  onClick?: () => void;
  className?: string;
  style?: CSSProperties;
}
```

### Notas de comportamento

- **Não** herda de `InputBaseProps` — é um componente independente, sem `label`, `state`
  ou `size`. A única "configuração" visual é `variant`.
- `variant` define ícone, cor da barra lateral (`rail`), cor de fundo e cor do glifo, via
  `CALLOUT_CONFIG` (`Callout.constants.ts`):
  - `info` → `Info` (lucide)
  - `success` → `CheckCircle2`
  - `warning` → `AlertTriangle`
  - `error` → `AlertCircle`
  - `ai` → `LogoIcon` (diamante da marca SRM, `fill="currentColor"`) — esta variante **não**
    usa o círculo de fundo do ícone (`noCircle: true`); o glifo fica "solto", como assinatura.
  - `neutral` → `Info` (mesmo ícone de `info`, mas com paleta neutra — `--surface-muted`,
    `--callout-rail-neutral`, `--feedback-tint-neutral`, texto `--text-secondary`); usado para
    destaque sem semântica de status/alerta.
- **Modo interativo**: a presença de `onClick` (checada via `typeof onClick === 'function'`)
  decide o elemento raiz — `AriaButton` (`Button` de `react-aria-components`, disparado via
  `onPress={onClick}`) quando interativo, `<div>` caso contrário. Não há prop booleana
  separada para isso; é inferido do próprio `onClick`. `onClick` é tipado como `() => void`
  — **não** recebe o evento (`MouseEvent`/`KeyboardEvent`) como argumento.
- Quando interativo, um `ChevronRight` é anexado à direita automaticamente (`aria-hidden`),
  sinalizando visualmente que o bloco é navegável.
- `title` é opcional — se omitido, o Callout mostra apenas o `body` (sem quebra de linha
  extra para o título).
- No modo **não**-interativo, o elemento raiz ganha `role`/`aria-live` conforme a variante,
  via `CALLOUT_STATUS_ROLE` (`Callout.constants.ts`):
  - `error` → `role="alert"` + `aria-live="assertive"`
  - `warning` | `success` | `info` → `role="status"` + `aria-live="polite"`
  - `ai` | `neutral` → **sem** `role`/`aria-live` (nenhuma das duas está em
    `CALLOUT_STATUS_ROLE`)
  No modo interativo esse `role`/`aria-live` não é aplicado — o `AriaButton` já expõe
  `role="button"` nativamente.
- Tamanhos de ícone são fixos por `Callout.constants.ts`: `CALLOUT_ICON_SIZE = 16` (glifo
  dentro do círculo **e** glifo "bare" da `ai`, mesmo tamanho para as duas), `CALLOUT_CHEVRON_SIZE = 16`.
- Não há prop de tema (`theme`) — as cores por variante vêm de tokens CSS
  (`--feedback-info`, `--feedback-success`/`--success-default`, `--feedback-warning`/`--warning-strong`,
  `--feedback-error`/`--error-strong`, `--ai-bg`/`--text-brand`, `--surface-muted`/`--text-secondary`)
  que já respondem a light/dark automaticamente.
- `className` e `style` são aplicados ao elemento raiz (`AriaButton` ou `div`), mesclados às
  classes de variante via `clsx`.

---

## Exemplos

```tsx
import { Callout } from '@srm/diamond';

// Básico — informativo, sem título
<Callout body="O extrato de junho já pode ser consultado." />

// Com título
<Callout
  variant="success"
  title="Cadastro concluído"
  body="Sua conta está pronta para receber o primeiro aporte."
/>

// Aviso
<Callout
  variant="warning"
  title="Documento pendente"
  body="Envie o comprovante de residência para liberar o saque."
/>

// Erro
<Callout variant="error" title="Falha na sincronização" body="Não foi possível atualizar seu saldo agora." />

// Destaque de IA (glifo da marca, sem círculo)
<Callout
  variant="ai"
  title="Sugestão"
  body="Seu perfil indica espaço para maior exposição em renda variável."
/>

// Neutro (destaque sem semântica de status)
<Callout
  variant="neutral"
  title="Nova função disponível"
  body="Agora você pode exportar seu extrato em PDF."
/>

// Interativo (renderiza como AriaButton, ganha chevron e foco)
<Callout
  variant="info"
  body="Extrato disponível — toque para abrir."
  onClick={() => router.push('/extrato')}
/>

// Estilo/posicionamento customizado
<Callout
  variant="warning"
  body="Limite diário quase atingido."
  className="meu-espacamento"
  style={{ maxWidth: 480 }}
/>
```

Não se aplica exemplo com React Hook Form — `Callout` não é um campo de formulário (não
possui `value`/`onChange` de dado editável).

---

## Acessibilidade

- No modo interativo, o elemento raiz é o `Button` de `react-aria-components` (`AriaButton`):
  focável via teclado (Tab), expõe `role="button"` nativamente e é ativável por
  Enter/Espaço sem código adicional (disparado via `onPress`, não `onClick` nativo).
- Ícone, barra lateral (`rail`) e chevron são todos `aria-hidden="true"` — são puramente
  decorativos; o conteúdo semântico é `title` + `body` (texto real dentro do DOM).
- No modo **não**-interativo, o `role`/`aria-live` do elemento raiz depende da `variant`:
  `error` → `role="alert"` + `aria-live="assertive"` (anúncio imediato); `warning`,
  `success`, `info` → `role="status"` + `aria-live="polite"` (anúncio ao final da leitura
  atual); `ai` e `neutral` → **sem** `role`/`aria-live` — se precisar que um Callout `ai`/
  `neutral` seja anunciado ao aparecer dinamicamente, envolva-o (ou anuncie) você mesmo.
- Quando interativo, esse `role`/`aria-live` por variante **não** é aplicado — o `AriaButton`
  já expõe sua própria semântica de botão.
- Quando interativo e o texto do `body`/`title` não deixar claro o destino da navegação,
  considere reforçar o rótulo (o `Callout` não aceita `aria-label` — a rotulagem vem do
  texto visível).

## Armadilhas comuns

- **Não** use `Callout` para mensagens que devem sumir sozinhas — ele não tem
  auto-dismiss nem temporizador; para isso, use o Toast.
- `onClick` decide sozinho se o componente vira `AriaButton` — não existe uma prop
  `interactive`/`clickable` separada; passar uma função (mesmo vazia) já muda a semântica
  e a marcação (chevron, foco, cursor, ausência de `role`/`aria-live` por variante).
- `onClick` é `() => void` — não espere receber o `MouseEvent`/`KeyboardEvent` como
  argumento (diferente de um handler nativo de `<button onClick>`).
- A variante `ai` não deve ser usada para "avisos genéricos de destaque" — o glifo é a
  marca (diamante) e implica que o conteúdo veio de um mecanismo de IA/recomendação; para
  destaque neutro sem essa conotação, use `variant="neutral"`.
- `ai` e `neutral` não expõem `role`/`aria-live` no modo não-interativo — se o conteúdo for
  crítico e inserido dinamicamente, anuncie você mesmo (não assuma que essas duas variantes
  serão lidas automaticamente como `info`/`success`/`warning`/`error`).
- `body` é obrigatório e tipado como `string` — não passe `ReactNode` complexo; para
  conteúdo rico, componha ao redor do `Callout` em vez de forçar dentro de `body`.
- Como não há prop de tamanho, não tente encolher/expandir o Callout por variante —
  ajuste `style`/`className` (largura, `maxWidth`) via container.
