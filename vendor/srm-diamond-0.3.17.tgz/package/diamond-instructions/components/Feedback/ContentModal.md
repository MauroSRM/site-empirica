# ContentModal

Modal de conteúdo genérico para diálogos, avisos regulatórios, confirmações e formulários
dentro de um overlay. Suporta dois layouts (`center`/`left`), cinco tamanhos, ícone semântico,
divisor automático de scroll no header/footer e um footer de ações que alterna sozinho entre
`DoubleButton` (duas ações) e `Button` solto (uma ação). Construído sobre
`ModalOverlay` + `Modal` + `Dialog` + `Heading` do `react-aria-components`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/ContentModal/`
- **Export:** `import { ContentModal } from '@srm/diamond';`
- **Relacionados/Base:** [Button](../Forms/Button.md), `DoubleButton`, `IconButton`, `Icon` (usados internamente)

---

## Quando usar

- Avisos regulatórios/compliance que exigem leitura e confirmação explícita (ex.: mudança de
  regulamento CVM, termo de suitability) antes de o usuário prosseguir.
- Confirmação de ação com contexto textual maior do que cabe em um tooltip/alert simples
  (ex.: "excluir conta", "cancelar resgate", "confirmar transferência entre contas").
- Formulários curtos dentro de um overlay modal (ex.: editar meta, criar alerta).
- Conteúdo longo que precisa rolar dentro de uma área fixa (`scrollable`), com indicação visual
  de que há mais conteúdo acima/abaixo (divisores automáticos no header e footer).

## Quando **não** usar

- Notificação transitória sem necessidade de bloquear a tela → use um Toast/Snackbar (não é
  este componente).
- Menu de opções ou seletor pequeno ancorado a um elemento → prefira um popover/dropdown.
- Duas ações lado a lado fora de um modal → use `DoubleButton` diretamente.
- Um único botão de ação isolado → use [`Button`](../Forms/Button.md) diretamente.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonVariant } from '@srm/diamond'; // Forms/Button
import type { IconType } from '@srm/diamond';       // Icons/Icon

type ContentModalSize = 'sm' | 'md' | 'lg' | 'xl' | 'full';
type ContentModalAlign = 'center' | 'left';

interface ContentModalAction {
  label: string;
  onClick: () => void;
  variant?: ButtonVariant;   // default (nas duas ações): ver "Notas de comportamento"
  disabled?: boolean;
  loading?: boolean;
}

interface ContentModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  /**
   * Ícone semântico (usa o componente Icon internamente).
   * align="center": ícone "lg" centralizado acima do título.
   * align="left": ícone "lg" inline ao lado do título.
   */
  iconType?: IconType;        // 'success' | 'error' | 'warning' | 'info' | 'default' | 'accent'
  align?: ContentModalAlign;  // default: 'center'
  children?: ReactNode;
  primaryAction?: ContentModalAction;
  secondaryAction?: ContentModalAction;
  size?: ContentModalSize;    // default: 'md'
  dismissible?: boolean;      // default: true
  scrollable?: boolean;       // default: true
  showDivider?: boolean;      // default: true — divisor entre body e footer
  footerNote?: string;        // nota exibida só no layout "left", ao lado das ações
}
```

### Notas de comportamento

- **Sem `className` na assinatura pública** — o componente não expõe customização de classe;
  toda a aparência é controlada pelas props (`size`, `align`, `iconType`, etc.).
- **Fechamento (`onClose`)**: disparado pelo `X` no header (quando `dismissible`), por clique
  fora do modal e por `Esc` — via `ModalOverlay` do react-aria. Quando `dismissible={false}`,
  o `X` some **e** o dismiss por clique-fora/teclado é desabilitado
  (`isKeyboardDismissDisabled`) — o usuário só sai pelas ações do footer.
- **Footer de ações — resolução automática**:
  - `primaryAction` **e** `secondaryAction` presentes → renderiza **um único** `DoubleButton`
    (`layout="horizontal"`, `size="md"`), e o `pair` visual é inferido automaticamente:
    - `primaryAction.variant === 'destructive'` → `'destructive-ghost'`
    - senão, `secondaryAction.variant === 'secondary'` → `'primary-secondary'`
    - senão (padrão) → `'primary-ghost'`
  - Apenas uma das duas ações presente → renderiza um `Button` avulso (`size="md"`), com
    `variant` default `'ghost'` para `secondaryAction` e `'primary'` para `primaryAction`.
  - Nenhuma ação e sem `footerNote` → o footer inteiro **não é renderizado**.
  - `footerNote` só aparece visualmente no layout `align="left"` (fica à esquerda do footer,
    ao lado das ações); no layout `align="center"` a prop é ignorada silenciosamente.
- **Divisores automáticos por scroll**: um `useEffect` com `ResizeObserver` + listener de
  `scroll` mede o conteúdo (`bodyRef`) e adiciona a classe de divisor no header quando o body
  está rolado para baixo (`scrollTop > 1`), e no footer via `showDivider` (estático, não
  depende de scroll). Isso só é observado enquanto `isOpen` é `true`.
- **`scrollable={false}`**: remove o comportamento de rolagem interna do body — use quando o
  conteúdo é curto e fixo (ex.: confirmação simples) para evitar scrollbar desnecessária.
- **Ícone (`iconType`)**: usa o componente `Icon` internamente (`size="lg"`); em
  `align="center"` fica centralizado acima do título, em `align="left"` fica inline à
  esquerda do bloco de título/subtítulo.
- **`aria-label` do `Dialog`**: recebe `title ?? 'Conteúdo'` automaticamente — não é
  necessário (nem possível) passar `aria-label` manualmente.
- **Tamanhos (`size`)**: controlam a largura máxima do painel modal (`sm` → `full`); `full`
  ocupa a viewport inteira — útil para fluxos mobile ou conteúdo extenso.

---

## Exemplos

```tsx
import { useState } from 'react';
import { ContentModal, Button } from '@srm/diamond';

// Básico — aviso regulatório centralizado, com uma ação
function AvisoRegulamento() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setIsOpen(true)}>Ver aviso</Button>
      <ContentModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        align="center"
        iconType="info"
        title="Novo regulamento disponível"
        subtitle="A CVM publicou atualizações nos requisitos de suitability. Revise antes de continuar."
        primaryAction={{ label: 'Entendi', onClick: () => setIsOpen(false) }}
      >
        <p>Conteúdo detalhado do comunicado regulatório...</p>
      </ContentModal>
    </>
  );
}

// Duas ações — confirmação padrão (DoubleButton primary-ghost inferido)
<ContentModal
  isOpen={isOpen}
  onClose={onClose}
  align="center"
  title="Confirmar resgate"
  subtitle="O valor será processado em até 1 dia útil."
  primaryAction={{ label: 'Confirmar', onClick: handleConfirm }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
>
  <p>Você está resgatando R$ 10.000,00 do fundo XP Renda Fixa.</p>
</ContentModal>

// Ação destrutiva — infere pair="destructive-ghost" automaticamente
<ContentModal
  isOpen={isOpen}
  onClose={onClose}
  align="center"
  iconType="error"
  title="Excluir conta"
  subtitle="Esta ação não pode ser desfeita."
  primaryAction={{ label: 'Excluir', variant: 'destructive', onClick: handleDelete }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
/>

// Layout "left" com ícone inline, footerNote e loading na ação primária
<ContentModal
  isOpen={isOpen}
  onClose={onClose}
  align="left"
  iconType="warning"
  title="Atualizar dados cadastrais"
  subtitle="Alguns campos exigem confirmação adicional."
  footerNote="Última atualização há 6 meses."
  primaryAction={{ label: 'Salvar', onClick: handleSave, loading: isSaving }}
  secondaryAction={{ label: 'Depois', onClick: onClose }}
>
  <FormularioCadastro />
</ContentModal>

// Não dismissível — só sai pelas ações do footer (ex.: termo obrigatório)
<ContentModal
  isOpen={isOpen}
  onClose={onClose}
  dismissible={false}
  align="center"
  title="Termo de suitability"
  size="lg"
  primaryAction={{ label: 'Aceito', onClick: handleAccept }}
  secondaryAction={{ label: 'Recusar', onClick: handleDecline }}
>
  <TextoLongoDoTermo />
</ContentModal>

// Tamanho "full" para conteúdo extenso, sem divider no footer
<ContentModal
  isOpen={isOpen}
  onClose={onClose}
  size="full"
  showDivider={false}
  title="Extrato detalhado"
  primaryAction={{ label: 'Fechar', onClick: onClose }}
>
  <TabelaExtratoCompleta />
</ContentModal>
```

---

## Acessibilidade

- O `Dialog` interno recebe `aria-label={title ?? 'Conteúdo'}` automaticamente — sempre passe
  `title` (ou aceite o fallback genérico) para que leitores de tela anunciem o propósito do
  modal ao abrir.
- Foco é gerenciado pelo `Modal`/`Dialog` do react-aria (foco preso dentro do modal, retorno ao
  elemento disparador ao fechar) — comportamento padrão, não requer configuração adicional.
- `dismissible={false}` remove o fechamento por `Esc`/clique-fora **e** o botão `X` — garanta
  que sempre existam `primaryAction`/`secondaryAction` para o usuário conseguir sair do modal;
  do contrário o modal fica sem saída acessível.
- O botão de fechar (`X`) já tem `aria-label="Fechar"` fixo — não é configurável.
- Quando `primaryAction.loading` é `true`, o `Button`/`DoubleButton` interno assume o estado de
  loading padrão (desabilitado + spinner) — mantenha `label` descritivo.

## Armadilhas comuns

- Passar `primaryAction` e `secondaryAction` juntos **muda o componente renderizado** no footer
  (de `Button` avulso para `DoubleButton`) — o `variant` de cada ação também **muda o `pair`**
  visual inteiro do `DoubleButton`, não apenas a cor do botão individual. Ao usar
  `variant: 'destructive'` na primária, o secundário vira automaticamente estilo "ghost" do par
  `destructive-ghost`, ignorando qualquer `variant` custom passado no `secondaryAction`.
- `footerNote` **só é visível em `align="left"`** — em `align="center"` a prop é silenciosamente
  ignorada; não é um bug de renderização condicional a ser "corrigido" no consumo.
- Sem `primaryAction`, `secondaryAction` **e** `footerNote`, o footer inteiro desaparece — se o
  modal precisa de uma barra de rodapé vazia por layout, isso não é suportado; use pelo menos
  uma ação ou `footerNote`.
- `scrollable={false}` não trunca conteúdo — apenas remove o scroll interno; conteúdo maior que
  o painel pode transbordar visualmente. Use com conteúdo já conhecido como curto.
- Não confundir `ContentModalAction.variant` com props de `DoubleButton` diretamente — a prop
  é do tipo `ButtonVariant` do [`Button`](../Forms/Button.md) e serve apenas de sinal para a
  heurística de `resolvePair`, não é repassada 1:1 ao `DoubleButton`.
