# FileUpload

Área de upload de arquivos por arraste-e-solte (drag & drop) ou clique, com seleção nativa
via `<input type="file">` oculto. Gerencia estado visual (padrão, ativo/arraste, sucesso, erro,
desabilitado), validação de tamanho máximo por arquivo e lista os arquivos aceitos como `Chip`s
removíveis. Não usa `react-aria-components` — é HTML nativo (`div[role="button"]` + input file)
com estado React local (`useState`).

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/FileUpload/`
- **Export:** `import { FileUpload } from '@srm/diamond';`
- **Relacionados:** [Chip](./Chip.md) (usado internamente para listar arquivos), [UploadAreaMobile](./UploadAreaMobile.md) (variante mobile, mesma API de props)

---

## Quando usar

- Upload de documentos em fluxos de onboarding/KYC: regulamento, contrato social, comprovante
  de endereço, extrato.
- Anexar arquivos a um formulário (ex.: comprovantes de aporte, laudos, planilhas de posição).
- Quando o usuário precisa ver a lista dos arquivos já selecionados/anexados, com opção de
  remover cada um antes de enviar.
- Tanto para arquivo único (`multiple={false}`, padrão) quanto para múltiplos arquivos
  acumulativos (`multiple={true}`).

## Quando **não** usar

- Upload disparado por um botão simples sem necessidade de drag&drop ou preview de lista →
  use [`Button`](./Button.md) com um `<input type="file">` próprio, mais leve.
- Campo de texto comum (não é arquivo) → use [`TextInput`](./Inputs/TextInput.md).
- Layout mobile dedicado com apresentação diferente → prefira
  [`UploadAreaMobile`](./UploadAreaMobile.md), que compartilha a mesma superfície de props.

---

## Interface

```ts
import type { ReactNode } from 'react';

export interface FileUploadProps {
  accept?: string;                      // filtro nativo do seletor de arquivo (ex.: ".pdf,.xlsx")
  multiple?: boolean;                   // default: false
  onFiles?: (files: File[]) => void;    // chamado a cada mudança na lista de arquivos
  label?: ReactNode;                    // rótulo exibido acima da dropzone
  hint?: string;                        // texto de apoio; default calculado (ver abaixo)
  maxSizeMB?: number;                   // default: 10 — tamanho máximo por arquivo, em MB
  disabled?: boolean;                   // default: false
  forceHover?: boolean;                 // default: false — força o estado visual "active" (specimen/demo)
  previewFiles?: File[];                // lista inicial/controlada de arquivos para pré-visualização
  errorText?: string;                   // erro externo (ex.: vindo de validação de formulário)
}

export function FileUpload(props: FileUploadProps): JSX.Element;
```

> `FileUpload` **não** estende `InputBaseProps` — é um componente independente, sem herança de
> `label`/`state`/`size`/`theme` no formato dos demais campos de formulário do Diamond.

### Estados visuais (`FileUpload.utils.ts` → `resolveUploadVisualState`)

O componente deriva um único estado visual interno, com prioridade fixa:

```ts
type UploadVisualState = 'default' | 'active' | 'success' | 'error' | 'disabled';

// prioridade: disabled > error > success (tem arquivos) > active (arraste/forceHover) > default
```

| Estado     | Gatilho                                                              | Efeito visual                                                    |
|------------|-----------------------------------------------------------------------|-------------------------------------------------------------------|
| `disabled` | `disabled={true}`                                                     | opacidade reduzida, `cursor: not-allowed`, ignora clique/drop     |
| `error`    | erro interno (arquivo grande demais) ou `errorText` externo            | borda sólida vermelha, título e subtítulo em `--feedback-error`   |
| `success`  | `files.length > 0`                                                     | borda sólida verde, padding reduzido, lista de `Chip`s visível    |
| `active`   | arraste em curso (`onDragOver`) ou `forceHover={true}`                 | borda azul + anel de foco (`--focus-ring`)                        |
| `default`  | nenhum dos anteriores                                                  | borda tracejada padrão                                            |

### Comportamentos não óbvios

- **Validação de tamanho é client-side e bloqueia toda a seleção**: se **qualquer** arquivo do
  lote exceder `maxSizeMB`, `onFiles` **não** é chamado e a mensagem
  `"Arquivo muito grande. Máximo: {maxSizeMB}MB."` substitui o texto normal — nenhum arquivo do
  lote é aceito, mesmo os que estariam dentro do limite.
- **Erro interno tem prioridade sobre `errorText`**: `error = internalError ?? errorText`. Uma
  vez que o usuário tente subir um arquivo grande, o erro interno permanece até uma nova seleção
  válida (`setInternalError(null)` só ocorre no próximo `processFiles` bem-sucedido).
- **`multiple` controla se a seleção acumula ou substitui**: com `multiple={false}` (padrão),
  cada nova seleção **substitui** a lista inteira; com `multiple={true}`, novos arquivos são
  **anexados** aos já existentes (`[...files, ...list]`).
- **`previewFiles` é ressincronizado por `useEffect`** sempre que a prop muda — útil para
  controlar a lista externamente (ex.: preencher com arquivos já enviados ao editar um registro),
  mas **não é bidirecional**: alterações feitas pelo usuário (remoção, nova seleção) não retro-
  alimentam `previewFiles`; o pai deve ouvir `onFiles` para manter seu próprio estado em sincronia.
- **Remover um arquivo** (`x` no `Chip`) chama `onFiles` com a lista atualizada; não há
  confirmação nem forma de desfazer.
- **`hint` tem default calculado por estado**: em `default`/`active` é
  `Máximo {maxSizeMB}MB por arquivo{accept ? " · " + accept : ""}`; em `success` (com `multiple`)
  vira `"Clique para adicionar mais arquivos"`; passar `hint` explicitamente sobrescreve esse
  texto em ambos os casos (exceto quando `visual === 'error'`, onde o subtítulo sempre mostra o
  texto de erro, não o `hint`).
- **Clique dispara o input nativo** (`inputRef.current?.click()`) e o valor do input é resetado
  (`e.target.value = ''`) após cada seleção, permitindo selecionar o **mesmo arquivo** duas vezes
  seguidas e disparar `onChange` novamente.
- A dropzone inteira é clicável e arrastável; clicar em um `Chip`/remover não propaga para o
  clique da dropzone (`onClick={(e) => e.stopPropagation()}` no container dos chips).

---

## Exemplos

```tsx
import { useState } from 'react';
import { FileUpload } from '@srm/diamond';

// Básico — arquivo único
function DocumentoUnico() {
  const [arquivos, setArquivos] = useState<File[]>([]);
  return (
    <FileUpload
      label="Comprovante de endereço"
      accept=".pdf,.jpg,.png"
      maxSizeMB={5}
      onFiles={setArquivos}
    />
  );
}

// Múltiplos arquivos, acumulativo
<FileUpload
  label="Documentos do fundo"
  accept=".pdf,.xlsx"
  multiple
  maxSizeMB={10}
  onFiles={(files) => console.log(files.map((f) => f.name))}
/>

// Estado de erro vindo de validação externa (ex.: resposta da API)
<FileUpload
  label="Regulamento assinado"
  errorText="Falha no envio. Tente novamente."
/>

// Desabilitado
<FileUpload label="Anexos" disabled />

// Pré-visualização controlada (ex.: editando um registro com anexos já existentes)
function EditarAnexos({ arquivosSalvos }: { arquivosSalvos: File[] }) {
  const [arquivos, setArquivos] = useState<File[]>(arquivosSalvos);
  return (
    <FileUpload
      label="Anexos"
      previewFiles={arquivos}
      multiple
      onFiles={setArquivos}
    />
  );
}

// Forçando o estado "active" (uso em specimen/demo, não em produção)
<FileUpload label="Documentos" forceHover />
```

### Integração com React Hook Form

```tsx
<Controller
  name="anexos"
  control={control}
  render={({ field, fieldState }) => (
    <FileUpload
      label="Anexos"
      multiple
      onFiles={field.onChange}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

> `FileUpload` não expõe `value` no formato de outros inputs — o valor controlado é
> `previewFiles` (para exibição) e a mudança chega via `onFiles`. Ao integrar com RHF, mapeie
> `field.value` para `previewFiles` se precisar reidratar o formulário com arquivos existentes.

---

## Acessibilidade

- A dropzone é um `div[role="button"]` com `tabIndex={0}` (ou `-1` quando `disabled`) e
  `aria-label="Área de upload. Clique ou arraste arquivos aqui."` fixo — não configurável via
  props; se precisar de um rótulo diferente para leitores de tela, ajuste via `label` visível
  (que não substitui o `aria-label` da dropzone) ou solicite uma prop nova ao time de plataforma.
- Suporta ativação por teclado: `Enter` e `Espaço` disparam o seletor de arquivo
  (`onKeyDown` trata ambas as teclas).
- Em `disabled`, `tabIndex={-1}` remove o elemento da ordem de tabulação.
- Cada arquivo listado tem um botão de remoção com `removeLabel={"Remover " + nome do arquivo}`,
  garantindo nome acessível único por item.
- Mensagens de erro (interno ou `errorText`) aparecem como texto visual no lugar do subtítulo,
  mas **não** são associadas via `aria-describedby`/`role="alert"` — considere anunciar erros
  críticos também por outro canal (toast, `aria-live` externo) se o fluxo exigir.

## Armadilhas comuns

- Não assuma que arquivos parcialmente válidos de um lote passam: **um único** arquivo acima de
  `maxSizeMB` invalida a seleção inteira.
- `onFiles` recebe a lista **completa** atual (não apenas os arquivos novos) — ao persistir em
  estado externo, substitua a lista inteira, não faça `push`.
- `previewFiles` não é um `value` reativo de mão dupla: se você espera que remover um arquivo
  atualize automaticamente `previewFiles` no componente pai, isso **não** acontece sozinho —
  trate `onFiles` como fonte da verdade e recalcule `previewFiles` a partir dele.
- `forceHover` é para specimen/Storybook (fixar o estado "active" visualmente); não use em
  produção para simular arraste.
- O componente não faz upload de fato (sem `fetch`/XHR) — apenas coleta `File[]` no browser;
  o envio para o backend é responsabilidade do consumidor.
- Sem herança de `InputBaseProps`: não espere `state`, `size` ou `theme` como em `TextInput`/
  `CurrencyInput` — o único controle de estado visual de erro é `errorText` (mais o erro interno
  de tamanho, que tem prioridade).
