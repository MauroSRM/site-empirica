# InputBase (base compartilhada dos Inputs)

Não é um componente que se usa diretamente — é o **shell estrutural interno** consumido por
todos os campos de `Forms/Inputs` (`TextInput`, `CurrencyInput`, `PercentInput`, `PhoneInput`,
`CepInput`, `CpfInput`, `CnpjInput`, `EmailInput`, `PasswordInput`, `SearchInput`, `CardInput`,
entre outros). Resolve label, estado visual/funcional, wrapper com foco, texto de ajuda e
mensagem de erro de forma consistente para toda a família. Construído sobre `TextField`,
`Label`, `Text` e `FieldError` do `react-aria-components`.

Este documento existe para que um agente de IA entenda **de onde vêm** as props `label`,
`state`, `size`, `theme`, `helperText`, `errorText`, `required`, `forceFocus` e `className`
que aparecem repetidas em todo input do Diamond — e o que cada uma faz de fato no DOM/estado.

- **Categoria:** Forms / Inputs (base interna)
- **Fonte:** `src/components/Forms/Inputs/_shared/InputBase/` (`InputBase.tsx`, `input.types.ts`, `input.variants.ts`)
- **Export:** **não é exportado** em `@srm/diamond` — não há `import { InputBase } from '@srm/diamond'`.
  Cada input público (`CurrencyInput`, `TextInput`, ...) estende `InputBaseProps` na sua própria
  interface e você usa essas props através **dele**, nunca do `InputBase` em si.
- **Usado por:** [CurrencyInput](./CurrencyInput.md), [PercentInput](./PercentInput.md), [TextInput](./TextInput.md)
  e demais campos de texto/máscara da pasta `Forms/Inputs`.

---

## Quando usar

- Você **não** importa isto diretamente. Esta página serve para consultar o contrato comum
  antes de ler a doc de um input específico (evita repetir a mesma tabela em cada arquivo).
- Consulte quando precisar saber: "que valores `state` aceita?", "o que `forceFocus` faz?",
  "`errorText` sozinho já marca o campo como erro?".

## Quando **não** usar

- Para renderizar um campo de formulário → use o componente concreto
  ([`TextInput`](./TextInput.md), [`CurrencyInput`](./CurrencyInput.md), [`PercentInput`](./PercentInput.md), etc.).
- Se estiver criando um **novo** input interno ao design system (fora do escopo de consumo do
  DS) → isso é trabalho de manutenção da biblioteca, não de consumo via `@srm/diamond`.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { TextFieldProps } from 'react-aria-components';

export type InputState = 'default' | 'error' | 'disabled' | 'read-only';
export type InputSize  = 'sm' | 'md';
export type InputTheme = 'default' | 'dark';

// Omitidas de TextFieldProps por serem geridas internamente pelo InputBase
// ou pelo input concreto: children, isDisabled, isReadOnly, isInvalid, isRequired,
// label, description, errorMessage, style, slot, value, defaultValue, onChange, className.
export type InputBaseProps = Omit<TextFieldProps, /* ver acima */ string> & {
  state?: InputState;         // default: 'default'
  size?: InputSize;           // default: 'md'
  theme?: InputTheme;         // default: 'default'
  label?: ReactNode;          // default: undefined (sem <Label> renderizado)
  helperText?: ReactNode;     // default: undefined
  errorText?: ReactNode;      // default: undefined
  required?: boolean;         // default: false
  forceFocus?: boolean;       // default: false
  className?: string;         // aplicado no wrapper <TextField>, não no <input>
};
```

### O que cada prop realmente faz (lido de `InputBase.tsx`)

| Prop         | Efeito real                                                                                                                                  |
|--------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| `state`      | `'disabled'` → `isDisabled` no `TextField` (bloqueia clique/foco no wrapper). `'read-only'` → `isReadOnly`. `'error'` → `isInvalid`. `'default'` não seta nenhuma flag. |
| `errorText`  | Se presente, força `isInvalid = true` **mesmo que `state` seja `'default'`** (`isError = state === 'error' \|\| Boolean(errorText)`). Renderiza `<FieldError>` com ícone `AlertCircle` no lugar do `helperText`. |
| `helperText` | Só é exibido quando **não** há erro ativo (`isError`). Renderizado como `<Text slot="description">`. |
| `label`      | Se ausente, nenhum `<Label>` é renderizado — o campo fica **sem nome acessível visível** (forneça `aria-label` via passthrough de `TextFieldProps` nesse caso). |
| `required`   | Além de `isRequired` no `TextField`, desenha um `*` (`aria-hidden`) ao lado do label. Não adiciona `required` nativo do HTML por si só — validação é responsabilidade do form. |
| `size`       | Controla altura/padding/font-size do wrapper via CVA (`sizeSm` = `--height-button-sm`, `sizeMd` = `--height-input`). Não afeta o `label` nem as mensagens. |
| `theme`      | `'dark'` aplica `styles.fieldDark` (cores de label/mensagem) e `styles.wrapperDark` (fundo `rgba(255,255,255,0.10)`, bordas e focus ring próprios `#F87171 @45%`). Use em superfícies escuras (ex.: header brand). |
| `forceFocus` | Aplica a classe do anel de foco (`wrapperFocused`) **independente do foco real do DOM** — usado para demonstrar/forçar o estado visual de foco (ex.: Storybook, validação guiada). Não move o foco do teclado. |
| `className`  | Mesclado (via `clsx`) na raiz `<TextField>` — o wrapper interno (`div` com borda/fundo) tem suas próprias classes CVA, não recebe `className` diretamente. |

### Comportamento não óbvio: clique na "área" do input

O `InputBase` escuta `onClick` no `div` wrapper e foca o `<input>` interno automaticamente —
**exceto** quando o alvo do clique é (ou está dentro de) um `button`/`[role="button"]`
(ex.: botão de "olho" do `PasswordInput`, botão de limpar do `SearchInput`) e **exceto** quando
`state === 'disabled'`. Isso é o que permite clicar em qualquer parte do wrapper (incluindo
prefixos como `R$`) e o foco ir para o campo de texto.

### Precedência de estado visual

- `isError` (via `state="error"` OU `errorText` truthy) tem precedência sobre `helperText`.
- Quando `theme="dark"` **e** `state` é `error`/`disabled`/`read-only` ao mesmo tempo, os
  seletores compostos em `input.module.scss` (`.field[data-invalid] .wrapper.wrapperDark`, etc.)
  garantem que o estado vence sobre o fundo escuro padrão — sem isso o visual de erro se perderia
  dentro de `theme="dark"`.

### Passthrough de `TextFieldProps`

Além das props acima, todo input público recebe de graça (via `...textFieldProps`
repassado ao `<TextField>` do react-aria): `name`, `id`, `autoComplete`, `inputMode`, `onBlur`,
`onFocus`, `aria-label`, `aria-describedby` e demais `aria-*`.

---

## Exemplos

Estes exemplos usam `TextInput` apenas para ilustrar o efeito das props de `InputBaseProps` —
o padrão se repete em qualquer input da família.

```tsx
import { useState } from 'react';
import { TextInput } from '@srm/diamond';

// state="error" sem errorText — fica inválido mas sem mensagem (evite; sempre combine os dois)
<TextInput label="Código" state="error" />

// errorText sozinho já força o estado de erro, mesmo com state="default" (o default)
<TextInput label="Apelido da conta" errorText="Nome já utilizado." />

// helperText só aparece quando não há erro
function Campo() {
  const [valor, setValor] = useState('');
  const erro = valor.length > 20 ? 'Máximo de 20 caracteres.' : undefined;
  return (
    <TextInput
      label="Apelido"
      value={valor}
      onChange={setValor}
      helperText="Use um nome curto e memorável."
      errorText={erro}
    />
  );
}

// tamanho compacto em toolbar/filtro
<TextInput label="Buscar" size="sm" />

// tema escuro sobre header brand
<TextInput label="Usuário" theme="dark" />

// forceFocus — força visualmente o anel de foco (ex.: destaque em onboarding guiado)
<TextInput label="Nome completo" forceFocus />
```

---

## Acessibilidade

- **Sempre** forneça `label` (ou, na ausência de rótulo visível, um `aria-label` via
  passthrough) — sem nenhum dos dois o campo fica sem nome acessível.
- `errorText` é anunciado por leitores de tela via `<FieldError>` do react-aria (associado
  ao input por `aria-describedby` automaticamente); não duplique a mensagem em outro lugar.
- O `*` de `required` é `aria-hidden` — a obrigatoriedade real para tecnologia assistiva vem
  de `isRequired` no `TextField` (setado internamente a partir da prop `required`).
- `forceFocus` é puramente visual — não substitui o foco real de teclado nem deve ser usado
  para simular acessibilidade de foco em produção.

## Armadilhas comuns

- Tentar `import { InputBase } from '@srm/diamond'` — **não existe**; a base é interna, use
  o componente concreto (`TextInput`, `CurrencyInput`, ...).
- Definir `state="error"` sem `errorText` (ou vice-versa esquecendo de resetar `state` quando
  o erro passa) — prefira sempre derivar `state` de `fieldState.error` (React Hook Form) e
  passar `errorText={fieldState.error?.message}` junto.
- Esperar que `className` estilize o wrapper com borda/fundo — ele é aplicado na raiz
  `<TextField>`, não no `div` que tem a borda (esse é controlado só por `size`/`theme` via CVA).
- Usar `theme="dark"` sem verificar o contraste do `helperText`/`errorText` sobre o fundo —
  as cores mudam (`fieldDark`) mas o conteúdo (texto do helper) é seu.
