# Diamond — Índice de Componentes (Roteador)

> **Como usar:** localize o componente pela coluna **Componente** ou por um termo em
> **Buscar por / usar quando**, depois abra **apenas** o arquivo indicado. Não leia este
> índice inteiro atrás de código — ele só roteia. Protocolo completo em
> [`../AGENTS.md`](../AGENTS.md). Tokens de design em [`../design.md`](../design.md).
>
> Todos os docs abaixo são gerados a partir do código-fonte real (`src/components/`).

## AI

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [IaSRMAvatar](./AI/IASRMAvatar.md) | Avatar de marca do iaSRM, wrapper do `LogoIcon` em 4 variantes (squareBrand/circleBrand/circleTint/circleGlass) e 3 tamanhos. Decorativo por default. | avatar de ia, avatar do assistente, ícone da marca srm, logo em avatar, glass avatar |
| [IaSRMFab](./AI/IASRMFab.md) | Botão flutuante de entrada do assistente: FAB circular brand + pill de label opcional. `aria-label` obrigatório. | fab, botão flutuante, entrada do assistente, botão de ia, bottom-right |
| [IaSRMHero](./AI/IASRMHero.md) | Card hero de entrada: avatar + saudação + `MessageComposer` + chips de sugestão com `onChipPress`. | hero de ia, card do assistente, saudação, input do assistente, chips de sugestão, home com ia |
| [MessageComposer](./AI/MessageComposer.md) | Pill compound de mensagem `[anexar]? [texto] [gravar]? [enviar]`. Fonte única do input de chat (Hero + Tray). | input de chat, composer, campo de mensagem, enviar mensagem, anexar, gravar áudio |
| [IaSRMChatBubble](./AI/IaSRMChatBubble.md) | Mensagem de chat com union discriminada por `type` (`iaSRM` \| `user`), timestamp automático e slot `embed`. Exporta os átomos `Bubble`, `BubbleContent`, `BubbleTime`, `BubbleTypingDots`, `TypingIndicator`. | bolha de chat, mensagem, balão, timestamp, digitando, typing indicator |
| [IaSRMChatEmbed](./AI/IaSRMChatEmbed.md) | Container do slot `embed` de uma bolha. Shell puro, sem layout interno prescrito — o miolo é composto com átomos do DS. | card na bolha, embed, card de confirmação, otp no chat, comprovante no chat |
| [IaSRMConversationFeed](./AI/IaSRMConversationFeed.md) | Feed scrollável de mensagens com `role="log"`, auto-scroll condicional (não sequestra o scroll do usuário) e `onScroll`. | feed de conversa, lista de mensagens, chat scroll, histórico, paginação de mensagens |
| [IaSRMTray](./AI/IaSRMTray.md) | Central de controle: `MessageComposer` no topo + slot `children` com controles contextuais. Vai no slot `tray` do Drawer/Overlay. | tray, rodapé do chat, controles contextuais, tiles, slider no chat |
| [PanelHeader](./AI/PanelHeader.md) | Header dos painéis de IA: avatar + título/subtítulo + ações opt-in (expandir/minimizar/fechar). `label` nomeia o diálogo. | header de painel, título do drawer, ações de janela, minimizar, expandir |
| [IaSRMDrawer](./AI/IaSRMDrawer.md) | Painel lateral direito sobre React Aria (focus trap, ESC, scroll lock). Sizes `sm \| md \| lg`, slots `children` + `tray`. | drawer de ia, painel lateral, chat lateral, assistente lateral |
| [IaSRMOverlay](./AI/IaSRMOverlay.md) | Modal centralizado sobre React Aria — view ampliada do Drawer, com `onMinimize` para voltar. | overlay de ia, modal do assistente, chat em tela cheia, expandir conversa |

## Brand

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Logo](./Brand/Logo.md) | Marca SRM em SVG (símbolo ou completa), com tamanho e tema; inclui `LogoIcon`. | logo, marca, logotipo, logo srm, símbolo, brand mark, logo header, logo dark, mono |

## Cards

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Card](./Cards/Card.md) | Card com ícone, título, descrição, tag e ação (single/dupla); variantes outlined/elevated/ghost, vertical/horizontal. | card, cartão, card clicável, hub de navegação, card com ação, card com tag, grid de cards |
| [BalanceCard](./Cards/BalanceCard.md) | Card de saldo (primary/consolidated), toggle de visibilidade, tendência, estado NoConnection. | card de saldo, saldo disponível, saldo consolidado, open finance, ocultar saldo, card financeiro |
| [KPICard](./Cards/KPICard.md) | Card compacto de métrica KPI com ícone semântico, valor, trend e tag de período. | card de kpi, card de métrica, indicador de dashboard, patrimônio sob gestão, trend up/down |
| [ButtonCard](./Cards/ButtonCard.md) | Card-botão de ação rápida (square/rectangle), toda a área clicável. | botão card, ação rápida, atalho dashboard, PIX, transferir |
| [CTACard](./Cards/CTACard.md) | Card de oferta/feature com header dinâmico (cor/ícone/imagem/bancos), vertical ou horizontal. | CTA, oferta, banner, feature banner, promoção, hero card |
| [OpenFinanceAccountCard](./Cards/OpenFinanceAccountCard.md) | Linha de conta bancária Open Finance, conectada (saldo+trend) ou desconectada (CTA reconectar). | open finance, conta bancária, banco conectado, conciliação |
| [ReceivableAlertCard](./Cards/ReceivableAlertCard.md) | Card de alerta de recebível (vencido/hoje/em breve/pendente), sempre clicável. | recebível, cobrança, vencimento, alerta financeiro, inadimplência |

## Data Display

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Tag](./DataDisplay/Tag.md) | Etiqueta compacta para status, categorias e filtros removíveis (7 cores, 3 tamanhos). | tag, etiqueta, badge, filtro removível, status label, rótulo, categoria |
| [RiskBadge](./DataDisplay/RiskBadge.md) | Selo textual não interativo de nível de risco (alto/médio/baixo/desconhecido). | badge de risco, selo de risco, classificação de risco, risco alto/médio/baixo, não classificado |
| [TrendIndicator](./DataDisplay/TrendIndicator.md) | Ícone direcional + delta + contexto, para variação de KPIs e saldos. | indicador de tendência, variação percentual, seta de alta/baixa, delta, vs mês anterior |
| [Chart](./DataDisplay/Chart.md) | Família de gráficos (barra, linha, combo, donut, sparkline, aging strip, card) sobre Recharts, cor via tokens `--chart-tone-*`. | gráfico, chart, barra, linha, donut, combo, sparkline, aging, fluxo de caixa, série temporal, composição percentual |
| [Table](./DataDisplay/Table.md) | Tabela genérica sobre react-aria-components: colunas declarativas, sort/seleção/paginação controlados (server-side), resize, coluna fixa à direita, células de moeda/número/percentual/data. | tabela, table, listagem, grid de dados, ordenação server-side, paginação, coluna fixa, resize de coluna, célula de moeda |
| [ApprovalRow](./DataDisplay/ApprovalRow.md) | Row de fila de aprovação (beneficiário/data/prioridade/valor) com ações Aprovar/Reprovar inline ou em menu. | fila de aprovação, aprovar/reprovar, row de operação, prioridade de aprovação |
| [DocumentRow](./DataDisplay/DocumentRow.md) | Row de documento com ícone de status e ações genéricas (0/1/2+ = vazio/ícone/menu). | linha de documento, lista de documentos, contrato, comprovante, status de documento |
| [PermissionRow](./DataDisplay/PermissionRow.md) | Row de permissão com Aprovar/Reprovar ou seleção múltipla; inclui `PermissionBulkActions`/`PermissionRowGroup`. | permissão, perfil de acesso, aprovar permissão, seleção em lote, bulk actions |
| [AuditLine](./DataDisplay/AuditLine.md) | Linha do tempo semântica de trilha de auditoria (timestamp, ator, ação, estágio, tag). | trilha de auditoria, histórico, timeline, log de eventos, quem aprovou |
| [ListLabel](./DataDisplay/ListLabel.md) | Par tipográfico label/caption (stacked/horizontal) com destaque semântico opcional. | par label valor, chave valor, caption, destaque de valor, detalhe de operação |
| [ListLabelGroup](./DataDisplay/ListLabelGroup.md) | Agrupador de pares label/value (4 layouts); inclui presets de comprovante `ReceiptPix`/`ReceiptTed`. | grupo de labels, resumo de dados, comprovante pix, comprovante ted, recibo de transferência |

## Icons

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Icon](./Icons/Icon.md) | Ícone semântico (feedback ou livre), opcionalmente em badge circular, sobre catálogo lucide-react. | ícone, glifo, símbolo, feedback icon, badge de ícone, lucide |

## Identity

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Avatar](./Identity/Avatar.md) | Círculo de identidade com iniciais de pessoa/empresa; base de AvatarDropdown/AvatarStatic. | avatar, foto de perfil, iniciais, usuário, empresa, círculo de identidade |
| [AvatarSRM](./Identity/AvatarSRM.md) | Círculo com a logo SRM (`AvatarSRM`) e base `ColabCircle`, para representar a instituição. | avatar srm, logo srm em avatar, instituição, colaborador srm |
| [AvatarDropdown](./Identity/AvatarDropdown.md) | Trigger de menu de conta (avatar + nome/cargo ou CNPJ + chevron); inclui `AvatarColaborador`. | menu de conta, avatar dropdown, usuário logado, empresa, trigger de menu |
| [AvatarStatic](./Identity/AvatarStatic.md) | Blocos não interativos avatar+texto: `AvatarWithLabel`, `AvatarCompanyCNPJStatic`, `AvatarColaboradorStatic`. | avatar com label, avatar estático, avatar + nome, empresa cnpj estático |
| [BankAvatar](./Identity/BankAvatar.md) | Avatar de instituição financeira; resolve código BACEN/slug/nome para SVG, fallback de iniciais. | avatar de banco, logo de banco, instituição financeira, bacen, ícone de banco |
| [BankAvatarGroup](./Identity/BankAvatarGroup.md) | Grupo de `BankAvatar` empilhados/espaçados com contador +N; resolve aliases/BACEN por item. | grupo de bancos, pilha de bancos, +N bancos, instituições agrupadas |

## Forms — Botões

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Button](./Forms/Button.md) | Botão de ação principal: variantes, tamanhos, ícone (4 modos), loading e tema claro/escuro. | botão, CTA, ação, submit, confirmar, salvar, destrutivo, accent, link |
| [IconButton](./Forms/IconButton.md) | Botão somente-ícone (primary/secondary/destructive/ghost, 3 tamanhos, tema). | botão de ícone, botão só ícone, fechar, editar/excluir, ação em toolbar |
| [DoubleButton](./Forms/DoubleButton.md) | Par de botões (primária + secundária) para rodapé de modal/diálogos. | par de botões, salvar e cancelar, confirmar e cancelar, footer de modal, duas ações |

## Forms — Seleção & Controles

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Checkbox](./Forms/Checkbox.md) | Caixa de seleção binária/tri-estado com rótulo; inclui `CheckboxGroup`. | checkbox, caixa de seleção, aceite de termos, seleção múltipla, indeterminate, selecionar todos |
| [Chip](./Forms/Chip.md) | Pílula de seleção/filtro (ToggleButton) com ícone e variante removível. | chip, tag, filtro, pílula, toggle button, chip removível |
| [ChipGroup](./Forms/ChipGroup.md) | Agrupador de Chips com seleção única ou múltipla agregada. | grupo de chips, grupo de filtros, seleção agregada, toggle button group |
| [Radio](./Forms/Radio.md) | Botão de opção (radio): item de um grupo ou toggle booleano avulso. | radio button, botão de opção, seleção única, radio avulso |
| [RadioGroup](./Forms/RadioGroup.md) | Contêiner de seleção exclusiva para múltiplos `Radio`. | grupo de radio, seleção exclusiva, escolha única, conjunto de opções |
| [Switch](./Forms/Switch.md) | Toggle liga/desliga para configurações binárias com efeito imediato. | switch, toggle, liga/desliga, ativar/desativar, on/off |
| [Select](./Forms/Select.md) | Dropdown de seleção única (lista de strings) com busca opcional e temas. | select, dropdown, combobox, lista suspensa, select com busca, picklist |
| [MultiSelect](./Forms/MultiSelect.md) | Dropdown de seleção múltipla com busca, resumo/contador no gatilho e ações em massa. | multi select, multiselect, seleção múltipla, múltipla escolha, select múltiplo, filtro multi, checklist suspensa |
| [Autocomplete](./Forms/Autocomplete.md) | Campo de busca com sugestões (combobox): filtro client-side ou busca no servidor com debounce, `isLoading` e opções vindas de API. | autocomplete, autocompletar, combobox com input, busca com sugestões, typeahead, buscar empresa/cliente, select assíncrono, lista da API, busca remota, debounce |
| [Slider](./Forms/Slider.md) | Controle de arraste para valor único ou intervalo (range), com bolha e ticks. | slider, range, controle deslizante, faixa de valores, min/máx, ajuste por arraste |
| [OptionCard](./Forms/OptionCard.md) | Cartão de opção única (radio card) com rótulo/descrição; inclui `OptionCardGroup`. | option card, cartão de opção, radio card, escolha única, tipo de conta, cartão selecionável |

## Forms — Compostos & Upload

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [FieldGroup](./Forms/FieldGroup.md) | Agrupador semântico (fieldset/legend) com grid de 1–3 colunas. | agrupar campos, fieldset, legend, grid de formulário, seção de formulário, colunas de campos |
| [FileUpload](./Forms/FileUpload.md) | Upload por arraste-e-solte ou clique, com sucesso/erro e lista removível. | upload de arquivo, drag and drop, dropzone, anexar documento, anexos, kyc |
| [UploadAreaMobile](./Forms/UploadAreaMobile.md) | Upload otimizado para toque (mobile), card clicável e chips de arquivos. | upload mobile, anexar arquivo, anexo touch, seletor de arquivo mobile, comprovante |
| [SenhaTransacional](./Forms/SenhaTransacional.md) | Senha transacional numérica mascarada com tentativas e bloqueio (sobre OTPInput). | senha transacional, senha numérica, confirmar transação, segundo fator, pin, bloqueio |
| [Textarea](./Forms/Textarea.md) | Texto multilinha com contador de caracteres e estados (não herda InputBase). | textarea, área de texto, multilinha, observações, comentário, contador de caracteres |

## Forms — Inputs

> Todos os Inputs abaixo herdam a base [`_shared` (InputBase)](./Forms/Inputs/_shared.md):
> `label`, `state`, `size`, `theme`, `helperText`, `errorText`, `required`, `className`.

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [_shared (InputBase)](./Forms/Inputs/_shared.md) | Base estrutural comum a todos os campos de Forms/Inputs (não exportada diretamente). | base dos inputs, InputBaseProps, props herdadas, label/state/size/theme, wrapper interno |
| [TextInput](./Forms/Inputs/TextInput.md) | Texto genérico sem máscara, com ícone decorativo opcional. | input de texto, campo de texto, text field, input genérico, campo livre, nome |
| [PasswordInput](./Forms/Inputs/PasswordInput.md) | Senha com botão mostrar/ocultar. | senha, password, campo de senha, mostrar/ocultar senha, login |
| [SearchInput](./Forms/Inputs/SearchInput.md) | Busca com lupa e botão de limpar automático. | campo de busca, search, pesquisa, filtro de lista, busca instantânea |
| [CurrencyInput](./Forms/Inputs/CurrencyInput.md) | Monetário BRL com prefixo `R$` e máscara de 2 casas decimais. | dinheiro, moeda, R$, valor, BRL, aporte, resgate, currency |
| [PercentInput](./Forms/Inputs/PercentInput.md) | Percentual com preenchimento direita-para-esquerda (estilo POS) e `max`. | percentual, porcentagem, taxa de administração, alocação, rentabilidade alvo, campo % |
| [CardInput](./Forms/Inputs/CardInput.md) | Número de cartão em grupos de 4 com detecção de bandeira (Visa/Master/Elo/Amex/Hiper). | cartão de crédito, número do cartão, bandeira, checkout, meio de pagamento |
| [CepInput](./Forms/Inputs/CepInput.md) | CEP com máscara `00000-000`. | cep, código postal, endereço, cadastro de endereço |
| [CpfInput](./Forms/Inputs/CpfInput.md) | CPF com máscara `000.000.000-00`. | cpf, documento pessoa física, cadastro, kyc, cotista |
| [CnpjInput](./Forms/Inputs/CnpjInput.md) | CNPJ com máscara alfanumérica e DV numérico. | cnpj, documento empresa, cadastro PJ, pessoa jurídica |
| [EmailInput](./Forms/Inputs/EmailInput.md) | E-mail que bloqueia espaços (sem validar formato). | email, e-mail, cadastro de email, login por email, contato |
| [PhoneInput](./Forms/Inputs/PhoneInput.md) | Telefone BR com máscara dinâmica fixo/celular (8/9 dígitos). | telefone, celular, ddd, máscara de telefone, contato |
| [OTPInput](./Forms/Inputs/OTPInput.md) | Código OTP em células, avanço de foco, contador de reenvio. | otp, código de verificação, 2fa, mfa, código sms, pin, token |
| [DatePicker](./Forms/Inputs/DatePicker.md) | Data única com segmentos `dd/mm/aaaa` e calendário em popover (saída ISO). | data, seletor de data, calendário, vencimento, nascimento, date field |
| [DateRangePicker](./Forms/Inputs/DateRangePicker.md) | Intervalo de datas com campos segmentados, calendário, presets e limites. | período, range de datas, intervalo, data inicial/final, filtro de período |

## Feedback — Indicadores

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Skeleton](./Feedback/Skeleton.md) | Placeholder animado (linha/bloco/círculo/avatar) e composições prontas. | skeleton, loading placeholder, carregando, shimmer, skeleton screen |
| [Spinner](./Feedback/Spinner.md) | Loading indeterminado standalone, com anúncio acessível. | loading, carregando, loader, spinner, aguardando, overlay |
| [EmptyState](./Feedback/EmptyState.md) | Estado vazio (default/error/search/offline) com ação opcional. | estado vazio, sem itens, sem resultados, erro ao carregar, offline, sem dados |

## Feedback — Mensagens

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Callout](./Feedback/Callout.md) | Bloco de destaque inline (info/success/warning/error/ai), persistente. | aviso inline, banner, destaque de status, alerta contextual, callout de ia |
| [Tooltip](./Feedback/Tooltip.md) | Dica textual ao focar/hover, com posicionamento automático. | tooltip, dica, balão de ajuda, hint, hover, dica de ícone |
| [TooltipSheet](./Feedback/TooltipSheet.md) | Ícone de ajuda que abre BottomSheet com explicação de termos; inclui `TooltipSheetInline`. | ajuda contextual, o que é, explicação, bottom sheet de ajuda, cdi o que é |
| [Toast](./Feedback/Toast.md) | Notificação individual com variantes, ação e auto-dismiss com progresso. | toast, notificação, alerta, snackbar, feedback, sucesso/erro |
| [Toastr](./Feedback/Toastr.md) | Container/stack de Toasts com hook `useToast` para a fila. | toastr, stack de toasts, fila de notificações, useToast, posição de toast |

## Feedback — Fluxos

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [RequirementsChecklist](./Feedback/RequirementsChecklist.md) | Lista de requisitos/etapas com status, progresso e itens clicáveis. | checklist, requisitos de senha, kyc, etapas do cadastro, onboarding, compliance |
| [BiometriaScreen](./Feedback/BiometriaScreen.md) | Tela fullscreen mobile de biometria (rosto/prova de vida/documento). | biometria, reconhecimento facial, prova de vida, liveness, kyc, onboarding mobile |

## Feedback — Overlays

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Modal](./Feedback/Modal.md) | Shell mínimo de modal (overlay + painel), composição livre via children. | modal, diálogo, dialog, overlay, popup, janela modal, confirmação |
| [ContentModal](./Feedback/ContentModal.md) | Modal com header, body rolável e footer (Button ou DoubleButton). | modal de confirmação, modal de aviso, modal regulatório, content modal, duas ações |
| [SplitModal](./Feedback/SplitModal.md) | Modal de duas colunas (documento + formulário/detalhes). | modal split, revisar e assinar, lado a lado, pdf + formulário, revisão de contrato |
| [DocumentViewer](./Feedback/DocumentViewer.md) | Preview fullscreen de PDF/imagem com zoom/download/upload; inclui `DocumentViewerSheet`. | visualizar pdf, preview de documento, contrato, comprovante, zoom, download |
| [Drawer](./Feedback/Drawer.md) | Painel lateral deslizante (slide-in) com header, conteúdo e rodapé. | drawer, painel lateral, slide-over, side panel, detalhes da operação, formulário lateral |
| [BottomSheet](./Feedback/BottomSheet.md) | Shell de sheet mobile (slide-up) livre, base para `SheetContent`. | bottom sheet, sheet mobile, modal inferior, painel deslizante, mobile-first |
| [SheetContent](./Feedback/SheetContent.md) | Preset mobile de sheet com header, corpo, callout e até 2 ações. | sheet de confirmação mobile, equivalente mobile do ContentModal, sucesso/erro mobile |
| [UploadSheet](./Feedback/UploadSheet.md) | Bottom sheet mobile de envio de documentos, com dropzone touch e chips. | upload de documentos, enviar comprovante, sheet de anexo, upload mobile, kyc |
| [Overlay](./Feedback/Overlay.md) | Painel flutuante ancorado a um trigger (dropdown/popover/menu). | overlay, dropdown, popover, menu contextual, painel flutuante, ancorado, triggerRef |

## Navigation

| Componente | Descrição | Buscar por / usar quando |
|------------|-----------|--------------------------|
| [Accordion](./Navigation/Accordion.md) | Lista colapsável com cabeçalho, asset, badge e 3 variantes. | acordeão, sanfona, expansível, faq, boxed/line/compact |
| [AppBar](./Navigation/AppBar.md) | Cabeçalho de página/seção com título, subtítulo, voltar e ações. | app bar, barra superior, título de seção, voltar, ações, filtro |
| [AppHeader](./Navigation/AppHeader.md) | Header sticky pós-login: logo, busca, saldo, avatar, notificações, mega menu. | header, topo pós-login, brand navy, busca, saldo, avatar, notificações |
| [AppFooter](./Navigation/AppFooter.md) | Rodapé institucional com logo, links (máx. 4) e copyright. | rodapé, footer, links institucionais, copyright, light/brand |
| [Breadcrumb](./Navigation/Breadcrumb.md) | Trilha hierárquica com truncamento automático (5+) ou manual. | breadcrumb, trilha, migalhas, caminho, navegação hierárquica |
| [MegaMenu](./Navigation/MegaMenu.md) | Painel de navegação com seções de links agrupados (via AppHeader). | mega menu, menu grande, navegação principal, seções de links |
| [NavBalanceChip](./Navigation/NavBalanceChip.md) | Chip de saldo do AppHeader com mascarar/revelar valor. | chip de saldo, saldo na nav, mascarar valor, revelar saldo |
| [NavIconButton](./Navigation/NavIconButton.md) | Botão de ícone para barras de navegação, com badge numérico. | botão de ícone na nav, badge de notificação, header icon, brand/light |
| [PageHeader](./Navigation/PageHeader.md) | Cabeçalho de página/seção/drawer/sheet com breadcrumb, título, ações, fechar. | page header, cabeçalho de página, título + ações, botão fechar, breadcrumb |
| [Stepper](./Navigation/Stepper.md) | Indicador de progresso em etapas (wizard) desktop, horizontal/vertical. | stepper, passos, etapas, wizard, progresso, horizontal/vertical |
| [MobileStepper](./Navigation/MobileStepper.md) | Versão compacta do Stepper para mobile, sem labels. | stepper mobile, passos mobile, progresso compacto, sem labels |
| [TabBar](./Navigation/TabBar.md) | Barra de abas horizontal (pill/line) para alternar seções. | tabs, abas, tab bar, alternar seções, pill/line |
| [UserAccess](./Navigation/UserAccess.md) | Tela cheia de autenticação com 6 telas (login, esqueci, enviado, redefinir, 1º acesso, sucesso). | login, cadastro, recuperar senha, primeiro acesso, autenticação, fluxo de acesso |

---

## Utilitários & Hooks

Documentados em [`../design.md`](../design.md) (ou docs próprios a definir):
`cn`, `useDisclosure`, `useClickOutside`, `useFocusVisible`, `useIsTruncated`, `useToast`
(ver [Toastr](./Feedback/Toastr.md)).

`useIsTruncated<T extends HTMLElement>(content?)` → `{ ref, isTruncated }`: aponte `ref` para
o elemento com `text-overflow: ellipsis` e use `isTruncated` para só então envolver o texto
num [`Tooltip`](./Feedback/Tooltip.md) com o valor completo — tooltip em texto que cabe na
tela é ruído. Remede no resize do elemento (`ResizeObserver`) e sempre que o argumento
`content` mudar; passe o texto exibido como esse argumento. Padrão aplicado em
[`BalanceCard`](./Cards/BalanceCard.md) e [`KPICard`](./Cards/KPICard.md).
