# PanelHeader

Header das superfícies de painel de IA: avatar + título/subtítulo + ações opt-in
(expandir / minimizar / fechar). Nome neutro porque é compartilhado por
[IaSRMDrawer](./IaSRMDrawer.md) e [IaSRMOverlay](./IaSRMOverlay.md).

- **Categoria:** AI
- **Fonte:** `src/components/AI/PanelHeader/`
- **Export:** `import { PanelHeader } from '@srm/diamond';`
- **Relacionados:** [IaSRMDrawer](./IaSRMDrawer.md) e [IaSRMOverlay](./IaSRMOverlay.md) (o consomem), [IaSRMAvatar](./IASRMAvatar.md) (avatar default), [IconButton](../Forms/IconButton.md) (as ações)

---

## Quando usar

- Como topo de um painel de IA próprio, quando você não usa `IaSRMDrawer`/`IaSRMOverlay` mas quer o mesmo header.
- Dentro de um `Dialog` do React Aria: o título vira o **nome acessível** do diálogo automaticamente.

## Quando **não** usar

- Dentro de `IaSRMDrawer`/`IaSRMOverlay` — eles **já** renderizam o `PanelHeader`; configure via `label`/`subtitle`/`avatar`/`tone`/`headerActions` deles.
- Header de página ou de aplicação → componentes de `Navigation`.
- Header de card → [`Card`](../Cards/Card.md).

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactNode, Ref } from 'react';

type PanelHeaderTone = 'default' | 'brand';

interface PanelHeaderProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  label: ReactNode;                 // OBRIGATÓRIO — nomeia o diálogo
  subtitle?: ReactNode;
  headingLevel?: number;            // default: 2
  avatar?: ReactNode | null;        // null remove o slot
  tone?: PanelHeaderTone;           // default: 'default'
  actions?: ReactNode;              // ações extras, antes dos botões padrão
  onExpand?: () => void;            // sem handler, botão não renderiza
  onMinimize?: () => void;          // sem handler, botão não renderiza
  onClose?: () => void;             // sem handler, botão não renderiza
  expandAriaLabel?: string;         // default: 'Expandir'
  minimizeAriaLabel?: string;       // default: 'Diminuir'
  closeAriaLabel?: string;          // default: 'Fechar'
  ref?: Ref<HTMLDivElement>;
  // + atributos nativos de <div>: id, className, data-*, …
}
```

### Notas de comportamento

- **`label` é obrigatório.** O título é renderizado com o `Heading` do React Aria e `slot="title"`: dentro de um `Dialog` isso dá o nome acessível ao diálogo sem `aria-labelledby` manual. Fora de um Dialog, é um heading comum. Um painel sem nome não é anunciável por leitor de tela.
- `headingLevel` ajusta o nível semântico (`h1`–`h6`) conforme a hierarquia da página que hospeda o painel.
- **Toda ação é opt-in por handler**: sem `onExpand`/`onMinimize`/`onClose`, o botão correspondente não existe no DOM. Sem nenhum dos três (e sem `actions`), o container de ações não é renderizado.
- `actions` entra **antes** dos botões padrão, permitindo ações de domínio (ex.: "Histórico", "Nova conversa") sem perder as de janela.
- `avatar` tem default (`IaSRMAvatar squareBrand md`), aceita nó próprio ou `null` para remover o slot.
- `tone` é resolvido com **CVA** (`panelHeaderVariants`, também exportado): `default` usa `--surface-default` + texto primary; `brand` usa `--brand-primary` + texto on-brand e reconfigura os `--ghost-ctx-*` para os ícones ficarem claros.

---

## Exemplos

```tsx
import { PanelHeader } from '@srm/diamond';

// Mínimo
<PanelHeader label="Assistente" />

// Com subtítulo e fechar
<PanelHeader label="Assistente" subtitle="Online agora" onClose={close} />

// Todas as ações de janela
<PanelHeader
  label="Assistente"
  subtitle="Online agora"
  onExpand={expandToOverlay}
  onMinimize={collapseToDrawer}
  onClose={close}
/>

// Ações de domínio + ações de janela
<PanelHeader
  label="Assistente"
  actions={
    <IconButton
      variant="ghost"
      size="sm"
      aria-label="Nova conversa"
      icon={<Icon icon="plus" circle={false} size={14} />}
      onPress={startNewChat}
    />
  }
  onClose={close}
/>

// Tom brand + avatar próprio + heading em nível 3
<PanelHeader
  label="Assistente"
  tone="brand"
  headingLevel={3}
  avatar={<MinhaMarca />}
  onClose={close}
/>

// Sem avatar, aria-labels em outro idioma
<PanelHeader label="Assistant" avatar={null} onClose={close} closeAriaLabel="Close" />
```

---

## Acessibilidade

- O título é um heading real (`Heading` do React Aria com `slot="title"`), não um `div` estilizado — leitores de tela navegam por ele e o `Dialog` pai o usa como nome acessível.
- Cada botão de ação é [`IconButton`](../Forms/IconButton.md) só-ícone com `aria-label` configurável.
- O avatar default é decorativo (`aria-hidden`) — o título já dá o contexto, então não há nome duplicado.
- Ajuste `headingLevel` para não quebrar a hierarquia de headings da página hospedeira.

## Armadilhas comuns

- Não use dentro de `IaSRMDrawer`/`IaSRMOverlay` — eles já o compõem, e um segundo header duplica o `slot="title"`, quebrando o nome acessível do diálogo.
- Não passe um `div` com texto em `label` esperando estilo próprio: ele é renderizado dentro de um heading. Para texto puramente decorativo, use `subtitle`.
- Não simule "botão desabilitado" omitindo o handler — omitir **remove** o botão. Para desabilitar, passe o handler e controle o estado no seu próprio `actions`.
- Não sobrescreva `background` via `className` para obter o tom brand — use `tone="brand"`, que também ajusta os ícones ghost.
