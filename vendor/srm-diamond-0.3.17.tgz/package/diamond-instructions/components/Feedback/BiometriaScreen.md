# BiometriaScreen

Tela completa (fullscreen mobile) para fluxos de biometria: reconhecimento facial,
prova de vida (liveness), foto de documento e upload de documento. Orquestra
`Tag`, `Icon`, `Button`, `DoubleButton` e `UploadAreaMobile` para renderizar o
copy, a moldura de câmera (viewfinder) e as ações corretas conforme `type` +
`status`. Não faz captura de câmera nem upload real — é **puramente apresentacional/controlado**:
o consumidor decide as transições de `status` e implementa a captura/envio de fato. O
componente é **agnóstico de domínio/rota/store** — não conhece nenhuma tela específica de
produto; toda ação (`onCapture`/`onFiles`/`onCancel`) é só um evento emitido para o consumidor.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/BiometriaScreen/`
- **Export:** `import { BiometriaScreen } from '@srm/diamond';` — o barrel também reexporta os
  tipos `BiometriaScreenProps`, `BiometriaType`, `BiometriaStatus` e `BiometriaCopy`
- **Relacionados:** [DoubleButton](../Forms/DoubleButton.md) (par de ações primária/secundária),
  [UploadAreaMobile](../Forms/UploadAreaMobile.md) (usado internamente no modo `document-upload`),
  [Tag](../DataDisplay/Tag.md), [Icon](../Icons/Icon.md)

---

## Quando usar

- Onboarding de conta / KYC: captura facial para validação de identidade (`type="face"`).
- Prova de vida com sequência de instruções dinâmicas (aproximar/afastar/ficar parado/validando)
  antes de liberar uma operação sensível (`type="liveness"`).
- Captura de foto de documento (RG, CNH) pela câmera do dispositivo (`type="document-photo"`).
- Upload de arquivo de documento quando a câmera não é usada — o usuário anexa um
  JPG/PNG/PDF (`type="document-upload"`).
- Qualquer fluxo mobile fullscreen onde a etapa de biometria/documento precisa de
  feedback visual forte (glow, moldura pulsante, progress bar indeterminada), inclusive com
  copy de produto específico via `copy`/props de label (ver abaixo).

## Quando **não** usar

- Fluxo de biometria embutido em um formulário desktop/inline (não fullscreen) → componha
  `Tag` + `Icon` + `Button`/`DoubleButton` manualmente, sem `BiometriaScreen`.
- Upload de arquivo genérico sem contexto de biometria/documento → use
  [`UploadAreaMobile`](../Forms/UploadAreaMobile.md) diretamente.
- Mensagem de sucesso/erro simples e pontual (toast) → use [`Toastr`](./Toastr.md).
- Você precisa de **captura de câmera real** (`getUserMedia`, SDK de liveness, etc.) — este
  componente só desenha a UI; a integração com câmera/SDK é responsabilidade do consumidor.

---

## Interface

```ts
export type BiometriaType = 'face' | 'liveness' | 'document-photo' | 'document-upload';

// Sub-estados 'move-closer' | 'move-away' | 'hold-still' | 'validating' só fazem
// sentido para type='liveness' — são as etapas da sequência de prova de vida.
// O consumidor controla a transição via prop `status`; NÃO há auto-flow interno
// (o componente não avança sozinho de um status para outro).
export type BiometriaStatus =
  | 'idle'
  | 'capturing'
  | 'success'
  | 'error'
  | 'move-closer'
  | 'move-away'
  | 'hold-still'
  | 'validating';

export interface BiometriaCopyEntry {
  headline: string;
  support: string;
}

export interface BiometriaCopyByStatus {
  idle: BiometriaCopyEntry;         // única entrada obrigatória — serve de fallback
  capturing?: BiometriaCopyEntry;
  success?: BiometriaCopyEntry;
  error?: BiometriaCopyEntry;
  'move-closer'?: BiometriaCopyEntry;
  'move-away'?: BiometriaCopyEntry;
  'hold-still'?: BiometriaCopyEntry;
  validating?: BiometriaCopyEntry;
}

export type BiometriaCopy = Record<BiometriaType, BiometriaCopyByStatus>;

interface BiometriaScreenProps {
  type?: BiometriaType;                  // default: 'face'
  onCapture?: () => void;                // disparo da ação primária (capturar/enviar/continuar/tentar de novo)
  onFiles?: (files: File[]) => void;     // só relevante em type='document-upload' — repassado ao UploadAreaMobile
  onCancel?: () => void;                 // disparo da ação secundária (cancelar/voltar)
  status?: BiometriaStatus;              // default: 'idle'

  /** Sobrescreve parcialmente os textos padrão (BIOMETRIA_COPY) por tipo/status. */
  copy?: Partial<BiometriaCopy>;
  /** Sobrescreve o label da ação primária (default derivado do status). */
  primaryLabel?: string;
  /** Sobrescreve o label da ação de cancelar/voltar (default derivado do status). */
  cancelLabel?: string;
  /** @default 'Continuar' — botão único de sucesso em type='liveness' */
  continueLabel?: string;
  /** @default 'Captura criptografada' — tag do topo em modo câmera */
  encryptedTagLabel?: string;
  /** @default 'Envio criptografado' — tag do topo em type='document-upload' */
  uploadEncryptedTagLabel?: string;
  /** @default 'Validando prova de vida' — aria-label da progress bar em status='validating' */
  validatingAriaLabel?: string;
  /** @default 'JPG, PNG ou PDF · até 10MB' — hint da área de upload em type='document-upload' */
  uploadHint?: string;
}
```

Não há `ref`, `className` nem `theme` — o componente não expõe customização de
estilo; layout, cores e tema (claro) são fixos via CSS Modules.

### Regras de composição por `status` (lidas direto do JSX)

| Condição | O que é renderizado no rodapé |
|---|---|
| Liveness em qualquer sub-estado em andamento (`idle`\* só quando via liveness, `move-closer`, `move-away`, `hold-still`, `validating`) | `Button` ghost full-width único, label = `cancelLabel ?? BIOMETRIA_SECONDARY_LABEL[status]` (default "Cancelar"); barra de progresso reservada acima, ativa (`role="progressbar"`, `aria-label={validatingAriaLabel}`) somente em `validating` |
| `status="error"` (qualquer `type`) | `DoubleButton` vertical `primary-ghost`: primária = `primaryLabel ?? "Tentar novamente"`, secundária = `cancelLabel ?? "Voltar"` |
| `status="success"` **e** `type="liveness"` | `Button` primary full-width único: `continueLabel` (default "Continuar") |
| `status="success"` (demais `type`) | `Button` ghost full-width único: `cancelLabel ?? "Voltar"` |
| `status="idle"` ou `"capturing"` (não-liveness) | `DoubleButton` vertical `primary-ghost`: primária = `primaryLabel ?? "Capturar"/"Capturando..."` (ou "Enviar documento"/"Enviando..." se `type="document-upload"`), secundária = `cancelLabel ?? "Cancelar"`; `primaryLoading` fica `true` durante `capturing` |

\* Note que `idle` **sem** ser liveness cai no ramo `DoubleButton` (linha final da
tabela) — só o `idle` de `type="liveness"` seria tratado como "em andamento" se
`status` já tivesse avançado (na prática `idle` nunca ativa `viewfinderCapturing`
nem a barra de progresso, pois a condição exige `status !== 'idle'`).

### Comportamentos não óbvios

- **Copy sobrescrevível, não mais fixa**: `headline`/`support` vêm de
  `{ ...BIOMETRIA_COPY[type], ...(copy?.[type] ?? {}) }[status]` — a prop `copy` é mesclada
  **por cima** dos defaults internos (`BIOMETRIA_COPY`), status a status; se a combinação
  final `type`+`status` ainda não tiver entrada, cai em `resolvedCopy.idle`. Ou seja: dá para
  sobrescrever só o `error` de `face`, por exemplo, sem precisar redeclarar `idle`/`capturing`
  daquele tipo.
- **Labels de ação sobrescrevíveis**: `primaryLabel` e `cancelLabel`, quando informados,
  **substituem totalmente** o label calculado a partir do status/tipo (`BIOMETRIA_PRIMARY_LABEL`
  / `BIOMETRIA_SECONDARY_LABEL`) em qualquer branch da tabela acima — não há merge parcial
  como em `copy`.
- **Ícone por tipo**: `face` → `scan-face`, `liveness` → `scan-eye`,
  `document-photo`/`document-upload` → `id-card` (via `Icon`, mapa fixo `BIOMETRIA_TYPE_ICON`
  — não configurável por prop).
- **Viewfinder**: moldura oval (`shapeOval`) para `face`/`liveness`; moldura
  retangular (`shapeDocument`) para `document-photo`. Fica pulsante
  (`viewfinderCapturing`) quando `status="capturing"` ou, em liveness, em
  qualquer sub-estado em andamento diferente de `idle`. Respeita
  `prefers-reduced-motion` (desliga a animação).
- **`document-upload`** não mostra viewfinder nem glow de fundo — em vez disso
  renderiza `UploadAreaMobile` com `accept="image/*,.pdf"` e `hint={uploadHint}`
  (default `'JPG, PNG ou PDF · até 10MB'`); `forceHover` fica ativo durante `capturing`
  (dá feedback de "enviando" na área de upload).
- **Ícone de conclusão**: em `success`/`error` some a câmera/upload e aparece
  `Icon` (`success` ou `error`, `size={41}`) acima do texto.
- **Tag do topo**: sempre visível, texto muda entre `uploadEncryptedTagLabel` (default
  "Envio criptografado", modo upload) e `encryptedTagLabel` (default "Captura criptografada",
  modo câmera).
- **Callbacks condicionais**: `onCapture`/`onFiles`/`onCancel` só são
  espalhados nos componentes filhos se estiverem definidos (`!== undefined`) —
  passar `undefined` explicitamente é seguro e não gera handler vazio.
- **Sem gerenciamento de estado interno**: o componente é 100% controlado por
  `status`; para simular um fluxo completo, o consumidor deve trocar `status`
  manualmente a cada evento (ex.: `onCapture` → `setStatus('capturing')` → depois
  de alguma promise → `setStatus('success' | 'error')`).
- O antigo status auxiliar `LIVENESS_VALIDATING_STATUS` foi **removido** do módulo de
  constantes — `'validating'` já é um valor de primeira classe em `BiometriaStatus`; não há
  mais uma constante separada para referenciá-lo.

---

## Exemplos

```tsx
import { useState } from 'react';
import { BiometriaScreen, type BiometriaStatus } from '@srm/diamond';

// Reconhecimento facial — fluxo básico controlado
function FaceCaptureScreen() {
  const [status, setStatus] = useState<BiometriaStatus>('idle');

  const handleCapture = async () => {
    setStatus('capturing');
    const ok = await runFaceRecognitionSdk(); // integração real fica a cargo do consumidor
    setStatus(ok ? 'success' : 'error');
  };

  return (
    <BiometriaScreen
      type="face"
      status={status}
      onCapture={handleCapture}
      onCancel={() => history.back()}
    />
  );
}
```

```tsx
// Prova de vida (liveness) — sequência de sub-estados
function LivenessScreen() {
  const [status, setStatus] = useState<BiometriaStatus>('idle');

  const handleCapture = () => {
    // exemplo simplificado de máquina de estados dirigida pelo SDK de liveness
    setStatus('move-closer');
    // ... callbacks do SDK avançam para 'hold-still', depois 'validating', depois 'success' | 'error'
  };

  return (
    <BiometriaScreen
      type="liveness"
      status={status}
      onCapture={handleCapture}
      onCancel={() => setStatus('idle')}
    />
  );
}
```

```tsx
// Foto de documento
<BiometriaScreen
  type="document-photo"
  status="idle"
  onCapture={handleCaptureDocumento}
  onCancel={handleVoltar}
/>
```

```tsx
// Upload de documento (sem câmera), com hint customizado
function DocumentUploadScreen() {
  const [status, setStatus] = useState<BiometriaStatus>('idle');

  const handleFiles = async (files: File[]) => {
    setStatus('capturing');
    try {
      await enviarDocumento(files[0]);
      setStatus('success');
    } catch {
      setStatus('error');
    }
  };

  return (
    <BiometriaScreen
      type="document-upload"
      status={status}
      onFiles={handleFiles}
      onCancel={() => setStatus('idle')}
      uploadHint="PDF ou foto nítida · até 10MB"
    />
  );
}
```

```tsx
// Estado de erro — DoubleButton "Tentar novamente" / "Voltar" aparece sozinho
<BiometriaScreen type="face" status="error" onCapture={retry} onCancel={goBack} />

// Estado de sucesso em liveness — único botão primário "Continuar"
<BiometriaScreen type="liveness" status="success" onCapture={goToNextStep} />

// Copy de negócio sobrescrita (produto específico), mesclada sobre os defaults
<BiometriaScreen
  type="face"
  status="idle"
  copy={{
    face: {
      idle: { headline: 'Vamos confirmar sua identidade', support: 'Centralize o rosto no quadro' },
    },
  }}
  primaryLabel="Iniciar verificação"
  cancelLabel="Fazer depois"
/>
```

---

## Acessibilidade

- A barra de progresso indeterminada usa `role="progressbar"` com
  `aria-label={validatingAriaLabel}` (default `'Validando prova de vida'`) **apenas** quando
  ativa (`status="validating"`); fora disso fica `aria-hidden`, sem interferir na árvore de
  acessibilidade.
- Ícones decorativos (`Lock` da tag, ícone do viewfinder) recebem `aria-hidden="true"`.
- O headline em estado de erro (`status="error"`) muda de cor (`headlineError`)
  mas o texto em si já comunica o erro — não depende só de cor.
- Botões internos (`Button`/`DoubleButton`) já carregam seus próprios rótulos
  textuais (não são ícone-apenas), então herdam nome acessível automaticamente —
  inclusive quando o texto vem de `primaryLabel`/`cancelLabel`/`continueLabel` customizados.
- Respeita `prefers-reduced-motion: reduce` tanto na pulsação do viewfinder
  quanto na animação da barra de progresso.

## Armadilhas comuns

- **Não** espere transição automática de status — `BiometriaScreen` não tem
  timer nem lógica de avanço; cada mudança de `status` deve vir do consumidor.
- **Não** use `onFiles` fora de `type="document-upload"` — nos demais tipos o
  callback nunca é acionado (não há `UploadAreaMobile` renderizado).
- Ao usar `status="error"`, tanto `onCapture` (para "Tentar novamente"/`primaryLabel`) quanto
  `onCancel` (para "Voltar"/`cancelLabel`) devem estar definidos — sem eles os botões renderizam
  mas não disparam nada.
- O componente assume um contêiner fullscreen mobile (`height: 100%`,
  `min-height: 480px`); em telas muito baixas ou containers sem altura definida
  o layout pode colapsar — sempre envolva em um frame com altura explícita
  (como no `PhoneFrame` das stories).
- Não existe prop de `theme`/dark mode — o componente sempre renderiza no tema claro.
- **`copy` faz merge raso por tipo/status** (`{ ...defaults[type], ...copy[type] }`) — se você
  passar `copy={{ face: { idle: {...} } }}`, só a entrada `idle` de `face` é sobrescrita; as
  demais entradas de `face` (`capturing`, `success`, `error`) continuam vindo do default. Não
  esqueça de fornecer todas as entradas de status que o seu fluxo realmente visita.
- `primaryLabel`/`cancelLabel` sobrescrevem o texto do botão em **todos** os branches da
  tabela de composição (idle/capturing/success/error) — não há como customizar só um status
  específico via essas props (para isso, troque o label manualmente conforme `status` no lado
  do consumidor).
