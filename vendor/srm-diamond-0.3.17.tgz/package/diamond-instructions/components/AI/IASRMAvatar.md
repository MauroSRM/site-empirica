# IaSRMAvatar

Átomo de identidade visual do iaSRM: wrapper em torno do `LogoIcon` (Brand/Logo) em
formato de avatar, com 4 variantes de shape+tone e 3 tamanhos. Base visual das
superfícies de IA como [IaSRMHero](./IASRMHero.md), [IaSRMFab](./IASRMFab.md),
`IaSRMChatBubble` e `PanelHeader`.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMAvatar/`
- **Export:** `import { IaSRMAvatar } from '@srm/diamond';`
- **Relacionados:** [IaSRMFab](./IASRMFab.md) (usa `circleBrand`/`lg` como miolo default), [IaSRMHero](./IASRMHero.md) (usa `circleGlass`/`lg`), [Logo](../Brand/Logo.md) (fonte do `LogoIcon`)

---

## Quando usar

- Identificar visualmente a marca do iaSRM em qualquer superfície de IA (hero, header de painel, mensagens do assistente).
- Sobre fundo claro, área quadrada (ex.: header de painel) → `variant="squareBrand"`.
- Sobre fundo claro, círculo sólido (ex.: miolo do FAB) → `variant="circleBrand"`.
- Ao lado de texto em superfície neutra (ex.: bolha de chat) → `variant="circleTint"`.
- Sobre gradiente/imagem brand ou dark (glassmorphism) → `variant="circleGlass"`.

## Quando **não** usar

- Para avatar de pessoa/empresa → [`Avatar`](../Identity/Avatar.md).
- Para avatar institucional SRM (colaborador/instituição, não IA) → [`AvatarSRM`](../Identity/AvatarSRM.md).
- Para redesenhar o diamante da marca à mão (SVG customizado) — sempre reutilize este componente ou o `LogoIcon` diretamente.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

type IaSRMAvatarSize = 'sm' | 'md' | 'lg';
type IaSRMAvatarVariant = 'squareBrand' | 'circleBrand' | 'circleTint' | 'circleGlass';

interface IaSRMAvatarProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  size?: IaSRMAvatarSize;        // default: 'md'
  variant?: IaSRMAvatarVariant;  // default: 'circleTint'
  decorative?: boolean;          // default: true → aria-hidden
  'aria-label'?: string;         // se não vazio, torna semântico (role="img")
  ref?: Ref<HTMLDivElement>;
  // + todos os atributos nativos de <div>: id, data-*, onClick, style, …
}
```

### Notas de comportamento

- Variantes são resolvidas por **CVA** (`iaSRMAvatarVariants`, também exportado) mapeando classes do CSS Module. Cada variante define fundo + shape + fill do glifo de forma fixa:
  - `squareBrand`: fundo `--brand-primary`, `border-radius: --radius-lg`, glifo `--text-on-brand`.
  - `circleBrand`: fundo `--brand-primary`, `border-radius: --radius-full`, glifo `--text-on-brand`. Expõe `--iasrm-avatar-bg` para um parent sobrescrever no hover via cascade CSS.
  - `circleTint`: fundo `--brand-primary-light` (dark: `--brand-1-500`), glifo `--brand-primary` (dark: `--text-on-brand`) — contraste ≈7:1 nos dois temas.
  - `circleGlass`: fundo `--white-a18` + borda `--white-a30`. Use **apenas** sobre superfícies brand/dark.
- `size` controla container e glifo juntos, via tokens `--iasrm-avatar-*` e `--iasrm-avatar-glyph-*` — não é possível variar um sem o outro.
- **Decorativo por default** (`aria-hidden`), mesma convenção do átomo [`Icon`](../Icons/Icon.md): na maioria dos usos o avatar acompanha um texto ou um controle que já tem nome acessível. Informe `aria-label` (não vazio) ou `decorative={false}` para torná-lo semântico (`role="img"`).
- `aria-label=""` **não** cria nome acessível vazio — o componente permanece decorativo.
- Não expõe `onPress` próprio; para tornar clicável, envolva em um `Button`/`AriaButton` ou use [`IaSRMFab`](./IASRMFab.md).

---

## Exemplos

```tsx
import { IaSRMAvatar } from '@srm/diamond';

// Default (circleTint, md) — decorativo, ao lado de texto
<IaSRMAvatar />

// Header de painel
<IaSRMAvatar variant="squareBrand" size="md" />

// Sobre gradiente brand (glassmorphism)
<div style={{ background: 'var(--grad-ai-hero)', padding: 32, borderRadius: 12 }}>
  <IaSRMAvatar variant="circleGlass" size="lg" />
</div>

// Semântico: o avatar é o único portador de significado
<IaSRMAvatar aria-label="Assistente iaSRM" />

// Atributos nativos passam direto
<IaSRMAvatar id="brand-mark" data-testid="mark" className="minha-classe" />
```

---

## Acessibilidade

- Decorativo por default é o comportamento correto na composição típica (avatar + texto, ou avatar dentro de um botão com `aria-label`): evita nome acessível duplicado.
- Torne semântico só quando o avatar **substitui** o texto. Nesse caso informe um `aria-label` descritivo.
- Por ser não-interativo, não participa da ordem de tab — não adicione `tabIndex`.

## Armadilhas comuns

- Não use `circleGlass` sobre fundo claro — foi desenhado para superfícies brand/dark.
- Não redimensione via `style={{ width, height }}` fora de `sm/md/lg`: o glifo é dimensionado por classe e ficará desproporcional.
- Não passe `aria-label` só para "documentar" o avatar decorativo — isso cria um nome acessível redundante ao lado do texto/botão que já o descreve.
- `className` é aplicada por último (via CVA), mas sobrescrever `background`/`border-radius` ad-hoc quebra a consistência das variantes — prefira a variante correta.
