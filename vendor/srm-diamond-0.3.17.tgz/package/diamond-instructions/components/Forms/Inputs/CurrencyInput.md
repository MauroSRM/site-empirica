# CurrencyInput

Campo de entrada monetária em Real (BRL). Exibe prefixo fixo **`R$`** e aplica máscara
numérica com separador de milhar (`.`), separador decimal (`,`) e **2 casas decimais**
sempre preenchidas. Construído sobre `InputBase` (herda label, estados, temas e mensagens)
e sobre a ponte de máscara `IMaskBridge` (imask).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/CurrencyInput/`
- **Export:** `import { CurrencyInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [PercentInput](./PercentInput.md), [TextInput](./TextInput.md)

---

## Quando usar

- Captura de valores em dinheiro: aportes, resgates, limites, metas, transferências.
- Sempre que o valor precise ser formatado como moeda enquanto o usuário digita.

## Quando **não** usar

- Percentuais → use [`PercentInput`](./PercentInput.md).
- Números sem semântica monetária (quantidades, códigos) → use [`TextInput`](./TextInput.md)
  com `inputMode="numeric"`.
- Faixas de valor (mín–máx) → componha dois `CurrencyInput` em um [`FieldGroup`](../FieldGroup.md).

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface CurrencyInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string mascarada, ex.: "1.234,56")
  placeholder?: string;                    // default: '0,00'
  onChange?: (value: string) => void;      // recebe a string aceita pela máscara
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por imask com estas opções fixas (`CurrencyInput.constants.ts`):

```ts
{ mask: Number, scale: 2, thousandsSeparator: '.', radix: ',',
  normalizeZeros: true, padFractionalZeros: true }
```

- `onChange` entrega a **string mascarada** (ex.: `"1.234,56"`), não um `number`.
- Para persistir/calcular, converta você mesmo:
  `Number(value.replace(/\./g, '').replace(',', '.'))`.
- O prefixo `R$` ganha destaque visual automaticamente quando o valor numérico é `> 0`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { CurrencyInput } from '@srm/diamond';

// Básico (controlado)
function AporteField() {
  const [valor, setValor] = useState('');
  return <CurrencyInput label="Valor do aporte" value={valor} onChange={setValor} />;
}

// Com ajuda e obrigatório
<CurrencyInput label="Meta mensal" required helperText="Informe o valor bruto." />

// Estado de erro
<CurrencyInput label="Resgate" state="error" errorText="Saldo insuficiente." value={valor} onChange={setValor} />

// Somente leitura
<CurrencyInput label="Saldo atual" state="read-only" value="12.500,00" />

// Tema escuro (sobre header brand)
<CurrencyInput label="Limite" theme="dark" value={valor} onChange={setValor} />

// Convertendo para número no submit
const numero = Number(valor.replace(/\./g, '').replace(',', '.')); // "1.234,56" → 1234.56
```

### Integração com React Hook Form

```tsx
<Controller
  name="valor"
  control={control}
  render={({ field, fieldState }) => (
    <CurrencyInput
      label="Valor"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- O prefixo `R$` é `aria-hidden` (decorativo) — o rótulo semântico vem de `label`.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.

## Armadilhas comuns

- **Não** trate `value`/`onChange` como número — é string mascarada.
- **Não** re-mascare o valor manualmente; a máscara já roda no `IMaskBridge`.
- Para exibir valores vindos da API, formate para o padrão `1.234,56` **antes** de passar em `value`.
