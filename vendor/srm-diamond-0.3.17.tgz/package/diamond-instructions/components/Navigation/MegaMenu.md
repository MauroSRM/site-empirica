# MegaMenu

Painel de navegação expandido para menus densos (dezenas de links agrupados por seção).
Renderiza uma grade responsiva de links — em layout **horizontal** (1 seção, grid de 4
colunas) ou **vertical** (múltiplas seções lado a lado, com cabeçalho por seção). O
componente é **agnóstico**: cada link dispara apenas o `onClick` que você passar, e as
`key`s de seções/links são estáveis (derivadas de `title`/`label`, não de índice de array).
Construído sobre `Button` do `react-aria-components` (cada link é um botão acessível) e
`cva` para as variantes de grid.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/MegaMenu/`
- **Export:** `import { MegaMenu } from '@srm/diamond';`
- **Relacionados:** [AppHeader](./AppHeader.md) (consumidor típico via prop `megaMenuSections`)

---

## Quando usar

- Menu de navegação principal de um app com muitas funcionalidades agrupadas por domínio
  (ex.: "Usuários & Perfis", "Controle & Alçadas", "Auditoria & Compliance", "Movimentações").
- Painel acionado pelo botão hambúrguer do `AppHeader` — normalmente você **não** renderiza
  `MegaMenu` sozinho, e sim passa `sections` via a prop `megaMenuSections` do `AppHeader`.
- Navegação bancária/financeira com muitas rotas de segundo nível: cadastro de usuários,
  alçadas de aprovação, PLD/FT, transferências, extratos, Open Finance, etc.

## Quando **não** usar

- Menu simples com poucos itens, sem agrupamento → um dropdown/menu comum é mais leve.
- Navegação lateral persistente (sidebar) → não é o papel do `MegaMenu`, que é um painel
  temporário disparado por um gatilho (hambúrguer).
- Uso isolado sem o `AppHeader`: é possível (veja Exemplos), mas o padrão recomendado e já
  encapsulado (foco, dismiss, posicionamento) é via `AppHeader.megaMenuSections`.

---

## Interface

```ts
import type { ReactNode } from 'react';

interface MegaLinkItem {
  label: string;             // texto principal do link — também usado como key do item
  description?: string;      // linha secundária, menor e mais clara
  icon?: ReactNode;          // ícone à esquerda do texto
  onClick?: () => void;      // handler de navegação/ação — o componente não navega por conta própria
}

interface MegaMenuSection {
  title?: string;            // cabeçalho da seção — ignorado em layout horizontal (1 seção)
  icon?: ReactNode;          // ícone ao lado do título (exibido em círculo destacado)
  wide?: boolean;            // atalho para cols = 2 (ignorado se cols for definido)
  cols?: number;             // colunas internas do grid da seção (default: 1)
  links: MegaLinkItem[];
}

interface MegaMenuProps {
  sections?: MegaMenuSection[];  // default: []
  fluid?: boolean;                // default: false — força seções a dividir a largura igualmente
  className?: string;
}
```

### Notas de comportamento

- **`onClick` por link é a única forma de reagir a uma interação.** O componente não conhece
  rotas nem executa navegação — ele é totalmente agnóstico da camada de roteamento; toda a
  ação de cada item vem de `MegaLinkItem.onClick`.
- **Keys estáveis, não posicionais.** A `key` de cada seção é `section.title` (ou, na
  ausência de título, os `label`s dos links concatenados por `|`, como fallback
  determinístico); a `key` de cada link é o próprio `link.label`. Isso evita remontagens
  desnecessárias e bugs de foco/estado ao reordenar `sections`/`links` — mas exige que
  `title`s de seção e `label`s de link dentro da mesma seção sejam únicos (ver Armadilhas).
- **1 seção → layout horizontal automático.** Quando `sections.length === 1`, o componente
  ignora `title`/`icon` da seção e renderiza os links em um grid de **4 colunas** (`linksSingle`),
  que reduz para 3 → 2 → 1 coluna conforme a **largura do viewport** encolhe (ver breakpoints
  abaixo).
- **2+ seções → layout vertical/multi-coluna.** Cada seção vira uma coluna com cabeçalho
  (ícone + título, ou só título em `sectionLabel` caps-lock se não houver `icon`). Os links
  dentro da seção usam grid de `cols` colunas (via `wide`/`cols`).
- **`fluid`** faz as seções dividirem a largura disponível igualmente (`flex: 1 1 0`), em vez
  de manter uma largura fixa por coluna (`COLUMN_WIDTH = 260px` × `cols`, definida em
  `MegaMenu.constants.ts`). `fluid` é ativado automaticamente também quando há **apenas 1
  seção** (`singleColumn`), mesmo que você não passe a prop.
- **Os breakpoints respondem ao viewport, não ao painel — apesar da aparência de container
  query.** O `.root` declara `container-type: inline-size` (SCSS), mas atualmente **não há
  nenhuma regra `@container`** no módulo — todo o responsivo é feito com `@media (max-width: ...)`
  tradicional, ou seja, reage à largura da **janela**, não à largura real do painel. Isso é
  relevante para IA/dev que for depurar ou reimplementar o CSS: um `MegaMenu` dentro de um
  container estreito em uma tela larga **não** vai colapsar para o layout compacto — e um
  `MegaMenu` numa tela estreita colapsa mesmo que o painel em si tenha espaço de sobra.
  - `≥ 960px`: seções lado a lado com separador `border-left`.
  - `< 960px`: seções empilhadas com separador `border-top`; **exceção**: exatamente 4 (ou
    mais) seções formam um grid 2×2 entre 780–959px (seletor `:has(> .section:nth-child(4))`).
  - `< 780px`: força empilhamento total (cancela a exceção 2×2).
  - `< 1024px` / `< 768px` / `< 480px`: o grid horizontal de 4 colunas (`linksSingle`) reduz
    para 3 / 2 / 1 coluna; o grid de 2 colunas de uma seção `wide`/`cols=2` (`linksWide`) some
    para 1 coluna abaixo de 780px.
- Cada `MegaLinkItem` é renderizado como um `Button` do `react-aria-components` — herda
  automaticamente estados `data-hovered` e `data-focus-visible` (foco visível via outline),
  suporte a teclado e toque. `onClick` é opcional; se ausente, o link fica sem `onPress`
  (visualmente clicável mas sem ação — normalmente não desejado, sempre passe `onClick`).
- `description` é opcional e renderizado como uma segunda linha, menor e em cor terciária,
  abaixo do `label`.
- O painel tem `max-height: calc(100dvh - var(--nav-height))` com `overflow-y: auto` interno —
  já vem preparado para menus longos sem estourar a viewport.

---

## Exemplos

```tsx
import { MegaMenu } from '@srm/diamond';
import { Users, UserPlus, KeyRound, Building2 } from 'lucide-react';

// Layout horizontal — 1 seção, sem título, grid de 4 colunas
<MegaMenu
  sections={[{
    links: [
      { label: 'Novo usuário', description: 'Cadastrar e definir perfil de acesso', icon: <UserPlus size={20} />, onClick: () => nav('/usuarios/novo') },
      { label: 'Gerenciar usuários', description: 'Editar, suspender e revogar acessos', icon: <Users size={20} />, onClick: () => nav('/usuarios') },
      { label: 'Redefinir acesso', description: 'Senha, MFA e certificados', icon: <KeyRound size={20} />, onClick: () => nav('/acesso/redefinir') },
      { label: 'Multi CNPJ', description: 'Gerenciar empresas vinculadas', icon: <Building2 size={20} />, onClick: () => nav('/empresas') },
    ],
  }]}
/>

// Layout vertical — múltiplas seções com cabeçalho e ícone, 2 colunas internas
<MegaMenu
  fluid
  sections={[
    {
      title: 'Usuários & Perfis',
      icon: <Users size={20} />,
      cols: 2,
      links: [
        { label: 'Novo usuário', icon: <UserPlus size={20} />, onClick: () => nav('/usuarios/novo') },
        { label: 'Gerenciar usuários', icon: <Users size={20} />, onClick: () => nav('/usuarios') },
      ],
    },
    {
      title: 'Controle & Alçadas',
      icon: <KeyRound size={20} />,
      cols: 2,
      links: [
        { label: 'Configurar alçadas', onClick: () => nav('/alcadas') },
        { label: 'Permissões', onClick: () => nav('/permissoes') },
      ],
    },
  ]}
/>

// Seção só com título (sem ícone) — cabeçalho vira label pequeno em caps-lock
<MegaMenu sections={[{ title: 'Movimentações', links: [/* ... */] }]} />

// Uso real recomendado: via AppHeader (encapsula abertura/fechamento e posicionamento)
import { AppHeader } from '@srm/diamond';

<AppHeader
  megaMenuSections={[
    { title: 'Usuários & Perfis', icon: <Users size={20} />, cols: 2, links: [/* ... */] },
    { title: 'Controle & Alçadas', icon: <KeyRound size={20} />, cols: 2, links: [/* ... */] },
  ]}
  // ...demais props do AppHeader
/>
```

### Uso isolado com posicionamento manual (fora do AppHeader)

Se precisar montar o painel fora do `AppHeader` (ex.: um header customizado), combine com
`@floating-ui/react` para ancorar o painel ao botão de disparo — é o padrão usado na story
`WithHeaderTrigger`:

```tsx
import { useState } from 'react';
import { useFloating, useDismiss, useInteractions, offset, autoUpdate, FloatingPortal } from '@floating-ui/react';
import { MegaMenu } from '@srm/diamond';

function HeaderComTrigger({ sections }) {
  const [isOpen, setIsOpen] = useState(false);
  const { refs, floatingStyles, context } = useFloating({
    open: isOpen,
    onOpenChange: setIsOpen,
    placement: 'bottom-start',
    strategy: 'fixed',
    middleware: [offset(0)],
    whileElementsMounted: autoUpdate,
  });
  const { getReferenceProps, getFloatingProps } = useInteractions([useDismiss(context)]);

  return (
    <>
      <button
        ref={refs.setReference}
        {...getReferenceProps()}
        aria-expanded={isOpen}
        aria-label={isOpen ? 'Fechar menu' : 'Abrir menu'}
        onClick={() => setIsOpen(o => !o)}
      >
        Menu
      </button>
      {isOpen && (
        <FloatingPortal>
          <div ref={refs.setFloating} style={floatingStyles} {...getFloatingProps()}>
            <MegaMenu sections={sections} fluid />
          </div>
        </FloatingPortal>
      )}
    </>
  );
}
```

---

## Acessibilidade

- Cada link é um `Button` do `react-aria-components` — recebe automaticamente foco por
  teclado, `aria-pressed`/estados de interação e disparo por Enter/Espaço.
- **Foco visível**: `data-focus-visible` aplica `outline: 2px solid var(--border-brand)`.
- O botão de gatilho (hambúrguer) deve ter `aria-expanded` refletindo o estado aberto/fechado
  e `aria-label` descritivo (ex.: "Abrir menu"/"Fechar menu") — ver exemplo acima.
- Se usar `useDismiss` do `floating-ui` (ou equivalente), o painel fecha com `Esc` e clique
  fora — comportamento esperado para menus temporários.
- `icon` de `MegaLinkItem`/`MegaMenuSection` é puramente decorativo; o texto acessível vem do
  `label` (e do `title` da seção). Não dependa apenas do ícone para transmitir significado.

## Armadilhas comuns

- **Não** renderize `MegaMenu` sem gatilho e sem `floating-ui`/portal em produção — ele não
  gerencia abertura/fechamento, posicionamento ou dismiss sozinho; use `AppHeader.megaMenuSections`
  sempre que possível.
- Esquecer `onClick` em um `MegaLinkItem` resulta em um botão clicável sem ação — o
  componente é agnóstico e nunca navega por conta própria; sempre associe a ação real.
- Repetir `title` entre seções, ou `label` entre links de uma mesma seção — quebra a
  unicidade das `key`s estáveis usadas internamente (título de seção / label de link).
- Misturar seções com e sem `title`/`icon` no mesmo `MegaMenu` gera cabeçalhos inconsistentes
  (uma seção com círculo de ícone ao lado de outra só com label em caps-lock) — padronize
  dentro do mesmo menu.
- `cols`/`wide` só têm efeito com **2 ou mais seções** (`singleColumn === false`); em layout
  horizontal (1 seção) o grid de 4 colunas do próprio painel já é fixo e essas props são
  ignoradas.
- Assumir que os breakpoints reagem à largura do painel (container query) — hoje eles
  reagem à largura do **viewport** via `@media`, mesmo com `container-type: inline-size`
  declarado no CSS. Um `MegaMenu` dentro de um container estreito numa tela larga não vai
  colapsar; isso pode surpreender ao depurar problemas de layout em containers customizados.
