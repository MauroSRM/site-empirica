# IconButton

Botão de ação que exibe **apenas um ícone**, sem texto. Suporta quatro variantes semânticas
(`primary`, `secondary`, `destructive`, `ghost`), três tamanhos e tema claro/escuro — usado
tipicamente em toolbars, headers, tabelas e cards, onde espaço é limitado e a ação é
reconhecível por ícone. Construído sobre `Button` do `react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/IconButton/`
- **Export:** `import { IconButton } from '@srm/diamond';`
- **Relacionados:** [Button](./Button.md) (ação com texto, inclui modo `icon="only"`)

---

## Quando usar

- Ações compactas em toolbars, headers de card/modal e linhas de tabela (editar, excluir,
  fechar, mais opções).
- Botão de fechar (`X`) em modais, drawers e toasts.
- Ações rápidas em listas densas (ex.: extratos, ordens, posições) onde repetir texto em
  cada linha poluiria a UI.
- Quando o ícone sozinho já é universalmente reconhecível para o contexto (lixeira = excluir,
  lápis = editar, sino = notificações).

## Quando **não** usar

- Quando a ação **não** é óbvia apenas pelo ícone, ou o produto exige rótulo visível por
  padrão de UX → use [`Button`](./Button.md) com `icon="left"`/`"right"` (texto + ícone).
- Botão só-ícone dentro de um fluxo onde `Button` já é o padrão estabelecido (ex.: rodapé de
  formulário) → prefira [`Button`](./Button.md) com `icon="only"` para manter a mesma família
  visual de tamanhos/loading do `Button`.
- Ação que precisa de estado de `loading` com spinner — `IconButton` **não** tem essa prop;
  use [`Button`](./Button.md) `icon="only"` `loading`.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { ButtonProps as AriaButtonProps } from 'react-aria-components';

type IconButtonSize = 'sm' | 'md' | 'lg';
type IconButtonVariant = 'primary' | 'secondary' | 'destructive' | 'ghost';
type IconButtonTheme = 'light' | 'dark';

interface IconButtonProps extends Omit<AriaButtonProps, 'className' | 'children' | 'aria-label'> {
  icon: ReactNode;               // obrigatório — o ícone renderizado dentro do botão
  size?: IconButtonSize;         // default: 'md'
  variant?: IconButtonVariant;   // default: 'ghost'
  theme?: IconButtonTheme;       // default: 'light' — usado para estilização em headers/bars escuros
  'aria-label': string;          // obrigatório — nome acessível (botão só tem ícone)
  className?: string;
  ref?: Ref<HTMLButtonElement>;
  // Herdado de AriaButtonProps: onPress, isDisabled, isPending, type, form, aria-*, ...
}
```

### Notas de comportamento

- `icon` é **obrigatório** — não há fallback; sem ele o botão renderiza vazio.
- `'aria-label'` é **obrigatório na tipagem** (não opcional como em `AriaButtonProps`) —
  o TypeScript falha a build se ele não for passado.
- Sem estado de `loading`: diferente de `Button`, `IconButton` não desabilita nem troca o
  conteúdo automaticamente durante operações assíncronas — controle isso via `isDisabled`
  manualmente se necessário.
- `theme="dark"` no `variant="ghost"` é **alinhado deliberadamente** com `Button.ghost.dark`
  (mesmos tokens de hover/pressed) para consistência visual entre os dois componentes.
- `variant="ghost"` herda cor do contexto via CSS custom properties (`--ghost-ctx-color`,
  `--ghost-ctx-hover-bg`, `--ghost-ctx-active-bg`) com fallback para as cores de marca —
  isso permite que containers como `Toast` sobrescrevam a cor do ícone sem precisar de uma
  prop dedicada.
- Prefira **`onPress`** (react-aria) a `onClick` — cobre teclado e toque de forma consistente.

---

## Exemplos

```tsx
import { IconButton } from '@srm/diamond';
import { X, Pencil, Plus, Trash2 } from 'lucide-react';

// Básico (ghost, default)
<IconButton icon={<X size={18} />} aria-label="Fechar" onPress={handleClose} />

// Variantes
<IconButton icon={<X size={18} />} variant="ghost" aria-label="Fechar" />
<IconButton icon={<Pencil size={18} />} variant="secondary" aria-label="Editar" />
<IconButton icon={<Plus size={18} />} variant="primary" aria-label="Adicionar" />
<IconButton icon={<Trash2 size={18} />} variant="destructive" aria-label="Excluir" onPress={handleDelete} />

// Tamanhos
<IconButton icon={<X size={16} />} size="sm" aria-label="Fechar" />
<IconButton icon={<X size={18} />} size="md" aria-label="Fechar" />
<IconButton icon={<X size={20} />} size="lg" aria-label="Fechar" />

// Desabilitado
<IconButton icon={<Trash2 size={18} />} variant="destructive" aria-label="Excluir" isDisabled />

// Tema escuro (sobre header/toolbar brand)
<IconButton icon={<X size={18} />} variant="ghost" theme="dark" aria-label="Fechar" />

// Em uma toolbar de tabela
<div style={{ display: 'flex', gap: '0.25rem' }}>
  <IconButton icon={<Pencil size={16} />} size="sm" variant="ghost" aria-label="Editar linha" onPress={() => onEdit(row.id)} />
  <IconButton icon={<Trash2 size={16} />} size="sm" variant="ghost" aria-label="Excluir linha" onPress={() => onDelete(row.id)} />
</div>
```

---

## Acessibilidade

- `aria-label` é **obrigatório** — sem texto visível, é a única forma de dar nome acessível
  ao botão para leitores de tela. A tipagem já força isso em tempo de compilação.
- Passe o ícone com `aria-hidden="true"` (como nos exemplos do Storybook) para que leitores
  de tela não tentem descrever o SVG em duplicidade com o `aria-label`.
- Estados de foco visível (`data-focus-visible`) e desabilitado (`data-disabled`) são
  tratados via CSS a partir dos data-attributes do react-aria — nenhuma configuração manual
  necessária.
- Use `aria-label` **descritivo da ação**, não do ícone (`"Excluir cliente"`, não `"Lixeira"`).

## Armadilhas comuns

- Esquecer o `aria-label` quebra a build (TypeScript) — é intencional, não um bug.
- Usar `IconButton` para uma ação ambígua sem contexto visual próximo (ex.: numa área isolada
  da tela) prejudica a usabilidade — combine com `title`/tooltip quando o ícone não for óbvio.
- Não existe prop `loading`; para ações assíncronas com feedback de carregamento, use
  [`Button`](./Button.md) `icon="only"` `loading` em vez de `IconButton`.
- `className` é mesclado às variantes (CVA) por último — evite sobrescrever cor/estado via
  CSS ad-hoc; prefira as props `variant`/`theme`.
