# Chip

Elemento compacto de seleção/filtro em formato pílula. É um `ToggleButton` do
`react-aria-components` — alterna entre selecionado/não-selecionado (sozinho ou dentro de
um [`ChipGroup`](./ChipGroup.md)), com suporte a ícone de liderança por "tipo semântico" e a
uma variante **removível** (ex.: tags de anexo, filtros aplicados).

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Chip/`
- **Export:** `import { Chip } from '@srm/diamond';`
- **Relacionados:** [ChipGroup](./ChipGroup.md) (agrupamento com seleção agregada)

---

## Quando usar

- Filtros de listas/tabelas (classes de ativo, status, categorias) — sozinho ou em `ChipGroup`.
- Seleção múltipla ou única de opções curtas e visíveis simultaneamente (chips de "escolha").
- Tags removíveis: anexos, palavras-chave, destinatários adicionados a um campo.
- Indicar filtros já aplicados em uma busca, com opção de removê-los individualmente.

## Quando **não** usar

- Ação de disparo único sem estado de seleção (ex.: "Salvar", "Confirmar") → use [`Button`](./Button.md).
- Alternância binária simples fora de um contexto de "escolha entre opções visíveis" → considere
  um `Switch`/`Checkbox` (mais adequados semanticamente para configurações).
- Navegação por abas → não é um `Tab`; não use `Chip` para trocar de seção de conteúdo.
- Escolha entre muitas opções, que não caberiam todas visíveis ao mesmo tempo →
  [`MultiSelect`](./MultiSelect.md) (com `Chip` removível abaixo do campo para mostrar
  o que já foi escolhido, se a seleção precisar ficar visível).

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { ToggleButtonProps as AriaToggleButtonProps } from 'react-aria-components';
import type { ChipVariants } from '@srm/diamond'; // internamente, ChipVariants['size']

type ChipIconType = 'filter' | 'choice' | 'input' | 'document';
type ChipSize = 'sm' | 'md' | 'lg';
type ChipTheme = 'default' | 'dark';

interface ChipProps extends Omit<AriaToggleButtonProps, 'className' | 'children'> {
  label: ReactNode;               // obrigatório — conteúdo textual do chip

  iconType?: ChipIconType;        // default: 'filter'
  size?: ChipSize;                 // default: 'md'
  theme?: ChipTheme;               // default: 'default'

  icon?: boolean;                  // default: false — exibe o ícone de iconType à esquerda

  removable?: boolean;             // default: false — troca para variante com botão "X" irmão

  onRemove?: () => void;           // chamado ao clicar no botão de remoção (só com removable)

  removeLabel?: string;            // default: 'Remover' — aria-label do botão de remoção
  className?: string;
  ref?: Ref<HTMLButtonElement>;
  // Herdado de AriaToggleButtonProps: isSelected, defaultSelected, onChange (selecionado: boolean),
  // isDisabled, id, aria-*, onPress (não recomendado — use onChange para estado de seleção)
}
```

### Notas de comportamento

- `Chip` é um `ToggleButton` — o estado de seleção é gerenciado por `isSelected`/`defaultSelected`
  + `onChange(isSelected: boolean)`, exatamente como o `react-aria-components`. **Não** existe prop
  `selected`/`onSelect` custom.
- `icon={true}` renderiza o ícone mapeado por `iconType` (`Filter`, `Tag`, `Search`, `FileText` —
  do `lucide-react`) à esquerda do `label`. Sem `icon`, nenhum ícone é exibido mesmo com `iconType` setado.
- `removable` muda a estrutura interna do componente: em vez de um único `<ToggleButton>`, o chip
  vira um `<span>` contendo **dois** controles independentes — o `ToggleButton` (label + seleção) e
  um `<Button>` de remoção com seu próprio `aria-label` (`removeLabel`). Clicar em remover **não**
  altera a seleção do chip nem dispara `onChange`.
- No modo `removable`, o chip sempre assume visualmente o estilo "selecionado" (borda e fundo
  `brand-primary-light`) — é o padrão visual de uma tag já aplicada, não uma opção a escolher.
- `isDisabled` no `ToggleButton` desabilita apenas o toggle; se quiser desabilitar também a remoção,
  isso é propagado automaticamente (o botão de remover herda `isDisabled` quando presente em `props`).
- Tamanhos (`sm`/`md`/`lg`) ajustam altura, padding e `font-size`; o ícone de leitura (`iconType`) e
  o ícone `X` de remoção usam `CHIP_ICON_SIZE` (`14px` em `sm`/`md`, `16px` em `lg`).
- `theme="dark"` aplica `data-theme="dark"` no elemento raiz — use sobre fundos escuros (ex.: header brand).

---

## Exemplos

```tsx
import { Chip } from '@srm/diamond';

// Básico, não controlado
<Chip label="Renda Fixa" />

// Controlado
function FiltroAtivo() {
  const [selecionado, setSelecionado] = useState(false);
  return <Chip label="FIDC" isSelected={selecionado} onChange={setSelecionado} />;
}

// Com ícone semântico
<Chip label="Buscar por CPF" icon iconType="input" />

// Tamanhos
<Chip label="Pequeno" size="sm" />
<Chip label="Médio" size="md" />
<Chip label="Grande" size="lg" />

// Removível (tag de filtro aplicado)
<Chip
  label="Vencimento: 2026"
  removable
  removeLabel="Remover filtro de vencimento"
  onRemove={() => removerFiltro('vencimento')}
/>

// Desabilitado
<Chip label="Indisponível" isDisabled />

// Tema escuro
<Chip label="Sobre header" theme="dark" defaultSelected />
```

### Dentro de um `ChipGroup`

```tsx
import { Chip, ChipGroup } from '@srm/diamond';

<ChipGroup aria-label="Classes de ativo" selectionMode="multiple" defaultSelectedKeys={['renda-fixa']}>
  <Chip id="renda-fixa" label="Renda Fixa" />
  <Chip id="multimercado" label="Multimercado" />
  <Chip id="fidc" label="FIDC" />
</ChipGroup>
```

Veja detalhes de agregação de seleção em [`ChipGroup`](./ChipGroup.md).

---

## Acessibilidade

- Renderiza como `role="button"` com `aria-pressed` refletindo o estado de seleção (padrão
  `ToggleButton` do react-aria) — leitores de tela anunciam "pressionado"/"não pressionado".
- Alternável por teclado com **Espaço** (e Enter), com foco visível padrão do react-aria.
- No modo `removable`, o botão de remoção **precisa** de um `removeLabel` descritivo quando houver
  mais de um chip removível na tela (o default genérico `'Remover'` é ambíguo em listas — prefira
  algo como `` `Remover ${label}` ``).
- Ícones (`iconType` e `X` de remoção) são `aria-hidden="true"` — o nome acessível do chip vem
  inteiramente do `label`.

## Armadilhas comuns

- Tentar usar `onPress` para capturar seleção — use **`onChange`** (retorna `boolean`), que é o
  contrato de `ToggleButton`.
- Esperar que clicar no botão "X" também desmarque a seleção — são interações **independentes**
  por design; se precisar de ambos os efeitos, trate isso explicitamente em `onRemove`.
- Usar `removeLabel` genérico (`'Remover'`) quando há múltiplos chips removíveis na mesma tela —
  leitores de tela não conseguirão diferenciá-los sem rótulo específico.
- Setar `icon` (boolean) esperando que ele aceite um elemento — o ícone é fixo por `iconType`;
  não há prop para ícone customizado (diferente de `Button.iconEl`).
