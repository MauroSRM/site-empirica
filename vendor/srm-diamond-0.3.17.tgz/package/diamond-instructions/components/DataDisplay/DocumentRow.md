# DocumentRow

Row de documento com ícone semântico (por `status`), info stack (nome + metadados) e ações
genéricas (`actions[]`). Duas densidades (`variant`): `default` (estilo card, com
tipo/tamanho/data) e `compact` (linha densa, só nome + tag). `onPress` torna a linha
clicável; as ações ficam fora da área clicável (siblings, sem interativos aninhados).
Construído sobre `Button` do `react-aria-components` (área de clique), `IconButton`,
`Overlay` (menu) e `Tag` (status).

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/DocumentRow/`
- **Export:** `import { DocumentRow } from '@srm/diamond';`
- **Relacionados:** [ApprovalRow](./ApprovalRow.md) e [PermissionRow](./PermissionRow.md)
  (mesmo padrão de row clicável + ações como siblings), [Tag](./Tag.md) (usado internamente
  para o status)

---

## Quando usar

- Listas de documentos (contratos, comprovantes, extratos) com status semântico
  (aprovado/pendente/em análise/reprovado) e ações por documento (visualizar, baixar,
  reenviar).
- Quando o número de ações por linha varia: 0 (sem área de ações), 1 (`IconButton` direto)
  ou 2+ (menu via `Overlay`) — a mesma prop `actions[]` cobre os três casos.
- Duas densidades: `default` para listas com poucos itens e mais contexto (tipo/tamanho/data)
  e `compact` para listas densas onde só nome + status importam.

## Quando **não** usar

- Fila de aprovação com ação binária fixa Aprovar/Reprovar → [`ApprovalRow`](./ApprovalRow.md).
- Linha de permissão com seleção em lote → [`PermissionRow`](./PermissionRow.md).
- Upload/anexo de arquivo (dropzone, progresso de envio) → `FileUpload`/`UploadAreaMobile`,
  não `DocumentRow` (que é só exibição de um documento já existente).

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';

type DocumentRowStatus = 'approved' | 'pending' | 'review' | 'rejected' | 'default';
type DocumentRowVariant = 'default' | 'compact';

interface DocumentAction {
  id: string;             // identificador único da ação
  label: string;          // aria-label do IconButton / label do item de menu
  icon?: string;           // nome do ícone Lucide
  onPress: () => void;     // handler acionado ao selecionar a ação
}

interface DocumentRowProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'onClick'> {
  name: ReactNode;                    // obrigatório — nome do documento (ex.: "Contrato-2026.pdf")
  type?: ReactNode;                   // extensão (ex.: "PDF") — só na variant 'default'
  size?: ReactNode;                   // tamanho formatado (ex.: "2.4 MB") — só na variant 'default'
  date?: ReactNode;                   // data (ex.: "23/06/2026") — só na variant 'default'
  status?: DocumentRowStatus;         // default: 'default' — define ícone + cor + label da Tag
  variant?: DocumentRowVariant;       // default: 'default'
  actions?: DocumentAction[];         // default: [] — 0 = sem área; 1 = IconButton; 2+ = menu
  onPress?: () => void;               // clique na linha (abre/visualiza)
  disabled?: boolean;                 // default: false
  className?: string;
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children/onClick): id, aria-*, data-*, ...
}
```

### Notas de comportamento

- `status` define, via `STATUS_CFG`, o ícone (`Icon`, com `iconType` semântico), a cor do
  círculo e o `label`/`variant` da Tag:

  | `status`   | Ícone             | `iconType` | Tag                          |
  |------------|--------------------|------------|-------------------------------|
  | `approved` | `check-circle-2`   | `success`  | "Aprovado" (`success`)        |
  | `pending`  | `clock`            | `warning`  | "Pendente" (`warning`)        |
  | `review`   | `alert-circle`     | `info`     | "Em análise" (`brandPrimary`) |
  | `rejected` | `x-circle`         | `error`    | "Reprovado" (`error`)         |
  | `default`  | `file-text`        | `default`  | sem Tag (label vazio)         |

- Só renderiza a linha inteira dentro de um `AriaButton` (área clicável) quando `onPress` é
  informado; sem `onPress`, o conteúdo é renderizado direto (sem wrapper de botão) —
  diferente do `ApprovalRow`/`PermissionRow`, que sempre têm a área clicável presente.
- `variant="compact"` oculta `type`/`size`/`date` (junta tudo em `nameCompact`) e centraliza
  a Tag verticalmente (`tagCentered`, que sobrescreve o `align-self: flex-start` padrão do
  átomo `Tag`); `variant="default"` mostra `name` + `metaText` (`type · size · date` filtrado
  e unido com ` · `).
- Ações são resolvidas por contagem, não por prop explícita:
  - `actions.length === 0` → nenhuma área de ações é renderizada.
  - `actions.length === 1` → um único `IconButton` com `aria-label={label}` e o ícone da ação.
  - `actions.length >= 2` → `Overlay` tipo `menu` com trigger `aria-label="Mais ações"`.
- As ações são sempre um `div` sibling ao conteúdo (dentro ou fora do `AriaButton`) — nunca
  aninhadas dentro da área clicável.
- `disabled` desabilita a área clicável (`isDisabled`) e todos os `IconButton`/`Overlay` de
  ações; marca `data-disabled` na raiz.

---

## Exemplos

```tsx
import { DocumentRow } from '@srm/diamond';

// Default, com metadados e duas ações (renderiza como menu)
<DocumentRow
  name="Contrato de investimento.pdf"
  type="PDF"
  size="1,2 MB"
  date="30/06/2026"
  status="approved"
  actions={[
    { id: 'view', label: 'Visualizar', icon: 'eye', onPress: () => visualizar(doc) },
    { id: 'download', label: 'Baixar', icon: 'download', onPress: () => baixar(doc) },
  ]}
  onPress={() => abrir(doc)}
/>

// Uma única ação (renderiza como IconButton direto)
<DocumentRow
  name="Extrato consolidado.xlsx"
  type="XLSX"
  size="412 KB"
  date="15/07/2026"
  status="pending"
  actions={[{ id: 'download', label: 'Baixar', icon: 'download', onPress: () => baixar(doc) }]}
/>

// Sem ações e sem onPress (só exibição)
<DocumentRow name="Termo de uso.pdf" status="default" />

// Compact
<DocumentRow
  name="Comprovante-PIX-20260718.pdf"
  status="approved"
  variant="compact"
  actions={[{ id: 'download', label: 'Baixar', icon: 'download', onPress: () => baixar(doc) }]}
/>

// Reprovado, com ação de reenvio
<DocumentRow
  name="Documento vencido.pdf"
  type="PDF"
  size="890 KB"
  date="12/05/2026"
  status="rejected"
  actions={[
    { id: 'view', label: 'Ver motivo', icon: 'eye', onPress: () => verMotivo(doc) },
    { id: 'reupload', label: 'Reenviar', icon: 'upload', onPress: () => reenviar(doc) },
  ]}
/>
```

---

## Acessibilidade

- Com `onPress`, o nome acessível da área clicável vem do conteúdo textual visível (`name` +
  metadados) — evite `name` genérico (ex.: "Documento.pdf" sem contexto) se houver várias
  linhas na mesma tela.
- O trigger de ação única usa `aria-label={action.label}` diretamente; o trigger de menu
  (2+ ações) usa `aria-label="Mais ações"` fixo — garanta que cada `action.label` no menu
  seja descritivo por si só (é o texto lido no item de menu).
- Os ícones (círculo de status e ícones de ação) são decorativos — a semântica de status
  já está no `label` da Tag, não só na cor/ícone.

## Armadilhas comuns

- Sem `onPress`, a linha **não** é focável/clicável — se o design espera abrir o documento
  ao clicar em qualquer parte da linha, `onPress` é obrigatório (o componente não infere
  isso de `actions`).
- `type`/`size`/`date` só aparecem em `variant="default"`; passá-los com `variant="compact"`
  não tem efeito visual — a variant compacta os ignora.
- `actions` com exatamente 2 itens já vira menu, não dois `IconButton` lado a lado — se o
  design pede dois ícones visíveis, isso não é possível via `actions[]`; seria necessário
  compor manualmente.
- `icon` em `DocumentAction` é uma `string` (nome do ícone Lucide), não um `ReactNode` — não
  passe elementos JSX nesse campo.
