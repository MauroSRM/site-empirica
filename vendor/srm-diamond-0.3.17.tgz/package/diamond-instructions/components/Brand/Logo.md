# Logo

Marca gráfica da SRM em SVG puro (sem dependência de imagem externa, fonte ou biblioteca de
ícones). Exporta dois componentes co-acoplados: **`Logo`**, a marca completa com variações de
tipo (símbolo isolado ou marca completa), tamanho e tema; e **`LogoIcon`**, a primitiva de baixo
nível que desenha apenas o símbolo (usada internamente por `Logo` quando `type="icon"`, mas também
exportada para uso direto). Ambos renderizam um único elemento `<svg>` — não há texto/wordmark
tipografado, a marca inteira (incluindo a parte "textual") é composta por `<path>`s.

- **Categoria:** Brand
- **Fonte:** `src/components/Brand/Logo/`
- **Export:** `import { Logo, LogoIcon } from '@srm/diamond';`
- **Relacionados:** usado internamente por `AppHeader` (`src/components/Navigation/AppHeader/AppHeader.tsx`) para o logo do topo da aplicação.

---

## Quando usar

- Cabeçalho/topbar da aplicação, tela de login, splash screen — qualquer lugar que exija a marca
  oficial da SRM em SVG escalável.
- `type="icon"` (ou `LogoIcon` direto) para espaços reduzidos: favicon in-app, avatar de sistema,
  monograma em notificações, estado vazio de branding.
- `theme="dark"` sobre fundos de cor sólida da marca (ex.: header azul); `theme="mono"` quando a
  marca completa precisa sair em uma única cor (impressão, marca d'água, superfícies que não
  suportam duas cores).
- `aria-hidden` quando o logo é puramente decorativo ao lado de um texto equivalente já visível
  (ex.: `<h1>SRM Asset</h1>`); `title` quando quiser um tooltip nativo além do nome acessível.

## Quando **não** usar

- Como botão/link clicável por si só — `Logo`/`LogoIcon` não tratam interação; envolva em um
  `Button`/`AriaButton`/`<a>` quando precisar de clique (como faz o `AppHeader`).
- Para ícones de produto genéricos (não-marca) — use os ícones da biblioteca de ícones do projeto
  (`Icon`/`lucide-react`), não `LogoIcon`.
- Quando você precisa de controle de cor totalmente livre por CSS externo — em `Logo` as cores vêm
  de tokens (`--logo-primary`, `--logo-secondary`, etc.) resolvidos internamente pela prop `theme`;
  para cor livre use `LogoIcon` direto com a prop `fill`.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

type LogoSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
type LogoType = 'full' | 'icon';
type LogoTheme = 'light' | 'dark' | 'mono';

interface LogoProps {
  type?: LogoType;               // default: 'full'
  size?: LogoSize;                // default: 'md'
  theme?: LogoTheme;              // default: 'light'
  className?: string;             // aplicado ao <svg> raiz (mesclado via clsx)
  'aria-label'?: string;          // ignorado quando aria-hidden é verdadeiro; default: 'SRM'
  'aria-hidden'?: boolean | 'true' | 'false'; // true → omite role/aria-label, marca como decorativo
  title?: string;                 // texto do <title> do SVG (tooltip nativo + nome acessível)
  ref?: Ref<SVGSVGElement>;
}

type SvgBrandProps = Omit<ComponentPropsWithoutRef<'svg'>, 'width' | 'height'>;

interface LogoIconProps extends Omit<SvgBrandProps, 'fill'> {
  fill?: string;                              // default: 'var(--logo-primary)'
  size?: number;                               // largura em px; altura calculada pela razão do viewBox; default: 40
  'aria-label'?: string;                       // ignorado quando aria-hidden é verdadeiro; default: 'SRM'
  'aria-hidden'?: boolean | 'true' | 'false';  // true → omite role/aria-label
  title?: string;                              // texto do <title> do SVG
  ref?: Ref<SVGSVGElement> | undefined;
  // + qualquer atributo nativo de <svg> (onClick, style, data-testid, id, tabIndex, ...)
}
```

### Tabelas de escala (constantes reais)

`Logo` não recebe um `size` em px — ele resolve `size` (`LogoSize`) para dimensões reais via
tabelas fixas em `Logo.constants.ts`:

| `size` | Escala (`type="full"`, sobre viewBox 124.48×32) | Largura `type="icon"` (px, passada a `LogoIcon`) |
|--------|---------------------------------------------------|----------------------------------------------------|
| `xs`   | `0.38`                                              | `16`                                                |
| `sm`   | `0.55`                                              | `24`                                                |
| `md`   | `0.75`                                              | `32`                                                |
| `lg`   | `1`                                                  | `40`                                                |
| `xl`   | `1.3`                                               | `52`                                                |

- `type="full"`: `width = round(124.48 * escala)`, `height = round(32 * escala)`.
- `type="icon"`: largura = tabela acima; altura = `round(largura * 46 / 40.1052)` (razão do
  viewBox do ícone, `40.1052 × 46`).
- `LogoIcon` usado isoladamente recebe `size` como **número em px** direto (largura), não uma das
  chaves `LogoSize` — **são APIs de tamanho diferentes entre `Logo` e `LogoIcon`.**

### Resolução de cor por `theme`

| `theme`  | `type="full"` — cor 1 (paths principais) | `type="full"` — cor 2 (paths secundários) | `type="icon"` / `LogoIcon` |
|----------|-------------------------------------------|---------------------------------------------|------------------------------|
| `light`  | `var(--logo-primary)`                      | `var(--logo-secondary)`                      | `var(--logo-primary)`        |
| `mono`   | `var(--logo-primary)`                      | `var(--logo-primary)` (igual à cor 1)        | `var(--logo-primary)` (idêntico a `light`) |
| `dark`   | `var(--surface-default)`                   | `var(--white-a85)`                           | `var(--surface-default)`     |

- `theme="mono"` só produz efeito visualmente distinto em `type="full"` (as duas cores colapsam
  em uma). Em `type="icon"` o resultado de `mono` é **idêntico** ao de `light`, pois o ícone
  isolado já usa uma única cor.
- Em `LogoIcon` usado diretamente (fora de `Logo`), não existe `theme` — você controla a cor via
  `fill` (qualquer string de cor CSS válida, não só os tokens acima).

### Acessibilidade e `<title>` — como `Logo` resolve por `type`

- **`type="icon"`**: `Logo` delega inteiramente a `LogoIcon`, passando `fill` (por `theme`),
  `size` (tabela acima) e `aria-label`/`aria-hidden`/`title`/`className`/`ref` (só spalhados
  quando definidos, para não sobrescrever os defaults internos de `LogoIcon` com `undefined`). A
  lógica de a11y abaixo, portanto, é a de `LogoIcon`.
- **`type="full"`**: `Logo` monta o `<svg>` diretamente (não usa `LogoIcon` internamente), com a
  mesma lógica de a11y replicada:
  - `hidden = ariaHidden === true || ariaHidden === 'true'`.
  - `hidden` → apenas `aria-hidden="true"` (sem `role`, sem `aria-label`).
  - não `hidden` → `role="img"` + `aria-label={ariaLabel ?? 'SRM'}`.
  - `title`, se definido, é renderizado como primeiro filho `<title>{title}</title>` do SVG
    (funciona tanto no modo decorativo quanto semântico).
- Ambos aplicam a classe `styles.icon` (CSS module, hoje só `display: block; flex-shrink: 0;`)
  mesclada via `clsx` com `className`.

### Comportamentos não óbvios

- Nenhum dos dois componentes renderiza wrapper `<div>`: a raiz é sempre o próprio `<svg>`.
  Layout (gap, alinhamento) deve ser resolvido pelo elemento pai.
- `LogoIcon` espalha `...rest` **antes** de `width`, `height`, `viewBox`, `fill` (via prop
  explícita), o bloco de a11y (`role`/`aria-label` **ou** `aria-hidden`) e `className` — ou seja,
  esses atributos explícitos **sempre vencem** e não podem ser sobrescritos via passthrough.
- `Logo` **não** aceita passthrough arbitrário de atributos `<svg>` — só as props tipadas em
  `LogoProps` (`type`, `size`, `theme`, `className`, `aria-label`, `aria-hidden`, `title`, `ref`).
  Para passthrough livre de atributos nativos de SVG, use `LogoIcon` diretamente.
- `Logo.module.scss` hoje só define a classe `.icon` — não há mais classes mortas
  (`.logo`/`.light`/`.dark`/`.wordmark`) residuais do módulo de estilo.

---

## Exemplos

```tsx
import { Logo, LogoIcon } from '@srm/diamond';

// Básico — marca completa, tema claro, tamanho padrão (md)
<Logo />

// Marca completa, tamanho grande (uso em header)
<Logo type="full" size="lg" />

// Apenas o símbolo (espaço reduzido)
<Logo type="icon" size="sm" />

// Tema escuro — sobre fundo azul da marca
<div style={{ background: 'var(--brand-primary)', padding: 24 }}>
  <Logo type="full" theme="dark" size="lg" />
</div>

// Tema mono — marca completa em uma única cor (impressão, marca d'água)
<Logo type="full" theme="mono" size="xl" />

// aria-label customizado (ex.: quando o texto ao redor já é "SRM Asset")
<Logo type="full" aria-label="SRM Asset — página inicial" />

// title — tooltip nativo do SVG além do nome acessível
<Logo type="full" title="SRM Asset — Diamond Design System" />

// Decorativo diretamente em Logo (aria-hidden), ao lado de um heading textual
<div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
  <Logo type="icon" size="sm" aria-hidden />
  <h1>SRM Asset</h1>
</div>

// LogoIcon direto, decorativo, ao lado de um heading textual
<div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
  <LogoIcon size={24} aria-hidden />
  <h1>SRM Asset</h1>
</div>

// LogoIcon com cor custom (fora dos temas de Logo)
<LogoIcon size={32} fill="var(--brand-accent)" aria-label="SRM" />
```

### Uso real no design system — `AppHeader`

```tsx
// src/components/Navigation/AppHeader/AppHeader.tsx
import { Logo } from '@srm/diamond';
import { Button as AriaButton } from 'react-aria-components';

{onLogoClick ? (
  <AriaButton onPress={onLogoClick}>
    <Logo type="full" size="md" theme={isDark ? 'dark' : 'light'} />
  </AriaButton>
) : (
  <div>
    <Logo type="full" size="md" theme={isDark ? 'dark' : 'light'} />
  </div>
)}
```

---

## Acessibilidade

- Por padrão, ambos os componentes renderizam `role="img"` com `aria-label` padrão `'SRM'` — a
  marca já é anunciada por leitores de tela sem configuração adicional.
- Passe `aria-hidden` (em `Logo` ou `LogoIcon`) para o modo puramente decorativo — omite `role` e
  `aria-label`, expõe só `aria-hidden="true"`. Use quando um texto equivalente já visível está ao
  lado (ex.: heading "SRM Asset").
- `title` adiciona um `<title>` nativo do SVG (tooltip do navegador); funciona em conjunto com o
  modo semântico ou decorativo — não interfere na lógica de `role`/`aria-label`/`aria-hidden`.
- Quando `Logo`/`LogoIcon` está dentro de um botão/link clicável (como no `AppHeader`), o nome
  acessível do controle interativo tende a vir do `aria-label` do `<svg>` filho (não há texto
  irmão). Se o botão pai também definir seu próprio `aria-label`, prefira remover a duplicidade —
  rotule em apenas um dos dois níveis (geralmente no elemento clicável, com algo como
  `aria-label="Ir para a página inicial"`), ou marque o `Logo` como `aria-hidden` nesse caso.

## Armadilhas comuns

- Não confundir a API de `size` dos dois componentes: em `Logo` é um enum semântico (`LogoSize`:
  `xs`–`xl`); em `LogoIcon` é um **número em px** de largura.
- `theme="mono"` só altera o resultado visual em `type="full"` — em `type="icon"` (ou em
  `LogoIcon` puro) não há diferença perceptível em relação a `light`.
- Não tente sobrescrever `width`/`height`/`viewBox`/`role`/`aria-hidden` de `LogoIcon` via props
  soltas — o componente já define esses atributos explicitamente depois do `...rest`, então eles
  sempre vencem.
- `Logo` não aceita `className` esperando que ele "envolva" a marca em um wrapper — a classe é
  aplicada diretamente no `<svg>` raiz.
- Passar `aria-label` **e** `aria-hidden={true}` juntos em `Logo`/`LogoIcon` — `aria-hidden` vence:
  o `aria-label` é ignorado e o elemento fica sem `role`/`aria-label`, só `aria-hidden="true"`.
- Não use `Logo`/`LogoIcon` como alvo de clique diretamente (não têm `onPress`/`onClick`
  tipados nem estados de foco/hover) — sempre envolva em um componente interativo real
  (`Button`, `AriaButton`, `<a>`) quando precisar de navegação/ação.
