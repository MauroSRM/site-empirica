# CardInput

Campo de entrada para **número de cartão** (crédito/débito). Aplica máscara numérica
em grupos de 4 dígitos (`0000 0000 0000 0000`) via `imask`/`react-imask` e detecta a
**bandeira do cartão em tempo real** a partir dos dígitos digitados, exibindo o ícone
correspondente (SVG) dentro do campo. Construído sobre `InputBase` (herda label, estados,
temas e mensagens) e sobre a ponte de máscara `IMaskBridge`.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/CardInput/`
- **Export:** `import { CardInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [TextInput](./TextInput.md), [CurrencyInput](./CurrencyInput.md)

---

## Quando usar

- Captura de número de cartão de crédito/débito em formulários de pagamento, cadastro
  de meio de pagamento, checkout ou telas de gestão de cartões.
- Sempre que for útil dar feedback visual imediato da bandeira (Visa, Mastercard, Elo,
  Amex, Hipercard) enquanto o usuário digita, sem exigir seleção manual da bandeira.

## Quando **não** usar

- CVV, validade (MM/AA) ou nome impresso no cartão → use [`TextInput`](./TextInput.md)
  com `inputMode` apropriado (esses campos não têm relação com detecção de bandeira).
- Valores monetários → use [`CurrencyInput`](./CurrencyInput.md).
- Campos numéricos genéricos sem semântica de cartão (CPF, telefone, CEP) → use o
  input mascarado específico ou `TextInput` com máscara própria.

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface CardInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string mascarada, ex.: "4111 1111 1111 1111")
  placeholder?: string;                    // default: '0000 0000 0000 0000'
  onChange?: (value: string) => void;      // recebe a string aceita pela máscara
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por imask com estas opções fixas (`CardInput.constants.ts`):

```ts
{ mask: '0000 0000 0000 0000' }
```

- `onChange` entrega a **string mascarada com espaços** (ex.: `"4111 1111 1111 1111"`),
  não um número nem uma string "crua" de 16 dígitos.
- Para persistir/enviar à API, remova os espaços você mesmo: `value.replace(/\s/g, '')`.
- **Não** é um campo de tamanho fixo de 16 dígitos — a máscara é literal (`0000 0000 0000 0000`),
  então cartões com layouts diferentes (ex.: Amex, 15 dígitos) ainda seguem esse agrupamento.

### Detecção de bandeira

- A bandeira é recalculada a cada render a partir de `value` (função pura `detectCardBrand`,
  em `src/utils/detectCardBrand.ts`), comparando os dígitos (sem espaços) contra prefixos BIN
  conhecidos: `hipercard`, `amex`, `elo`, `mastercard`, `visa` (nessa ordem de prioridade).
- Se a bandeira for detectada **e** existir um ícone correspondente em
  `src/assets/bank-icons/<bandeira>.svg`, o ícone é renderizado como `<img>` dentro do
  campo (`aria-hidden="true"`, 36×24px). Sem correspondência, nenhum ícone aparece —
  o campo funciona normalmente, apenas sem o indicador visual.
- Os ícones são resolvidos em build-time via `import.meta.glob` (Vite) — não há chamada de
  rede em runtime.

---

## Exemplos

```tsx
import { useState } from 'react';
import { CardInput } from '@srm/diamond';

// Básico (controlado)
function CartaoField() {
  const [numero, setNumero] = useState('');
  return <CardInput label="Número do cartão" value={numero} onChange={setNumero} />;
}

// Com ajuda e obrigatório
<CardInput label="Número do cartão" required helperText="Digite os 16 dígitos impressos no cartão." />

// Estado de erro
<CardInput
  label="Número do cartão"
  state="error"
  errorText="Número de cartão inválido."
  value={numero}
  onChange={setNumero}
/>

// Somente leitura (ex.: revisão de cadastro)
<CardInput label="Cartão cadastrado" state="read-only" value="4111 1111 1111 1111" />

// Tema escuro (sobre header brand)
<CardInput label="Número do cartão" theme="dark" value={numero} onChange={setNumero} />

// Enviando ao backend (removendo espaços da máscara)
const numeroLimpo = numero.replace(/\s/g, ''); // "4111 1111 1111 1111" → "4111111111111111"
```

### Integração com React Hook Form

```tsx
<Controller
  name="numeroCartao"
  control={control}
  render={({ field, fieldState }) => (
    <CardInput
      label="Número do cartão"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- O ícone da bandeira é `aria-hidden` (puramente decorativo) — não substitui rótulo
  nem anúncio de estado; a bandeira detectada **não** é lida por leitores de tela.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Considere `inputMode="numeric"` (passthrough de `TextFieldProps`) para abrir teclado
  numérico em dispositivos móveis.

## Armadilhas comuns

- **Não** trate `value`/`onChange` como número — é string mascarada, com espaços a cada
  4 dígitos.
- **Não** remova os espaços antes de passar em `value` como controlado — a máscara
  espera o formato mascarado; remova espaços apenas no submit/persistência.
- **Não** re-mascare o valor manualmente; a máscara já roda no `IMaskBridge`.
- A ausência de ícone de bandeira **não** significa número inválido — apenas que o
  prefixo não corresponde às bandeiras mapeadas ou o SVG correspondente não existe em
  `assets/bank-icons`. Validação de número de cartão (Luhn, tamanho por bandeira) não é
  feita pelo componente — implemente na camada de validação do formulário.
