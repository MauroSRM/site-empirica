# AppFooter

Rodapé institucional de aplicação: logo da SRM, lista de links (com divisores) e texto de
copyright. Adapta-se a dois eixos independentes — `theme` (claro/marca) e `device`
(desktop/mobile) — trocando layout, cores e disposição dos elementos. Construído com
markup próprio (`div`/`span`), reaproveita [`Button`](../Forms/Button.md) (`variant="link"`)
para links sem `href` e `Link` do `react-aria-components` (via `buttonVariants`) para links
com `href`. O componente é **agnóstico de roteamento**: não navega por conta própria.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/AppFooter/`
- **Export:** `import { AppFooter } from '@srm/diamond';` (também exporta os tipos `AppFooterProps` e `FooterLink`)
- **Relacionados:** `AppHeader` (cabeçalho institucional, mesma família de layout de aplicação) · [`Button`](../Forms/Button.md) (usado internamente para links sem `href`)

---

## Quando usar

- Rodapé fixo/estático de shells de aplicação (portal do investidor, área logada, backoffice).
- Exibir links institucionais recorrentes: Política de Privacidade, Termos de Uso, Suporte, Contato.
- Alternar visualmente entre um rodapé neutro (`theme="light"`) e um rodapé de destaque em
  navy (`theme="brand"`), por exemplo em telas de onboarding/login vs. área logada.
- Adaptar o mesmo rodapé para desktop (linha horizontal) e mobile (coluna empilhada) via `device`.
- Integrar com qualquer roteador (SPA client-side, `<a>` semântico, ou os dois combinados) —
  o componente delega a navegação inteiramente ao consumidor via `href`/`onClick`.

## Quando **não** usar

- Cabeçalho/topo de aplicação → use `AppHeader`.
- Navegação de conteúdo (abas, trilha de passos) → veja `TabBar` ou `Stepper`.
- Se precisar de mais de 4 links ou de estrutura customizada (colunas, redes sociais, newsletter),
  `AppFooter` **não** foi feito para isso — ele corta silenciosamente em 4 itens (veja abaixo);
  monte um rodapé próprio compondo `Button`/`Link` diretamente.

---

## Interface

```ts
import type { AppFooterProps, FooterLink } from '@srm/diamond';

interface FooterLink {
  label:    string;    // texto do link
  href?:    string;    // se presente, o item é renderizado como <a href> semântico (react-aria Link)
  onClick?: () => void; // handler de clique; a navegação em si é responsabilidade do consumidor
}

interface AppFooterProps {
  theme?:     'light' | 'brand';   // default: 'light'
  device?:    'desktop' | 'mobile'; // default: 'desktop'
  copyright?: string;               // default: 'SRM © 2026 - Todos os direitos reservados'
  links?:     FooterLink[];         // default: 4 links institucionais (ver abaixo) — apenas os
                                     // 4 primeiros (MAX_VISIBLE_LINKS) são exibidos, mesmo passando mais
}
```

`AppFooter` **não** tem `className` nem `ref` na sua assinatura — não é possível estilizar
o wrapper de fora nem obter uma referência ao DOM.

### Defaults reais

```ts
// AppFooter.constants.ts
MAX_VISIBLE_LINKS = 4;

DEFAULT_LINKS = [
  { label: 'Política de Privacidade' },
  { label: 'Termos de Uso' },
  { label: 'Suporte' },
  { label: 'Contato' },
];
```
Os links padrão **não têm** `href` nem `onClick` — são renderizados como botões de link
sem ação (útil só como placeholder visual; em produção, sempre passe `href`/`onClick`
próprios).

### Notas de comportamento

- **Corte silencioso em 4 links**: `links.slice(0, MAX_VISIBLE_LINKS)` — se você passar mais
  de 4 itens, o 5º em diante é descartado **sem aviso**. Não há paginação nem indicador de
  overflow. `MAX_VISIBLE_LINKS` é uma constante interna (não exportada), mas seu valor (4)
  está documentado no JSDoc do tipo `FooterLink`.
- **Renderização por link é agnóstica de roteamento**:
  - se `href` estiver presente, o item é um `<a>` real (`Link` do react-aria-components,
    estilizado via `buttonVariants({ variant: 'link', ... })`) — navegação nativa, suporta
    abrir em nova aba/Ctrl+clique. Se `onClick` também for passado, ele é anexado como
    `onPress` **além** do `href` (dispara em conjunto com a navegação, não em vez dela);
  - se `href` estiver ausente, o item é um `Button` (`variant="link"`) do react-aria; se
    `onClick` for passado, é usado como `onPress`; se nenhum dos dois existir, o botão fica
    sem `onPress` (clicável visualmente, sem efeito);
  - **não há mais navegação via `window.location.href`** — o componente nunca navega por
    conta própria; toda navegação é responsabilidade do `href` nativo do `<a>` ou do
    `onClick` do consumidor.
- **`theme="brand"`** ativa `data-dark` no wrapper: fundo `var(--brand-primary)` (navy),
  remove a borda superior, troca a cor do traço do logo para `var(--surface-default)`
  (branco) e os links/copyright/divisores para tons `white-a*` (translúcidos sobre navy).
- **`device="mobile"`** empilha em coluna: logo → lista de links (`flex-wrap`, sem divisores
  verticais) → divisor horizontal → copyright, com `justify-content: center`. No desktop,
  logo+links ficam à esquerda (com divisores verticais `|` entre eles) e o copyright à direita.
- O logo (`SRMLogoMark`) é um componente **interno, não exportado** — SVG decorativo com
  `aria-hidden="true"`, sempre no mesmo tamanho (28×32). Não há prop pública para variar o
  tamanho do logo.
- `key` de cada link é o próprio `label` — labels duplicados entre itens de `links` geram
  `key` duplicada no React (warning em dev).

---

## Exemplos

```tsx
import { AppFooter } from '@srm/diamond';

// Básico (defaults: theme="light", device="desktop", links institucionais padrão)
<AppFooter />

// Copyright customizado
<AppFooter copyright="SRM Asset © 2026" />

// Links com navegação real (<a href>) — SEO/acessibilidade, abre em nova aba com Ctrl+clique
<AppFooter
  links={[
    { label: 'Política de Privacidade', href: '/privacidade' },
    { label: 'Termos de Uso', href: '/termos' },
    { label: 'Suporte', href: 'https://suporte.srmasset.com' },
    { label: 'Contato', href: 'mailto:contato@srmasset.com' },
  ]}
/>

// Links via onClick — navegação client-side (SPA), sem <a> real
import { useNavigate } from 'react-router-dom';

function AppFooterConnected() {
  const navigate = useNavigate();
  return (
    <AppFooter
      links={[
        { label: 'Política de Privacidade', onClick: () => navigate('/privacidade') },
        { label: 'Termos de Uso', onClick: () => navigate('/termos') },
        { label: 'Suporte', onClick: () => navigate('/suporte') },
        { label: 'Contato', onClick: () => navigate('/contato') },
      ]}
    />
  );
}

// href + onClick combinados: <a> real com efeito colateral adicional (ex.: telemetria)
<AppFooter
  links={[
    { label: 'Suporte', href: 'https://suporte.srmasset.com', onClick: () => track('footer_suporte_click') },
  ]}
/>

// Tema de marca (navy) — ex.: telas de login/onboarding
<AppFooter theme="brand" />

// Layout mobile (coluna empilhada)
<AppFooter device="mobile" theme="brand" />

// Menos de 4 links (o array pode ter menos; nunca renderiza mais de 4)
<AppFooter links={[{ label: 'Suporte', href: '/suporte' }]} />
```

---

## Acessibilidade

- O logo é `aria-hidden="true"` — puramente decorativo, não compete com o nome acessível
  do rodapé.
- Links com `href` são `<a>` reais (react-aria `Link`) — aparecem corretamente como link em
  leitores de tela e suportam abrir em nova aba (clique do meio, Ctrl+clique, menu de
  contexto). **Prefira `href` sempre que a rota tiver uma URL real**, mesmo que a navegação
  final seja interceptada por um roteador SPA.
- Links sem `href` são `Button` (`variant="link"`) do react-aria — recebem foco por teclado
  e disparam por Enter/Espaço, mas **não** são anunciados como link nem suportam abrir em
  nova aba. Use esse caminho apenas para ações sem URL associada.
- O elemento raiz é um `div` sem landmark `<footer>` semântico — se precisar de landmark
  `contentinfo` para leitores de tela, envolva `<AppFooter />` em um `<footer>` no seu app.
- Garanta contraste ao usar `theme="brand"`: copyright e divisores já são ajustados
  internamente (`white-a55`/`white-a15`) — não sobrescreva via CSS externo, pois não há
  `className` exposto para isso de forma segura.

## Armadilhas comuns

- Passar mais de 4 `links` esperando que todos apareçam — só os 4 primeiros são exibidos,
  sem erro nem aviso.
- Usar apenas `onClick` quando existe uma URL real — perde-se a semântica de link, "abrir em
  nova aba" e indexação por crawlers; prefira `href` (combinado com `onClick` se precisar de
  um efeito colateral) sempre que houver uma rota real.
- Esperar que o componente navegue por conta própria a partir de `href` sem um `<a>` real
  por trás (ex.: assumir `window.location`) — isso não existe mais; a navegação é sempre via
  `<a href>` nativo ou via `onClick` fornecido pelo consumidor.
- Usar `label` repetido em dois links diferentes — quebra a unicidade de `key` do React.
- Tentar customizar o tamanho do logo — não existe prop pública para isso.
- Esperar landmark `<footer>` automático — o componente renderiza um `div`; adicione o
  wrapper semântico você mesmo se for necessário.
