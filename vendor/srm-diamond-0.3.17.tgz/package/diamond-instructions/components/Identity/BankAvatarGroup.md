# BankAvatarGroup

Grupo compacto de ícones de bancos/instituições, empilhados com sobreposição (estilo
"pilha de avatares") ou espaçados lado a lado. Usado para representar múltiplas contas,
integrações ou instituições vinculadas a um cliente em pouco espaço horizontal, com
contador `+N` para os itens que excedem o limite visível. **Compõe [`BankAvatar`](./BankAvatar.md)
diretamente** — cada ícone visível é um `BankAvatar` renderizado internamente (com resolução
completa de aliases/BACEN/catálogo interno), envolto em `role="group"` com `aria-label`.

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/BankAvatarGroup/`
- **Export:** `import { BankAvatarGroup } from '@srm/diamond';`
- **Relacionados:** [BankAvatar](./BankAvatar.md) (ícone único de banco, usado internamente
  por este componente)

---

## Quando usar

- Exibir, em uma célula de tabela, card ou cabeçalho, **múltiplas instituições financeiras**
  vinculadas a um cliente/operação (ex.: contas cadastradas, bancos de origem de TED,
  instituições custodiantes).
- Resumir visualmente "N bancos conectados" com efeito de pilha (`overlap`) semelhante a
  grupos de avatares de usuário.
- Quando a lista pode ser longa e você quer limitar a quantidade de ícones exibidos,
  delegando o restante a um contador `+N`.

## Quando **não** usar

- Exibir **um único banco** → use [`BankAvatar`](./BankAvatar.md) diretamente.
- Grupo de avatares de **pessoas/usuários** → use o `Avatar`/`AvatarDropdown` (não este componente).
- Precisa que cada ícone individual seja anunciado por nome para leitores de tela — o grupo
  esconde os nomes individuais (ver "Acessibilidade"); nesse caso, renderize `BankAvatar`
  avulsos em vez do grupo.

---

## Interface

```ts
import type { ComponentPropsWithoutRef } from 'react';
import type { BankSize } from '../BankAvatar'; // 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

interface BankAvatarGroupProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  banks?: string[];       // default: [] — código BACEN, slug ou nome livre; resolvido por item via BankAvatar
  size?: BankSize;        // default: 'md'
  max?: number;           // default: 4 — quantidade máxima de ícones visíveis
  overlap?: boolean;      // default: true — pilha sobreposta (true) ou itens espaçados (false)
  'aria-label'?: string;  // default: 'Instituições financeiras'
  // Demais props: passthrough para a <div> raiz (className, style, data-*, ...)
}
```

### Notas de comportamento

- **`banks`** aceita os **mesmos formatos que `BankAvatar.bank`** — código BACEN, slug ou
  nome livre em pt-BR — porque cada item é renderizado como `<BankAvatar bank={bank} .../>`
  internamente, com resolução completa via `resolveBankSlug` e fallback de iniciais próprio
  do `BankAvatar`. **Não há mais um lookup direto/case-sensitive separado** (esse era o
  comportamento do sistema antigo, já removido — ver "Armadilhas comuns").
- **`max`** é clampado com `Math.max(0, max)` (negativos viram `0`, ou seja, nenhum ícone
  visível e todo o array vira o contador `+N`).
- **`remaining = banks.length - visible.length`** — o badge `+N` só é renderizado quando
  `remaining > 0`, com `aria-label={`${remaining} bancos adicionais`}`.
- `overlap=true` aplica `margin-left` negativo (sobreposição) + `box-shadow` como borda
  contra o fundo (`--surface-default`), criando o efeito de pilha; `overlap=false`
  aplica espaçamento positivo (`--space-1`) sem a borda de contorno.
- Cada `BankAvatar` interno é renderizado com `shape="circle"` fixo, no `size` recebido pelo
  grupo (não há `size` numérico customizado por item — apenas os tokens de `BankSize`).
- Tamanhos suportados (`BankSize`): `xs` (20px), `sm` (24px), `md` (32px), `lg` (40px),
  `xl` (48px), `2xl` (64px).

---

## Exemplos

```tsx
import { BankAvatarGroup } from '@srm/diamond';

// Básico — pilha sobreposta, máximo padrão (4)
<BankAvatarGroup banks={['itau', 'nubank', 'btg-pactual', 'c6', 'inter', 'santander']} />
// → renderiza itau, nubank, btg-pactual, c6 sobrepostos + badge "+2"

// Aceita código BACEN e nome livre misturados (resolvidos individualmente por BankAvatar)
<BankAvatarGroup banks={['237', 'Banco do Brasil', 'nubank']} />

// Tamanho menor, em uma linha de tabela
<BankAvatarGroup banks={['itau', 'nubank']} size="sm" />

// Sem sobreposição (itens espaçados, sem borda de contorno)
<BankAvatarGroup banks={['itau', 'nubank', 'c6']} overlap={false} />

// Limite customizado de ícones visíveis
<BankAvatarGroup banks={['itau', 'nubank', 'btg-pactual', 'c6', 'inter']} max={2} />
// → 2 ícones + badge "+3"

// aria-label customizado no grupo
<BankAvatarGroup banks={['itau', 'nubank']} aria-label="Bancos conectados" />

// Tamanho grande, destaque em card de resumo
<BankAvatarGroup banks={['itau', 'santander', 'caixa']} size="lg" overlap />
```

---

## Acessibilidade

- O container raiz tem `role="group"` e `aria-label` (default `"Instituições financeiras"`,
  sobrescrevível via prop `aria-label`) — leitores de tela anunciam o grupo como uma unidade.
- Cada `BankAvatar` interno mantém seu próprio `role="img"`/`aria-label` (nome do banco
  resolvido) — diferente do sistema antigo, os ícones individuais **são** anunciáveis, mas
  o grupo em si não lista os nomes no seu próprio `aria-label`.
- O badge `+N` tem `aria-label={`${remaining} bancos adicionais`}`, garantindo que a
  quantidade de itens ocultos seja anunciada mesmo sem detalhar quais.

## Armadilhas comuns

- **Não confundir com o comportamento antigo**: antes da consolidação, `BankAvatarGroup`
  usava um `BankIcon` interno com lookup direto/case-sensitive em `BANK_ICON_URLS` (sem
  aliases nem BACEN). Hoje ele **compõe `BankAvatar`** e resolve aliases/BACEN normalmente —
  não é mais necessário passar apenas o slug exato.
- Slug/nome sem correspondência no catálogo interno não gera erro — cada `BankAvatar` cai
  silenciosamente no seu próprio fallback de iniciais.
- `max` negativo não lança erro — apenas zera os ícones visíveis e joga todo o array
  para o contador `+N` (ex.: `banks.length` inteiro aparece como `+banks.length`).
- As `key`s internas usam `${bank}-${index}`; bancos duplicados na mesma lista são
  aceitos e renderizados normalmente (não há deduplicação automática).
- Não há `size` numérico por item (diferente de `BankAvatar` avulso) — apenas os tokens de
  `BankSize` são aceitos pelo grupo.
