# PageHeader

Cabeçalho padronizado para página, seção de conteúdo, painel, drawer e bottom sheet.
Compõe internamente [`Breadcrumb`](./Breadcrumb.md), [`Button`](../Forms/Button.md),
[`DoubleButton`](../Forms/DoubleButton.md), [`IconButton`](../Forms/IconButton.md) e
[`Icon`](../Icons/Icon.md) — não é construído sobre `react-aria-components` diretamente,
mas herda o comportamento de acessibilidade de cada sub-componente que utiliza. Título,
subtítulo e breadcrumb são strings/arrays simples; ações aceitam tanto uma lista
estruturada (`actions`) quanto um slot livre (`actionsSlot`). Tipografia e padding usam
variantes CVA (`PageHeader.variants.ts`).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/PageHeader/`
- **Export:** `import { PageHeader } from '@srm/diamond';` (também exporta os tipos
  `PageHeaderAction`, `PageHeaderProps`, `PageHeaderSize`, `PageHeaderAlign`)
- **Relacionados/Base:** [Breadcrumb](./Breadcrumb.md) (trilha), [Button](../Forms/Button.md)
  e [DoubleButton](../Forms/DoubleButton.md) (ações), [IconButton](../Forms/IconButton.md)
  (botão de fechar)

---

## Quando usar

- Topo de página (`size="lg"`, com `breadcrumb` e até 2 `actions`) — ex.: "Aprovações
  pendentes", "Posições abertas".
- Título de seção de conteúdo dentro de uma página (`size="lg"`, sem `actions`) — ex.:
  separar blocos de um relatório ou dashboard.
- Cabeçalho de painel ou drawer lateral (`size="md"`, com `onClose` para exibir o X).
- Cabeçalho de bottom sheet mobile, tanto no layout padrão à esquerda (`align="left"`)
  quanto no layout centralizado com ícone (`align="center"`) — ex.: confirmação de
  operação (TED, resgate, ordem).
- Ações que não se encaixam no par `label`/`variant`/`onClick` (ex.: menu, split button,
  botão com ícone) → use `actionsSlot` para renderizar qualquer `ReactNode` no lugar do
  render automático de `actions`.

## Quando **não** usar

- Menu de navegação lateral ou abas → use os componentes de `Sidebar`/`Tabs`, não `PageHeader`.
- Trilha de navegação **clicável** com links reais → use [`Breadcrumb`](./Breadcrumb.md)
  diretamente; o `breadcrumb` de `PageHeader` aceita apenas `string[]` (rótulos estáticos,
  sem `href`/`onClick`).
- Mais de 2 ações com hierarquia visual — o `PageHeader` degrada para uma fileira de
  `Button`s soltos (sem o agrupamento cuidadoso do `DoubleButton`); use `actionsSlot` se
  precisar de mais controle sobre o layout.
- Cabeçalho de card/tabela pequeno → prefira um título simples (`<h2>`/`<h3>`) sem o peso
  visual do `PageHeader`.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { IconProps } from '@srm/diamond'; // Icon.types

interface PageHeaderAction {
  label: string;
  variant?: 'primary' | 'secondary' | 'ghost' | 'link';
  onClick?: () => void;
}

type PageHeaderSize  = 'sm' | 'md' | 'lg';
type PageHeaderAlign = 'left' | 'center';

interface PageHeaderProps {
  breadcrumb?: string[];             // rótulos estáticos — SEM link/onClick
  title: string;                     // obrigatório
  subtitle?: string;
  actions?: PageHeaderAction[];      // default: [] — ignorado se actionsSlot for fornecido
  actionsSlot?: ReactNode;           // slot livre; quando presente, sobrescreve o render de `actions`
  onClose?: () => void;              // presença = exibe o X
  closeAriaLabel?: string;           // default: 'Fechar' — rótulo acessível do X
  size?: PageHeaderSize;             // default: 'lg'
  showDivider?: boolean;             // default: true
  align?: PageHeaderAlign;           // default: 'left'
  icon?: IconProps;                  // só tem efeito quando align="center"
  fullWidthDivider?: boolean;        // default: false
}
```

### Comportamentos não-óbvios

- **`align="center"` muda tudo.** Nesse modo o componente ignora `breadcrumb`,
  `actions`/`actionsSlot` **e `showDivider`** — nunca renderiza divider (é o container
  externo, ex. `BottomSheet`, quem decide a borda). Só renderiza: X de fechar (via
  `IconButton`, canto superior — quando `onClose` é passado), `icon` (via `Icon`), `title`
  e `subtitle`, todos centralizados. Esse layout é o único caso em que a prop `icon` tem
  efeito — em `align="left"` ela é simplesmente ignorada (não existe no JSX desse ramo).
- **`actionsSlot` tem prioridade absoluta sobre `actions`.** A checagem é
  `actionsSlot !== undefined ? actionsSlot : ...` — se você passar `actionsSlot` (mesmo um
  elemento vazio), o array `actions` é completamente ignorado para fins de render (ainda é
  aceito pelo tipo, mas não produz nenhum `Button`/`DoubleButton`).
- **Lógica de `actions` em `align="left"` (quando `actionsSlot` não é fornecido):**
  - **Exatamente 2 ações** → renderiza um único [`DoubleButton`](../Forms/DoubleButton.md)
    em vez de dois `Button`s soltos. `secondaryLabel`/`onSecondary` vêm de `actions[0]` e
    `primaryLabel`/`onPrimary` de `actions[1]`. O `pair` é decidido **só** pela variante do
    **segundo** item: `actions[1]?.variant === 'secondary'` → `pair="primary-secondary"`,
    caso contrário → `pair="primary-ghost"`. A variante de `actions[0]` é **ignorada**
    nesse caminho (o `DoubleButton` já define o par de estilos); só o `onClick` de cada
    item é preservado.
  - **0, 1 ou 3+ ações** → cada item vira um `Button` isolado, com `onPress={() =>
    a.onClick?.()}`. Se `variant` não for informado, o **último** item (índice
    `actions.length - 1`) recebe `variant="primary"` e todos os demais recebem
    `variant="ghost"`. Todos os botões usam `size="md"` fixo (não segue o `size` do
    `PageHeader`).
  - O X de `onClose` sempre aparece **depois** das ações/`actionsSlot`, dentro da mesma
    `actionsRow`. A `actionsRow` só é renderizada quando há `actionsSlot`, `actions.length
    > 0` **ou** `onClose`.
- **Divider (`showDivider`)**: só é desenhado quando `align === 'left'` **e**
  `showDivider === true` (comparação estrita — `undefined` não conta como `true`, mas o
  default do parâmetro já resolve isso para `true`). Em `align="center"` nunca há divider.
- **`fullWidthDivider`**: adiciona padding horizontal interno ao container do
  título/ações (`styles.innerPadded`). Usado quando o `PageHeader` fica dentro de um
  `BottomSheet`/drawer que não tem padding próprio — o header "puxa" seu próprio respiro
  lateral em vez de depender do container pai.
- **`breadcrumb`**: cada string é convertida internamente em `{ label }` para o
  [`Breadcrumb`](./Breadcrumb.md) — **sem** `href` nem `onClick`. Ou seja, dentro do
  `PageHeader` a trilha é sempre **estática/visual**, mesmo que o `Breadcrumb`
  isoladamente suporte itens clicáveis.
- **`size`** controla apenas tipografia do título/subtítulo (via `titleVariants`/
  `subtitleVariants`) e padding do container (`innerVariants`, ambos em
  `PageHeader.variants.ts`, CVA) — não afeta o tamanho dos botões de ação (sempre `md`)
  nem do `IconButton` de fechar (sempre `md`).
- **`closeAriaLabel`** (default `'Fechar'`) é aplicado ao `aria-label` do `IconButton` de
  fechar em **ambos** os layouts (`align="left"` e `align="center"`) — diferente de
  versões anteriores, não é mais um texto fixo não-customizável.
- O X de fechar usa `<Icon icon="x" circle={false} size={18} />` dentro de um `IconButton`
  `variant="ghost" size="md"` com `onPress={onClose}`.

---

## Exemplos

```tsx
import { PageHeader } from '@srm/diamond';

// Página — breadcrumb + 2 ações (renderiza DoubleButton internamente)
<PageHeader
  breadcrumb={['Início', 'Aprovações']}
  title="Aprovações pendentes"
  subtitle="12 operações aguardando sua autorização"
  size="lg"
  actions={[
    { label: 'Exportar', variant: 'ghost', onClick: handleExport },
    { label: 'Confirmar', variant: 'primary', onClick: handleConfirm },
  ]}
/>

// Seção de conteúdo — sem divider, sem ações
<PageHeader
  title="Posições abertas"
  subtitle="Atualizado em 30/06/2026"
  size="lg"
  showDivider={false}
/>

// Painel/drawer — size md, sem X
<PageHeader
  title="Filtros"
  subtitle="Ajuste os parâmetros do relatório"
  size="md"
/>

// Drawer com botão de fechar e rótulo acessível customizado
<PageHeader
  title="Detalhes da operação"
  subtitle="TED · 30/06/2026"
  size="md"
  onClose={() => setOpen(false)}
  closeAriaLabel="Fechar detalhes da operação"
/>

// Ação única (vira Button "primary" sozinho, sem DoubleButton)
<PageHeader
  title="Confirmar cadastro"
  actions={[{ label: 'Concluir', onClick: handleConcluir }]}
/>

// actionsSlot — layout de ação livre, ignora `actions`
<PageHeader
  title="Notificações"
  actionsSlot={<IconButton icon={<Icon icon="filter" />} aria-label="Filtrar" onPress={openFilters} />}
/>

// Bottom sheet — layout esquerdo, dentro de container sem padding próprio
<PageHeader
  title="Confirmar operação"
  subtitle="Confirme antes de prosseguir com esta operação."
  size="md"
  onClose={() => setOpen(false)}
  fullWidthDivider={true}
/>

// Bottom sheet — layout centralizado com ícone (nunca tem divider nem actions)
<PageHeader
  title="Confirmar operação"
  subtitle="Confirme antes de prosseguir com esta operação."
  align="center"
  onClose={() => setOpen(false)}
  icon={{ type: 'info', size: 'md' }}
/>
```

`PageHeader` não é um campo de formulário — não há integração com React Hook Form
aplicável.

---

## Acessibilidade

- O título é sempre renderizado como `<h1>` — se o `PageHeader` aparecer mais de uma vez
  na árvore (ex.: dentro de um drawer sobre uma página que já tem seu próprio `<h1>`),
  avalie a hierarquia de headings da página para não duplicar o nível `1`.
- O botão de fechar aceita `closeAriaLabel` — sempre passe um rótulo descritivo quando o
  `onClose` fizer algo mais específico do que "fechar a tela atual" (ex.: "Fechar filtros",
  "Cancelar confirmação de TED").
- `actions` sem `variant` explícita seguem a regra automática (último = `primary`, demais
  = `ghost`) — isso preserva contraste e hierarquia visual mesmo sem configuração manual,
  mas o `label` continua sendo sua responsabilidade tornar claro e descritivo para
  leitores de tela.
- Ao usar `actionsSlot`, a acessibilidade do conteúdo passado (foco, rótulos, roles) é
  100% responsabilidade de quem monta o slot — o `PageHeader` não adiciona nenhuma
  semântica extra ao redor dele.
- O `icon` em `align="center"` é passado para `Icon`, que trata sua própria semântica
  (decorativo vs. semântico); não é possível adicionar `aria-label` ao ícone através do
  `PageHeader`.

## Armadilhas comuns

- Passar `icon` esperando vê-lo em `align="left"` (padrão) — a prop **só** tem efeito em
  `align="center"`; no layout padrão ela é silenciosamente ignorada.
- Esperar que `breadcrumb` seja clicável — são apenas rótulos (`string[]`); para
  navegação real, use [`Breadcrumb`](./Breadcrumb.md) fora do `PageHeader`.
- Passar `actions` **e** `actionsSlot` ao mesmo tempo esperando algum tipo de combinação —
  `actionsSlot`, quando definido, sobrescreve `actions` por completo (não são somados).
- Passar exatamente 2 `actions` esperando dois `Button`s independentes — o componente
  substitui por um [`DoubleButton`](../Forms/DoubleButton.md), e a variante do
  **primeiro** item é ignorada (só a do segundo decide o `pair`). Se precisar de duas
  ações com variantes livres, use 1 ou 3+ itens, ou `actionsSlot`.
- Esquecer `onClick` em `PageHeaderAction` — sem ele, o `Button`/`DoubleButton` gerado é
  clicável mas não dispara nenhuma ação (o `onPress` interno chama `a.onClick?.()`, que é
  um no-op se `onClick` não existir).
- Passar `showDivider={true}` junto de `align="center"` esperando ver a borda — o modo
  centralizado nunca renderiza divider, independentemente dessa prop.
- Esquecer `fullWidthDivider` ao usar `PageHeader` dentro de um container sem padding
  próprio (bottom sheet, drawer "cru") — o título e as ações ficam colados na borda.
