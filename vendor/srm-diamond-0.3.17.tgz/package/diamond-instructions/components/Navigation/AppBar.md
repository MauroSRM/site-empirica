# AppBar

Barra de cabeçalho de página/seção secundária — fica **dentro** do conteúdo, abaixo do
header global da aplicação (`AppHeader`). Mostra título, subtítulo opcional, botão de
voltar e um slot de ações à direita. Adapta o layout entre `desktop` (título alinhado à
esquerda) e `mobile` (título centralizado sobre a barra). Construído com HTML semântico
(`<header>`) + CSS Modules (`AppBar.module.scss`) — sem dependência de react-aria ou
outra lib de headless UI para o próprio `AppBar` (o botão de voltar reaproveita
`IconButton`). O barril do módulo também exporta `AppBarFilter`, um componente de filtros
pensado para o slot `actions`, documentado na segunda parte deste arquivo.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/AppBar/`
- **Export:** `import { AppBar, AppBarFilter } from '@srm/diamond';`
- **Relacionados/Base:** usa internamente [`IconButton`](../Forms/IconButton.md) (botão de
  voltar). `AppBarFilter` usa internamente `Chip`, `IconButton`, `BottomSheet` e
  `@floating-ui/react` — ver seção dedicada abaixo.

---

## Quando usar

- Cabeçalho de uma tela/seção de conteúdo que precisa de título, e opcionalmente
  subtítulo, navegação de retorno e ações (ex.: "Extrato consolidado", "Meus fundos",
  "Configurações da conta").
- Telas que precisam alternar entre layout desktop e mobile (ex.: uma mesma tela
  renderizada dentro de um app shell responsivo ou de uma visualização tipo "moldura de
  celular").
- Quando a ação de voltar deve levar o usuário à tela/rota anterior dentro do fluxo
  (extratos, detalhes de operação, telas de configuração aninhadas).
- Como container para um slot de ações à direita — botões, um `Select`, ou o
  `AppBarFilter` (documentado abaixo, já pronto para uso via `@srm/diamond`).

## Quando **não** usar

- Header global fixo do topo da aplicação (logo, marca, navegação principal) →
  isso é papel do `AppHeader`, não do `AppBar`.
- Apenas para agrupar título de card/seção sem contexto de página → use um `<h2>`/`<h3>`
  semântico direto no card.
- Navegação por abas dentro do conteúdo → componente de Tabs (fora do escopo deste doc).

---

## Interface

```ts
import type { ReactNode } from 'react';

type AppBarTheme = 'light' | 'brand';
type AppBarDevice = 'desktop' | 'mobile';

interface AppBarProps {
  title?: string;                // default de parâmetro: 'Título da página'
  subtitle?: string;             // ignorado quando device === 'mobile'
  showBack?: boolean;            // default: false
  backLabel?: string;            // default: 'Voltar' — usado como aria-label do botão de voltar
  onBack?: () => void;           // se ausente, o botão de voltar é renderizado SEM onClick
  actions?: ReactNode;           // slot direito — Select, Button, AppBarFilter, ou qualquer nó
  theme?: AppBarTheme;           // default: 'light'
  device?: AppBarDevice;         // default: 'desktop'
}
```

### Notas de comportamento

- `title` ausente **não** deixa o cabeçalho vazio: cai no valor default do parâmetro,
  `'Título da página'` — trate isso como um placeholder de desenvolvimento, não como copy
  de produção. Sempre passe `title` real.
- `subtitle` só é renderizado em `device="desktop"`. Em `device="mobile"` o layout usa
  `titleMobile` (centralizado, `position: absolute`) e o subtítulo é descartado — não
  espere vê-lo no mobile mesmo que a prop esteja setada.
- `theme="brand"` ativa o fundo navy (`--brand-primary`) e ajusta automaticamente o tema
  do botão de voltar para `dark` (`isDark ? 'dark' : 'default'` repassado ao `IconButton`).
  Não é necessário (nem possível) configurar o tema do botão de voltar separadamente.
- `showBack={true}` **sem** `onBack` renderiza o botão de voltar visualmente, mas **sem**
  handler de clique — o spread condicional (`{...(onBack !== undefined ? { onClick: onBack } : {})}`)
  omite `onClick` inteiramente nesse caso. É uma armadilha comum (ver seção abaixo).
- Em `device="mobile"`, um elemento `.spacer` (`flex: 1`) é inserido entre o botão de
  voltar e o slot de `actions`, empurrando as ações para a extremidade direita enquanto
  o título fica absolutamente centralizado por cima de toda a barra.
- O elemento raiz é um `<header>` com `data-mobile` presente apenas quando
  `device === 'mobile'` (usado só para hooks de CSS, não é uma prop pública).
- `AppBar` não tem `className` nem `ref` na sua assinatura — não é possível estilizar o
  wrapper de fora nem obter uma referência ao DOM.

---

## Exemplos

```tsx
import { AppBar } from '@srm/diamond';

// Básico — apenas título
<AppBar title="Extrato consolidado" />

// Com subtítulo (só aparece no desktop)
<AppBar
  title="Extrato consolidado"
  subtitle="Movimentação de todas as contas"
/>

// Com botão de voltar funcional
<AppBar
  title="Detalhe da operação"
  showBack
  onBack={() => navigate(-1)}
/>

// Com ações à direita (ex.: botão de exportar)
import { Button } from '@srm/diamond';

<AppBar
  title="Meus fundos"
  actions={<Button size="sm" variant="secondary">Exportar</Button>}
/>

// Tema brand (fundo navy) — botão de voltar já herda tema dark automaticamente
<AppBar
  title="Configurações da conta"
  theme="brand"
  showBack
  onBack={handleBack}
/>

// Layout mobile — título centralizado, subtítulo ignorado
<AppBar
  title="Extrato"
  subtitle="Não aparece no mobile"
  device="mobile"
  showBack
  onBack={handleBack}
  actions={<Button size="sm" icon="only" iconEl={<MoreIcon />} aria-label="Mais opções" />}
/>
```

---

## Acessibilidade

- O botão de voltar é um `IconButton` só-ícone; seu nome acessível vem de `backLabel`
  (default `'Voltar'`) — se você customizar o texto, mantenha-o descritivo ("Voltar para
  extrato", por exemplo, em contextos aninhados).
- `showBack` sem `onBack` produz um botão focável e anunciado por leitor de tela que
  **não faz nada** ao ser ativado — isso é uma falha de acessibilidade funcional, não
  apenas um detalhe de UX. Sempre forneça `onBack` quando `showBack` for `true`.
- O título é renderizado como `<p>`, não como heading (`<h1>`/`<h2>`) — se a página
  precisar de uma hierarquia de headings navegável por leitor de tela, complemente com
  seu próprio heading semântico fora ou dentro do `title`/estrutura da página.
- Conteúdo passado em `actions` é responsabilidade do consumidor quanto a
  rótulos/`aria-*` (ex.: um `IconButton` só-ícone dentro de `actions` **precisa** de
  `aria-label` próprio).

## Armadilhas comuns

- Esquecer `onBack` ao usar `showBack` — o botão aparece mas não navega (ver nota acima).
- Esperar que `subtitle` apareça no mobile — ele é descartado nesse `device`, não apenas
  escondido via CSS; não há hack de layout para forçar sua exibição.
- Confundir `AppBar` com o header global fixo da aplicação — este componente é para
  cabeçalhos de página/seção dentro do conteúdo.
- Depender do texto default `'Título da página'` em produção — sempre passe `title`.

---

## `AppBarFilter`

Componente de filtros por chips, pensado para ser usado dentro do slot `actions` do
`AppBar` — é exatamente assim que aparece no Storybook (`AppBar.stories.tsx`): filtros em
chips no desktop (dropdown via `floating-ui`) e em `BottomSheet` no mobile, com badge de
contagem de filtros ativos.

Hoje **é exportado publicamente** pelo barril do módulo (`AppBar/index.ts` →
`export { AppBarFilter } from './AppBarFilter';` → re-exportado por `src/components/index.ts`),
ou seja `import { AppBarFilter } from '@srm/diamond'` funciona.

### Interface

```ts
interface AppBarFilterProps {
  label?:      string;                          // default: 'Filtros' — aria-label do gatilho e do painel
  options:     string[];                         // opções de filtro exibidas como Chip; default interno: []
  value?:      string[];                         // seleção controlada — presença ativa modo controlado
  onChange?:   (selected: string[]) => void;     // disparado a cada toggle de chip, com a seleção acumulada
  theme?:      AppBarTheme;                      // default: 'light'
  device?:     AppBarDevice;                     // default: 'desktop'
  container?:  HTMLElement | null;               // portal target do BottomSheet no mobile
}
```

### Notas de comportamento

- **Controlado vs. não controlado.** `isControlled = value !== undefined`. Sem `value`, o
  componente mantém sua própria seleção em estado interno (`internal`); com `value`, a
  seleção exibida é sempre a prop — alternar um chip chama `onChange` com a nova seleção,
  mas **não** atualiza estado interno (cabe ao consumidor re-passar o novo `value`).
- **Badge de contagem.** Um badge numérico aparece sobre o botão de gatilho sempre que
  `selected.length > 0` — não há prop para ocultá-lo isoladamente.
- **Desktop:** o gatilho é um `IconButton` (`aria-haspopup="true"`, `aria-expanded`) que
  abre um painel flutuante (`floating-ui`, `placement: 'bottom-end'`, `offset(8)`, `flip()`,
  `shift({ padding: 8 })`) com **`role="group"`** e `aria-label={label}` — **não** é um
  `listbox`/`menu`. Fecha com `Escape` e clique fora (`useDismiss`, habilitado apenas fora
  do mobile).
- **Mobile (`device="mobile"`):** o gatilho tem `aria-haspopup="dialog"` e abre um
  `BottomSheet` (`maxHeight="60vh"`) com cabeçalho próprio — título (`label`) e um botão de
  fechar com texto fixo **"Fechar filtros"** (não configurável via prop). Os chips usam
  tamanho `lg` no mobile e `sm` no desktop.
- Cada opção é renderizada como um `Chip` (`iconType="filter"`), com `key` igual à própria
  string de `option` — evite valores duplicados em `options`.
- `container` só tem efeito no mobile; é repassado ao `BottomSheet` como destino do portal.

### Exemplo

```tsx
import { useState } from 'react';
import { AppBar, AppBarFilter } from '@srm/diamond';

function ExtratoHeader() {
  const [filters, setFilters] = useState<string[]>([]);

  return (
    <AppBar
      title="Extrato consolidado"
      actions={
        <AppBarFilter
          label="Filtros"
          options={['Renda Fixa', 'Renda Variável', 'PIX', 'TED']}
          value={filters}
          onChange={setFilters}
        />
      }
    />
  );
}

// Variante mobile — abre BottomSheet em vez de dropdown flutuante
<AppBarFilter
  device="mobile"
  options={['Renda Fixa', 'PIX']}
  onChange={(selected) => console.log(selected)}
/>
```

### Armadilhas comuns (`AppBarFilter`)

- Passar `value` sem `onChange` — a seleção fica visualmente travada (chips não alternam
  de estado ao clicar, pois o componente não atualiza estado interno em modo controlado).
- Esperar semântica de `listbox`/`menu` no painel desktop para testes com Testing Library —
  o `role` correto para consulta é `group`, não `listbox`.
- Tentar customizar o texto do botão de fechar do `BottomSheet` mobile — é fixo
  ("Fechar filtros"), não há prop para isso.
- Duplicar valores em `options` — quebra a unicidade de `key` do React nos chips.
