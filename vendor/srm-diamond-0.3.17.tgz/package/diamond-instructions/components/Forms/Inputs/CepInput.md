# CepInput

Campo de entrada para CEP (Código de Endereçamento Postal) brasileiro. Aplica máscara
fixa `00000-000` enquanto o usuário digita. Construído sobre `InputBase` (herda label,
estados, temas e mensagens) e sobre a ponte de máscara `IMaskBridge` (imask/react-imask).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/CepInput/`
- **Export:** `import { CepInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [CpfInput](./CpfInput.md),
  [CnpjInput](./CnpjInput.md), [PhoneInput](./PhoneInput.md), [TextInput](./TextInput.md)

---

## Quando usar

- Captura de endereço em cadastros de cliente, formulários KYC, endereço de correspondência,
  dados cadastrais de contraparte/beneficiário.
- Sempre que o valor precise ser exibido com a formatação `00000-000` enquanto o usuário digita.
- Em conjunto com uma busca de endereço (ex.: consulta a serviço de CEP para autopreencher
  logradouro/cidade/UF) — o componente só cuida da máscara e exibição, a consulta é responsabilidade
  do consumidor no `onChange`.

## Quando **não** usar

- Outros documentos numéricos com máscara própria → use [`CpfInput`](./CpfInput.md) ou
  [`CnpjInput`](./CnpjInput.md).
- Telefone → use [`PhoneInput`](./PhoneInput.md).
- Texto livre sem máscara (logradouro, complemento, bairro) → use [`TextInput`](./TextInput.md).

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface CepInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string, com ou sem máscara)
  placeholder?: string;                    // default: '00000-000'
  onChange?: (value: string) => void;      // recebe a string aceita pela máscara
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por imask com estas opções fixas (`CepInput.constants.ts`):

```ts
{ mask: '00000-000' }
```

- A ponte `IMaskBridge` usa `unmask={true}` internamente. Isso significa que `onChange`
  (via `onAccept` do imask) entrega o valor **sem máscara** — só os dígitos, sem o hífen
  (ex.: digitar `01310100` no campo, que é exibido como `01310-100`, dispara
  `onChange("01310100")`).
- O prop `value` é aplicado como valor **desmascarado** (`mask.unmaskedValue = value`), então
  o fluxo controlado natural é `value` em dígitos (`"01310100"`) ↔ `onChange` também em dígitos.
  Na prática o parser do imask tolera receber o valor já com o hífen (`"01310-100"`) e ainda
  assim exibe/computa corretamente — mas **não conte com isso**: mantenha `value`/`onChange`
  sempre em dígitos para round-trip previsível.
- Passar `value=""` limpa o campo de forma controlada (comportamento coberto por teste:
  o componente reflete corretamente a transição de um valor preenchido para vazio).
- Não há validação de CEP embutida (não verifica se o CEP existe/é válido) — isso é
  responsabilidade do formulário (ex.: Zod + consulta a serviço de CEP).

---

## Exemplos

```tsx
import { useState } from 'react';
import { CepInput } from '@srm/diamond';

// Básico (controlado)
function EnderecoField() {
  const [cep, setCep] = useState('');
  return <CepInput label="CEP" value={cep} onChange={setCep} />;
}

// Com ajuda e obrigatório
<CepInput label="CEP" required helperText="Digite apenas os 8 dígitos do CEP." />

// Estado de erro
<CepInput label="CEP" state="error" errorText="CEP inválido." value={cep} onChange={setCep} />

// Somente leitura
<CepInput label="CEP" state="read-only" value="01310100" />

// Desabilitado
<CepInput label="CEP" state="disabled" />

// Tema escuro (sobre header brand)
<CepInput label="CEP" theme="dark" value={cep} onChange={setCep} />

// Autopreenchendo endereço a partir do CEP
function EnderecoComBusca() {
  const [cep, setCep] = useState('');

  const handleChange = async (valor: string) => {
    setCep(valor);
    const digitos = valor.replace(/\D/g, '');
    if (digitos.length === 8) {
      // dispare aqui a consulta ao serviço de CEP e preencha os demais campos
    }
  };

  return <CepInput label="CEP" value={cep} onChange={handleChange} />;
}
```

### Integração com React Hook Form

```tsx
<Controller
  name="cep"
  control={control}
  render={({ field, fieldState }) => (
    <CepInput
      label="CEP"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Use `inputMode="numeric"` (herdado via `InputBaseProps`/`TextFieldProps`) em contextos onde
  vale reforçar o teclado numérico em dispositivos móveis, embora a máscara já restrinja a
  entrada a dígitos.

## Armadilhas comuns

- **Não** espere o hífen em `onChange` — diferente do que a formatação visual sugere, o
  `onChange` entrega apenas os dígitos (`"01310100"`), porque a ponte interna usa
  `unmask={true}`. Se você precisa exibir o CEP formatado em outro lugar (fora do input),
  formate você mesmo, ex.: `valor.replace(/(\d{5})(\d{3})/, '$1-$2')`.
- **Não** passe `value` já formatado como o texto exibido na tela partindo de outro
  `CepInput`/estado que armazene a string mascarada por engano — prefira sempre manter o
  estado controlado em dígitos, espelhando o formato que o próprio `onChange` devolve.
- **Não** valide o CEP (existência/formato completo, 8 dígitos) dentro do componente — ele só
  aplica a máscara de digitação, não a validação semântica; valide no schema do formulário.
- Ao popular `value` a partir de dados vindos de API (geralmente só dígitos), não é necessário
  formatar antes — o componente aceita `"01310100"` e exibe `"01310-100"` corretamente.
