# OTPInput

Campo de código de verificação (OTP / one-time password) dividido em células, uma por
dígito, com avanço/retrocesso automático de foco, contador de reenvio e mensagens de
sucesso/erro. **Não** é construído sobre `InputBase`/`TextField` do react-aria — usa
`<input>` nativos controlados manualmente (`useState` + refs), reaproveitando apenas os
tipos `InputState`/`InputTheme` da base compartilhada para consistência visual. O botão de
reenvio usa o `Button` (`variant="link"`) do próprio Diamond.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/OTPInput/`
- **Export:** `import { OTPInput } from '@srm/diamond';`
- **Relacionados:** [_shared (InputBase)](./_shared.md) — apenas empresta os tipos de estado/tema;
  para texto livre use [TextInput](./TextInput.md)

---

## Quando usar

- Confirmação de login/transação por código enviado via SMS, e-mail ou app autenticador
  (2FA/MFA) — cenário comum em fluxos financeiros da SRM (aprovação de transferência,
  troca de senha, liberação de operação de alto valor).
- Qualquer código numérico curto e de comprimento fixo que o usuário deva digitar
  dígito a dígito, com preenchimento automático de `autoComplete="one-time-code"` no
  primeiro campo (suporta autofill de SMS em navegadores compatíveis).

## Quando **não** usar

- Texto livre ou códigos alfanuméricos de comprimento variável → use [`TextInput`](./TextInput.md).
- Valores monetários ou percentuais → [`CurrencyInput`](./CurrencyInput.md) / [`PercentInput`](./PercentInput.md).
- Se precisar de todas as props de acessibilidade/estado do `TextField` do react-aria
  (name, id, form, etc. em um único campo) — `OTPInput` **não** repassa essas props;
  ele não estende `InputBaseProps`.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { InputState, InputTheme } from '@srm/diamond'; // tipos reaproveitados da base

interface OTPInputProps {
  state?: InputState;              // 'default' | 'error' | 'disabled' | 'read-only' — default: 'default'
  theme?: InputTheme;              // 'default' | 'dark' — default: 'default'
  label?: ReactNode;                // rótulo centralizado acima das células
  length?: number;                  // default: 6 — quantidade de células/dígitos
  masked?: boolean;                 // default: false — quando true, cada célula usa type="password"
  errorText?: ReactNode;            // mensagem de erro; força visual de erro mesmo sem state="error"
  helperText?: ReactNode;           // texto de ajuda (só aparece se não houver erro nem sentMessage)
  sentMessage?: ReactNode;          // mensagem de sucesso (ex.: "Código enviado para ***-1234")
  onChange?: (code: string) => void;    // chamado a cada dígito digitado, com o código parcial/completo
  onComplete?: (code: string) => void;  // chamado quando TODAS as células estão preenchidas
  onResend?: () => void;            // habilita a UI de reenvio (mensagem de contagem ou botão "link")
  resendSeconds?: number;           // se definido, inicia countdown (mm:ss) antes de liberar o reenvio
  resendLabel?: string;             // default: 'Reenviar código' — label do botão quando o countdown zera
}
```

> `OTPInput` **não estende `InputBaseProps`**. Ele não é um `TextField` do
> react-aria — não há passthrough de `name`, `id`, `onBlur`, `onFocus`, `aria-*` de
> nível de componente. Cada célula individual já recebe internamente
> `aria-label="Dígito N de length"`, `inputMode="numeric"` e `maxLength={1}`.

### Comportamentos não óbvios

- **Estado interno controla tudo**: não há prop `value`/`defaultValue` — o componente é
  **não controlado externamente**; a única forma de ler o código é via `onChange` (parcial)
  ou `onComplete` (completo, todos os dígitos preenchidos e não vazios).
- **Avanço de foco automático**: ao digitar um dígito válido em uma célula que não é a
  última, o foco pula para a próxima (`refs.current[i + 1]?.focus()`).
- **Retrocesso com Backspace**: `Backspace` em uma célula vazia move o foco para a célula
  anterior (não apaga a anterior automaticamente).
- **Sanitização de entrada**: cada `onChange` de célula roda `v.replace(/\D/g, '').slice(-1)`
  — apenas o último caractere numérico digitado é aceito; colar texto não numérico é
  filtrado, mas colar uma string multi-dígito **não distribui automaticamente** entre as
  células (só o último dígito da própria célula é aproveitado).
- **`masked`**: alterna `type` do `<input>` de `'text'` para `'password'` em todas as
  células — útil quando o código não deve ficar visível na tela (ex.: PIN local).
- **Prioridade de mensagens**: erro > `sentMessage` > `helperText` — só uma é exibida por vez.
  `isError` é `true` se `state === 'error'` **ou** se `errorText` estiver presente.
- **UI de reenvio condicional**: só renderiza a seção de reenvio se `onResend` estiver
  definido **ou** `resendSeconds != null`. Enquanto `remaining > 0`, mostra texto com
  contagem regressiva (`formatCountdown`, formato `m:ss`); ao chegar a zero, mostra o
  `Button` (`variant="link"`) com `resendLabel`.
- **`handleResend`**: limpa todas as células, reinicia o contador (se `resendSeconds`
  estiver definido) e devolve o foco à primeira célula, além de chamar `onResend`.
- `state="disabled"` e `state="read-only"` desabilitam também o clique/foco de reenvio.

---

## Exemplos

```tsx
import { useState } from 'react';
import { OTPInput } from '@srm/diamond';

// Básico
function VerificacaoLogin() {
  const [erro, setErro] = useState<string>();

  return (
    <OTPInput
      label="Digite o código enviado por SMS"
      length={6}
      errorText={erro}
      onComplete={async (code) => {
        const valido = await validarCodigo(code);
        setErro(valido ? undefined : 'Código inválido ou expirado.');
      }}
    />
  );
}

// Com mensagem de envio (sucesso) e helperText
<OTPInput
  label="Confirme a transferência"
  sentMessage="Código enviado para ***-1234."
  onComplete={(code) => confirmarTransferencia(code)}
/>

// Com contador de reenvio (60s)
<OTPInput
  label="Código de autenticação"
  resendSeconds={60}
  onResend={() => reenviarCodigo()}
  onComplete={(code) => validar(code)}
/>

// Reenvio imediato (sem countdown) — botão "link" direto
<OTPInput
  label="Digite o código"
  onResend={() => reenviarCodigo()}
  resendLabel="Reenviar código"
/>

// Mascarado (PIN local, não exibe os dígitos)
<OTPInput label="PIN de aprovação" length={4} masked />

// Estado de erro explícito
<OTPInput label="Código" state="error" errorText="Código inválido." />

// Desabilitado / somente leitura
<OTPInput label="Código" state="disabled" />
<OTPInput label="Código" state="read-only" />

// Tema escuro (sobre header brand)
<OTPInput label="Código de acesso" theme="dark" onComplete={(code) => validar(code)} />
```

### Integração com React Hook Form

`OTPInput` não é controlado por `value`, então a integração se dá via `onComplete`
atualizando o form (não via `Controller` clássico com `field.value`):

```tsx
import { useForm } from 'react-hook-form';
import { OTPInput } from '@srm/diamond';

function FormularioMFA() {
  const { setValue, setError, formState: { errors }, handleSubmit } = useForm<{ code: string }>();

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <OTPInput
        label="Código de verificação"
        length={6}
        errorText={errors.code?.message}
        onComplete={async (code) => {
          setValue('code', code, { shouldValidate: true });
          const ok = await validarCodigo(code);
          if (!ok) setError('code', { message: 'Código incorreto.' });
        }}
      />
    </form>
  );
}
```

---

## Acessibilidade

- Cada célula recebe `aria-label="Dígito N de length"` automaticamente — não é
  necessário (nem possível) customizar isso via props.
- `aria-invalid` é aplicado em cada célula quando em estado de erro.
- `autoComplete="one-time-code"` é aplicado **apenas na primeira célula**, permitindo que
  navegadores/SO preencham o código inteiro via SMS autofill nesse campo — o restante
  usa `autoComplete="off"`.
- O `label` do componente é um `<label>` visual centralizado, mas **não** está associado
  via `htmlFor`/`id` a nenhum input específico (são várias células) — funciona como
  título do grupo, não como rótulo formal de campo único. Garanta que o texto ao redor
  (heading da tela, `sentMessage`) deixe claro o propósito do código para leitores de tela.
- Mensagens de erro (`errorText`) e sucesso (`sentMessage`) são parágrafos simples, sem
  `role="alert"` — se precisar de anúncio imediato por leitor de tela, envolva o campo em
  uma região com `aria-live` no nível da tela/formulário.

## Armadilhas comuns

- **Não** existe prop `value`/`defaultValue` — não tente controlar o código de fora; leia
  o valor via `onChange`/`onComplete` e trate erros via `errorText`.
- Colar (`Ctrl+V`) um código completo **não distribui os dígitos** entre as células —
  apenas o último caractere da célula focada é aproveitado. Se o produto exigir colar o
  código inteiro de uma vez, isso não é suportado pela implementação atual.
- `onChange` é chamado a cada tecla, mesmo com o código incompleto (string com posições
  vazias) — só confie em `onComplete` para validar o código completo.
- Ao trocar `length` dinamicamente depois da montagem, o estado interno de células **não
  é resincronizado automaticamente** de forma reativa a mudanças externas — trate `length`
  como estático para uma instância do componente.
- `state="disabled"`/`"read-only"` desabilita também o botão de reenvio — não é preciso
  controlar isso separadamente.
