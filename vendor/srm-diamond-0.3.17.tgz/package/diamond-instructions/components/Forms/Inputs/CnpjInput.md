# CnpjInput

Campo de entrada para CNPJ. Aplica máscara posicional `NN.NNN.NNN/NNNN-00`, aceitando
letras **e** dígitos nos 8 primeiros blocos (formato alfanumérico do CNPJ da Receita
Federal) e mantendo os 2 dígitos verificadores finais sempre numéricos. Letras digitadas
são convertidas para maiúsculas automaticamente. Construído sobre `InputBase` (herda
label, estados, temas e mensagens) e sobre a ponte de máscara `IMaskBridge` (react-imask).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/CnpjInput/`
- **Export:** `import { CnpjInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [CpfInput](./CpfInput.md), [TextInput](./TextInput.md)

---

## Quando usar

- Cadastro/consulta de pessoa jurídica: onboarding de cliente PJ, cadastro de
  contraparte, gestor, distribuidor, fundo ou empresa emissora.
- Qualquer formulário que precise capturar CNPJ formatado enquanto o usuário digita,
  incluindo o novo formato **alfanumérico** (letras + números) previsto pela Receita
  Federal.

## Quando **não** usar

- CPF de pessoa física → use [`CpfInput`](./CpfInput.md).
- Identificadores numéricos sem máscara de CNPJ (código interno, protocolo) →
  use [`TextInput`](./TextInput.md).
- Validação de dígito verificador do CNPJ **não** é feita pelo componente — ele só
  aplica a máscara de digitação; valide o valor (formato e DV) na camada de negócio
  antes de submeter.

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface CnpjInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string mascarada, ex.: "12.ABC.345/0001-00")
  placeholder?: string;                    // default: '00.000.000/0000-00'
  onChange?: (value: string) => void;      // recebe a string SEM máscara (unmask: true)
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por `react-imask` com estas opções fixas (`CnpjInput.constants.ts`):

```ts
{
  mask: 'NN.NNN.NNN/NNNN-00',
  blocks: { N: { mask: /^[A-Z0-9]$/ } },
  prepare: (str: string) => str.toUpperCase(),
}
```

- Os **8 primeiros caracteres** (blocos `N`) aceitam letras maiúsculas **ou** dígitos —
  suporte ao CNPJ alfanumérico. Letras minúsculas digitadas são convertidas para
  maiúsculas pelo `prepare`.
- Os **2 últimos caracteres** (`00`, após o `-`) usam o padrão embutido do imask para
  dígito numérico — os verificadores permanecem sempre `0-9`, mesmo no formato novo.
- O `IMaskBridge` roda com `unmask: true`: `onChange`/`onAccept` entrega o valor **sem**
  pontuação (ex.: digitar `12.ABC.345/0001-00` dispara `onChange` com `"12ABC345000100"`),
  enquanto o `<input>` exibe a string mascarada.
- Ao passar `value` controlado, use o valor **sem máscara** (mesmo formato entregue por
  `onChange`) — é o que o `IMaskBridge` espera para re-sincronizar o campo.
- Limpar o campo externamente (`value=""` após já ter havido um valor) é suportado: o
  `IMaskBridge` detecta a transição e força o input a esvaziar (fix coberto em
  `CnpjInput.test.tsx`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { CnpjInput } from '@srm/diamond';

// Básico (controlado)
function CnpjField() {
  const [cnpj, setCnpj] = useState('');
  return <CnpjInput label="CNPJ" value={cnpj} onChange={setCnpj} />;
}

// Com ajuda e obrigatório
<CnpjInput label="CNPJ do gestor" required helperText="Aceita o novo formato alfanumérico." />

// Estado de erro
<CnpjInput label="CNPJ da contraparte" state="error" errorText="CNPJ inválido" value={cnpj} onChange={setCnpj} />

// Somente leitura
<CnpjInput label="CNPJ cadastrado" state="read-only" value="12345678000199" />

// Tema escuro (sobre header brand)
<CnpjInput label="CNPJ" theme="dark" value={cnpj} onChange={setCnpj} />
```

### Integração com React Hook Form

```tsx
<Controller
  name="cnpj"
  control={control}
  render={({ field, fieldState }) => (
    <CnpjInput
      label="CNPJ"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- O placeholder padrão (`00.000.000/0000-00`) serve como dica de formato para leitores
  de tela e usuários — evite removê-lo sem oferecer alternativa equivalente (`helperText`).

## Armadilhas comuns

- **Não** trate `onChange` como o valor mascarado — ele entrega a string **sem**
  pontuação (`unmask: true`); formate você mesmo se precisar exibir em outro lugar.
- **Não** valide dígito verificador no componente — ele só aplica máscara de digitação;
  a validação de CNPJ (formato/DV) é responsabilidade da camada de formulário/negócio.
- Ao popular `value` a partir de dados vindos da API, envie o CNPJ **sem máscara**
  (só dígitos/letras), não o valor já formatado com pontos e traço.
- Letras minúsculas são normalizadas para maiúsculas automaticamente — não espere
  preservar caixa baixa digitada pelo usuário.
