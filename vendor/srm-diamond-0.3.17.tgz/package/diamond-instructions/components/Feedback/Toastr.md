# Toastr

Container de posicionamento e empilhamento (*stack*) para múltiplos [`Toast`](./Toast.md).
Fica fixo em um canto/borda da tela, anima entrada e saída de cada toast, resolve a ordem de
empilhamento (mais novo por cima) e — quando `stackable` — mostra um efeito de "leque" (peek)
que se expande ao passar o mouse. Não tem estado global embutido: você mesmo controla a lista
de toasts (tipicamente via o hook `useToast`, exportado junto).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Toastr/Toastr/`
- **Export:** `import { Toastr, useToast } from '@srm/diamond';`
- **Relacionados/Base:** [Toast](./Toast.md) (peça renderizada dentro do stack)

---

## Quando usar

- Sistema de notificações da aplicação: confirmações de operações financeiras (aporte,
  resgate, transferência), erros de API, avisos de sessão, etc., que podem ocorrer em
  sequência e precisam se acumular na tela sem se sobrepor.
- Quando mais de um toast pode existir ao mesmo tempo (ex.: múltiplas ações em lote).
- Quando você precisa de posicionamento consistente (canto da tela) e animação de
  entrada/saída padronizada — sem reimplementar isso a cada tela.

## Quando **não** usar

- Um único toast avulso, sem necessidade de stack/posicionamento fixo → renderize
  [`Toast`](./Toast.md) diretamente.
- Mensagem bloqueante que exige decisão do usuário → modal/dialog, não `Toastr`.
- Mensagem persistente atrelada a um campo → `errorText`/`helperText` do input.

---

## Interface

```ts
type ToastrPosition =
  | 'top-right' | 'top-left' | 'top-center'
  | 'bottom-right' | 'bottom-left' | 'bottom-center';

interface ToastrProps {
  toasts: ToastRecord[];         // fila de toasts a renderizar (ver Toast.md)
  onRemove: (id: string) => void; // chamado quando um toast deve sair da lista
  position?: ToastrPosition;      // default: 'top-right'
  stackable?: boolean;            // default: true
  label?: string;                 // aria-label da região que agrupa os toasts. default: 'Notificações'
}
```

`ToastRecord` (definido em `Toast.types.ts`, reexportado por `@srm/diamond`):

```ts
interface ToastRecord extends Omit<ToastProps, 'onDismiss'> {
  id: string; // obrigatório — chave de identidade do item na fila
}
```

### `stackable: true` (default) — empilhamento em leque

- Toasts se acumulam. Em repouso, mostra até `MAX_PEEK_VISIBLE` (3) toasts em "peek"
  (deslocamento vertical pequeno + leve *scale down* + opacidade decrescente nos de trás).
- Ao passar o mouse sobre a área do stack, expande em leque completo (cada toast na sua
  altura real, com gap de 12px) — o mouse-leave recolhe de volta com debounce de 150ms
  (`HOVER_LEAVE_DELAY`), para não fechar o leque só porque o cursor passou entre dois toasts.
- A saída (`onRemove`) é animada: o item entra em estado "leaving" (classe de exit conforme
  a borda — topo ou fundo), some após `EXIT_DURATION` (200ms), e só então `onRemove(id)` é
  chamado de fato.

### `stackable: false` — substituição

- Apenas o toast **mais recente** fica visível. Quando um novo toast chega e há mais de um
  na lista, o `Toastr` **descarta automaticamente** os anteriores (dispara a mesma animação
  de saída e chama `onRemove` para cada um), mantendo só o último.
- Útil para notificações de status "ao vivo" onde só a mensagem mais atual importa (ex.:
  progresso de sincronização).

### Largura do stack

O `Toastr` calcula a largura do container pelo **maior** `width` entre os toasts visíveis
(`TOAST_FIXED_WIDTHS`: `sm` 320px, `md` 480px, `lg` 600px; sem `width`, usa `TOAST_DEFAULT_WIDTH`
= 380px) — todos os toasts do stack ficam com a mesma largura de container, ainda que cada
`ToastRecord` declare um `width` diferente.

### Diferença importante de default: `autoDismiss`

Dentro do `Toastr`, cada `ToastRecord` é convertido para `ToastProps` via uma função interna
(`buildToastProps`) que aplica `autoDismiss: toast.autoDismiss ?? true` — ou seja, **ao
contrário do `Toast` isolado (default `false`)**, todo toast disparado através de `Toastr`
fecha sozinho por padrão após `duration` (5000ms) **a menos que você passe
`autoDismiss: false` explicitamente** no registro. Além disso, essa função também repassa
`isPaused` forçado (`hovered && stackable`) a cada `Toast` interno — é assim que passar o
mouse sobre a pilha pausa **todos** os toasts visíveis, não só o que está sob o cursor.

`buildToastProps` **não repassa** `dismissLabel` do `ToastRecord` para o `Toast` renderizado
— mesmo que `ToastRecord` (via `Omit<ToastProps, 'onDismiss'>`) aceite `dismissLabel` no
objeto, esse campo é ignorado dentro do `Toastr`; o botão de fechar de cada toast do stack
sempre usa o default `'Fechar'` do `Toast`.

### Acessibilidade do container

- Elemento raiz com `role="region"` e `aria-label` (via prop `label`, default
  `'Notificações'`) — **não** é uma live region (sem `aria-live`/`aria-atomic` no wrapper);
  cada `Toast` interno já expõe seu próprio `role="status"`/`role="alert"` +
  `aria-live` (ver [Toast](./Toast.md#acessibilidade)), então o anúncio vem de cada item
  individualmente, não do container.

---

## Exemplos

### Padrão recomendado — hook `useToast` + `Toastr`

```tsx
import { Toastr, useToast, Button } from '@srm/diamond';

function TelaComNotificacoes() {
  const { toasts, addToast, removeToast } = useToast();

  const handleTransferir = async () => {
    try {
      await transferir();
      addToast({
        variant: 'success',
        title: 'Transferência enviada',
        message: 'O comprovante já está disponível no seu histórico.',
      });
    } catch {
      addToast({
        variant: 'error',
        message: 'Não foi possível concluir a transferência.',
      });
    }
  };

  return (
    <>
      <Button onPress={handleTransferir}>Transferir</Button>

      <Toastr toasts={toasts} onRemove={removeToast} position="top-right" />
    </>
  );
}
```

### Posições diferentes

```tsx
<Toastr toasts={toasts} onRemove={removeToast} position="bottom-center" />
<Toastr toasts={toasts} onRemove={removeToast} position="top-left" />
```

### Modo substituição (`stackable={false}`) — só o mais recente

```tsx
<Toastr toasts={toasts} onRemove={removeToast} stackable={false} position="bottom-right" />
```

### `label` customizado (aria-label da região)

```tsx
<Toastr toasts={toasts} onRemove={removeToast} label="Notificações de transferência" />
```

### Desativando o auto-dismiss padrão do stack

```tsx
addToast({
  variant: 'warning',
  message: 'Revise os dados antes de confirmar.',
  autoDismiss: false, // permanece até o usuário fechar manualmente
});
```

### Toast com largura e ação custom dentro do stack

```tsx
addToast({
  variant: 'info',
  width: 'lg',
  title: 'Nova versão disponível',
  message: 'Atualize a página para aplicar as melhorias.',
  action: { label: 'Atualizar', onClick: () => window.location.reload() },
  autoDismiss: false,
});
```

### Disponibilizando `addToast` para a árvore inteira (padrão de app)

O `useToast` é um hook local — o design system **não** fornece um `Context`/`Provider`
pronto. Para disparar toasts de qualquer lugar da aplicação, monte seu próprio provider por
cima do hook:

```tsx
import { createContext, useContext, type ReactNode } from 'react';
import { Toastr, useToast } from '@srm/diamond';

const ToastContext = createContext<ReturnType<typeof useToast>['addToast'] | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const { toasts, addToast, removeToast } = useToast();
  return (
    <ToastContext.Provider value={addToast}>
      {children}
      <Toastr toasts={toasts} onRemove={removeToast} position="top-right" />
    </ToastContext.Provider>
  );
}

export function useAppToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useAppToast deve ser usado dentro de ToastProvider');
  return ctx;
}
```

---

## Acessibilidade

- O container usa `role="region"` + `aria-label` (via `label`, default `'Notificações'`) —
  **não** é uma live region em si; ele apenas agrupa/rotula a área da tela. Cada `Toast`
  interno mantém seu próprio `role="status"`/`role="alert"` + `aria-live` (por `variant`, ver
  [Toast](./Toast.md)), que é quem efetivamente aciona o anúncio ao leitor de tela.
- O botão de fechar de cada toast (`IconButton`, focável e acionável via Enter/Espaço) usa o
  `dismissLabel` default do `Toast` (`'Fechar'`) — `buildToastProps` não repassa
  `dismissLabel` do `ToastRecord`, então não é possível customizá-lo por item dentro do
  `Toastr` (veja Armadilhas).

## Armadilhas comuns

- Esquecer que **dentro do `Toastr`** o default de `autoDismiss` é `true` (diferente do
  `Toast` isolado, que é `false`) — toasts "somem sozinhos" se você não passar
  `autoDismiss: false` explicitamente quando quiser persistência.
- Passar `dismissLabel` num `ToastRecord` esperando customizar o botão de fechar daquele
  item — o `Toastr` **não repassa** esse campo (`buildToastProps` não o inclui); o label
  fica sempre `'Fechar'` para toasts renderizados via `Toastr`.
- Montar mais de um `<Toastr>` com a **mesma** `position` na árvore — os stacks vão se
  sobrepor visualmente; use posições diferentes ou um único `Toastr` compartilhado.
- Gerar `id` manualmente de forma não-única para `ToastRecord` — prefira sempre `addToast`
  do `useToast` (gera `${Date.now()}-${random}`), que garante unicidade e evita chaves
  React duplicadas.
- Esperar um `Context`/Provider pronto de fábrica — não existe; o hook `useToast` é local por
  design, então disparar toasts de componentes distantes exige seu próprio provider (veja
  exemplo acima).
- Usar `stackable={false}` esperando que os toasts anteriores desapareçam instantaneamente —
  eles passam pela mesma animação de saída (~200ms) antes de sumir de fato.
