# Switch

Controle de liga/desliga (toggle) para configurações binárias. Renderiza rótulo e texto de
apoio opcionais ao lado do indicador visual. Construído sobre `SwitchField` + `SwitchButton`
do `react-aria-components` (a dupla recomendada pela lib em substituição ao `Switch` legado),
herdando toda a lógica de acessibilidade, teclado e validação de formulário.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Switch/`
- **Export:** `import { Switch } from '@srm/diamond';`
- **Relacionados:** [Checkbox](./Checkbox.md) (seleção múltipla/afirmativa), [RadioGroup](./RadioGroup.md) (escolha única entre opções)

---

## Quando usar

- Ativar/desativar uma configuração imediatamente, sem necessidade de "salvar" (ex.: receber
  notificações por e-mail, ativar autenticação em duas etapas, modo escuro).
- Preferências que têm efeito instantâneo ao alternar (a mudança de estado já É a ação).
- Item único de configuração — não para escolher entre 3+ opções mutuamente exclusivas.

## Quando **não** usar

- Seleção de um item entre várias opções em lista → [`Checkbox`](./Checkbox.md) (múltipla) ou
  [`RadioGroup`](./RadioGroup.md) (única).
- Ação que precisa de confirmação explícita (ex.: "Excluir conta") → use [`Button`](./Button.md)
  ou um modal de confirmação, não um switch.
- Estado que só é aplicado após clicar em "Salvar" — nesse caso um `Checkbox` comunica melhor a
  ideia de "seleção pendente" do que um switch, que sugere efeito imediato.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { SwitchFieldProps as AriaSwitchFieldProps } from 'react-aria-components';

type SwitchSize = 'sm' | 'md';
type SwitchTheme = 'default' | 'dark';

interface SwitchProps extends Omit<AriaSwitchFieldProps, 'className' | 'children'> {
  size?: SwitchSize;        // default: 'md'
  theme?: SwitchTheme;      // default: 'default'
  children?: ReactNode;     // rótulo do switch
  helper?: ReactNode;       // texto de apoio, abaixo do rótulo
  className?: string;       // aplicado internamente ao SwitchButton (via CVA)
}
```

### Props herdadas de `AriaSwitchFieldProps` (react-aria-components)

Passthrough direto — nenhuma reimplementação. As mais relevantes:

| Prop              | Tipo                                 | Descrição                                                              |
|-------------------|---------------------------------------|--------------------------------------------------------------------------|
| `isSelected`      | `boolean`                              | Controlado: estado ligado/desligado.                                    |
| `defaultSelected` | `boolean`                              | Não controlado: estado inicial.                                         |
| `onChange`        | `(isSelected: boolean) => void`        | Disparado a cada alternância.                                           |
| `isDisabled`      | `boolean`                              | Desabilita interação e aplica `[data-disabled]` (opacidade reduzida).   |
| `isReadOnly`      | `boolean`                              | Renderiza mas impede alternância pelo usuário.                          |
| `isRequired`      | `boolean`                              | Marca como obrigatório para validação (`[data-required]`).              |
| `name` / `value`  | `string`                                | Para submissão em `<form>` nativo.                                      |
| `autoFocus`       | `boolean`                               | Foca o switch na montagem.                                              |
| `aria-label` etc. | `string`                                | Nome acessível — obrigatório se `children` não for passado.             |

### Notas de comportamento

- **Estrutura DOM**: `SwitchField` (wrapper com `display: contents`, sem impacto de layout) →
  `SwitchButton` (área clicável, estilizada por `switchVariants` do CVA) → track + thumb
  (puramente visuais, `aria-hidden="true"`) + bloco de texto opcional.
- `children` (rótulo) e `helper` (apoio) só renderizam o `<span>` de texto se **pelo menos um**
  dos dois estiver presente — caso contrário o switch fica "nu" (só o indicador visual).
- `theme="dark"` aplica `data-theme="dark"` no `SwitchField` — use sobre fundos escuros
  (headers, sidebars).
- Tamanhos: `sm` → track 32×18px, thumb 12×12px. `md` (default) → track 44×24px, thumb 18×18px.
- Estado selecionado pinta o track com `--brand-primary`; foco por teclado desenha
  `box-shadow: var(--focus-ring)` no track (`[data-focus-visible]`).
- Respeita `prefers-reduced-motion: reduce` (desativa as transições de track/thumb).
- **Não recebe** `label`/`state`/`errorText` no estilo `InputBase` — este componente **não**
  herda de `InputBaseProps`; seu rótulo é via `children` (slot de conteúdo), não `label` (string).

---

## Exemplos

```tsx
import { useState } from 'react';
import { Switch } from '@srm/diamond';

// Básico, não controlado
<Switch defaultSelected>Notificações por e-mail</Switch>

// Controlado
function NotificacoesField() {
  const [ativo, setAtivo] = useState(false);
  return (
    <Switch isSelected={ativo} onChange={setAtivo}>
      Notificações por e-mail
    </Switch>
  );
}

// Com texto de apoio
<Switch
  isSelected={ativo}
  onChange={setAtivo}
  helper="Você receberá um resumo diário às 9h."
>
  Resumo diário
</Switch>

// Tamanho pequeno
<Switch size="sm">Modo compacto</Switch>

// Desabilitado
<Switch isDisabled defaultSelected>
  Recurso em manutenção
</Switch>

// Somente leitura (exibe estado, mas não permite alternar)
<Switch isReadOnly isSelected>
  Aprovado por compliance
</Switch>

// Sem rótulo visível (exige aria-label)
<Switch aria-label="Ativar modo escuro" isSelected={darkMode} onChange={setDarkMode} />

// Tema escuro (sobre header/sidebar brand)
<Switch theme="dark" isSelected={ativo} onChange={setAtivo}>
  Sair do modo compacto
</Switch>
```

### Integração com React Hook Form

```tsx
<Controller
  name="notificacoesEmail"
  control={control}
  render={({ field }) => (
    <Switch isSelected={field.value} onChange={field.onChange}>
      Notificações por e-mail
    </Switch>
  )}
/>
```

---

## Acessibilidade

- Sem `children` (rótulo visível), **sempre** forneça `aria-label` — do contrário o switch fica
  sem nome acessível para leitores de tela.
- O indicador visual (track/thumb) é `aria-hidden` — o estado ligado/desligado é comunicado ao
  leitor de tela via semântica nativa do `input[type=checkbox]` gerado pelo react-aria
  (papel de switch, `aria-checked`).
- Alternância por teclado (Espaço/Enter quando focado) já é tratada pelo react-aria — não
  reimplemente handlers de tecla.
- `isReadOnly` mantém o switch focável e anunciado, mas bloqueia a alternância — use para
  exibir estado sem permitir edição (diferente de `isDisabled`, que também reduz opacidade e
  remove da ordem de foco esperada pelo usuário para itens realmente indisponíveis).

## Armadilhas comuns

- Não confunda `helper` (prop deste componente, texto de apoio) com `helperText` de
  `InputBase` — `Switch` **não** herda de `InputBaseProps`; são APIs independentes.
- `onChange` aqui entrega **`boolean`** diretamente (`isSelected`), não um evento — diferente de
  inputs de texto que entregam string.
- Não use `Switch` para ações que exigem confirmação (ex.: exclusão) — o padrão visual comunica
  "efeito imediato e reversível", o que pode enganar o usuário em ações destrutivas.
- `className` é injetado no `SwitchButton` via CVA (`switchVariants`) — evite sobrescrever
  cores de track/thumb por CSS ad-hoc; prefira `theme`/tokens do design system.
