# UploadAreaMobile

Área de upload de arquivos otimizada para toque (mobile). É a contraparte de
[`FileUpload`](./FileUpload.md) sem drag-and-drop: todo o card é uma zona clicável/tocável
que abre o seletor nativo de arquivos do sistema operacional. Compartilha a mesma lógica de
estado visual (`resolveUploadVisualState`) e de validação de tamanho (`findOversizedFile`) do
`FileUpload`, definidas em `FileUpload.utils.ts`. Construído com um `<div role="button">`
nativo (não usa `react-aria-components`) e renderiza [`Icon`](../Icons/Icon.md) e
[`Chip`](./Chip.md) para o feedback visual e a lista de arquivos selecionados.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/UploadAreaMobile/`
- **Export:** `import { UploadAreaMobile } from '@srm/diamond';`
- **Relacionados:** [FileUpload](./FileUpload.md) (versão desktop com drag-and-drop), [Chip](./Chip.md) (usado internamente para os arquivos selecionados)

---

## Quando usar

- Telas mobile ou responsivas onde o usuário precisa anexar documentos por toque
  (comprovantes, contratos, documentos de KYC, comprovantes de residência).
- Fluxos onde não há suporte a drag-and-drop (apps embutidos em WebView, telas touch-first).
- Sempre que o layout for otimizado para largura estreita — o card ocupa `width: 100%`.

## Quando **não** usar

- Telas desktop com mouse, onde drag-and-drop é esperado → use [`FileUpload`](./FileUpload.md)
  (mesma API de props, mas com zona de drop e feedback de "arraste aqui").
- Seleção de opções que não são arquivos → não é um `Chip`/seletor genérico, é
  especificamente upload de `File`.

---

## Interface

```ts
import type { ReactNode } from 'react';

export interface UploadAreaMobileProps {
  label?: ReactNode;                     // rótulo acima do card
  hint?: string;                         // texto de ajuda; some quando há erro/sucesso e cede lugar à mensagem de estado
  accept?: string;                       // passthrough para o atributo `accept` do <input type="file">
  multiple?: boolean;                    // default: false — permite selecionar/acumular vários arquivos
  onFiles?: (files: File[]) => void;     // chamado com a lista completa e atual de arquivos a cada mudança
  maxSizeMB?: number;                    // default: 10 — limite de tamanho por arquivo
  errorText?: string;                    // erro controlado externamente (ex.: validação de servidor)
  disabled?: boolean;                    // default: false

  forceHover?: boolean;                  // default: false — força visualmente o estado "active" (uso em storybook/demos)
  previewFiles?: File[];                 // define/sincroniza a lista de arquivos de fora (controlado)
}
```

Não há `ref` encaminhada e o componente **não** herda `InputBaseProps` — é um componente
próprio, sem InputBase.

### Estado visual (`UploadVisualState`)

O card calcula um estado visual único via `resolveUploadVisualState`, com esta prioridade
(primeira condição verdadeira vence):

| Ordem | Condição                          | Estado (`data-state`) | Efeito                                                  |
|-------|------------------------------------|------------------------|----------------------------------------------------------|
| 1     | `disabled`                        | `disabled`             | Opacidade reduzida, `cursor: not-allowed`, não abre seletor. |
| 2     | erro (interno ou `errorText`)     | `error`                | Borda e texto em vermelho (`--feedback-error`), ícone de erro. |
| 3     | `files.length > 0`                | `success`              | Borda verde (`--feedback-success`), ícone de sucesso, chips visíveis. |
| 4     | `pressed \|\| forceHover`         | `active`               | Borda/realce de foco (`--brand-primary` + `focus-ring`). |
| —     | nenhuma das anteriores            | `default`              | Borda tracejada neutra, ícone de upload.                |

Notas importantes:

- **Erro interno vs. externo**: existe validação embutida de tamanho de arquivo
  (`findOversizedFile`) que gera a mensagem `"Arquivo muito grande. Máximo: {maxSizeMB}MB."`
  automaticamente e **bloqueia** a seleção (não atualiza `files`, não chama `onFiles`). Esse
  erro interno tem prioridade sobre `errorText`: `const error = internalError ?? errorText`.
- **`pressed`** é controlado por `onMouseDown`/`onMouseUp`/`onMouseLeave` e
  `onTouchStart`/`onTouchEnd` — simula estado "ativo" durante o toque, não é um verdadeiro
  drag-and-drop (o componente **não** implementa `onDragOver`/`onDrop`, diferente do `FileUpload`).
- **`multiple`**: quando `true`, cada nova seleção é **acumulada** com os arquivos já
  presentes (`[...files, ...list]`); quando `false`, a nova seleção **substitui** a anterior.
- **`previewFiles`**: torna o componente controlado externamente via `useEffect` — toda vez
  que `previewFiles` muda, `files` é ressincronizado. Útil para popular a lista a partir de
  dados já existentes (ex.: edição de um cadastro com anexos salvos).
- **Textos dinâmicos** (`titleText`/`subText`) mudam conforme `visual` e `multiple`:
  - `error`: título fixo "Não foi possível enviar o arquivo"; subtítulo = mensagem de erro.
  - `success`: título "Arquivo selecionado" ou "Arquivos selecionados" (plural se `files.length > 1`);
    subtítulo = "Toque para adicionar mais arquivos" (se `multiple`) ou `hint`/limite de tamanho.
  - `default`: título "Toque para selecionar"; subtítulo = `hint` ou
    `"Máximo {maxSizeMB}MB por arquivo · {accept}"` (o `accept` só aparece se informado).
- **Remoção de arquivo**: cada `Chip` tem `removable` com `onRemove` que remove o arquivo
  pelo índice e chama `onFiles` com a lista atualizada. O clique no chip usa
  `e.stopPropagation()` para não reabrir o seletor de arquivos.
- **Reset do input nativo**: após `onChange`, `e.target.value` é limpo — permite selecionar
  o **mesmo arquivo** duas vezes seguidas e ainda disparar o evento de mudança.
- **`aria-label`** do card: usa `label` como string se ele for string; caso contrário
  (ex.: `label` como `ReactNode` custom ou ausente), cai para
  `"Área de upload. Toque para selecionar arquivos."`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { UploadAreaMobile } from '@srm/diamond';

// Básico — um único arquivo
function AnexoUnico() {
  const [files, setFiles] = useState<File[]>([]);
  return (
    <UploadAreaMobile
      label="Comprovante de residência"
      accept="image/*,.pdf"
      onFiles={setFiles}
    />
  );
}

// Múltiplos arquivos, acumulando seleções
<UploadAreaMobile
  label="Documentos do cadastro"
  multiple
  accept=".pdf,.jpg,.png"
  maxSizeMB={5}
  onFiles={(files) => console.log(files)}
/>

// Estado de erro controlado externamente (ex.: falha no upload ao servidor)
<UploadAreaMobile
  label="Contrato assinado"
  errorText="Falha ao enviar. Tente novamente."
/>

// Desabilitado
<UploadAreaMobile label="Anexo" disabled />

// Controlado com arquivos pré-existentes (ex.: edição de cadastro)
function EditarAnexos({ arquivosSalvos }: { arquivosSalvos: File[] }) {
  const [files, setFiles] = useState<File[]>(arquivosSalvos);
  return (
    <UploadAreaMobile
      label="Documentos"
      multiple
      previewFiles={arquivosSalvos}
      onFiles={setFiles}
    />
  );
}

// Forçando visualmente o estado ativo (uso em Storybook/demos)
<UploadAreaMobile label="Anexo" forceHover />
```

### Integração com React Hook Form

```tsx
<Controller
  name="anexos"
  control={control}
  render={({ field, fieldState }) => (
    <UploadAreaMobile
      label="Anexos"
      multiple
      previewFiles={field.value}
      onFiles={field.onChange}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- O card tem `role="button"` e `tabIndex` (0, ou `-1` quando `disabled`) — navegável por
  teclado; `Enter`/`Espaço` abrem o seletor de arquivos (`onKeyDown`).
- **Sempre** forneça `label` como string simples quando possível: ela vira o `aria-label` do
  card. Se `label` for um `ReactNode` complexo (ex.: com ícone), o `aria-label` cai para o
  texto genérico "Área de upload. Toque para selecionar arquivos." — considere passar também
  um rótulo textual claro nesse caso.
- Cada arquivo removível (`Chip` com `removable`) recebe `removeLabel` dinâmico
  (`"Remover {nome do arquivo}"`), garantindo que leitores de tela anunciem qual arquivo será
  removido.
- O estado de erro é comunicado visualmente (cor + texto no subtítulo) mas **não** usa
  `aria-live` ou `role="alert"` — se a mensagem de erro precisar ser anunciada
  proativamente, trate isso no componente pai (ex.: com um `FieldError`/região `aria-live`
  externa).
- O `<input type="file">` real fica oculto via `style={{ display: 'none' }}` — todo o
  disparo de interação passa pelo `<div role="button">`.

## Armadilhas comuns

- Não confunda com `FileUpload`: `UploadAreaMobile` **não** responde a `onDragOver`/`onDrop`
  — em telas desktop, arrastar um arquivo sobre o card não tem efeito algum.
- O limite de tamanho (`maxSizeMB`) só é validado **no momento da seleção**; arquivos que já
  estão em `previewFiles`/`files` não são revalidados retroativamente.
- Ao usar `multiple`, lembre-se que cada nova seleção **soma** arquivos — não há deduplicação
  por nome; selecionar o mesmo arquivo duas vezes cria duas entradas na lista.
- `errorText` só aparece quando não há erro interno de tamanho ativo — se o usuário acabou
  de selecionar um arquivo grande, a mensagem interna sobrepõe temporariamente qualquer
  `errorText` externo até uma nova seleção válida.
- Não existe prop de `ref` nem herança de `InputBaseProps` — para estilizar via CSS externo,
  use `className` não está disponível; ajuste via `label`/composição externa (`div` wrapper).
