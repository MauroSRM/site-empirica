# ChipGroup

Contêiner de seleção para múltiplos [`Chip`](./Chip.md), construído diretamente sobre
`ToggleButtonGroup` do `react-aria-components`. Agrega a seleção dos chips filhos por `id`,
suportando seleção única ou múltipla, e propaga `isDisabled` para todo o grupo.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Chip/` (arquivo `ChipGroup.tsx`)
- **Export:** `import { ChipGroup } from '@srm/diamond';`
- **Relacionados/Base:** [Chip](./Chip.md) (item individual — obrigatório como filho)

---

## Quando usar

- Grupos de filtros onde a seleção de um ou mais chips precisa ser lida como um conjunto
  (ex.: `Set<Key>` de classes de ativo selecionadas para filtrar uma tabela).
- Sempre que precisar de `selectionMode="single"` (rádio-like) ou `"multiple"` (checkbox-like)
  entre vários `Chip`s, com estado de seleção único e agregado.
- Quando quiser desabilitar **todos** os chips do grupo de uma vez (`isDisabled` no grupo).

## Quando **não** usar

- Um único `Chip` isolado sem necessidade de agregação de seleção → use [`Chip`](./Chip.md) sozinho.
- Chips **removíveis** (tags já aplicadas, sem necessidade de seleção agregada) — `removable` do
  `Chip` funciona fora de um `ChipGroup`; agrupar apenas para layout, sem `selectionMode`, não
  traz benefício sobre um `<div>`/`flex` simples.
- Navegação por seções → não é um `Tabs`; para isso use o componente de abas do Diamond.
- Muitas opções (a ponto de os chips quebrarem em várias linhas ou exigirem busca) →
  [`MultiSelect`](./MultiSelect.md). Os dois se combinam bem: o `MultiSelect` faz a escolha
  e um `ChipGroup` abaixo do campo exibe a seleção como chips removíveis.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ToggleButtonGroupProps as AriaToggleButtonGroupProps } from 'react-aria-components';

interface ChipGroupProps extends Omit<AriaToggleButtonGroupProps, 'className' | 'children'> {
  children: ReactNode;   // obrigatório — os <Chip id="..." /> filhos
  className?: string;
}
```

### Notas de comportamento

- `ChipGroup` é 100% passthrough de layout + agregação sobre `ToggleButtonGroup` do react-aria —
  todas as props de seleção vêm de lá: `selectionMode` (`'single' | 'multiple'`), `selectedKeys`,
  `defaultSelectedKeys`, `onSelectionChange` (recebe um `Set<Key>`), `disallowEmptySelection`,
  `isDisabled` (desabilita todos os `Chip`s filhos), `aria-label`/`aria-labelledby`.
- Cada `Chip` filho **precisa** de um `id` único para participar corretamente da agregação — sem
  `id`, o react-aria não consegue rastrear qual chip está em `selectedKeys`.
- O layout aplicado é `display: flex; flex-wrap: wrap; gap: var(--space-2)` — os chips quebram
  linha automaticamente em containers estreitos.
- Não gerencia tema (`theme`) nem tamanho (`size`) dos filhos — esses são configurados
  individualmente em cada `Chip`.

---

## Exemplos

```tsx
import { Chip, ChipGroup } from '@srm/diamond';

// Seleção múltipla (filtros de listagem)
function FiltroClasseAtivo() {
  const [selecionados, setSelecionados] = useState<Set<React.Key>>(new Set(['renda-fixa']));
  return (
    <ChipGroup
      aria-label="Classes de ativo"
      selectionMode="multiple"
      selectedKeys={selecionados}
      onSelectionChange={(keys) => setSelecionados(keys as Set<React.Key>)}
    >
      <Chip id="renda-fixa" label="Renda Fixa" />
      <Chip id="multimercado" label="Multimercado" />
      <Chip id="fidc" label="FIDC" />
      <Chip id="debentures" label="Debentures" />
    </ChipGroup>
  );
}

// Seleção única (não controlado)
<ChipGroup aria-label="Período" selectionMode="single" defaultSelectedKeys={['mensal']}>
  <Chip id="mensal" label="Mensal" />
  <Chip id="anual" label="Anual" />
</ChipGroup>

// Grupo desabilitado
<ChipGroup aria-label="Interesses" selectionMode="multiple" isDisabled>
  <Chip id="fidc" label="FIDC" />
  <Chip id="cri" label="CRI" />
</ChipGroup>
```

---

## Acessibilidade

- Requer `aria-label` (ou `aria-labelledby`) no próprio grupo — descreva o conjunto de opções
  (ex.: `"Classes de ativo"`), pois os `Chip`s individuais não carregam esse contexto sozinhos.
- Cada `Chip` continua anunciando seu próprio `aria-pressed`; o grupo em si é responsável por
  agregar o `Set` de chaves selecionadas, refletido em `onSelectionChange`.
- `isDisabled` no grupo desabilita a navegação/interação de todos os filhos de forma consistente
  para tecnologia assistiva (nenhum chip fica "meio habilitado").

## Armadilhas comuns

- Esquecer o `id` em algum `Chip` filho — a seleção agregada desse chip não funcionará.
- Misturar `selectionMode="single"` com expectativa de múltiplos chips marcados simultaneamente —
  o modo `single` desmarca o anterior ao selecionar um novo (comportamento padrão do react-aria).
- Usar `ChipGroup` para chips `removable` esperando que a remoção também afete `selectedKeys` —
  são mecanismos independentes; a remoção não atualiza automaticamente a seleção do grupo.
- Omitir `aria-label` no grupo — sem rótulo, leitores de tela não conseguem descrever o propósito
  do conjunto de chips.
