# Drawer

Painel lateral deslizante (slide-in) que cobre parte da tela sem sair do contexto da
página atual. Construído sobre `ModalOverlay` + `Modal` + `Dialog` + `Heading` do
`react-aria-components` — herda foco preso (focus trap), fechamento por `Esc`, clique
fora do painel e gerenciamento de `aria-modal` de graça. O rodapé de ações reaproveita
`Button` e `DoubleButton` do Diamond.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Drawer/`
- **Export:** `import { Drawer } from '@srm/diamond';`
- **Relacionados:** [Modal](./Modal.md) (diálogo centralizado), [BottomSheet](./BottomSheet.md)
  (painel inferior, mobile), [Button](../Forms/Button.md), [DoubleButton](../Forms/DoubleButton.md)
  (usado internamente quando há duas ações no rodapé)

---

## Quando usar

- Exibir detalhes de um registro sem trocar de página: detalhes de uma operação (TED,
  TEV, resgate), extrato de um lançamento, dados de um cliente/conta.
- Formulários laterais que não interrompem totalmente o fluxo: editar um cadastro,
  criar uma nova transferência, ajustar um limite.
- Fluxos que precisam de uma ação primária (e opcionalmente secundária) fixada no
  rodapé, sempre visível independentemente do scroll do conteúdo.

## Quando **não** usar

- Confirmação curta e bloqueante (ex.: "Excluir conta?") → prefira um diálogo modal
  centralizado ([`Modal`](./Modal.md)).
- Em telas mobile onde o padrão de interação é "puxar de baixo para cima" → considere
  [`BottomSheet`](./BottomSheet.md).
- Conteúdo que precisa ficar lado a lado com a página (não sobrepor) → não é um caso de
  overlay; repense o layout como painel fixo na própria página.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonVariant } from '@srm/diamond'; // re-exportado por Button

type DrawerSize = 'sm' | 'md' | 'lg';

interface DrawerAction {
  label: string;
  onClick: () => void;
  variant?: ButtonVariant;   // ex.: 'primary', 'destructive', 'ghost'...
}

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children?: ReactNode;
  primaryAction?: DrawerAction;
  secondaryAction?: DrawerAction;
  size?: DrawerSize;          // default: 'md'
}
```

### Notas de comportamento

- **Controlado**: `isOpen`/`onClose` são obrigatórios — o Drawer não gerencia seu
  próprio estado de abertura. Quando o usuário pressiona `Esc` ou clica fora do
  painel, o `ModalOverlay` dispara `onOpenChange(false)`, que internamente chama
  `onClose()`.
- **`aria-label` do diálogo**: se `title` não for informado, o `Dialog` recebe
  `aria-label="Painel"` como fallback — sempre prefira passar `title`.
- **Rodapé condicional**: só é renderizado se `primaryAction` **ou** `secondaryAction`
  existir.
  - Com **as duas** ações: renderiza um único [`DoubleButton`](../Forms/DoubleButton.md)
    (`layout="vertical"`, `size="lg"`), escolhendo automaticamente o par
    `destructive-ghost` quando `primaryAction.variant === 'destructive'`, ou
    `primary-ghost` nos demais casos.
  - Com **apenas uma** ação: renderiza um único [`Button`](../Forms/Button.md)
    `fullWidth` `size="lg"` — `primaryAction` usa `variant` (default `'primary'`),
    `secondaryAction` usa `variant` (default `'ghost'`).
- **Tamanhos** (`size`): controlam a largura do painel via CSS vars
  (`--drawer-width-sm` / `--drawer-width` / `--drawer-width-lg`). Abaixo de `767px` de
  viewport, os três tamanhos colapsam para `--drawer-width-mobile` (o painel ocupa a
  largura útil da tela).
- **Animação**: entrada/saída fazem slide horizontal (da direita) em `280ms`, com fade
  no overlay; ambas respeitam `prefers-reduced-motion: reduce` (animação desativada).
- Não há prop `theme` — o painel usa sempre o tema claro (`--surface-default`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { Drawer, Button } from '@srm/diamond';

// Básico — apenas conteúdo, sem ações no rodapé
function DetalhesOperacao() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onPress={() => setIsOpen(true)}>Ver detalhes</Button>
      <Drawer
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Detalhes da operação"
        subtitle="TED · 30/06/2026"
      >
        <p>Valor: R$ 1.234,56</p>
        <p>Destinatário: Fulano de Tal</p>
      </Drawer>
    </>
  );
}

// Com uma única ação primária
<Drawer
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  title="Novo aporte"
  primaryAction={{ label: 'Confirmar aporte', onClick: handleConfirm }}
>
  {/* formulário */}
</Drawer>

// Com duas ações — vira um DoubleButton internamente
<Drawer
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  title="Editar limite"
  primaryAction={{ label: 'Salvar', onClick: handleSave }}
  secondaryAction={{ label: 'Cancelar', onClick: () => setIsOpen(false) }}
>
  {/* formulário */}
</Drawer>

// Ação primária destrutiva — par vira "destructive-ghost" automaticamente
<Drawer
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  title="Excluir cadastro"
  primaryAction={{ label: 'Excluir', onClick: handleDelete, variant: 'destructive' }}
  secondaryAction={{ label: 'Cancelar', onClick: () => setIsOpen(false) }}
>
  <p>Esta ação não pode ser desfeita.</p>
</Drawer>

// Tamanho pequeno, sem título/subtítulo (sem page header)
<Drawer isOpen={isOpen} onClose={() => setIsOpen(false)} size="sm">
  <p>Conteúdo compacto.</p>
</Drawer>

// Tamanho grande, para conteúdo denso (formulário longo, tabela)
<Drawer isOpen={isOpen} onClose={() => setIsOpen(false)} size="lg" title="Extrato completo">
  {/* tabela ou formulário extenso */}
</Drawer>
```

---

## Acessibilidade

- O `ModalOverlay` do react-aria já provê: foco preso dentro do painel enquanto aberto,
  retorno de foco ao elemento que abriu o Drawer ao fechar, fechamento por `Esc` e
  `aria-modal="true"` no `Dialog`.
- Sempre informe `title` — sem ele o diálogo recebe apenas o rótulo genérico "Painel",
  o que prejudica usuários de leitor de tela ao identificar o conteúdo.
- O botão de fechar é um [`IconButton`](../Forms/IconButton.md) com `aria-label="Fechar"`
  fixo (não configurável) — já nomeado corretamente para leitores de tela.
- Respeita `prefers-reduced-motion` automaticamente (desativa as animações de slide/fade).

## Armadilhas comuns

- Não gerenciar `isOpen` como estado controlado (ex.: sempre `true`) impede o
  fechamento pelo teclado/overlay de funcionar corretamente — o `onClose` **precisa**
  atualizar o estado que controla `isOpen`.
- Passar `primaryAction` **e** `secondaryAction` muda o layout do rodapé para
  `DoubleButton` (empilhado, vertical) — não é possível ter dois `Button` lado a lado
  nesse componente; se precisar de outro arranjo, componha o rodapé manualmente dentro
  de `children` e não use as props de ação.
- `size` só define a largura em telas ≥ 768px; em mobile todo Drawer ocupa a largura
  cheia independentemente do valor escolhido — não assuma que `sm` continuará estreito
  em qualquer viewport.
- O `variant` de `primaryAction`/`secondaryAction` só é lido em `primaryAction` para
  decidir o par do `DoubleButton` (`destructive` vs. demais); o `variant` de
  `secondaryAction` é ignorado nesse cenário combinado.
