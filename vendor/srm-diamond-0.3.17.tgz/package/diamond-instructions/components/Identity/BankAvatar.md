# BankAvatar

Ícone circular que representa visualmente uma instituição financeira (banco, fintech,
maquininha, bandeira de cartão, carteira digital) a partir de um identificador flexível —
código BACEN, slug ou nome livre em pt-BR. Resolve o identificador para um slug de ícone
via `bankRegistry` (interno), busca a URL do SVG no **catálogo interno de assets**
(`bankIcons.ts`, ~83 SVGs em `src/assets/bank-icons/*.svg`, carregados via `import.meta.glob`
do Vite) e cai automaticamente para iniciais (fallback) quando não há correspondência ou o
carregamento da imagem falha. Não depende de `react-aria-components` — é um `<div role="img">`
(fallback) ou `<div><img></div>` (com ícone), estilizado por `class-variance-authority` (CVA).
É o item **canônico** de avatar de banco no Diamond: `BankAvatarGroup` e
`Cards/OpenFinanceAccountCard` o consomem diretamente.

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/BankAvatar/`
- **Export:** `import { BankAvatar, BANKS, BANK_ICON_URLS } from '@srm/diamond';`
- **Tipos exportados:** `BankAvatarProps`, `BankAvatarShape`, `BankSize`, `BankCatalogEntry`
- **Relacionados:** [BankAvatarGroup](./BankAvatarGroup.md) (composição em grupo de vários
  `BankAvatar`), [Avatar](./Avatar.md) (círculo de iniciais de pessoa/empresa — domínio
  diferente, não confundir)

---

## Quando usar

- Extrato de transações, listagem de contas ou boletos onde cada item precisa exibir o
  logo do banco de origem/destino.
- Seletor de banco em formulários de cadastro de conta bancária, TED/PIX, ou onboarding.
- Card de "conta conectada" (open finance) mostrando a instituição — é o componente usado
  internamente por `Cards/OpenFinanceAccountCard`.
- Qualquer contexto em que o identificador do banco venha em formatos heterogêneos (código
  BACEN vindo do backend, slug já normalizado, ou nome digitado/livre) — a resolução é
  feita internamente, sem o consumidor precisar normalizar antes.
- Múltiplos bancos lado a lado, com contador de excedentes → prefira
  [`BankAvatarGroup`](./BankAvatarGroup.md), que já compõe `BankAvatar` por baixo.

## Quando **não** usar

- Avatar de usuário/colaborador (foto, iniciais de pessoa) — esse componente é
  exclusivamente para **instituições financeiras**, não para pessoas. Use [`Avatar`](./Avatar.md).
- Ícone decorativo genérico sem relação com bancos — use um ícone comum (ex.: `lucide-react`).
- Se precisar de um badge de status sobreposto ao avatar (online/offline, notificação) —
  este componente não tem slot para overlay; envolva-o você mesmo em um wrapper posicionado.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactEventHandler, Ref } from 'react';

type BankAvatarShape = 'circle'; // único valor suportado hoje

type BankSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';

interface BankAvatarProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children' | 'onError'> {
  bank?: string;                             // código BACEN ("237"), slug ("bradesco") ou nome livre ("Banco Bradesco")
  size?: BankSize | number;                  // default: 'md' — token ou pixels custom (número)
  shape?: BankAvatarShape;                   // default: 'circle' — único valor existente
  fallbackInitials?: string;                 // sobrescreve as iniciais calculadas automaticamente
  fallbackBg?: string;                       // cor de fundo custom quando cai no fallback
  iconBase?: string;                         // ver "Resolução de ícone" — sobrescreve o catálogo interno
  'aria-label'?: string;                     // sobrescreve o nome acessível (default: `bank` ou texto genérico)
  onError?: ReactEventHandler<HTMLImageElement>; // disparado quando a <img> falha ao carregar
  ref?: Ref<HTMLDivElement>;
  // Herdado de ComponentPropsWithoutRef<'div'>: id, style, data-*, aria-*, onClick, ...
  // (`children` é omitido — o conteúdo é sempre a imagem ou o fallback de iniciais)
}

// Catálogo de instituições suportadas (~90 entradas; usado para popular seletores)
declare const BANKS: Array<{ value: string; label: string }>;
// ex.: { value: 'itau', label: 'Itaú' }, { value: 'nubank', label: 'Nubank' }, ...

// Mapa slug → URL do SVG interno, resolvido em build-time (Vite glob import), ~83 entradas
declare const BANK_ICON_URLS: Record<string, string>;
```

### Tokens de tamanho (`BANK_SIZE_PX`)

| Token  | Pixels |
|--------|--------|
| `xs`   | 20     |
| `sm`   | 24     |
| `md`   | 32 (default) |
| `lg`   | 40     |
| `xl`   | 48     |
| `2xl`  | 64     |

Passar um **número** em `size` (ex.: `size={56}`) usa esse valor em pixels diretamente
(`width`/`height` inline), ignorando os tokens de classe CVA de tamanho — útil para casos
fora da escala padrão.

### Resolução de `bank` → slug (`bankRegistry.ts`, interno)

A prop `bank` é resolvida por `resolveBankSlug()` (não exportado publicamente), nesta ordem:

1. **Código BACEN numérico** (ex.: `"237"`, `"001"`) — consulta `BACEN_MAP`. Cobre os
   principais bancos/fintechs brasileiros (Bradesco, Itaú, BB, Caixa, Nubank, Inter, C6,
   BTG, Santander, Sicoob, Sicredi, Stone, PagSeguro, Mercado Pago, etc.).
2. **Nome normalizado exato** — remove tudo que não é `[a-z0-9-]` e faz lowercase, compara
   contra `NAME_MAP` (aceita variações como `"Banco do Brasil"`, `"bb"`, `"BANCODOBRASIL"`,
   `"nu"` → `nubank`, `"itaú"` com acento, etc.).
3. **Correspondência parcial** — se não achou exato, procura por substring (`includes`) nas
   duas direções entre o texto digitado e as chaves de `NAME_MAP`.
4. Se nada bater, retorna `null` → o componente cai automaticamente no **fallback de iniciais**.

- `bank` indefinido/vazio também cai no fallback, mostrando `"?"` (a menos que
  `fallbackInitials` seja passado).

### Resolução de slug → imagem (`iconBase` vs. catálogo interno)

**Importante — corrige uma armadilha comum**: `BankAvatar` já vem com um **catálogo interno
de SVGs** (`BANK_ICON_URLS`, ~83 ícones em `src/assets/bank-icons/`, resolvidos via
`import.meta.glob` no build). Você **não precisa** passar `iconBase` para os bancos mais
comuns funcionarem — a resolução é:

```ts
const src = slug
  ? (iconBase !== undefined
      ? buildIconSrc(iconBase, slug)          // iconBase informado → SEMPRE usa esse prefixo
      : (BANK_ICON_URLS[slug] ?? buildIconSrc('', slug))) // sem iconBase → usa o catálogo interno primeiro
  : null;
```

- **`iconBase` omitido (comportamento default)**: usa `BANK_ICON_URLS[slug]` (catálogo
  interno) sempre que o slug resolvido tiver um SVG embutido no pacote. Só cai em
  `buildIconSrc('', slug)` (uma URL relativa vazia, que 404 e aciona o fallback de
  iniciais) se o slug **não** estiver no catálogo interno.
- **`iconBase` informado (mesmo `''`)**: passa a ter **prioridade total** sobre o catálogo
  interno — a URL final é sempre `` `${iconBase sem barra final}/${slug}.svg` ``. Use isso
  para: (a) apontar para um CDN próprio com ícones customizados/atualizados, ou (b) resolver
  bancos que **não** estão no catálogo interno mas têm SVG hospedado externamente.
- Erro de carregamento da `<img>` (evento `onError`) também aciona o fallback de iniciais
  automaticamente, via estado interno (`hasImageError`), além de repassar o evento para a
  prop `onError` se fornecida.

### Fallback de iniciais

- Iniciais = `fallbackInitials` OU as 2 primeiras letras de `bank` em maiúsculas
  (`BANK_AVATAR_FALLBACK_INITIALS_LENGTH = 2`), ou `"?"` se `bank` não for informado.
- Quando `size` é numérico, o `font-size` do fallback é calculado como
  `Math.round(size * 0.36)` (`BANK_AVATAR_FALLBACK_FONT_RATIO`); com token de `size`, o
  tamanho da fonte vem do CSS Module por breakpoint (`.xs .fallback`, `.md .fallback`, etc.).
- `fallbackBg` define `backgroundColor` inline apenas no modo fallback (não afeta o avatar
  com imagem carregada).

---

## Exemplos

```tsx
import { BankAvatar, BANKS } from '@srm/diamond';

// Básico — resolve "itau" e já carrega o ícone do catálogo interno (sem iconBase)
<BankAvatar bank="itau" />

// Por código BACEN (comum quando o dado vem direto do backend/open finance)
<BankAvatar bank="237" /> // Bradesco — catálogo interno resolve sem config extra

// Por nome livre digitado pelo usuário
<BankAvatar bank="Banco do Brasil" />

// Tamanhos por token
<BankAvatar bank="nubank" size="xs" />
<BankAvatar bank="nubank" size="2xl" />

// Tamanho custom em pixels (fora da escala de tokens)
<BankAvatar bank="stone" size={56} />

// Banco não identificado ou sem SVG no catálogo → cai em fallback de iniciais
<BankAvatar bank="Banco Regional XYZ" fallbackBg="#EEF2FF" />

// Fallback com iniciais forçadas
<BankAvatar fallbackInitials="OT" fallbackBg="#FDE68A" aria-label="Outro banco" />

// Sobrescrevendo o catálogo interno com um CDN próprio (ex.: ícones atualizados)
<BankAvatar bank="itau" iconBase="https://cdn.srmasset.com/banks" />

// Seletor de banco (lista de opções a partir do catálogo BANKS)
<select>
  {BANKS.map((bank) => (
    <option key={bank.value} value={bank.value}>{bank.label}</option>
  ))}
</select>

// Lista de contas conectadas (open finance)
function ContasConectadas({ contas }: { contas: { bacenCode: string; nome: string }[] }) {
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      {contas.map((c) => (
        <BankAvatar key={c.bacenCode} bank={c.bacenCode} aria-label={c.nome} size="lg" />
      ))}
    </div>
  );
}
```

---

## Acessibilidade

- Em ambos os modos (imagem ou fallback), o componente expõe um nome acessível: `aria-label`
  explícito tem prioridade; senão usa o valor bruto de `bank`; senão o texto genérico
  **"Instituição financeira"** (`BANK_AVATAR_DEFAULT_ARIA_LABEL`).
- Modo fallback: o `<div>` externo recebe `role="img"` + `aria-label`; o `<span>` das
  iniciais é `aria-hidden="true"` (é puramente decorativo/redundante ao label).
- Modo imagem: o `alt` da `<img>` recebe o mesmo nome acessível calculado — evite passar
  `bank` como um código cru sem sentido para o usuário (ex.: prefira `aria-label="Bradesco"`
  a deixar o leitor de tela anunciar `"237"`).
- Como o componente não é interativo (não é botão nem link), **não** adicione `tabIndex`
  ou handlers de teclado — se o avatar for clicável, envolva-o em um elemento focável
  (`button`, `Link`) e mantenha o `aria-label` no wrapper, não duplicado.

## Armadilhas comuns

- **Achar que `iconBase` é obrigatório**: não é — o catálogo interno (`BANK_ICON_URLS`)
  já resolve ~83 instituições sem nenhuma configuração. Só use `iconBase` para sobrescrever
  com um CDN próprio ou cobrir bancos fora do catálogo interno. Passá-lo sem necessidade
  (ex.: `iconBase=""`) **desativa** o catálogo interno e força a URL relativa vazia,
  que 404 e cai no fallback — o comportamento oposto do que normalmente se quer.
- **Confundir `bank` com um valor já validado**: a resolução por nome livre usa
  correspondência por substring como último recurso — nomes muito genéricos ou ambíguos
  podem casar com a entrada errada em `NAME_MAP`. Prefira sempre que possível passar o
  código BACEN ou um slug já conhecido.
- **Esperar outras formas além de círculo**: `shape` só aceita `'circle'` hoje — não é um
  enum com mais opções "escondidas".
- **Achar que existe alternância de tema (`theme`)**: ao contrário de outros componentes do
  Diamond, `BankAvatarProps` **não tem** prop `theme`; a aparência (cores de borda/fundo)
  vem inteiramente de tokens CSS globais, então ela já responde ao tema ativo da aplicação
  sem prop extra.
- **Passar `children`**: a prop é omitida do tipo (`Omit<..., 'children'>`) — o conteúdo
  visual é sempre gerenciado internamente (imagem ou iniciais), não é possível injetar
  conteúdo customizado dentro do avatar.
- **Confundir com o antigo `BankIcon`**: o componente `BankIcon` (que vivia em
  `Identity/Avatar/bankIcons.tsx`, com prop `bankSlug`) foi **removido** na consolidação —
  não existe mais como export público. `BankAvatar` (prop `bank`, não `bankSlug`) é o
  único item canônico para avatar de instituição financeira.
