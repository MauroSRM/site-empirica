# TooltipSheet

Botão gatilho em forma de ícone "ⓘ" que abre uma `BottomSheet` (via `SheetContent`) com
conteúdo explicativo — o padrão mobile para "mais informações" sobre um termo, taxa ou
conceito financeiro (ex.: "O que é CDI?"). `TooltipSheetInline` — variante que acopla o
ícone a um rótulo de texto inline (`label + ⓘ`) — é um **export próprio**, definido em seu
próprio arquivo (`TooltipSheetInline.tsx`), não um subcomponente interno do `TooltipSheet`.
Construído sobre `SheetContent` (que por sua vez usa `BottomSheet`), reaproveitando header,
variantes semânticas e footer de ações desse preset.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/TooltipSheet/`
- **Export:** `import { TooltipSheet, TooltipSheetInline } from '@srm/diamond';`
- **Relacionados/Base:** [BottomSheet](./BottomSheet.md) (shell inferior), `SheetContent` (preset de header/footer usado internamente, sem doc própria), [ContentModal](./ContentModal.md) (equivalente desktop)

---

## Quando usar

- Ícone de ajuda contextual ao lado de um label/valor em telas mobile (ex.: "Taxa de
  administração ⓘ", "O que é CDI? ⓘ") que abre uma folha inferior com a explicação.
- Explicações de termos financeiros/regulatórios (CDI, Selic, taxa de saída, come-cotas)
  que exigem mais espaço do que um tooltip simples cabe.
- Quando o conteúdo explicativo precisa, opcionalmente, de uma ação de confirmação
  (`primaryAction`) além de simplesmente fechar — ex.: "Entendi" ou "Ver mais detalhes".
- `TooltipSheetInline` quando o gatilho precisa ficar **colado** a um texto/label existente,
  sem precisar posicionar o ícone manualmente (ex.: dentro de um `<label>` de formulário).

## Quando **não** usar

- Telas **desktop** → prefira [`ContentModal`](./ContentModal.md), que é o equivalente
  desktop do mesmo padrão (aviso/explicação em overlay).
- Confirmação de ação destrutiva ou irreversível (excluir, cancelar resgate) → use
  `ContentModal`/`SheetContent` diretamente com `variant="destructive"` e ambas as ações
  (`primaryAction` + `secondaryAction`), não um tooltip de ajuda.
- Dica curtíssima de uma linha que cabe em um tooltip nativo posicionado (hover) →
  este componente é sempre uma folha inferior de toque, não um popover flutuante.
- Menu de opções ou navegação → não é o propósito deste componente.

---

## Interface

```ts
import type { CSSProperties, ReactNode } from 'react';
import type { SheetContentVariant } from '../SheetContent';

interface TooltipSheetAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive';
}

// Exclui 'destructive' das variantes de SheetContent — sem sentido para um tooltip de ajuda
type TooltipSheetVariant = Exclude<SheetContentVariant, 'destructive'>;
// equivalente a: 'default' | 'info' | 'warning' | 'success' | 'error'

interface TooltipSheetProps {
  title?: string;
  children: ReactNode;                 // corpo da folha (explicação)
  triggerLabel?: string;               // usado só no aria-label do gatilho, se `title` ausente
  variant?: TooltipSheetVariant;       // default: 'default' — repassado ao SheetContent (ícone/cor do header)
  iconSize?: number;                   // default: 16 — tamanho do ícone Info (lucide-react)
  maxHeight?: string;                  // default: '60vh' — repassado ao SheetContent/BottomSheet
  container?: HTMLElement;             // escopa o portal (ex.: moldura de celular em demos)
  className?: string;                  // aplicado ao botão gatilho (ícone)
  primaryAction?: TooltipSheetAction;  // ação primária no footer da folha
  secondaryAction?: TooltipSheetAction;// ação secundária — só relevante junto de primaryAction
  triggerAriaLabel?: string;           // aria-label do gatilho. default: `Mais informações: ${title ?? triggerLabel ?? helpLabel}`
  helpLabel?: string;                  // default: 'ajuda' — fallback do aria-label quando não há title nem triggerLabel
  dismissLabel?: string;               // default: 'Entendi' — label da ação padrão de fechar
}

interface TooltipSheetInlineProps {
  label: ReactNode;       // texto/nó exibido antes do ícone
  title?: string;         // default: label, se label for string
  children: ReactNode;    // corpo da folha
  labelStyle?: CSSProperties; // aplicado ao <span> wrapper (label + ícone)
}
```

### Notas de comportamento

- O gatilho é um `<button type="button">` com ícone `Info` (lucide-react); **não há texto
  visível** — o nome acessível vem do `aria-label`, resolvido em cascata:
  `triggerAriaLabel` explícito → senão `` `Mais informações: ${title ?? triggerLabel ?? helpLabel}` ``
  (`helpLabel` default `'ajuda'`). Passar `triggerAriaLabel` **substitui totalmente** o
  formato `"Mais informações: ..."` — o valor é usado como aria-label puro, sem prefixo.
- **Ação padrão implícita**: se nem `primaryAction` nem `secondaryAction` forem passadas,
  o componente injeta sozinho um botão com o label de `dismissLabel` (default `'Entendi'`,
  `variant` implícito `ghost` via `SheetContent`) que apenas fecha a folha. Se **qualquer
  uma** das duas for passada, esse padrão automático desaparece — nesse caso, se você
  passar só `primaryAction`, a folha fica com **uma única ação** (sem a ação de dispensa
  automática).
- `dismissLabel` só é usado quando nenhuma ação é passada (ação de dispensa automática) —
  se você passar `secondaryAction` manualmente, `dismissLabel` é ignorado (o label vem de
  `secondaryAction.label`).
- `variant` controla o header do `SheetContent` subjacente: `'default'` mostra
  título + X à esquerda; `'info' | 'warning' | 'success' | 'error'` trocam para o header
  centralizado com ícone semântico grande (mesmo vocabulário do `ContentModal`).
- `maxHeight` tem default **`'60vh'`** aqui — menor que o default de `SheetContent`/
  `BottomSheet` (`'80vh'`), porque tooltips tendem a ter conteúdo curto.
- Estado de abertura (`open`) é **interno** — não há prop para controle externo; o
  consumidor não decide quando a folha abre/fecha, só o conteúdo e as ações.
- `TooltipSheetInline` é um **export próprio** (`TooltipSheetInline.tsx`, não um subcomponente
  interno) que renderiza um `<span>` com o `label` seguido de um `TooltipSheet`. Sempre usa
  `iconSize={14}` (menor que o default de `16`) e deriva `title` do `label` quando este for
  uma string simples — se `label` for um `ReactNode` complexo (ex.: `<strong>...</strong>`),
  passe `title` explicitamente. Não expõe `triggerAriaLabel`/`helpLabel`/`dismissLabel` —
  essas props só existem em `TooltipSheetProps`.

---

## Exemplos

```tsx
import { TooltipSheet, TooltipSheetInline } from '@srm/diamond';

// Básico — só título e conteúdo, ação "Entendi" automática
<TooltipSheet title="O que é CDI?">
  <p>
    O CDI é a taxa de referência usada para remunerar aplicações de renda fixa no Brasil.
    Ele acompanha de perto a Taxa Selic.
  </p>
</TooltipSheet>

// dismissLabel customizado na ação padrão de fechar
<TooltipSheet title="Taxa de saída" dismissLabel="Ok, entendi">
  <p>Percentual descontado do resgate conforme o prazo de permanência.</p>
</TooltipSheet>

// aria-label do gatilho customizado (substitui o formato "Mais informações: ...")
<TooltipSheet title="CDI" triggerAriaLabel="Explicação sobre o CDI">
  <p>Taxa de referência para renda fixa no Brasil.</p>
</TooltipSheet>

// Variante semântica com header de ícone (info)
<TooltipSheet title="Come-cotas" variant="info">
  <p>Antecipação semestral do IR sobre fundos de renda fixa e multimercado.</p>
</TooltipSheet>

// Com ação primária customizada (substitui o "Entendi" automático)
<TooltipSheet
  title="Taxa de saída"
  primaryAction={{ label: 'Ver tabela completa', onClick: () => abrirTabela() }}
>
  <p>Percentual descontado do resgate conforme o prazo de permanência.</p>
</TooltipSheet>

// Com duas ações (primária + secundária)
<TooltipSheet
  title="Suitability desatualizado"
  variant="warning"
  primaryAction={{ label: 'Atualizar agora', onClick: () => irParaSuitability() }}
  secondaryAction={{ label: 'Depois', onClick: () => {} }}
>
  <p>Seu perfil de investidor está vencido e pode limitar algumas operações.</p>
</TooltipSheet>

// Escopado a um contêiner (ex.: moldura de demo/celular)
function ExemploComContainer() {
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  return (
    <div ref={setContainer} style={{ position: 'relative', height: 640 }}>
      <TooltipSheet title="Rentabilidade líquida" container={container ?? undefined}>
        <p>Rentabilidade já descontados impostos e taxas.</p>
      </TooltipSheet>
    </div>
  );
}

// TooltipSheetInline — ícone colado a um label de formulário
<label style={{ display: 'inline-flex', alignItems: 'center' }}>
  <TooltipSheetInline label="Valor líquido estimado">
    <p>Valor após dedução de IR e taxa de administração, calculado no momento do resgate.</p>
  </TooltipSheetInline>
</label>

// TooltipSheetInline com label complexo (title explícito obrigatório nesse caso)
<TooltipSheetInline
  label={<strong>Patrimônio sob gestão</strong>}
  title="Patrimônio sob gestão"
  labelStyle={{ fontWeight: 600 }}
>
  <p>Soma de todos os ativos administrados pela gestora na data de referência.</p>
</TooltipSheetInline>
```

---

## Acessibilidade

- O gatilho tem **nome acessível obrigatório e automático** via `aria-label` — garanta que
  `title` (ou ao menos `triggerLabel`) seja sempre descritivo; sem nenhum dos dois, o
  `aria-label` cai para o genérico `"Mais informações: ajuda"` (ou `"Mais informações: <helpLabel>"`
  se `helpLabel` for customizado). Use `triggerAriaLabel` quando precisar de um rótulo
  totalmente diferente do formato `"Mais informações: ..."`.
- O ícone `Info` é `aria-hidden="true"` — toda a semântica está no `aria-label` do botão,
  não no SVG.
- O `SheetContent`/`BottomSheet` subjacente cuida do foco (dialog modal) e do `aria-label`
  do próprio diálogo (`title ?? 'Conteúdo'`) — forneça sempre `title` para um anúncio
  adequado ao abrir.
- Botões de ação (`primaryAction`/`secondaryAction`) herdam foco e ativação por
  teclado/toque do `Button`/`DoubleButton` internos — nenhum tratamento extra necessário.
- Em `TooltipSheetInline`, o `label` visual **não** é automaticamente associado a um
  `<label htmlFor>` de input — se usado ao lado de um campo de formulário, associe o
  campo separadamente (ex.: via `label` do próprio Input, não via este componente).

## Armadilhas comuns

- Passar `primaryAction` **sem perceber** que isso remove o botão de dispensa automático
  (`dismissLabel`, default "Entendi") — se quiser manter a dispensa e adicionar uma ação
  extra, passe as duas (`primaryAction` + `secondaryAction`) explicitamente.
- Passar `dismissLabel` **junto com** `secondaryAction` esperando que ele mude o label da
  ação secundária — `dismissLabel` só afeta a ação de dispensa automática (quando nenhuma
  ação é passada); com `secondaryAction` explícita, o label vem de `secondaryAction.label`.
- Usar em telas desktop — este componente é **mobile-only** (herdado do `SheetContent`/
  `BottomSheet`); em desktop use [`ContentModal`](./ContentModal.md).
- Esquecer `title` (ou `triggerLabel`) — o botão fica com um `aria-label` genérico
  ("ajuda"), pouco útil para leitores de tela.
- Em `TooltipSheetInline` com `label` como elemento (não string), esquecer de passar
  `title` — o dialog abre sem nome acessível descritivo além do genérico `'Conteúdo'`.
- Tentar controlar a abertura/fechamento da folha externamente — não existe prop `isOpen`
  neste componente (diferente de `SheetContent`/`BottomSheet`, que são controlados).
