# Toast

Cartão de notificação individual (sucesso, erro, aviso, informação ou "ai"). Renderiza um
ícone semântico circular, título opcional, mensagem, botão de fechar (ou uma ação custom) e,
quando `autoDismiss` está ativo, uma barra de progresso que fecha o toast sozinha. É o bloco
visual usado internamente pelo `Toastr` para empilhar notificações, mas pode ser renderizado
sozinho quando você só precisa de **um** toast fixo em tela (sem stack/posicionamento).
Construído com CVA (`class-variance-authority`) para as variantes de estilo — não usa
react-aria-components.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Toastr/Toast/`
- **Export:** `import { Toast, useToast } from '@srm/diamond';`
- **Relacionados:** [Toastr](./Toastr.md) (stack/posicionamento de múltiplos toasts)

---

## Quando usar

- Confirmar o resultado de uma ação assíncrona (transferência enviada, cadastro salvo,
  erro de validação de backend, aviso de sessão prestes a expirar).
- Feedback efêmero e não bloqueante — o usuário continua a operar a tela por trás.
- Variante `ai` para respostas/sugestões geradas por funcionalidades de IA do produto
  (usa o ícone do diamante da marca, não um glifo genérico).
- Ação embutida no toast (ex.: "Desfazer") via prop `action`, no lugar do botão de fechar.

## Quando **não** usar

- Múltiplos toasts empilhados, com posicionamento de tela e animação de entrada/saída
  coordenada → use [`Toastr`](./Toastr.md) (que renderiza `Toast` internamente).
- Mensagem que exige confirmação do usuário antes de prosseguir (bloqueante) → use um
  modal/dialog, não `Toast`.
- Mensagem permanente vinculada a um campo de formulário → use `errorText`/`helperText`
  do próprio input (`InputBase`), não um toast.

---

## Interface

```ts
import type { ReactNode } from 'react';

type ToastVariant = 'success' | 'error' | 'warning' | 'info' | 'ai';
type ToastSize = 'sm' | 'md';
type ToastWidth = 'sm' | 'md' | 'lg';

interface ToastAction {
  label: string;
  onClick: () => void;
}

interface ToastProps {
  variant?: ToastVariant;       // default: 'info'
  size?: ToastSize;             // default: 'md'
  width?: ToastWidth;           // sem default — sem valor, ocupa 100% do container
  title?: string;
  message: ReactNode;
  dismissible?: boolean;        // default: true
  autoDismiss?: boolean;        // default: false
  duration?: number;            // default: 5000 (TOAST_AUTO_DISMISS_MS)
  showIcon?: boolean;           // default: true
  onDismiss?: () => void;
  action?: ToastAction;
  dismissLabel?: string;        // aria-label do botão de fechar. default: 'Fechar'
  /**
   * Força pause externo do timer de auto-dismiss (barra de progresso), independente
   * do hover local. @default false — usado pelo Toastr para pausar TODOS os toasts
   * quando o mouse está sobre a pilha (senão só o toast sob o cursor pausaria).
   */
  isPaused?: boolean;
  className?: string;
}

// Registro usado por listas/filas de toasts (ex.: dentro de Toastr)
interface ToastRecord extends Omit<ToastProps, 'onDismiss'> {
  id: string;
}
```

### Semântica de `size` e `width`

- `size="sm"` — 1 linha, **sem título** (ignorado mesmo se `title` for passado pela tela
  consumidora — quem decide omitir é quem monta o objeto, o componente não trunca o `title`
  sozinho), mensagem trunca com ellipsis via CSS.
- `size="md"` (default) — 2+ linhas, título opcional.
- `width`: `'sm'` 320px · `'md'` 480px · `'lg'` 600px. Sem `width`, o toast preenche 100% do
  elemento pai — é o modo esperado quando renderizado solto fora do `Toastr`.

### Ícones por variante (`TOAST_ICONS`)

| variant   | ícone                                  |
|-----------|----------------------------------------|
| `success` | `CheckCircle2` (lucide-react)          |
| `error`   | `XCircle` (lucide-react)               |
| `warning` | `AlertTriangle` (lucide-react)         |
| `info`    | `Info` (lucide-react)                  |
| `ai`      | `LogoIcon` (diamante da marca, `Brand/Logo`) — **nunca** um glifo genérico |

Tamanho do ícone: 20px em `size="md"`, 15px em `size="sm"` (`TOAST_ICON_SIZE` /
`TOAST_ICON_SIZE_SM`).

### Comportamento de `action` vs. botão de fechar

- O botão de fechar só aparece quando `dismissible && !action` (`showClose` interno) — ou
  seja, `action` **sempre** suprime o botão de fechar, mesmo com `dismissible={true}`.
  `action` e o botão "X" são **mutuamente exclusivos**; não há como ter os dois ao mesmo tempo.
- Se `action` for passado, o Toast renderiza um `Button` (`variant="ghost" size="sm"`) com
  `action.label`/`action.onClick` no lugar do botão de fechar.
- Sem `action` e com `dismissible={true}` (default), renderiza um `IconButton` ghost com
  ícone `X` e `aria-label={dismissLabel}` (`dismissLabel` default `'Fechar'`, agora
  customizável via prop).
- Se `dismissible={true}` mas `onDismiss` **não** for passado, o botão de fechar é renderizado
  mesmo assim, só que sem `onPress` — clicar não faz nada. Sempre passe `onDismiss` quando
  `dismissible` estiver ativo.

### Comportamento de `autoDismiss`

- Quando `true`, uma barra de progresso (`role` visual, não anunciada por si só) encolhe de
  100% a 0% ao longo de `duration` ms usando `requestAnimationFrame`; ao chegar a 0, chama
  `onDismiss?.()` automaticamente.
- **Pausa ao passar o mouse** sobre o próprio `Toast` (`onMouseEnter`/`onMouseLeave` no
  container) — o cronômetro retoma de onde parou ao tirar o mouse, sem pular tempo.
- `isPaused` (prop) força a pausa **externamente**, independente do hover local — usado pelo
  `Toastr` para pausar todos os toasts da pilha simultaneamente quando o mouse está sobre a
  área do stack (sem essa prop, só o toast diretamente sob o cursor pausaria, e os demais
  continuariam contando e sumindo por baixo do leque).
- Se `autoDismiss={true}` e `onDismiss` não for passado, o toast conta o tempo e "tenta"
  fechar, mas nada visualmente acontece (não há efeito colateral fora do callback) — sempre
  forneça `onDismiss` junto com `autoDismiss`.

### Acessibilidade do container

- `role`/`aria-live` dependem da `variant`: `error` → `role="alert"` + `aria-live="assertive"`
  (anúncio imediato, interrompe o que o leitor de tela estiver lendo); qualquer outra
  variante (`success`, `warning`, `info`, `ai`) → `role="status"` + `aria-live="polite"`
  (anúncio ao final da leitura atual). Não há prop para sobrescrever esse comportamento —
  é derivado automaticamente de `variant === 'error'`.
- O ícone circular (ou o `LogoIcon` da variante `ai`) é `aria-hidden="true"` (puramente
  decorativo) e só aparece quando `showIcon` (default `true`).

---

## Exemplos

```tsx
import { Toast } from '@srm/diamond';

// Básico — sucesso com título
<Toast
  variant="success"
  title="Transferência enviada"
  message="O comprovante já está disponível no seu histórico."
  onDismiss={() => setOpen(false)}
/>

// Erro, tamanho compacto (sem título)
<Toast
  variant="error"
  size="sm"
  message="Não foi possível concluir a operação."
  onDismiss={() => setOpen(false)}
/>

// Auto-dismiss com barra de progresso (fecha sozinho em 4s)
<Toast
  variant="info"
  message="Sincronizando dados da carteira…"
  autoDismiss
  duration={4000}
  onDismiss={() => setOpen(false)}
/>

// Com ação custom no lugar do botão de fechar
<Toast
  variant="warning"
  title="Ordem parcialmente executada"
  message="30% do volume ainda está em aberto."
  action={{ label: 'Ver detalhes', onClick: () => navigate('/ordens/123') }}
/>

// Variante "ai" — ícone de marca
<Toast
  variant="ai"
  title="Sugestão"
  message="Detectamos uma concentração acima de 20% em um único ativo."
  onDismiss={() => setOpen(false)}
/>

// Largura fixa, sem ícone
<Toast width="sm" showIcon={false} message="Copiado para a área de transferência." onDismiss={() => setOpen(false)} />

// dismissLabel customizado (aria-label do botão de fechar)
<Toast message="Sessão prestes a expirar." dismissLabel="Dispensar aviso" onDismiss={() => setOpen(false)} />
```

### Uso junto com `useToast` (fila simples, sem `Toastr`)

```tsx
import { useToast, Toast } from '@srm/diamond';

function Pagina() {
  const { toasts, addToast, removeToast } = useToast();
  const ultimo = toasts[toasts.length - 1];

  return (
    <>
      <button onClick={() => addToast({ variant: 'success', message: 'Salvo!' })}>
        Salvar
      </button>
      {ultimo && (
        <Toast {...ultimo} onDismiss={() => removeToast(ultimo.id)} />
      )}
    </>
  );
}
```

> Para empilhar **múltiplos** toasts com posicionamento fixo na tela, use
> [`Toastr`](./Toastr.md) — ele já consome `ToastRecord[]` e resolve empilhamento, animação
> de entrada/saída e posição.

---

## Acessibilidade

- `role`/`aria-live` fazem o anúncio automático sem atributo adicional: `error` usa
  `role="alert"` + `aria-live="assertive"` (mais urgente); as demais variantes usam
  `role="status"` + `aria-live="polite"`.
- O botão de fechar tem `aria-label` configurável via `dismissLabel` (default `'Fechar'`).
- `message` aceita `ReactNode` — se usar markup rico (links, negrito), garanta que o
  conteúdo continue com um texto acessível equivalente.
- Toasts que se autodestroem (`autoDismiss`) devem sempre ter uma forma alternativa de
  o usuário revisitar a informação (histórico, notificações), pois leitores de tela podem
  não ler a tempo em telas com foco em outro lugar.

## Armadilhas comuns

- Passar `dismissible={true}` (ou deixar o default) sem `onDismiss` — o "X" aparece mas não
  faz nada.
- Passar `autoDismiss` sem `onDismiss` — a barra de progresso anima e zera, mas o toast
  nunca some (quem remove do estado é sempre o consumidor, via `onDismiss`).
- Esperar que `action` e o botão de fechar coexistam — são mutuamente exclusivos.
- Usar `Toast` solto para múltiplas notificações simultâneas — sem `Toastr` você mesmo
  precisa resolver empilhamento e posição; prefira `Toastr` nesse cenário.
- Usar ícone genérico para a variante `ai` — o design system já injeta o `LogoIcon` da
  marca; não sobrescreva com `showIcon={false}` + ícone custom fora do padrão.
- Passar `isPaused` esperando que ele controle o auto-dismiss por conta própria — ele só
  força a pausa (soma-se ao hover local); não existe um "retomar" externo equivalente além
  de voltar `isPaused` para `false`.
- Esperar `role="alert"` em toasts que não sejam `variant="error"` — apenas essa variante
  usa `alert`/`assertive`; as demais (incluindo `warning`) usam `status`/`polite`.
