# TrendIndicator

Indicador atômico de **performance de números comparativos**: ícone direcional colorido
(seta para cima/baixo ou traço neutro) + delta principal (`label`) + contexto secundário
opcional (`suffix`). Não busca dado nem calcula variação — é puramente apresentacional.
Construído sobre o átomo `Icon` (que resolve os ícones `trending-up`/`trending-down`/`minus`
do `lucide-react` por nome), com `size`/`layout` aplicados via atributos `data-*` no CSS
Module (sem `class-variance-authority`) e cor semântica injetada por CSS var
(`--trend-color`) setada em JS conforme a `direction`.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/TrendIndicator/`
- **Export:** `import { TrendIndicator } from '@srm/diamond';`
- **Relacionados:** usado internamente pelo `BalanceCard` (prop `trend`/`trendLabel`) para
  indicar variação de saldo vs. período anterior.

---

## Quando usar

- Ao lado de um KPI, saldo ou valor consolidado, para indicar variação vs. um baseline
  (mês anterior, dia anterior, período customizado): ex. `+3,2% vs. mês anterior`.
- Em cards de resumo financeiro (saldo total, patrimônio, rentabilidade) onde a direção
  da variação (alta/baixa/estável) é informação relevante à primeira leitura.
- Quando só o ícone direcional já comunica o suficiente (omita `label`/`suffix`).

## Quando **não** usar

- Valor sem baseline comparativo (é métrica pura, não tendência) → use `Tag` ou texto simples.
- Múltiplos períodos lado a lado para comparação → use tabela ou gráfico, não vários
  `TrendIndicator` empilhados horizontalmente.
- Necessidade de interação (clique para expandir detalhe da variação) → `TrendIndicator`
  não é interativo; envolva-o você mesmo em um elemento clicável se precisar disso.

---

## Interface

```ts
type TrendDirection = 'up' | 'down' | 'neutral' | 'none';
type TrendIndicatorSize = 'sm' | 'md' | 'lg';
type TrendIndicatorLayout = 'inline' | 'stacked';

interface TrendIndicatorProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  direction: TrendDirection;        // obrigatório — sem default
  label?: string;                   // delta principal (ex.: "+3,2%"). Sem ele, só o ícone aparece.
  suffix?: string;                  // texto secundário (ex.: "vs. mês anterior")
  size?: TrendIndicatorSize;        // default: 'md'
  layout?: TrendIndicatorLayout;    // default: 'inline'
  className?: string;
  style?: CSSProperties;
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children): id, aria-*, onClick, ...
}
```

### Notas de comportamento

- `direction` é a única prop obrigatória. Não tem valor default — precisa ser sempre informada
  pelo consumidor (normalmente calculada a partir do sinal do delta).
- Mapeamento ícone/cor por `direction` (fixo em `DIRECTION_ICON`/`DIRECTION_COLOR` no TSX,
  **não** configurável por prop):

  | `direction` | Ícone (lucide)  | Cor (`--trend-color`)   |
  |-------------|-----------------|-------------------------|
  | `up`        | `TrendingUp`    | `var(--success-default)` |
  | `down`      | `TrendingDown`  | `var(--error-strong)`    |
  | `neutral`   | `Minus`         | `var(--text-tertiary)`   |
  | `none`      | `Minus`         | `var(--text-secondary)`  |

  `neutral` e `none` usam o mesmo ícone (traço), diferindo só na cor — use `neutral` para
  "variação zero/estável" com leitura discreta, e `none` quando não há semântica de
  tendência alguma a comunicar (cor ainda mais neutra).
- Tamanho de ícone por `size` (`ICON_SIZE_MAP`): `sm` = 11px, `md` = 13px, `lg` = 15px.
  Tipografia acompanha via atributo `data-size` consumido pelo SCSS: `sm` → `--text-10`,
  `md` → `--text-11`, `lg` → `--text-13`.
- `layout="stacked"` empilha `suffix` abaixo do `label` (útil quando o suffix é longo e
  quebraria o layout inline); `layout="inline"` (default) mantém tudo na mesma linha.
- Sem `label` e sem `suffix`, renderiza **só o ícone** — útil como indicador visual compacto
  em células de tabela densas.
- `direction` não é resolvido por classe (não há CVA neste componente) — a cor muda via JS
  (CSS var `--trend-color` no `style` inline do elemento raiz); o SCSS só consome a var.
- O componente é `memo`izado — evite recriar `style`/objetos inline desnecessariamente em
  loops de renderização (ex.: listas grandes de KPIs).
- `{...rest}` repassa qualquer atributo HTML nativo de `div` (ex.: `id`, `data-*`, `onClick`)
  para o elemento raiz.

---

## Exemplos

```tsx
import { TrendIndicator } from '@srm/diamond';

// Básico — alta, com label e suffix
<TrendIndicator direction="up" label="+3,2%" suffix="vs. mês anterior" />

// Queda
<TrendIndicator direction="down" label="-1,8%" suffix="no dia" />

// Estável (sem variação relevante)
<TrendIndicator direction="neutral" label="0,0%" suffix="vs. mês anterior" />

// Sem semântica de tendência (cor mais neutra que "neutral")
<TrendIndicator direction="none" label="—" />

// Só o ícone (sem label nem suffix) — ex.: célula compacta de tabela
<TrendIndicator direction="up" />

// Tamanho grande — quando o próprio delta é o dado principal
<TrendIndicator direction="up" size="lg" label="+12,4%" suffix="YTD" />

// Layout empilhado — suffix longo, abaixo do label
<TrendIndicator
  direction="down"
  layout="stacked"
  label="-0,6%"
  suffix="vs. benchmark CDI no período"
/>

// Uso real: dentro do BalanceCard (variant "consolidated")
<BalanceCard
  variant="consolidated"
  balance="R$ 1.968.975,72"
  balanceLabel="Total consolidado"
  accountCount={2}
  trend="up"
  trendLabel="+3,2% no mês"
  accounts={[
    { label: 'SRM Asset', value: 'R$ 1.245.860,32' },
    { label: 'Open Finance', value: 'R$ 723.115,40' },
  ]}
/>
```

---

## Acessibilidade

- O ícone é `aria-hidden` — não carrega semântica própria; a informação textual precisa
  estar no `label`/`suffix` (ou em texto adjacente) para ser lida por leitores de tela.
- O componente não define `role` nem `aria-label` próprios: se usado sem `label`/`suffix`
  (só ícone) em um contexto onde a direção é informação relevante e não redundante com
  texto ao redor, adicione você mesmo um `aria-label` (ex.: `aria-label="Em alta"`) via
  `{...rest}`.
- Cor não é o único veículo da informação: o ícone direcional (seta para cima/baixo/traço)
  já reforça a semântica para quem não distingue verde/vermelho — mantenha sempre o ícone
  visível, não o remova por CSS.

## Armadilhas comuns

- Não confunda `neutral` com `none`: `neutral` é semanticamente "estável" (cor terciária,
  ainda ligada à ideia de tendência); `none` é "sem tendência a comunicar" (cor secundária,
  mais apagada). Escolher o errado passa a mensagem errada ao usuário.
- `direction` não tem default — sempre calcule-a explicitamente a partir do sinal do valor
  (`up`/`down`/`neutral`), nunca deixe um estado indefinido chegar ao componente.
- `label` e `suffix` são `string`, não number — formate o delta (`+3,2%`, `-1,8%`) antes de
  passar; o componente não formata nem adiciona sinal automaticamente.
- Empilhar vários `TrendIndicator` lado a lado para comparar múltiplos períodos é abuso do
  componente — prefira tabela ou gráfico dedicado nesse caso.
- Cor e ícone (`up`/`down`/`neutral`/`none`) não são customizáveis por prop além da escolha
  de `direction` — não tente sobrescrever `--trend-color` via `className` para casos fora
  do vocabulário semântico definido (isso quebra a consistência do DS).
