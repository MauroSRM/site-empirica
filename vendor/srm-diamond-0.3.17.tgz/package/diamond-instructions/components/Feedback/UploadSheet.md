# UploadSheet

Bottom sheet mobile-only para envio de documentos (comprovantes, contratos, selfies com
documento etc.), com uma área de toque para seleção de arquivo, chips removíveis por
arquivo selecionado e um rodapé de ações "Confirmar/Cancelar" que só habilita a ação
primária depois que pelo menos um arquivo é escolhido. É um preset pronto sobre
[`SheetContent`](./SheetContent.md) (que por sua vez usa `BottomSheet`) combinado com
`UploadAreaMobile` (dropzone touch-first do módulo Forms).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/UploadSheet/`
- **Export:** `import { UploadSheet } from '@srm/diamond';` (barrel também reexporta o tipo
  `UploadSheetProps` a partir de `UploadSheet.types.ts`)
- **Relacionados/Base:** [SheetContent](./SheetContent.md) (shell de bottom sheet com header/footer),
  `UploadAreaMobile` (`src/components/Forms/UploadAreaMobile/`, dropzone interna — hoje um wrapper
  fino sobre `FileUpload` com `layout="mobile"`; ambos **são** exportados no barrel público),
  [BottomSheet](./BottomSheet.md) (base de mais baixo nível)

---

## Quando usar

- Fluxos mobile de envio de documento avulso: comprovante de residência, selfie com
  documento, contrato assinado, extrato para conciliação.
- Quando o upload precisa acontecer dentro de um sheet modal (não embutido na página),
  com confirmação explícita antes de prosseguir (ex.: KYC, onboarding, disputas).
- Casos de **um único arquivo por vez** (`multiple=false`, padrão) ou de **múltiplos
  arquivos acumulados** (`multiple=true`), com validação de tamanho máximo por arquivo.

## Quando **não** usar

- Em desktop — o componente é **mobile-only** (herda o comentário de `SheetContent`:
  "nunca usar em desktop"); no desktop o padrão equivalente é
  [`ContentModal`](./ContentModal.md) compondo a dropzone diretamente.
- Upload embutido no layout da página, sem overlay/sheet → use `UploadAreaMobile`
  (ou `FileUpload` com `layout="desktop"`) diretamente, sem o wrapper de sheet.
- Visualização de um documento já enviado (preview de PDF/imagem) → use
  [`DocumentViewer`](./DocumentViewer.md).
- Sheets genéricos de confirmação/feedback sem upload → use
  [`SheetContent`](./SheetContent.md) diretamente.

---

## Interface

```ts
export interface UploadSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onFiles?: (files: File[]) => void;
  title?: string;                          // default: 'Enviar documentos'
  subtitle?: string;
  accept?: string;                         // ex.: 'application/pdf,image/jpeg,image/png'
  multiple?: boolean;                      // default: false
  hint?: string;                           // sobrescreve o texto auxiliar calculado
  maxSizeMB?: number;                      // default: 10
  primaryLabel?: string;                   // default: 'Confirmar'
  onConfirm?: (files: File[]) => void;
  confirmLoading?: boolean;                // default: false
  container?: HTMLElement | null;          // portal (ex.: moldura de celular em demo)
}
```

### Comportamentos não óbvios

- **Estado de arquivos é interno.** `UploadSheet` guarda `files` em `useState` próprio —
  não é um componente controlado. `onFiles` é chamado a cada seleção/remoção só como
  notificação; para ler os arquivos escolhidos, use o próprio `onFiles` ou o argumento
  recebido em `onConfirm`.
- **A ação primária só aparece quando há arquivo(s).** Enquanto `files.length === 0`,
  `primaryAction` é `undefined` e o `SheetContent` renderiza **apenas** o botão
  "Cancelar" (ghost, full width). Assim que o primeiro arquivo é selecionado, o footer
  vira um `DoubleButton` vertical (`pair="primary-ghost"`) com `primaryLabel` habilitado.
  Veja o teste do componente, que trava exatamente esse contrato:
  `UploadSheet.test.tsx` — busca o botão "Confirmar" e espera `not.toBeInTheDocument()`
  antes de qualquer seleção.
- **`onConfirm` não fecha o sheet sozinho.** É o `onClick` do botão primário; quem decide
  fechar o sheet (chamando `onClose`) é o código consumidor, dentro do próprio `onConfirm`.
- **`multiple`** controla acumulação: com `multiple=true`, cada nova seleção é
  **concatenada** à lista existente (`[...files, ...novos]`); com `multiple=false`
  (padrão), cada seleção **substitui** a anterior.
- **Validação é só de tamanho, não de tipo.** `maxSizeMB` (repassado a `UploadAreaMobile`)
  rejeita arquivo individualmente maior que o limite e mostra estado de erro inline
  ("Arquivo muito grande. Máximo: XMB.") na própria área de upload — não usa
  `errorText`/`state="error"` do `SheetContent`. `accept` só restringe o seletor nativo
  do sistema operacional; nada impede, no código, que um arquivo de outro MIME chegue
  em `onFiles`/`onConfirm` se o usuário forçar via drag-and-drop de outro app.
- **`hint` tem cálculo padrão.** Se `hint` não for passado, o texto auxiliar exibido é
  `` `${accept ?? 'PDF, JPG ou PNG'} · Máximo ${maxSizeMB}MB` ``. Ou seja, se você
  informar `accept` mas não `hint`, o valor de `accept` aparece literalmente no texto
  (ex.: `accept="application/pdf"` produz "application/pdf · Máximo 10MB" — prefira
  passar `hint` explícito com texto amigável nesse caso).
- **`container`** é repassado ao `SheetContent`/`BottomSheet` para portalizar o sheet
  dentro de um elemento específico (útil em Storybook/demos com moldura de celular);
  em produção normalmente se omite e o portal cai no `document.body`.
- **Sheet é dismissível por padrão** (tap fora / arrastar para fechar) — `UploadSheet`
  não expõe `dismissible`, então o comportamento do `SheetContent` (`dismissible: true`)
  não pode ser desligado através deste wrapper.
- O `title` (mesmo com o default `'Enviar documentos'`) também vira o `aria-label` do
  `BottomSheet` subjacente.

---

## Exemplos

```tsx
import { useState } from 'react';
import { UploadSheet, Button } from '@srm/diamond';

// Básico — single file
function EnviarComprovante() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onPress={() => setIsOpen(true)}>Enviar comprovante</Button>
      <UploadSheet
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Enviar comprovante"
        subtitle="Formatos aceitos: PDF, JPG ou PNG."
        accept="application/pdf,image/jpeg,image/png"
        onConfirm={(files) => {
          // enviar files[0] para a API
          setIsOpen(false);
        }}
      />
    </>
  );
}

// Múltiplos arquivos, com loading no confirm
function EnviarDocumentos() {
  const [isOpen, setIsOpen] = useState(false);
  const [enviando, setEnviando] = useState(false);

  const handleConfirm = async (files: File[]) => {
    setEnviando(true);
    await enviarArquivos(files);
    setEnviando(false);
    setIsOpen(false);
  };

  return (
    <UploadSheet
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      multiple
      maxSizeMB={5}
      hint="Até 5MB por arquivo · PDF, JPG ou PNG"
      primaryLabel="Enviar"
      confirmLoading={enviando}
      onConfirm={handleConfirm}
    />
  );
}

// Container escopado (demo em moldura de celular)
function DemoMobile() {
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div ref={setContainer} style={{ position: 'relative', width: 390, height: 760 }}>
      <Button onPress={() => setIsOpen(true)}>Abrir upload</Button>
      <UploadSheet
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        container={container ?? undefined}
        onConfirm={() => setIsOpen(false)}
      />
    </div>
  );
}
```

---

## Acessibilidade

- O `title` alimenta o `aria-label` do `BottomSheet` subjacente — evite deixar sem
  `title` em fluxos onde o default genérico ("Enviar documentos") não descreve o
  contexto real (ex.: prefira `title="Enviar comprovante de residência"`).
- A área de toque é um `DropZone`/`FileTrigger`/`Button` reais do `react-aria-components`
  (via `FileUpload` com `layout="mobile"`) — semântica de botão nativa, focável por
  teclado e ativável por Enter/Espaço sem código customizado. O `aria-label` do `DropZone`
  vem de `dropzoneLabel` (se passado), senão do `label` (se string), senão cai no fallback
  `"Área de upload. Toque para selecionar arquivos."` — como `UploadSheet` não expõe nem
  `label` nem `dropzoneLabel` para `UploadAreaMobile`, o fallback genérico é sempre o usado.
- Cada arquivo selecionado aparece como `Chip` removível com `removeLabel` dinâmico
  (`"Remover <nome-do-arquivo>"`), garantindo nome acessível por item na remoção.
- O botão de fechar (`X`) do header tem `aria-label="Fechar"` fixo, herdado do
  `SheetContent`.

## Armadilhas comuns

- **Não** espere `UploadSheet` reabrir "limpo": o estado `files` não é resetado
  automaticamente quando `isOpen` volta a `true` depois de fechado — se precisar
  garantir uma sessão de upload em branco a cada abertura, remonte o componente
  (`key` prop) ou controle isso fora, limpando o estado do lado consumidor.
- **Não** confie em `accept` como validação de tipo de arquivo — é apenas um filtro do
  seletor nativo; valide o `type`/extensão no seu `onConfirm` se isso for crítico.
- Lembre-se de chamar `onClose` dentro do seu `onConfirm` (ou depois de um `await` bem
  sucedido) — o componente não fecha sozinho após confirmar.
- Ao passar `accept` sem passar `hint`, o texto auxiliar exibirá o valor bruto de
  `accept` (ex.: MIME types) para o usuário final — normalmente você quer fornecer
  `hint` com uma descrição amigável.
- É mobile-only (bottom sheet); não use em telas desktop.
