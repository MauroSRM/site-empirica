# RequirementsChecklist

Lista de requisitos/etapas com status semântico (concluído, atual, pendente, erro, alerta),
progresso agregado opcional e itens clicáveis. Usado em fluxos de onboarding, abertura de
conta, compliance e KYC para mostrar o que falta para completar um cadastro. Não é
construído sobre `react-aria-components` — é um componente de apresentação interno,
renderizado como lista semântica (`<ul>`/`<li>`), que compõe o `Icon` do próprio Diamond
duas vezes por item: um badge circular com cor semântica de status, e um chevron
puramente decorativo (não é mais um `IconButton` — evita botão aninhado dentro do
`<button>` do item).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/RequirementsChecklist/`
- **Export:** `import { RequirementsChecklist } from '@srm/diamond';` (tipos
  `RequirementsChecklistProps`, `RequirementItemData`, `RequirementStatus` também
  exportados pelo barrel)
- **Relacionados:** `Icon` (badge de status e chevron decorativo)

---

## Quando usar

- Checklist de documentos para abertura de conta (RG, comprovante de residência,
  comprovante de renda, contrato social, selfie de verificação).
- Etapas de um cadastro/onboarding em que cada etapa tem um status independente
  (concluída, em análise, pendente, com erro).
- Checklist de compliance/KYC com itens que podem falhar (`error`) ou vencer em breve
  (`warning`), além dos itens simplesmente concluídos ou pendentes.
- Quando cada etapa pode ser navegável (ex.: voltar para editar uma etapa já enviada)
  usando `onClick`.

## Quando **não** usar

- Progresso linear de um wizard com uma etapa "atual" única e navegação sequencial →
  prefira um componente de `Stepper` dedicado, se existir no projeto.
- Uma única barra de progresso sem lista de itens → use um componente de progresso isolado
  (o `RequirementsChecklist` sempre renderiza uma lista de itens).
- Notificação pontual de sucesso/erro sem lista associada → use `Callout` ou `Toastr`.

---

## Interface

```ts
export type RequirementStatus = 'ok' | 'current' | 'pending' | 'error' | 'warning';

export interface RequirementItemData {
  label: string;
  hint?: string;
  status?: RequirementStatus;   // default efetivo: 'pending' (aplicado item a item)
  onClick?: () => void;         // presença define o item como potencialmente clicável
}

export interface RequirementsChecklistProps {
  items?: RequirementItemData[];   // default: []
  title?: string;
  showProgress?: boolean;          // default: false
  progressSize?: 'sm' | 'lg';      // default: 'sm'
}
```

Este componente **não** herda de `InputBaseProps`/`AriaButtonProps` — é 100% próprio,
sem passthrough de props externas. Não há `className` na raiz nem `ref` encaminhado.

### Mapeamento status → ícone (`STATUS_ICON_TYPE`, em `RequirementsChecklist.constants.ts`)

| `status`  | `Icon type` | Glifo custom | Significado visual                              |
|-----------|-------------|--------------|--------------------------------------------------|
| `ok`      | `success`   | —            | Concluído.                                        |
| `current` | `accent`    | —            | Etapa atual.                                      |
| `pending` | `default`   | `clock`      | Ainda não iniciado.                               |
| `error`   | `error`     | —            | Falhou/precisa reenvio.                           |
| `warning` | `warning`   | —            | Atenção (ex.: vence em breve).                    |

Quando o item está bloqueado (ver abaixo), o mapeamento de `STATUS_ICON_TYPE` é
**substituído** por `{ type: 'default', icon: 'lock' }`, independente do `status` original.

### Semântica de lista e `data-status`

- A lista é renderizada como `<ul className={styles.list}>` com um `<li>` por item —
  cada `<li>` carrega `data-status={status}` (o status efetivo, com fallback `'pending'`).
- Estilos visuais por status (opacidade do `ok`, destaque do `current`, cor de borda de
  `error`/`warning`) são resolvidos via CVA (`requirementItemVariants`) aplicada ao
  conteúdo do `<li>` (ao `<button>` quando clicável, ou diretamente ao `<li>` quando
  estático).

### Comportamento de clique e bloqueio (não-óbvio)

- Um item só é **potencialmente clicável** se tiver `onClick` definido.
- Mesmo com `onClick`, um item com `status="pending"` é **forçado a desabilitado**
  (`isDisabled = isInteractive && status === 'pending'`) — ele troca o ícone para
  `type="default"` com glifo `lock` (cadeado) e o `<li>` renderiza o conteúdo **sem**
  `<button>` (elemento estático), sem `styles.itemClickable`.
- Só vira `<button type="button">` real (único elemento interativo, sem botão aninhado)
  quando `onClick` existe **e** `status` é diferente de `pending` (`ok`, `current`,
  `error` ou `warning`).
- Itens sem `onClick` (independente do `status`) nunca renderizam `<button>`.
- Todo item clicável renderiza, ao final do conteúdo, um `Icon icon="chevron-right"`
  **puramente decorativo** (sem `circle`, `size={16}`) — não é mais um `IconButton`; é
  um ícone simples sem semântica de botão aninhado. O clique é tratado pelo `onClick` do
  `<button>` pai.

### Barra de progresso (`showProgress`)

- Só é renderizada se `showProgress={true}` **e** `items.length > 0`.
- `done` = quantidade de itens com `status === 'ok'` (demais status não contam).
- `pct = Math.round((done / items.length) * 100)`.
- Cabeçalho mostra `"{done} de {items.length} concluídos"` à esquerda e `"{pct}%"` à direita.
- Quando `pct === 100`, a barra e o texto de percentual mudam para a cor de sucesso
  (`--feedback-success`); abaixo de 100% usam a cor de marca (`--brand-primary`).
- `progressSize` controla apenas a altura da trilha (via `progressTrackVariants`, CVA):
  `sm` = 6px, `lg` = 14px.

---

## Exemplos

```tsx
import { RequirementsChecklist } from '@srm/diamond';

// Básico, sem progresso
<RequirementsChecklist
  title="Documentos para abertura de conta"
  items={[
    { label: 'Documento de identidade', hint: 'Enviado em 02/07/2026', status: 'ok' },
    { label: 'Comprovante de residência', hint: 'Enviado em 02/07/2026', status: 'ok' },
    { label: 'Comprovante de renda', hint: 'Em análise', status: 'current' },
    { label: 'Contrato social', status: 'pending' },
    { label: 'Selfie de verificação', status: 'pending' },
  ]}
/>

// Com barra de progresso
<RequirementsChecklist
  title="Documentos para abertura de conta"
  showProgress
  progressSize="sm"
  items={[
    { label: 'Documento de identidade', status: 'ok' },
    { label: 'Comprovante de residência', status: 'ok' },
    { label: 'Comprovante de renda', status: 'current' },
    { label: 'Contrato social', status: 'pending' },
  ]}
/>

// Erro e alerta (checklist de compliance)
<RequirementsChecklist
  title="Checklist de compliance"
  showProgress
  items={[
    { label: 'Cadastro de sócios', status: 'ok' },
    { label: 'Documento de identidade', hint: 'Foto ilegível — reenvie', status: 'error' },
    { label: 'Comprovante de endereço', hint: 'Vence em 5 dias', status: 'warning' },
    { label: 'Procuração', status: 'pending' },
  ]}
/>

// Itens clicáveis (navegar para revisar/editar uma etapa já enviada)
// Observação: itens com status "pending" continuam bloqueados (cadeado),
// mesmo passando onClick — só os demais status ficam efetivamente clicáveis.
<RequirementsChecklist
  title="Etapas do cadastro"
  showProgress
  items={[
    { label: 'Dados pessoais', status: 'ok', onClick: () => router.push('/cadastro/dados') },
    { label: 'Endereço', status: 'ok', onClick: () => router.push('/cadastro/endereco') },
    { label: 'Documento de identidade', hint: 'Foto ilegível — reenvie', status: 'error', onClick: () => router.push('/cadastro/documento') },
    { label: 'Comprovante de renda', hint: 'Em análise', status: 'current', onClick: () => router.push('/cadastro/renda') },
    { label: 'Contrato social', status: 'pending', onClick: () => router.push('/cadastro/contrato') }, // fica bloqueado
  ]}
/>

// Progresso completo (100%) — barra e percentual mudam para verde
<RequirementsChecklist
  title="Cadastro finalizado"
  showProgress
  progressSize="lg"
  items={[
    { label: 'Dados pessoais', status: 'ok' },
    { label: 'Documento de identidade', status: 'ok' },
    { label: 'Selfie de verificação', status: 'ok' },
  ]}
/>
```

---

## Acessibilidade

- A lista é semântica: `<ul>` com um `<li role="listitem">` por requisito — leitores de
  tela anunciam corretamente a quantidade de itens e a posição de cada um.
- Itens clicáveis são um **único** `<button type="button">` por item (sem botão
  aninhado) — recebem foco de teclado e disparam por Enter/Espaço nativamente.
- O ícone de chevron dentro do botão é **puramente decorativo** (não é mais um
  `IconButton` — é um `Icon` simples sem role de botão); o nome acessível do item vem do
  texto (`label`/`hint`) dentro do próprio `<button>`.
- Itens bloqueados (`onClick` + `status="pending"`) são renderizados sem `<button>`
  (conteúdo estático dentro do `<li>`) — não há foco nem anúncio de "desabilitado"; o
  cadeado é apenas visual. Se a semântica de "bloqueado" precisar ser anunciada a
  leitores de tela, complemente com texto no `hint` (ex.: "Disponível após envio
  do documento anterior").
- O status de cada item também é exposto via `data-status` no `<li>` — útil para seletores
  de teste (`[data-status="error"]`) e para QA visual, mas não substitui a leitura por
  `label`/`hint`.
- O ícone de status é decorativo por si — o significado semântico do estado deve
  estar refletido em `label`/`hint` (ex.: "Foto ilegível — reenvie"), não apenas na cor/ícone.
- A barra de progresso é texto simples (`"X de Y concluídos"` + `"Z%"`), não um
  elemento `role="progressbar"` — não espere anúncio automático de progresso por
  leitores de tela além do texto visível.

## Armadilhas comuns

- Passar `onClick` em um item com `status="pending"` **não** o torna clicável — ele
  é forçado a estado bloqueado com ícone de cadeado e sem `<button>`. Se a etapa deveria
  ser navegável desde o início, use outro `status` (ex.: `current`).
- `showProgress` sem itens (`items=[]`) não renderiza nada — não é necessário
  esconder a prop manualmente nesse caso, mas também não espere um "0%" visível.
- `done`/`pct` só contam `status === 'ok'`; itens `current`, `warning` ou `error`
  não entram no cálculo de progresso mesmo que representem trabalho parcialmente feito.
- O componente não expõe `className` nem `ref` — para ajustes de espaçamento externo,
  envolva em um container próprio.
- `progressSize` só existe visualmente quando `showProgress={true}` (nas stories,
  o controle já vem condicionado a isso) — defini-lo sem `showProgress` não tem efeito.
- Não busque mais um `REQUIREMENT_ICON` ou `IconButton` no código-fonte — o mapeamento de
  ícone por status agora é `STATUS_ICON_TYPE` (em `RequirementsChecklist.constants.ts`) e
  o chevron é um `Icon` decorativo simples.
