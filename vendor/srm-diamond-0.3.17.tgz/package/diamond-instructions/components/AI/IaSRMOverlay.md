# IaSRMOverlay

Modal centralizado do assistente — a view "ampliada" do
[`IaSRMDrawer`](./IaSRMDrawer.md). Mesma base React Aria
(`ModalOverlay` / `Modal` / `Dialog`), então portal, focus trap, restauração de foco,
dismiss por ESC e clique-fora, scroll lock e isolamento do conteúdo externo vêm da
biblioteca.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMOverlay/`
- **Export:** `import { IaSRMOverlay } from '@srm/diamond';`
- **Relacionados:** [IaSRMDrawer](./IaSRMDrawer.md) (view reduzida), [PanelHeader](./PanelHeader.md) (o header), [IaSRMConversationFeed](./IaSRMConversationFeed.md) (body típico), [IaSRMTray](./IaSRMTray.md) (slot `tray`), [Modal](../Feedback/Modal.md) (modal genérico do DS)

---

## Quando usar

- Quando a conversa precisa de área ampla: análise longa, tabela, gráfico, comparação.
- Como destino de `onExpand` do [`IaSRMDrawer`](./IaSRMDrawer.md), e com `onMinimize` para voltar.
- Quando o foco total do usuário na conversa é desejável.

## Quando **não** usar

- Quando o usuário precisa ver a página atrás → [`IaSRMDrawer`](./IaSRMDrawer.md).
- Diálogo genérico de confirmação/formulário → [`Modal`](../Feedback/Modal.md) ou [`ContentModal`](../Feedback/ContentModal.md).
- Conteúdo curto — o painel tem altura grande e ficaria vazio.

---

## Interface

```ts
import type { ReactNode } from 'react';

interface IaSRMOverlayProps {
  isOpen: boolean;
  onClose: () => void;                          // X, ESC ou backdrop
  onOpenChange?: (isOpen: boolean) => void;     // toda mudança de estado
  label: ReactNode;                             // OBRIGATÓRIO — nomeia o diálogo
  subtitle?: ReactNode;
  avatar?: ReactNode | null;                    // null remove o slot
  tone?: 'default' | 'brand';                   // tom do header; default 'default'
  headerActions?: ReactNode;                    // ações extras, antes dos botões padrão
  onMinimize?: () => void;                      // sem handler, botão não renderiza
  showCloseButton?: boolean;                    // default: true
  closeAriaLabel?: string;                      // default: 'Fechar'
  minimizeAriaLabel?: string;                   // default: 'Diminuir'
  isDismissable?: boolean;                      // clique fora fecha; default true
  isKeyboardDismissDisabled?: boolean;          // desliga ESC; default false
  children?: ReactNode;                         // body
  tray?: ReactNode;                             // rodapé fixo
  className?: string;                           // painel
  overlayClassName?: string;                    // scrim/backdrop
}
```

### Notas de comportamento

- **`label` é obrigatório**, pelo mesmo motivo do Drawer: o nome acessível do diálogo vem do `Heading slot="title"` do [`PanelHeader`](./PanelHeader.md).
- Não expõe `onExpand` — o overlay já é a view ampliada. A transição de volta é `onMinimize`.
- Dimensões via tokens `--iasrm-overlay-*`: 60vw de largura, `calc(100vh - 80px)` de altura com teto de 860px; vira tela cheia sem radius abaixo de 768px.
- Animação por `[data-entering]`/`[data-exiting]` (fade no scrim + zoom suave no painel), em CSS. Respeita `prefers-reduced-motion`.
- `className` mira o **painel**; `overlayClassName` mira o **scrim**.
- Todo o resto (dismiss, ações opt-in, slots) se comporta como no [`IaSRMDrawer`](./IaSRMDrawer.md).

---

## Exemplos

```tsx
import { IaSRMOverlay, IaSRMConversationFeed, IaSRMTray } from '@srm/diamond';

// Mínimo
<IaSRMOverlay isOpen={open} onClose={close} label="Assistente">
  <MeuConteudo />
</IaSRMOverlay>

// Conversa completa, com volta pro drawer
<IaSRMOverlay
  isOpen={open}
  onClose={close}
  label="Assistente"
  subtitle="Online agora"
  onMinimize={() => transitionToDrawer()}
  tray={<IaSRMTray onSend={sendMessage}>{contextualUI}</IaSRMTray>}
>
  <IaSRMConversationFeed messages={messages} thinking={isPending} userInitials="LO" />
</IaSRMOverlay>

// Par drawer ↔ overlay
const [view, setView] = useState<'closed' | 'drawer' | 'overlay'>('closed');

<IaSRMDrawer
  isOpen={view === 'drawer'}
  onClose={() => setView('closed')}
  onExpand={() => setView('overlay')}
  label="Assistente"
>
  …
</IaSRMDrawer>

<IaSRMOverlay
  isOpen={view === 'overlay'}
  onClose={() => setView('closed')}
  onMinimize={() => setView('drawer')}
  label="Assistente"
>
  …
</IaSRMOverlay>

// Fluxo que não pode ser abandonado
<IaSRMOverlay
  isOpen={open}
  onClose={close}
  label="Autorização"
  isDismissable={false}
  isKeyboardDismissDisabled
  showCloseButton={false}
>
  <FluxoDeAutorizacao />
</IaSRMOverlay>
```

---

## Acessibilidade

Idêntica ao [`IaSRMDrawer`](./IaSRMDrawer.md), pela base compartilhada:

- `role="dialog"` com nome acessível vindo do heading do header.
- Focus trap enquanto aberto e restauração de foco ao fechar.
- Conteúdo externo com `aria-hidden`. (React Aria não usa `aria-modal` — o isolamento é por `aria-hidden`.)
- Scroll do body travado.
- ESC fecha por padrão.

## Armadilhas comuns

- Não omita `label`.
- Não renderize um `PanelHeader` dentro de `children` — o overlay já tem um.
- Não mantenha Drawer e Overlay abertos ao mesmo tempo: são views alternativas da mesma conversa, e dois diálogos empilhados confundem o foco. Controle com um único estado de view.
- Não use `className` esperando o backdrop — é `overlayClassName`.
- Não bloqueie todas as vias de saída sem oferecer uma alternativa no conteúdo.
