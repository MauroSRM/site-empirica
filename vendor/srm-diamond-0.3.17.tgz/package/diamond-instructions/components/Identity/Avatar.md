# Avatar

Círculo primitivo de identidade visual: exibe iniciais (derivadas do `name` ou passadas
explicitamente em `initials`) sobre um fundo colorido (`bg`). É o bloco básico reusado por
`AvatarDropdown`, `AvatarWithLabel`, `AvatarCompanyCNPJStatic` e outras composições de
identidade do Diamond. Construído como `<div>` simples com variantes via `class-variance-authority`
(CVA) — sem dependência de `react-aria-components`.

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/Avatar/Avatar.tsx`
- **Export:** `import { Avatar, AVATAR_COLORS } from '@srm/diamond';`
- **Relacionados:** [AvatarSRM](./AvatarSRM.md) (círculo de marca SRM), [AvatarDropdown](./AvatarDropdown.md) (avatar + menu), [AvatarStatic](./AvatarStatic.md) (avatar + rótulo, sem interação), [BankAvatar](./BankAvatar.md) (ícone de banco/instituição — domínio diferente, não confundir)

---

## Quando usar

- Representar um usuário, colaborador ou empresa por iniciais quando não há foto/logo
  (ex.: cabeçalho de conta, lista de usuários, card de contato, timeline de atividades).
- Compor com outros elementos (nome, cargo, CNPJ) — use como peça isolada e monte o
  layout ao redor, ou prefira os componentes prontos `AvatarWithLabel` /
  `AvatarCompanyCNPJStatic` quando o padrão "avatar + duas linhas de texto" já servir.
- Gerar as iniciais automaticamente a partir de um nome completo (`name`) ou controlar
  o texto manualmente (`initials`), por exemplo para siglas de empresa (`"SRM"`).

## Quando **não** usar

- Precisa de um botão/trigger com menu dropdown acoplado → [`AvatarDropdown`](./AvatarDropdown.md)
  ou [`AvatarColaborador`](./AvatarDropdown.md).
- Precisa do círculo de marca SRM (logo, não iniciais) → [`AvatarSRM`](./AvatarSRM.md) ou `ColabCircle`.
- Precisa representar um banco/instituição financeira por logo → [`BankAvatar`](./BankAvatar.md).
- Precisa de avatar + texto ao lado já pronto (sem menu) → [`AvatarWithLabel`](./AvatarStatic.md).

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'collab';

interface AvatarProps extends Omit<ComponentPropsWithoutRef<'div'>, 'children'> {
  initials?: string;     // texto exibido; se ausente, deriva de `name`
  name?: string;         // usado para derivar iniciais quando `initials` está ausente; e como nome acessível preferencial (ver Notas)
  size?: AvatarSize;     // default: 'md'
  bg?: string;           // cor de fundo (qualquer valor CSS válido, ex.: 'var(--avatar-navy)')
  isDark?: boolean;      // default: false — aplica anel de contraste para fundos escuros
  className?: string;
  style?: CSSProperties;
  ref?: Ref<HTMLDivElement>;
  // Herdado de ComponentPropsWithoutRef<'div'>: id, onClick, data-*, aria-*, ...
}
```

### Notas de comportamento

- **Derivação de iniciais**: se `initials` não for passado mas `name` sim, o utilitário
  `deriveInitials` pega a primeira letra de cada palavra do nome (split por espaços),
  concatena, corta em **2 caracteres** e converte para maiúsculas — `"Carlos Mendes"` →
  `"CM"`. Se nenhum dos dois for passado, o avatar renderiza só o círculo vazio (sem texto).
- **Nome acessível com fallback em cadeia**: `accessibleName = name ?? aria-label ?? displayInitials`.
  Ou seja, mesmo **sem** `name`, o avatar ganha nome acessível a partir de `aria-label`
  explícito ou, na ausência de ambos, das próprias **iniciais exibidas** (explícitas ou
  derivadas). `role="img"` só é omitido quando **nenhum** desses três existir (nem `name`,
  nem `aria-label`, nem `initials`/`name` para derivar iniciais) — isto é, apenas no caso do
  "círculo vazio" (`<Avatar size="md" bg="..." />` sem nenhuma das três props).
- **Cor de fundo (`bg`)**: aceita qualquer valor CSS, mas o padrão de uso no DS é escolher
  a partir do dicionário `AVATAR_COLORS` (exportado pelo próprio módulo `Avatar`, em
  `Avatar.constants.ts`), que mapeia nomes (`'Navy'`, `'Índigo'`, `'Roxo'`, `'Crimson'`,
  `'Rosa'`, `'Verde'`, `'Teal'`, `'Âmbar'`, `'Grafite'`, `'Brand'`) para custom properties
  (`var(--avatar-navy)` etc.). Sem `bg`, o CSS module aplica `var(--brand-primary)` como
  fundo padrão.
- **`isDark`**: não muda a cor de fundo — adiciona um `box-shadow` inset (anel branco
  translúcido) para o círculo não se perder visualmente sobre fundos escuros/brand.
- **Tamanhos**: `xs`/`sm`/`md`/`lg`/`xl`/`collab` mapeiam para custom properties
  (`--avatar-size-xs` … `--avatar-size-collab`) com `font-size` proporcional; o tamanho
  em pixel de referência usado internamente pelo DS (`AVATAR_SRM_PX`) é
  `xs: 20, sm: 24, md: 32, lg: 40, xl: 48, collab: 36`.
- `className` e `style` são mesclados por último — `style.backgroundColor` do consumidor
  é sobrescrito por `bg` quando ambos estão presentes (a ordem no componente é
  `{ backgroundColor: bg, ...style }`).

---

## Exemplos

```tsx
import { Avatar } from '@srm/diamond';

// Iniciais derivadas do nome
<Avatar name="Carlos Mendes" />

// Iniciais explícitas + cor customizada
<Avatar initials="SRM" bg="var(--avatar-navy)" size="lg" />

// Tamanhos
<Avatar initials="CM" size="xs" />
<Avatar initials="CM" size="sm" />
<Avatar initials="CM" size="xl" />

// Sobre fundo escuro/brand (adiciona anel de contraste)
<div style={{ background: '#32353E', padding: 16 }}>
  <Avatar initials="CM" isDark />
</div>

// Iniciais explícitas sem name — ainda ganha aria-label = "CM" automaticamente
<Avatar initials="CM" />

// aria-label explícito cobre o caso de iniciais pouco descritivas
<Avatar initials="CM" aria-label="Carlos Mendes" />

// Círculo vazio (placeholder, sem iniciais, sem nome acessível)
<Avatar size="md" bg="var(--surface-subtle)" />
```

---

## Acessibilidade

- Passe **`name`** sempre que o avatar representar uma pessoa/empresa real — é a opção
  mais descritiva (ex.: `"Ana Lima"` em vez de só `"AL"`).
- Se só passar `initials` (sem `name`), o avatar **ainda** ganha `role="img"` com
  `aria-label` igual às iniciais exibidas (ex.: `"CM"`) — não fica sem nome acessível,
  mas o nome é menos descritivo do que passar `name`. Use `aria-label` explícito para dar
  um nome mais completo sem alterar o texto visual (`initials`).
- As iniciais visuais (`span` interno) são `aria-hidden="true"`: o texto não é lido
  duas vezes por leitores de tela (uma vez pelo `aria-label` do container, e evita
  redundância do `span`).
- O único caso sem nome acessível (`role` omitido) é o "círculo vazio" — sem `name`,
  `aria-label` **e** sem iniciais (nem explícitas nem derivadas de `name`).

## Armadilhas comuns

- Achar que `initials` aceita mais de 2 caracteres — `deriveInitials` corta em 2, mas se
  você passar `initials` manualmente, **nenhum corte é aplicado**; strings longas estouram
  o círculo visualmente.
- Esquecer `isDark` ao colocar o avatar sobre header/fundo brand — sem o anel de contraste,
  círculos com cor próxima ao fundo somem visualmente.
- Confundir com `ColabCircle`/`AvatarSRM` — `Avatar` é para **iniciais de pessoa/empresa**,
  não para o logo da SRM.
