# UserAccess

Tela cheia (`layout: fullscreen`) de autenticação com 6 etapas navegáveis internamente:
login, esqueci minha senha, e-mail enviado, redefinir senha, primeiro acesso e sucesso.
É um componente de **interface completa** (orquestrador) e **agnóstico de backend** — ele
monta sozinho o layout responsivo (split-screen no desktop, coluna única no mobile), a marca
SRM/Diamond (logo, diamante, tagline), o rodapé institucional e o selo "Conexão
criptografada", e alterna entre as 6 telas trocando um `step`. Cada tela é implementada por um
subcomponente **interno e não exportado** (`Login`, `Forgot`, `Sent`, `Reset`, `FirstAccess`,
`Success`), construído com `react-hook-form` + `zod` sobre os campos já catalogados do
Diamond (`TextInput`, `PasswordInput`, `Button`). `UserAccess` **não faz nenhuma chamada de
rede**: cada tela emite os dados digitados via callback (`onLogin`, `onForgotSubmit`,
`onResetSubmit`, `onFirstAccessSubmit`) e o consumidor decide o que fazer com eles —
incluindo o estado de carregamento, que é 100% controlado de fora via `isLoading`.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/UserAccess/`
- **Export:** `import { UserAccess } from '@srm/diamond';`
- **Relacionados/Base:** [Button](../Forms/Button.md), [TextInput](../Forms/Inputs/TextInput.md),
  [PasswordInput](../Forms/Inputs/PasswordInput.md) (usados internamente pelas telas)

---

## Quando usar

- Como a **tela de login completa** de um app SRM (produto novo, portal do cliente,
  backoffice) — substituindo a necessidade de montar login/recuperação/primeiro acesso do zero.
- Fluxos de **onboarding de senha**: primeiro acesso de um usuário recém-criado
  (`initialStep="first-access"`), com checklist de requisitos de senha em tempo real.
- Fluxo de **recuperação de senha** ponta a ponta: esqueci a senha → e-mail enviado →
  redefinir senha → login.
- Quando você precisa **plugar autenticação real**: implemente `onLogin`, `onForgotSubmit`,
  `onResetSubmit`, `onFirstAccessSubmit` fazendo a chamada de API, controle `isLoading`
  enquanto a requisição está em voo, e use `step` + `onStepChange` (modo controlado) para
  decidir a navegação com base na resposta do backend (ex.: só avançar para `sent` depois que
  a API confirmar o envio do e-mail).
- Protótipos/demos que precisam de uma tela de autenticação com a identidade visual da
  SRM já pronta (diamante, tagline, rodapé com copyright) — e permitem sobrescrever toda a
  copy via `copy`/`appTitle`/`tagline`/`copyright`/`footerLinks` para produtos white-label.

## Quando **não** usar

- Quando o formulário de login precisa ficar **embutido dentro de outro layout** (ex.: um
  modal, um card dentro de uma página com outro header) — `UserAccess` sempre renderiza a
  página inteira (header/sidebar/footer da marca). Nesse caso monte os campos manualmente
  com [`TextInput`](../Forms/Inputs/TextInput.md) + [`PasswordInput`](../Forms/Inputs/PasswordInput.md)
  + [`Button`](../Forms/Button.md).
- Quando você precisa **customizar profundamente** uma das telas internas (`Login`, `Forgot`,
  `Reset`, `FirstAccess`, `Sent`, `Success`) — elas não são exportadas pelo barrel; a
  customização possível é a superfície de `copy` por etapa, não a estrutura/validação delas.
- Para um stepper de formulário genérico (não é tela de autenticação) → use
  [`Stepper`](./Stepper.md) (se existir) para orquestrar passos com sua própria lógica de negócio.

---

## Interface

```ts
export type UserStep =
  | 'login'
  | 'forgot'
  | 'sent'
  | 'reset'
  | 'first-access'
  | 'success';

export interface UserAccessFooterLink {
  label: string;        // rótulo exibido no rodapé
  onClick: () => void;  // emitido ao acionar o link
}

export interface UserAccessCopy {
  login?: LoginCopy;
  forgot?: ForgotCopy;
  sent?: SentCopy;
  reset?: ResetCopy;
  firstAccess?: FirstAccessCopy;
  success?: SuccessCopy;
}

export interface UserAccessProps {
  appTitle?: string;                 // default: 'SRM Capital'
  tagline?: string;                  // default: 'Capital em movimento'
  copyright?: string;                // default: '© Copyrights Nova SRM. Todos os direitos reservados.'
  secureConnectionLabel?: string;    // default: 'Conexão criptografada'
  footerLinks?: UserAccessFooterLink[]; // default: [] — vazio não renderiza links
  accountEmail?: string;             // default: '' — exibido (com fallback '—') na etapa first-access
  isLoading?: boolean;               // default: false — controlado pelo consumidor
  step?: UserStep;                   // modo controlado — quando definido, dirige a navegação
  initialStep?: UserStep;            // default: 'login' — modo não-controlado
  onStepChange?: (step: UserStep) => void; // emitido a cada tentativa de mudança de etapa
  forceMobile?: boolean;             // default: false
  copy?: UserAccessCopy;             // textos sobrescrevíveis por etapa
  onLogin?: (values: { user: string; password: string }) => void;
  onForgotSubmit?: (email: string) => void;
  onResetSubmit?: (values: { password: string; confirmPassword: string }) => void;
  onFirstAccessSubmit?: (values: { password: string; confirmPassword: string }) => void;
  onSuccess?: () => void;            // emitido ao acionar "Acessar plataforma" na etapa success
}
```

Cada `*Copy` (`LoginCopy`, `ForgotCopy`, `SentCopy`, `ResetCopy`, `FirstAccessCopy`,
`SuccessCopy`) é um objeto de strings opcionais (título, subtítulo, labels de campo,
placeholders, labels de botão) — todas com default em português; passe apenas as chaves que
quiser sobrescrever. Não são exportadas individualmente pelo barrel do `UserAccess`; use o
formato aninhado via `copy` (ex.: `copy={{ login: { submitLabel: 'Entrar' } }}`).

### Notas de comportamento — deltas do redesenho agnóstico

- **Sem simulação de backend.** A versão anterior tinha um `setTimeout` fixo de 800 ms
  (`ASYNC_DELAY_MS`) que sempre "sucedia". Isso foi **removido**: `UserAccess` agora só chama
  os callbacks (`onLogin`, `onForgotSubmit`, `onResetSubmit`, `onFirstAccessSubmit`) com os
  dados validados pelo Zod e delega **inteiramente** ao consumidor decidir o que fazer —
  incluindo chamar uma API real, tratar erro de servidor e navegar para a próxima etapa.
- **`isLoading` é responsabilidade do consumidor.** Não há estado de loading interno; a prop
  `isLoading` (default `false`) é passada direto para o botão de submit da etapa ativa
  (`Login`, `Forgot`, `Reset`, `FirstAccess`). Se sua chamada de API for assíncrona, você
  controla `isLoading` de fora (ex.: `useState` + `true` antes da chamada, `false` no
  `finally`).
- **Navegação entre etapas — modo controlado e não-controlado:**
  - **Não-controlado** (`step` omitido): `UserAccess` gerencia um `step` interno, iniciado por
    `initialStep` (default `'login'`) e atualizado automaticamente nas transições padrão
    (ex.: `forgot` → `sent` no submit, `first-access` → `success` no submit).
  - **Controlado** (`step` definido): a navegação passa a ser **dirigida pelo consumidor**.
    Internamente o estado deixa de ser atualizado (`if (controlledStep === undefined)
    setInternalStep(next)`); em vez disso, toda tentativa de mudança de etapa (nas transições
    padrão e nos botões de "voltar") dispara `onStepChange(next)`, e cabe ao consumidor
    atualizar a prop `step` para de fato navegar. Isso permite, por exemplo, só avançar de
    `forgot` para `sent` depois que a API confirmar o envio do e-mail.
- **`onLogin`/`onForgotSubmit`/`onResetSubmit`/`onFirstAccessSubmit` só emitem dados; não
  navegam por si.** A navegação após cada submit (ex.: `forgot` → `sent`, `first-access` →
  `success`) é feita pelo próprio `UserAccess` via `changeStep(...)`, que **também** passa pelo
  fluxo controlado/não-controlado descrito acima — ou seja, em modo controlado, mesmo a
  transição "automática" pós-submit só ocorre se o consumidor atualizar `step` em resposta a
  `onStepChange`.
- **`accountEmail` não tem default forjado.** Prop default é `''`; a etapa `first-access`
  exibe um fallback neutro (`'—'`) quando vazia — **nunca** um e-mail de exemplo fixo
  (comportamento antigo continha PII fictícia como placeholder padrão).
- **Copy por etapa.** Cada tela interna já vem com defaults em português (`DEFAULT_COPY`
  local); a prop `copy` faz merge raso por etapa (`{ ...DEFAULT_COPY, ...copy?.login }`, etc.),
  então basta sobrescrever as chaves desejadas.
- **Identidade de marca configurável.** `appTitle`, `tagline`, `copyright` e `footerLinks`
  substituem os textos institucionais fixos da versão anterior — cada `footerLinks[]` item
  ({ `label`, `onClick` }) renderiza um `<button type="button">` que emite seu próprio evento
  (os links de rodapé deixaram de ser decorativos/sem `onClick`).
- **`initialStep` só vale no primeiro render** (modo não-controlado). É consumido via
  `useState(initialStep)` — não reage a mudanças posteriores da prop. Use `step` (controlado)
  para navegação dinâmica, ou uma `key` para forçar remount (padrão usado na própria story:
  `<UserAccess key={args.initialStep} {...args} />`).
- **Responsividade:** `isWide = window.innerWidth >= 768` (breakpoint fixo, não configurável),
  recalculado em `resize`. `forceMobile` sobrepõe isso e mantém o layout mobile fixo,
  ignorando o `resize`.
- **Rodapé com cadeado:** o selo de conexão segura (`secureConnectionLabel`) só aparece nas
  etapas `login`, `first-access` e `reset` (`STEPS_WITH_LOCK`).
- Cada tela interna já injeta suas próprias regras de validação via Zod (inalterado):
  - `login`: `user` e `password` obrigatórios (sem regra de formato). Emite
    `{ user, password }`.
  - `forgot`: `email` obrigatório e com formato de e-mail válido. Emite apenas a `string` do
    e-mail (`onForgotSubmit(email)`), não um objeto.
  - `reset` / `first-access`: senha com mínimo de 8 caracteres, ao menos 1 maiúscula e
    1 número, mais confirmação que precisa ser idêntica (`refine`). Emitem
    `{ password, confirmPassword }`. A etapa `first-access` também exibe um checklist visual
    que reage em tempo real ao valor digitado (via `useWatch`) e **não tem botão de voltar**
    (diferente de `login`, `forgot` e `reset`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { UserAccess } from '@srm/diamond';

// Básico — não-controlado, backend real plugado nos callbacks
function LoginPage() {
  const [isLoading, setIsLoading] = useState(false);

  return (
    <UserAccess
      appTitle="SRM Capital"
      isLoading={isLoading}
      onLogin={async ({ user, password }) => {
        setIsLoading(true);
        try {
          await api.login(user, password);
          router.push('/dashboard');
        } finally {
          setIsLoading(false);
        }
      }}
    />
  );
}

// Iniciando direto no fluxo de primeiro acesso (ex.: link recebido por e-mail)
<UserAccess
  initialStep="first-access"
  accountEmail="usuario@dominio.com"
  onFirstAccessSubmit={({ password }) => api.setPassword(password)}
  onSuccess={() => router.push('/onboarding')}
/>

// Controlado — navegação dirigida pelo consumidor com base na resposta da API
function RecoveryFlow() {
  const [step, setStep] = useState<UserStep>('forgot');
  const [isLoading, setIsLoading] = useState(false);

  return (
    <UserAccess
      step={step}
      onStepChange={setStep}
      isLoading={isLoading}
      onForgotSubmit={async (email) => {
        setIsLoading(true);
        const ok = await api.requestPasswordReset(email);
        setIsLoading(false);
        if (ok) setStep('sent'); // só avança se a API confirmar
      }}
    />
  );
}

// Marca e rodapé customizados (white-label)
<UserAccess
  appTitle="Portal do Cliente"
  tagline="Seu patrimônio, sempre à mão"
  copyright="© 2026 Minha Empresa. Todos os direitos reservados."
  footerLinks={[
    { label: 'Política de Privacidade', onClick: () => window.open('/privacidade') },
    { label: 'Dúvidas Frequentes', onClick: () => window.open('/faq') },
  ]}
  copy={{ login: { title: 'Bem-vindo de volta', submitLabel: 'Entrar' } }}
/>

// Forçando layout mobile (ex.: dentro de um WebView)
<UserAccess forceMobile onLogin={handleLogin} />
```

> Não há exemplo com React Hook Form direto porque `UserAccess` não expõe os formulários
> internos — ele já vem com `react-hook-form` + `zod` embutidos; a interface externa é só
> callbacks com o *shape* validado (`{ user, password }`, `email`, `{ password, confirmPassword }`).

---

## Acessibilidade

- Ícones decorativos (diamante, cadeado, SVGs da logo) usam `aria-hidden="true"`.
- Cada tela usa `<form onSubmit={...} noValidate>` com `Controller` do RHF conectando os
  campos a `TextInput`/`PasswordInput`, que já cuidam de `errorText` associado via
  `react-aria-components` (mesmo contrato de acessibilidade documentado em
  [TextInput](../Forms/Inputs/TextInput.md) e [PasswordInput](../Forms/Inputs/PasswordInput.md)).
  `noValidate` desativa a validação nativa do navegador para deixar a mensagem de erro
  (Zod) como única fonte de verdade.
- Os botões de "Voltar" (`Login`, `Forgot`, `Reset`, `Sent`) usam ícone (`arrow-left`) + texto —
  não são ícone-somente, portanto não dependem de `aria-label` adicional. A etapa
  `first-access` não tem botão de voltar.
- Os links de `footerLinks` são `<button type="button">` com o próprio `label` como texto
  visível — sem `href`; se a navegação for para outra rota/página real, prefira que o
  `onClick` do consumidor use um roteador (ou considere trocar por `<a>` fora do componente).

## Armadilhas comuns

- **Achar que `UserAccess` chama uma API por conta própria.** Ele não faz — os callbacks
  (`onLogin`, `onForgotSubmit`, `onResetSubmit`, `onFirstAccessSubmit`) só recebem os dados já
  validados pelo Zod; a chamada de rede, o tratamento de erro de servidor e a atualização de
  `isLoading` são 100% responsabilidade do consumidor.
- **Esperar navegação automática em modo controlado.** Com `step` definido, `UserAccess` nunca
  avança por conta própria (nem nas transições "padrão" pós-submit) — ele só chama
  `onStepChange(next)`. Se você não atualizar `step` em resposta a isso, a tela não muda.
- **Trocar `initialStep` em um componente já montado (modo não-controlado) e esperar
  navegação.** Não funciona — é `useState` inicializado uma única vez. Use `step` (controlado)
  para navegação dinâmica, ou uma `key` para forçar remount.
- **Tentar customizar as telas internas** (`Login`, `Forgot`, `Reset`, `FirstAccess`, `Sent`,
  `Success`) diretamente — elas não são exportadas pelo barrel (`index.ts` só exporta
  `UserAccess`, `UserAccessProps`, `UserStep`, `UserAccessCopy`, `UserAccessFooterLink`).
  A única superfície de customização de texto é `copy`.
- **Forjar `accountEmail` com um valor de exemplo por padrão.** O default é `''`
  (fallback visual `'—'`); nunca passe um e-mail fictício "só para preencher" — isso exporia
  um dado que parece real onde não há dado.
- **Confundir com um formulário de login "leve".** `UserAccess` sempre renderiza a página
  inteira (header/sidebar/footer com a marca) — não é adequado para embutir dentro de um
  modal ou card.
- O breakpoint mobile/desktop (768px) é fixo no componente; não há prop para customizá-lo
  além de `forceMobile` (que só força o modo mobile, não um breakpoint diferente).
