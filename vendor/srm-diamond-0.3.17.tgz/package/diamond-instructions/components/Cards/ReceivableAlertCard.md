# ReceivableAlertCard

Card compacto e sempre clicável para alertar sobre um recebível (ou grupo de recebíveis)
com prioridade visual: barra lateral colorida por variante, cliente + valor na linha
superior, `Tag` + data + contador na linha inferior, e chevron indicando navegação.
Renderizado como `<Button>` de **react-aria-components** — não existe modo estático.
Compõe os átomos `Tag` (`DataDisplay`) e `Icon` (`Icons`) sobre a superfície
compartilhada `Cards/cardSurface` (`appearance="outlined"`, `interactive: true`, sempre).

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/ReceivableAlertCard/`
- **Export:** `import { ReceivableAlertCard } from '@srm/diamond';`
- **Relacionados:** [Card](./Card.md), [Tag](../DataDisplay/Tag.md), [Icon](../Icons/Icon.md)

---

## Quando usar

- Listas de recebíveis no dashboard financeiro com prioridade clara: vencidos, a vencer
  hoje, a vencer em breve, ou pendentes de processamento.
- Notificações de cobrança / alertas em drawers de conciliação, onde cada card sempre
  navega para o detalhe (abre drawer, tela de cobrança, etc.) ao ser pressionado.
- Agrupar múltiplos títulos do mesmo cliente/vencimento sob um único card → `count`
  (ex.: "3 títulos").

## Quando **não** usar

- Recebíveis já liquidados / listagem de extrato sem necessidade de ação → use
  `DocumentRow` ou `Table` (`DataDisplay`), não este componente, que é sobre
  atenção/ação pendente.
- Card sem ação de navegação (`onPress` é **obrigatório** no tipo — não há modo
  display-only, ver Notas de comportamento).
- Adicionar um CTA extra dentro do card (ex.: um botão "Pagar" junto do chevron) — o
  próprio card já é o elemento clicável; interativo-dentro-de-interativo quebra teclado
  e HTML válido.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonProps as AriaButtonProps } from 'react-aria-components';

type ReceivableAlertVariant = 'overdue' | 'dueToday' | 'dueSoon' | 'pending';

interface ReceivableAlertCardBase {
  variant: ReceivableAlertVariant;  // obrigatório — cor da barra lateral + label da Tag
  customer: ReactNode;              // obrigatório — nome do cliente/pagador
  amount: ReactNode;                // obrigatório — valor formatado
  date?: ReactNode;                 // data/descrição de vencimento
  count?: number;                   // quantidade agrupada de títulos (ex.: 3 → "3 títulos")
}

interface ReceivableAlertCardProps extends ReceivableAlertCardBase,
  Omit<AriaButtonProps, 'children' | keyof ReceivableAlertCardBase> {
  onPress: NonNullable<AriaButtonProps['onPress']>; // obrigatório — sem modo estático
  // Herdado de AriaButtonProps: isDisabled, autoFocus, aria-*, excludeFromTabOrder, ...
}
```

### Notas de comportamento

- **`onPress` é obrigatório** (`NonNullable<AriaButtonProps['onPress']>`) e o componente
  **sempre** renderiza um `<Button>` de react-aria-components — não existe ramo `<div>`
  estático/display-only na implementação atual (diferente do que a documentação de uso
  das stories sugere; valide sempre contra `ReceivableAlertCard.types.ts` se este
  comportamento mudar em versões futuras).
- **Cor da barra lateral e label da `Tag` vêm de `VARIANT_CONFIG`**
  (`ReceivableAlertCard.constants.ts`), indexado por `variant`:
  - `overdue` → barra/tag vermelha, label "Vencido" (`tagVariant: 'error'`).
  - `dueToday` → barra/tag amarela, label "Vence hoje" (`tagVariant: 'warning'`).
  - `dueSoon` → barra/tag amarela, label "Vence em breve" (`tagVariant: 'warning'`).
  - `pending` → barra neutra, label "Pendente" (`tagVariant: 'info'`).
  - Os labels da `Tag` **não são customizáveis via props** — são fixos por `variant`.
- **`count`** usa comparação estrita `count != null` (aceita `0`) e pluraliza
  automaticamente: `${count} título${count > 1 ? 's' : ''}` — ou seja, `count={1}`
  renderiza "1 título" (singular) e `count={0}` renderiza "0 título" (singular, já que
  `0 > 1` é falso).
- `date` e `count` são ambos opcionais e independentes — podem aparecer juntos, sozinhos,
  ou nenhum dos dois (só cliente + valor + tag ficam visíveis nesse caso).
- O chevron (`chevron-right`, 18px) é sempre renderizado (não há modo sem chevron) e
  muda de cor para `--text-brand` no hover (`[data-hovered]:not([data-disabled])`).
- `className` só é aplicado se **não** for uma função — o tipo herda `AriaButtonProps`,
  cujo `className` pode ser `string | ((values) => string)`; quando função, é
  descartado (`typeof className === 'function' ? undefined : className`) para não
  quebrar a composição com as classes CVA do componente.
- `customer` tem `text-overflow: ellipsis` com `white-space: nowrap` — nomes longos
  truncam em vez de quebrar linha; `amount` nunca encolhe (`flex-shrink: 0`).

---

## Exemplos

```tsx
import { ReceivableAlertCard } from '@srm/diamond';

// Vencido
<ReceivableAlertCard
  variant="overdue"
  customer="Construtora Horizonte LTDA"
  amount="R$ 184.200,00"
  date="Venceu em 28/06"
  onPress={() => abrirDetalheRecebivel('123')}
/>

// Vence hoje, com contador de títulos agrupados
<ReceivableAlertCard
  variant="dueToday"
  customer="Comércio Silva & Filhos"
  amount="R$ 42.900,00"
  date="Vence hoje"
  count={3}
  onPress={() => abrirDetalheRecebivel('456')}
/>

// Vence em breve
<ReceivableAlertCard
  variant="dueSoon"
  customer="Distribuidora Norte S.A."
  amount="R$ 97.500,00"
  date="Vence em 03/07"
  onPress={() => abrirDetalheRecebivel('789')}
/>

// Pendente, sem data (ex.: processamento)
<ReceivableAlertCard
  variant="pending"
  customer="Indústria Sul Ltda"
  amount="R$ 210.000,00"
  onPress={() => abrirDetalheRecebivel('321')}
/>

// Lista de alertas
<div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
  <ReceivableAlertCard variant="overdue" customer="Cliente A" amount="R$ 12.000,00" date="Venceu em 20/06" onPress={() => {}} />
  <ReceivableAlertCard variant="dueToday" customer="Cliente B" amount="R$ 8.500,00" date="Vence hoje" count={2} onPress={() => {}} />
  <ReceivableAlertCard variant="pending" customer="Cliente C" amount="R$ 31.000,00" onPress={() => {}} />
</div>
```

---

## Acessibilidade

- O nome acessível do botão vem do conteúdo textual (`customer` + `amount` + tag/data/
  contador) — evite `customer`/`amount` vazios ou puramente decorativos.
- Foco, `:focus-visible`, ativação por Enter/Espaço/toque e `aria-*` de `AriaButtonProps`
  já vêm gratuitamente do `<Button>` de react-aria-components.
- O chevron é `aria-hidden="true"` — puramente indicativo de navegação, não carrega
  informação própria.
- A barra lateral colorida é decorativa (`aria-hidden="true"`) — a semântica da
  urgência/variante está na `Tag` textual ("Vencido", "Vence hoje", etc.), não só na cor.

## Armadilhas comuns

- Omitir `onPress` esperando um card estático — o tipo exige a prop (`onPress:
  NonNullable<...>`); não há como usar este componente apenas como display.
- Esperar customizar o texto da `Tag` por variante (ex.: trocar "Vencido" por outro
  texto) — os labels são fixos em `VARIANT_CONFIG`, não expostos via props.
- Assumir que `count={0}` ou `count={1}` pluralizam — a regra é estritamente
  `count > 1`; ambos os casos renderizam "título" no singular.
- Colocar uma ação extra (botão, link) dentro do card — quebra a regra de não aninhar
  interativos dentro de um `<Button>` (HTML inválido e navegação por teclado ambígua).
- Passar `className` como função (padrão de render prop de outros componentes
  react-aria) esperando que seja aplicado — é silenciosamente descartado neste
  componente; use uma string estática.
