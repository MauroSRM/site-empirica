# EmptyState

Estado vazio para listas, tabelas e telas sem conteúdo. Combina um ícone circular
(`lucide-react`, via `Icon`), título (heading), corpo de texto e um botão de ação
opcional, com quatro variantes semânticas pré-configuradas (`default`, `error`, `search`,
`offline`) que já vêm com ícone, textos e rótulo de ação padrão em pt-BR. Construído
internamente sobre o [`Button`](../Forms/Button.md) do Diamond para a ação; sem
dependência de `react-aria-components` diretamente. É consumido por `Table` e por
estados vazios de gráfico (`ChartEmpty`), o que motivou a prop `headingLevel`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/EmptyState/`
- **Export:** `import { EmptyState } from '@srm/diamond';` (tipos `EmptyStateProps`,
  `EmptyStateVariant` também exportados pelo barrel)
- **Relacionados:** [Button](../Forms/Button.md) (usado internamente para a ação),
  [Skeleton](./Skeleton.md) (estado de carregamento — não confundir com estado vazio)

---

## Quando usar

- Lista, tabela ou grid sem itens após carregamento (`variant="default"`).
- Falha ao carregar dados de uma tela ou seção (`variant="error"`), com ação de "Tentar novamente".
- Busca ou filtro que não retornou resultados (`variant="search"`), com ação de "Limpar filtros".
- Perda de conectividade impedindo carregar dados (`variant="offline"`).
- Telas de carteira, extrato, posições ou histórico de operações sem registros no período/filtro
  selecionado.
- Embutido dentro de `Table` ou de um gráfico sem dados — ajuste `headingLevel` para a
  hierarquia de heading correta do contexto (ver seção Interface).

## Quando **não** usar

- Carregamento em andamento → use [`Skeleton`](./Skeleton.md) ou [`Spinner`](./Spinner.md),
  não `EmptyState`.
- Erro bloqueante de página inteira (crash) → prefira uma tela de erro dedicada, não este componente
  de feedback inline.
- Mensagem de sucesso/confirmação pontual → não é um estado "vazio"; use um Toast/Alert.

---

## Interface

```ts
type EmptyStateVariant = 'default' | 'error' | 'search' | 'offline';

interface EmptyStateProps {
  variant?: EmptyStateVariant;        // default: 'default'
  withAction?: boolean;               // default: false — exibe/oculta o botão de ação
  onAction?: () => void;              // callback do botão (recebido via onPress do Button)
  customHeadline?: string;            // sobrescreve o título padrão da variante
  customBody?: string;                // sobrescreve o corpo de texto padrão da variante
  actionLabel?: string;               // sobrescreve o rótulo padrão do botão da variante
  headingLevel?: 2 | 3 | 4;           // default: 3 — nível do heading (h2/h3/h4)
  className?: string;                 // classe extra no container raiz
}
```

### Conteúdo padrão por variante (`EmptyState.constants.ts`)

| `variant`  | Ícone         | Título padrão              | Corpo padrão                                                                         | Ação padrão         |
|------------|---------------|-----------------------------|---------------------------------------------------------------------------------------|----------------------|
| `default`  | `inbox`       | "Nenhum item encontrado"    | "Não há itens para exibir no momento. Tente ajustar os filtros ou recarregar a página." | "Recarregar"         |
| `error`    | `alert-circle`| "Algo deu errado"           | "Ocorreu um erro ao carregar os dados. Por favor, tente novamente."                    | "Tentar novamente"   |
| `search`   | `search`      | "Sem resultados"            | "Nenhum resultado encontrado para sua busca. Tente outros termos ou limpe os filtros."  | "Limpar filtros"     |
| `offline`  | `wifi-off`    | "Sem conexão"               | "Verifique sua conexão com a internet e tente novamente."                              | "Tentar novamente"   |

### Notas de comportamento

- `customHeadline`, `customBody` e `actionLabel` sobrescrevem **individualmente** o conteúdo padrão
  da variante — você pode trocar só o corpo e manter título/ação padrão, por exemplo.
- O botão de ação só é renderizado quando `withAction` é `true`; sem ele, `onAction` e `actionLabel`
  são ignorados.
- A variante controla também a cor do ícone: `error` usa o círculo `iconError`
  (`--feedback-error-bg` / `--feedback-error`); as demais (`default`, `search`, `offline`) usam o
  círculo neutro `iconMuted` (`--surface-muted` / `--text-tertiary`).
- O botão renderizado usa `variant="primary"` para as variantes marcadas como "ação primária"
  (`EMPTY_STATE_PRIMARY_ACTION_VARIANTS`: `error` e `offline`) e `variant="ghost"` para as demais
  (`default`, `search`) — sempre `size="md"`.
- O ícone é fixo em `size={28}` (`EMPTY_STATE_ICON_SIZE`), sem `circle` (usa o círculo próprio do
  wrapper via CVA, não o `circle` do `Icon`).
- `headingLevel` controla o elemento renderizado (`h2`/`h3`/`h4`) via template string
  (``` `h${headingLevel}` ```) — **default `3`**, pensado para não furar o outline de heading
  quando o `EmptyState` está embutido dentro de `Table` ou de um gráfico que já tem seu próprio
  `h1`/`h2`.
- Não existe prop `theme`/`size` no componente — o `EmptyState` não tem variação de tamanho nem
  modo escuro dedicado; a cor de texto e superfícies vem dos tokens globais do tema ativo na página.

---

## Exemplos

```tsx
import { EmptyState } from '@srm/diamond';

// Básico — lista sem itens
<EmptyState variant="default" />

// Com ação de recarregar
<EmptyState
  variant="default"
  withAction
  onAction={() => refetch()}
/>

// Erro ao carregar dados, com ação de retry (botão primário)
<EmptyState
  variant="error"
  withAction
  onAction={() => refetch()}
/>

// Busca sem resultados, com ação de limpar filtros (botão ghost)
<EmptyState
  variant="search"
  withAction
  onAction={() => clearFilters()}
/>

// Offline
<EmptyState variant="offline" withAction onAction={() => window.location.reload()} />

// Textos customizados (mantendo ícone e variante padrão)
<EmptyState
  variant="default"
  customHeadline="Nenhuma operação neste período"
  customBody="Ajuste o intervalo de datas ou o tipo de operação para ver resultados."
  withAction
  actionLabel="Limpar período"
  onAction={() => resetDateRange()}
/>

// Embutido em uma Table (evita furar o outline — usa h4 se a seção já tem um h3)
<EmptyState
  variant="default"
  headingLevel={4}
  customHeadline="Sem movimentações"
  customBody="Não há lançamentos para a conta e período selecionados."
/>
```

---

## Acessibilidade

- O ícone é decorativo; a informação semântica está inteiramente no título (heading) e no
  corpo (`<p>`) de texto, sempre visíveis.
- O título é renderizado como `h{headingLevel}` (`h2`, `h3` ou `h4`, default `h3`) — escolha
  o nível que **não pule** a hierarquia de headings da página/seção onde o `EmptyState` está
  inserido (ex.: `headingLevel={4}` quando embutido dentro de uma seção que já usa `h3`).
- O botão de ação herda a acessibilidade do [`Button`](../Forms/Button.md) do Diamond (foco,
  ativação por teclado via react-aria) — não é necessário `aria-label` adicional, pois sempre há
  texto visível (`actionLabel` ou o rótulo padrão da variante).

## Armadilhas comuns

- Esquecer `withAction` — passar `onAction` sem `withAction={true}` não tem efeito nenhum; o botão
  simplesmente não é renderizado.
- Usar `variant="error"` para um estado que é apenas "sem dados" (não é erro) — isso muda o ícone,
  a cor e o botão para primário sem necessidade; prefira `default` ou `search` conforme o contexto.
- Deixar `headingLevel` no default (`3`) ao embutir `EmptyState` dentro de um componente que já usa
  `h3` na mesma seção — isso fura o outline de heading; ajuste para `4` (ou `2`) conforme o
  contexto real.
- Não existe controle de tamanho de ícone/espaçamento via props — para ajustar visual além do que
  as variantes oferecem, use `className` (mesclado via `clsx` ao container raiz), não sobrescreva
  estilos internos do SCSS module diretamente.
- `customHeadline`/`customBody`/`actionLabel` aceitam apenas `string` — não passam `ReactNode`;
  para conteúdo rico (links, formatação), não é o componente certo.
