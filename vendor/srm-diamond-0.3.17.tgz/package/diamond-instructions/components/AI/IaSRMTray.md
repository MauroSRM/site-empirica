# IaSRMTray

Central de controle interativa do usuário no chat. Alternativa deliberada ao chatbot
convencional (só texto): dá **duas rotas na mesma superfície** — escrever, via o
[`MessageComposer`](./MessageComposer.md) sempre visível no topo, ou interagir, via o slot
`children` com átomos do DS que respondem ao contexto da conversa.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMTray/`
- **Export:** `import { IaSRMTray } from '@srm/diamond';`
- **Relacionados:** [MessageComposer](./MessageComposer.md) (o input, compartilhado com o Hero), [IaSRMDrawer](./IaSRMDrawer.md) e [IaSRMOverlay](./IaSRMOverlay.md) (slot `tray`), [IaSRMConversationFeed](./IaSRMConversationFeed.md) (o feed, acima)

---

## Quando usar

- No slot `tray` de um `IaSRMDrawer` ou `IaSRMOverlay` — o uso típico.
- Solto, em superfícies custom que precisem da mesma central de controle.
- Quando o fluxo se beneficia de controles contextuais (tiles, slider, cards de confirmação, forms) **junto** do campo de texto.

## Quando **não** usar

- Se você só precisa do campo de texto → [`MessageComposer`](./MessageComposer.md) direto.
- Como card hero de entrada → [`IaSRMHero`](./IASRMHero.md).
- Para esconder o input quando há conteúdo no slot — as duas rotas paralelas **são** o design.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactNode, Ref } from 'react';

interface IaSRMTrayProps
  extends Omit<ComponentPropsWithoutRef<'div'>, 'onChange' | 'defaultValue'> {
  children?: ReactNode;                    // slot contextual, abaixo do composer
  value?: string;                          // presente => composer controlado
  defaultValue?: string;                   // não-controlado; não combine com value
  onChange?: (next: string) => void;       // valor cru do texto
  onSend?: (message: string) => void;       // texto TRIMADO
  onAttach?: () => void;                   // sem handler, o botão não renderiza
  onRecordAudio?: () => void;              // sem handler, o botão não renderiza
  placeholder?: string;                    // default: 'Digite sua mensagem...'
  inputLabel?: string;                     // default: 'Mensagem'
  attachLabel?: string;                    // default: 'Anexar arquivo'
  recordLabel?: string;                    // default: 'Gravar áudio'
  sendLabel?: string;                      // default: 'Enviar mensagem'
  isDisabled?: boolean;                    // default: false
  ref?: Ref<HTMLDivElement>;
  // + atributos nativos de <div>: id, className, data-*, aria-*, …
}
```

### Notas de comportamento

- Estrutura: `[MessageComposer]` → divider → `[children]`. O divider e o bloco do slot só aparecem quando há `children`.
- Todas as props de texto/ação são **repassadas ao `MessageComposer`**, incluindo os quatro `*Label` de acessibilidade. O comportamento (Enter para enviar, envio desabilitado com texto em branco, `onSend` sempre trimado) é o do composer.
- `isDisabled` desabilita o composer. **Não** desabilita o que você põe em `children` — esse estado é seu.

---

## O slot `children` é seu: os eventos também

`children` é um slot livre — o Tray não conhece nem controla o que entra nele. Isso
significa que **os handlers dos seus átomos são seus**, e é você quem decide o payload:

```tsx
type SlotAction =
  | { kind: 'tile'; value: string }
  | { kind: 'parcelas'; value: number }
  | { kind: 'confirmar' };

function ContextualControls({ onAction }: { onAction: (a: SlotAction) => void }) {
  return (
    <>
      <ButtonCard icon="check" label="Sim, organizar" onClick={() => onAction({ kind: 'tile', value: 'organizar' })} />
      <Slider minValue={1} maxValue={12} value={n} onChange={(v) => onAction({ kind: 'parcelas', value: Number(v) })} />
      <Button variant="primary" onClick={() => onAction({ kind: 'confirmar' })}>Confirmar</Button>
    </>
  );
}

<IaSRMTray onSend={sendMessage}>
  <ContextualControls onAction={handleContextualAction} />
</IaSRMTray>
```

A story do Storybook demonstra isso: o control `contentType` troca o conteúdo do slot e
o painel **Actions** mostra `slotAction` com `{ contentType, control, value? }` a cada
clique — para você ver, ao consumir, exatamente o que precisa tratar.

> Ponto de atenção: como o Tray não intercepta o slot, ele **não** emite nada pelo que
> acontece lá dentro. Se você esquecer de ligar os handlers dos seus próprios átomos, o
> clique se perde silenciosamente.

---

## Exemplos

```tsx
import { IaSRMTray } from '@srm/diamond';

// Só o composer
<IaSRMTray onSend={sendMessage} />

// Composer + controles contextuais
<IaSRMTray onSend={sendMessage} onAttach={openFilePicker} onRecordAudio={startRecording}>
  <ContextualControls onAction={handleContextualAction} />
</IaSRMTray>

// Dentro do Drawer
<IaSRMDrawer
  isOpen={open}
  onClose={close}
  label="Assistente"
  tray={<IaSRMTray onSend={sendMessage}>{contextualUI}</IaSRMTray>}
>
  <IaSRMConversationFeed messages={messages} />
</IaSRMDrawer>

// Controlado
<IaSRMTray value={draft} onChange={setDraft} onSend={sendMessage} />

// Bloqueado enquanto a resposta está em voo
<IaSRMTray isDisabled={isPending} onSend={sendMessage} />

// i18n
<IaSRMTray
  placeholder="Type a message…"
  inputLabel="Message"
  sendLabel="Send"
  onSend={sendMessage}
/>
```

---

## Acessibilidade

- O nome acessível do campo vem de `inputLabel` (repassado ao `MessageComposer`).
- Os aria-labels das três ações são configuráveis via `attachLabel`/`recordLabel`/`sendLabel` — antes da correção de auditoria eles ficavam inalcançáveis a partir do Tray.
- O conteúdo do slot é responsável pela própria acessibilidade: nomes, roles e ordem de foco dos seus átomos são seus.
- Ordem de foco: composer primeiro, slot depois — o que casa com a ordem visual.

## Armadilhas comuns

- Não esconda o composer quando o slot tem conteúdo relevante: as duas rotas paralelas são o design.
- Não passe `value` **e** `defaultValue` juntos.
- Não assuma que `isDisabled` desabilita o slot — passe o estado para os seus próprios controles.
- Não deixe os controles do slot sem handler: o Tray não emite nada por eles.
- Evite mais de uma ação primária no slot ao mesmo tempo.
