# TextInput

Campo de texto genérico do Diamond. É o input de propósito geral — sem máscara, sem
formatação — usado como base para qualquer captura textual livre (nomes, e-mails, buscas,
observações). Construído sobre `InputBase` (herda label, estados, tamanhos e tema) e sobre
o `Input` do `react-aria-components`.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/TextInput/`
- **Export:** `import { TextInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [CurrencyInput](./CurrencyInput.md), [PercentInput](./PercentInput.md), [CepInput](./CepInput.md), [CardInput](./CardInput.md)

---

## Quando usar

- Captura de texto livre sem regra de formatação: nome, e-mail, assunto, observação, busca.
- Como campo de entrada dentro de combos/autocompletes que precisem de um input "cru".
- Quando o campo exigir um ícone ilustrativo fixo (ex.: lupa em busca, `@` em e-mail) via
  a prop `icon`.

## Quando **não** usar

- Valores monetários → use [`CurrencyInput`](./CurrencyInput.md).
- Percentuais → use [`PercentInput`](./PercentInput.md).
- CEP → use [`CepInput`](./CepInput.md).
- Número de cartão → use [`CardInput`](./CardInput.md).
- Qualquer campo que precise de máscara ou validação de formato específica — prefira o
  Input dedicado da família antes de mascarar manualmente um `TextInput`.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface TextInputProps extends InputBaseProps {
  value?: string;                          // default: '' — valor controlado
  placeholder?: string;                    // default: 'Digite aqui...'
  onChange?: (value: string) => void;      // recebe e.target.value já extraído
  icon?: ReactNode;                        // ícone decorativo antes do input
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Notas de comportamento

- `onChange` já entrega a **string** (`e.target.value`), não o evento — diferente de um
  `<input>` nativo cru.
- `icon` é puramente decorativo: é renderizado com `aria-hidden="true"` dentro do wrapper,
  antes do `<input>`. Não substitui `aria-label`/`label` nem serve como botão clicável.
- Não há máscara, parsing ou validação de formato — o valor trafega exatamente como
  digitado.

---

## Exemplos

```tsx
import { useState } from 'react';
import { TextInput } from '@srm/diamond';
import { Search } from 'lucide-react';

// Básico (controlado)
function NomeField() {
  const [nome, setNome] = useState('');
  return <TextInput label="Nome completo" value={nome} onChange={setNome} />;
}

// Com placeholder customizado
<TextInput label="E-mail" placeholder="nome@empresa.com" value={email} onChange={setEmail} />

// Com ícone decorativo
<TextInput label="Buscar cliente" icon={<Search size={16} />} value={busca} onChange={setBusca} />

// Obrigatório com ajuda
<TextInput label="Assunto" required helperText="Descreva o motivo do contato." value={valor} onChange={setValor} />

// Estado de erro
<TextInput label="Nome" state="error" errorText="Campo obrigatório." value={valor} onChange={setValor} />

// Somente leitura
<TextInput label="Código do cliente" state="read-only" value="CLI-004821" />

// Desabilitado
<TextInput label="Identificador" state="disabled" value="—" />

// Tema escuro (sobre header brand)
<TextInput label="Login" theme="dark" value={login} onChange={setLogin} />
```

### Integração com React Hook Form

```tsx
<Controller
  name="nome"
  control={control}
  render={({ field, fieldState }) => (
    <TextInput
      label="Nome completo"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- O `icon` é `aria-hidden` — não conta como rótulo nem como descrição do campo.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- `state="disabled"` usa `isDisabled` do react-aria (remove o campo da ordem de tab);
  `state="read-only"` usa `isReadOnly` (permanece focável e lido por leitores de tela).

## Armadilhas comuns

- Não trate `onChange` como o evento do DOM — já é a string do valor.
- Não use `icon` para ações clicáveis (ex.: botão de limpar campo); ele é apenas visual e
  não recebe eventos de clique/foco.
- Para qualquer necessidade de máscara (moeda, percentual, CEP, cartão), não implemente a
  máscara à mão sobre `TextInput` — use o Input dedicado da família.
