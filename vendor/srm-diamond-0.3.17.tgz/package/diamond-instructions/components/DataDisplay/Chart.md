# Chart (família)

Família de gráficos do Diamond construída sobre **Recharts**, com API agnóstica de dados
(tudo entra por props — nenhum componente busca dados) e paleta resolvida por tokens
CSS (`--chart-tone-*`), nunca hex fixo. Cobre barras (vertical/horizontal/empilhada 100%),
linha, combo (linha+barra), donut, sparkline, faixa de aging e um card de moldura para
qualquer um dos anteriores.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/Chart/` (`ChartBar/`, `ChartBarHorizontal/`,
  `ChartBarStacked/`, `ChartCombo/`, `ChartLine/`, `ChartDonut/`, `ChartSparkline/`,
  `ChartAgingStrip/`, `ChartCard/`, com utilitários compartilhados em `_shared/`)
- **Export:** **não exportado pelo barrel público.** `src/components/index.ts` não inclui
  `Chart/`, e o `package.json` do pacote só declara `exports` para `.` (barrel principal),
  `./styles` e `./scss` — não há subpath para componentes internos. Ou seja, hoje a família
  **não é consumível via `@srm/diamond`** instalado; só existe como import relativo dentro
  deste monorepo (ex.: `import { ChartBar } from '../DataDisplay/Chart/ChartBar'`). Para
  liberar uso externo é preciso (1) reexportar em `src/components/index.ts` e (2), se a
  intenção for import por subpath, declarar a entrada correspondente em `exports` no
  `package.json`.
- **Relacionados:** [Table](./Table.md) (dados tabulares), [KPICard](../Cards/KPICard.md)
  (métrica única sem série), [Tag](./Tag.md)/[TrendIndicator](./TrendIndicator.md) (usados em
  headers/legendas de dashboards ao lado dos charts)

---

## Quando usar

- Exibir séries numéricas ao longo do tempo ou por categoria (fluxo de caixa, entradas
  vs. saídas, aging de recebíveis, composição de carteira).
- Dashboards e cards de métricas onde o valor precisa de contexto visual (tendência,
  comparação entre categorias, distribuição percentual).
- Cenários em que a paleta e os tokens do DS (`--chart-tone-*`) devem se manter
  consistentes entre light/dark sem hardcode de cor.

## Quando **não** usar

- Dado tabular detalhado, com muitas colunas/linhas e necessidade de ordenar, paginar ou
  selecionar → [`Table`](./Table.md).
- Uma métrica única sem série (ex.: "Patrimônio sob gestão: R$ 1,2M") → `KPICard`.
- Necessidade de customização visual do Recharts fora do que os componentes expõem —
  a família não expõe as primitivas do Recharts; não tente "furar" via `className`
  para reestilizar internals do SVG.

---

## Visão geral da família

| Componente | Uso principal |
|------------|----------------|
| `ChartBar` | Barras verticais, `grouped` (lado a lado) ou `stacked` (empilhado por **valor absoluto**). Ex.: entradas x saídas por trimestre. |
| `ChartBarHorizontal` | Barras horizontais de série única/múltipla, categorias no eixo Y. Ex.: ranking por cliente/categoria com labels longos. |
| `ChartBarStacked` | Barras **sempre normalizadas a 100%** (proporção), vertical ou horizontal. Ex.: composição percentual de aging por período. |
| `ChartCombo` | Combina `bar` e `line` na mesma série (`ChartComboSeries[].type`). Ex.: receita (barra) + margem % (linha). |
| `ChartLine` | Linhas/áreas ao longo de um eixo X contínuo (datas, períodos). Ex.: evolução de patrimônio. |
| `ChartDonut` | Composição em fatias (`slices`), com slot central opcional. Ex.: distribuição de despesas por categoria. |
| `ChartSparkline` | Mini-linha sem eixos/legenda, para uso inline (dentro de célula de tabela, KPI). |
| `ChartAgingStrip` | Barra segmentada única (0–100% normalizado internamente) com legenda. Ex.: aging de recebíveis por faixa. |
| `ChartCard` | Moldura (header + slot de ações/menu + corpo + footer) para qualquer chart concreto acima. |

---

## Interface

### Compartilhada (`ChartBaseProps`) — usada por `ChartBar`, `ChartBarHorizontal`, `ChartBarStacked`, `ChartCombo`, `ChartLine`

```ts
type ChartTone =
  | 'primary' | 'success' | 'warning' | 'error' | 'info'
  | 'neutral-1' | 'neutral-2' | 'neutral-3'
// resolvida via TONE_TO_TOKEN → var(--chart-tone-<tone>)

type ChartHeight = 'sm' | 'md' | 'lg' | 'xl' | number
// presets em px: sm=160, md=220, lg=280, xl=360

type ChartLegendPosition = 'top' | 'bottom' | false
type ChartReferenceVariant = 'info' | 'warning' | 'success'

interface ChartSeries<K extends string = string> {
  key: K
  label: string
  tone: ChartTone
  dashed?: boolean   // Line: renderiza dashed. Bar: ignora.
  area?: boolean     // Line: renderiza área preenchida com gradient abaixo.
}

interface ChartReferenceLine {
  value: number
  label: string
  variant: ChartReferenceVariant
}

interface ChartTokensOverride {
  seriesByTone?: Partial<Record<ChartTone, string>>
  axis?: string
  gridLine?: string
  tooltipBg?: string
  tooltipColor?: string
}

interface ChartBaseProps<TDatum extends Record<string, unknown>, K extends Extract<keyof TDatum, string>> {
  data: readonly TDatum[]                    // pontos em formato WIDE: { date, entradas, saidas }
  series: readonly ChartSeries<K>[]           // cada series[i].key deve existir em TDatum
  xKey: K                                     // coluna do eixo X
  height?: ChartHeight                        // default 'md' (220px)
  formatValue?: (value: number) => string     // default: BRL sem decimais
  formatLabel?: (value: string | number | Date) => string // default: identidade
  showTooltip?: boolean                       // default true
  showLegend?: ChartLegendPosition            // default 'bottom'
  showGrid?: boolean                          // default true
  referenceLines?: readonly ChartReferenceLine[]
  tokens?: ChartTokensOverride                // override raro; prefira series[i].tone
  emptyState?: ReactNode                      // default: ChartEmpty (EmptyState do DS)
  loading?: boolean                           // default false — Skeleton no lugar do chart
  className?: string
  style?: CSSProperties
  'aria-label'?: string                       // default varia por componente (ex.: "Gráfico de barras")
}
```

### `ChartBar`

```ts
type ChartBarLayout = 'grouped' | 'stacked'

interface ChartBarProps<TDatum, K> extends ChartBaseProps<TDatum, K> {
  layout?: ChartBarLayout   // default 'grouped'
  categoryGap?: number      // default 20 (%, 0..100)
  maxBarSize?: number       // default 48 (px)
}
```
`layout="stacked"` empilha por **valor absoluto** (soma das séries define a altura da
barra) — para percentual normalizado, use `ChartBarStacked`.

### `ChartBarHorizontal`

```ts
interface ChartBarHorizontalProps<TDatum, K>
  extends Omit<ChartBaseProps<TDatum, K>, 'referenceLines'> {
  maxBarSize?: number   // default 32 (px)
}
```
Sem `referenceLines` (não suportado nesta orientação). Categorias sempre no eixo Y
(`width: 110` fixo para rótulos).

### `ChartBarStacked`

```ts
type ChartBarStackedOrientation = 'vertical' | 'horizontal'

interface ChartBarStackedProps<TDatum, K>
  extends Omit<ChartBaseProps<TDatum, K>, 'referenceLines'> {
  orientation?: ChartBarStackedOrientation  // default 'vertical'
  maxBarSize?: number                       // default 32 (px)
  categoryGap?: number                      // default 20 (%)
}
```
Sem `referenceLines`. **Sempre 100% empilhado** (`stackOffset="expand"` no Recharts) —
o eixo de valor mostra `%`, não o valor absoluto; ver Armadilhas comuns.

### `ChartCombo`

```ts
type ChartComboSeries<K> =
  | (ChartSeries<K> & { type: 'line' })
  | (Omit<ChartSeries<K>, 'area' | 'dashed'> & { type: 'bar' })

interface ChartComboProps<TDatum, K> extends Omit<ChartBaseProps<TDatum, K>, 'series'> {
  series: readonly ChartComboSeries<K>[]
  curve?: 'basis' | 'natural' | 'monotone' | 'linear' | 'step'  // default 'basis'
  strokeWidth?: number   // default 2.5
  maxBarSize?: number    // default 24 (px)
}
```
Cada item de `series` precisa de `type: 'bar' | 'line'`. Barras não suportam
`area`/`dashed` (o tipo TS bloqueia).

### `ChartLine`

```ts
interface ChartLineProps<TDatum, K> extends ChartBaseProps<TDatum, K> {
  curve?: 'basis' | 'natural' | 'monotone' | 'linear' | 'step'  // default 'basis'
  strokeWidth?: number    // default 2.5
  showDots?: boolean      // default false
}
```

### `ChartDonut` (não estende `ChartBaseProps` — props próprias)

```ts
interface ChartDonutSlice {
  key: string
  label: string
  value: number
  tone: ChartTone
}

interface ChartDonutProps {
  slices: readonly ChartDonutSlice[]
  formatValue?: (value: number) => string        // default BRL sem decimais
  height?: 'sm' | 'md' | 'lg' | number            // default 'md'; donut é sempre quadrado
  innerRadiusPercent?: number                     // default 44 (menor % = anel mais grosso)
  paddingAngle?: number                           // default 0 (fatias grudadas)
  showLegend?: ChartLegendPosition                // default 'bottom'
  showTooltip?: boolean                            // default true
  centerSlot?: ReactNode                          // sobrescreve centerLabel/centerValue
  centerLabel?: string
  centerValue?: string
  tokens?: ChartTokensOverride
  emptyState?: ReactNode
  loading?: boolean
  className?: string
  style?: CSSProperties
  'aria-label'?: string
}
```

### `ChartSparkline` (props próprias)

```ts
interface ChartSparklineProps {
  data: readonly number[]      // série de valores, plotados na ordem do array
  tone?: ChartTone              // default 'primary'
  height?: number               // default 40 (px)
  width?: number | string       // default '100%'
  strokeWidth?: number          // default 1.5
  area?: boolean                // default false — preenche com gradient
  className?: string
  style?: CSSProperties
  'aria-label'?: string
}
```
Sem eixos, grid, tooltip ou legenda — feito para uso inline (célula de tabela, KPI).

### `ChartAgingStrip` (props próprias)

```ts
interface ChartAgingSegment {
  key: string
  label: string
  value: number
  tone: ChartTone
}

interface ChartAgingStripProps {
  segments: readonly ChartAgingSegment[]  // somam qualquer valor; normalização é automática
  height?: number                          // default 48 (px)
  formatValue?: (value: number) => string  // default BRL sem decimais (tooltip)
  formatPercent?: (ratio: number) => string // default "n,n%" 1 casa
  showLegend?: boolean                     // default true
  showTooltip?: boolean                    // default true (title HTML nativo por segmento)
  loading?: boolean
  emptyState?: ReactNode
  className?: string
  style?: CSSProperties
  'aria-label'?: string
}
```

### `ChartCard` (moldura, não é um gráfico)

```ts
type ChartCardPadding = 'sm' | 'md' | 'lg' | 'none'
type ChartCardAppearance = 'outlined' | 'elevated' | 'ghost'

interface ChartCardMenuItem {
  id: string
  label: string
  icon?: ReactNode
  onSelect: () => void
  danger?: boolean
}

interface ChartCardProps {
  title?: string
  subtitle?: string
  actions?: ReactNode           // slot antes do menu (ex.: filtro de período)
  menuItems?: readonly ChartCardMenuItem[]  // se presente, renderiza IconButton + Overlay(menu)
  menuAriaLabel?: string        // default 'Mais opções'
  children: ReactNode           // o chart concreto
  footer?: ReactNode
  appearance?: ChartCardAppearance  // default 'outlined'
  padding?: ChartCardPadding        // default 'md'
  className?: string
  style?: CSSProperties
}
```

### Notas de comportamento

- **Tone → cor:** todas as séries/fatias/segmentos são resolvidos por `tone` via
  `TONE_TO_TOKEN`, que aponta para `var(--chart-tone-<tone>)`. `tokens.seriesByTone`
  é o único jeito suportado de sobrescrever cor por tom — não passe hex direto.
  Trocar o tema (light/dark) é responsabilidade dos tokens CSS, não do componente.
- **Loading/empty são mutuamente exclusivos e vêm antes do dado:** `loading` renderiza
  um `Skeleton` no lugar do chart; sem `loading`, `data.length === 0` (ou `slices`/
  `segments` vazios, ou soma zero em `ChartAgingStrip`) renderiza `emptyState`
  (default: `EmptyState` do DS com "Sem dados para exibir").
  Ambos ignoram completamente `data`/`series`.
- **Tooltip e legend são geradas a partir de `series`/`slices`/`segments`**, não do
  Recharts puro — por isso a cor do swatch na legenda/tooltip sempre bate com a cor
  da série renderizada.
- **`ChartCombo`/`ChartLine` controlam ordem de desenho, não a ordem passada em
  `series`:** em `ChartCombo`, barras são desenhadas antes das linhas (linhas ficam
  por cima); em `ChartLine`, séries com `area: true` são desenhadas antes das sem área.
  Isso é para legibilidade visual e independe da ordem do array `series`.
- Todos os charts com áreas/eixos desabilitam animação (`isAnimationActive={false}`) —
  não há transições de entrada.
- `height` como preset (`sm`/`md`/`lg`/`xl`) usa classe CVA; como `number` usa `style`
  inline — os dois caminhos coexistem no mesmo componente.

---

## Exemplos

```tsx
import { ChartBar } from '../DataDisplay/Chart/ChartBar'
import { ChartLine } from '../DataDisplay/Chart/ChartLine'
import { ChartCombo } from '../DataDisplay/Chart/ChartCombo'
import { ChartDonut } from '../DataDisplay/Chart/ChartDonut'
import { ChartCard } from '../DataDisplay/Chart/ChartCard'
import { ChartSparkline } from '../DataDisplay/Chart/ChartSparkline'
import { ChartAgingStrip } from '../DataDisplay/Chart/ChartAgingStrip'
// import relativo — a família não está no barrel público (ver bullet "Export")

const QUARTERS = [
  { periodo: '1T', entradas: 42000, saidas: 18000 },
  { periodo: '2T', entradas: 58000, saidas: 22000 },
]

// Barras agrupadas
<ChartBar
  data={QUARTERS}
  xKey="periodo"
  series={[
    { key: 'entradas', label: 'Entradas', tone: 'primary' },
    { key: 'saidas', label: 'Saídas', tone: 'error' },
  ]}
/>

// Linha com área e referência
<ChartLine
  data={QUARTERS}
  xKey="periodo"
  series={[{ key: 'entradas', label: 'Entradas', tone: 'primary', area: true }]}
  referenceLines={[{ value: 50000, label: 'Meta', variant: 'success' }]}
/>

// Combo: barra + linha
<ChartCombo
  data={QUARTERS}
  xKey="periodo"
  series={[
    { key: 'entradas', label: 'Entradas', tone: 'primary', type: 'bar' },
    { key: 'saidas', label: 'Saídas', tone: 'error', type: 'line' },
  ]}
/>

// Donut com centro custom
<ChartDonut
  slices={[
    { key: 'rf', label: 'Renda Fixa', value: 60, tone: 'primary' },
    { key: 'acoes', label: 'Ações', value: 40, tone: 'warning' },
  ]}
  centerValue="R$ 406k"
  centerLabel="Total"
/>

// Sparkline inline (ex.: célula de tabela)
<ChartSparkline data={[10, 14, 9, 18, 22, 19]} tone="success" area />

// Faixa de aging
<ChartAgingStrip
  segments={[
    { key: 'ate30', label: 'Até 30 dias', value: 120000, tone: 'success' },
    { key: '31a60', label: '31–60 dias', value: 45000, tone: 'warning' },
    { key: 'acima60', label: '+60 dias', value: 12000, tone: 'error' },
  ]}
/>

// Moldura de card em volta de qualquer chart
<ChartCard title="Fluxo de Caixa" subtitle="Últimos 30 dias">
  <ChartLine data={QUARTERS} xKey="periodo" series={[/* ... */]} />
</ChartCard>
```

---

## Acessibilidade

- Todo chart de área/valor (`ChartBar*`, `ChartCombo`, `ChartLine`, `ChartDonut`,
  `ChartSparkline`, `ChartAgingStrip`) tem `role="img"` com `aria-label` (default
  descritivo tipo "Gráfico de barras"; sempre prefira passar um `aria-label` com o
  contexto real, ex.: `"Entradas e saídas por trimestre"`).
- `ChartAgingStrip` compõe um `aria-label` automático a partir dos segmentos e
  percentuais quando nenhum é passado (`"Até 30 dias: 68,2%, ..."`); os segmentos em
  si são `aria-hidden` (a informação já está no label do container e na legenda em
  lista real).
- Legendas (`ChartLegend`) e a legenda do `ChartAgingStrip` são `<ul role="list">` —
  navegáveis por leitor de tela; os swatches de cor são `aria-hidden`.
- Tooltip tem `role="tooltip"`, mas é hover/foco do Recharts — **não é** a fonte
  primária de acessibilidade do dado; não coloque informação crítica só no tooltip.
- `ChartCard` sem `title`/`subtitle`/`actions`/`menuItems` não renderiza header (evita
  `PageHeader` vazio); o `IconButton` do menu de ações sempre exige `menuAriaLabel`
  (tem default) e semântica de `Overlay` menu (react-aria) já cobre teclado.

## Armadilhas comuns

- **`ChartBarStacked` não é "empilhado por valor absoluto"** — é sempre normalizado a
  100% (`stackOffset="expand"`; eixo em `%`). Para comparar magnitude absoluta entre
  categorias empilhadas, use `ChartBar` com `layout="stacked"`, não `ChartBarStacked`.
- A família **não está no barrel** (`src/components/index.ts`) nem em `exports` do
  `package.json` — importar como se fosse `@srm/diamond` falha. Use import relativo
  dentro do monorepo, ou adicione a exportação antes de consumir externamente.
- `series[i].key` precisa existir literalmente em `TDatum` (tipagem genérica) — chaves
  divergentes entre `data` e `series` não dão erro em runtime, só barra vazia/tooltip
  sem valor.
- `formatValue`/`formatLabel` default assumem contexto financeiro em `pt-BR` (BRL,
  sem decimais) — em gráficos não-monetários, sempre sobrescreva os dois, senão o
  eixo Y e o tooltip mostram valores como moeda.
- `ChartBarHorizontal` e `ChartBarStacked` **não aceitam `referenceLines`** (omitido
  do tipo via `Omit`) — não é possível passar benchmark nessas duas variantes.
- `ChartDonut`, `ChartSparkline`, `ChartAgingStrip` e `ChartCard` **não estendem**
  `ChartBaseProps` — não existe `xKey`/`series` (no sentido de `ChartSeries`) neles;
  cada um tem seu próprio shape (`slices`, `data: number[]`, `segments`).
- `ChartCard.padding` e `appearance` reaproveitam a mesma fonte de superfície de card
  da Fase 1 (`cardSurfaceVariants`) — não redefina espaçamento/borda via `className`
  sem checar esse componente primeiro.
