# IaSRMChatBubble

Mensagem de chat: avatar + balão + timestamp. `type` é a **discriminante** do tipo
público — cada variante aceita apenas as props que realmente renderiza, então
combinações sem sentido são rejeitadas em tempo de compilação.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMChatBubble/`
- **Export:** `import { IaSRMChatBubble } from '@srm/diamond';`
- **Relacionados:** [IaSRMConversationFeed](./IaSRMConversationFeed.md) (mapeia N bubbles), [IaSRMChatEmbed](./IaSRMChatEmbed.md) (vai no slot `embed`), [IaSRMAvatar](./IASRMAvatar.md) (avatar do assistente), [Avatar](../Identity/Avatar.md) (avatar do usuário)

---

## Quando usar

- Renderizar uma mensagem individual de chat, do assistente ou do usuário.
- Solto, quando você monta o layout da conversa por conta própria.
- Quando a resposta precisa de um card visual embutido → passe `embed`.

## Quando **não** usar

- Para uma lista de mensagens → [`IaSRMConversationFeed`](./IaSRMConversationFeed.md), que já empilha, dá scroll e expõe `role="log"`.
- Para o estado "digitando" → o átomo `TypingIndicator` (exportado por este componente).
- Para texto corrido fora de contexto de conversa → tipografia comum.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, ReactNode, Ref } from 'react';

type IaSRMChatBubbleType = 'iaSRM' | 'user';

interface IaSRMChatBubbleTimeProps {
  timestamp?: number | Date;              // ativa o modo automático now → past
  now?: number | Date;                    // instante de referência (SSR determinístico)
  formatPast?: (date: Date) => string;    // default: HH:mm local
  time?: string;                          // literal; só quando timestamp ausente
  timeVariant?: 'now' | 'past';           // só quando timestamp ausente; default 'past'
  nowLabel?: string;                      // default: 'agora'
}

interface Base extends Omit<ComponentPropsWithoutRef<'div'>, 'children'>, IaSRMChatBubbleTimeProps {
  avatar?: ReactNode | null;              // null remove o slot
  ref?: Ref<HTMLDivElement>;
}

// type='iaSRM' (default) — três níveis de texto + embed
interface IaSRMChatBubbleAssistantProps extends Base {
  type?: 'iaSRM';
  main?: ReactNode;                       // título (bold)
  text?: ReactNode;                       // corpo
  hint?: ReactNode;                       // apoio terciário
  embed?: ReactNode;
  initials?: undefined;                   // exclusivo de 'user'
}

// type='user' — conteúdo textual único
interface IaSRMChatBubbleUserProps extends Base {
  type: 'user';
  text?: ReactNode;
  initials?: string;                      // ignorado se `avatar` for informado
  main?: undefined;                       // exclusivos de 'iaSRM'
  hint?: undefined;
  embed?: undefined;
}

type IaSRMChatBubbleProps = IaSRMChatBubbleAssistantProps | IaSRMChatBubbleUserProps;
```

### Notas de comportamento

- **Union discriminada, não flags.** Passar `main` numa bubble `user`, ou `initials` numa `iaSRM`, é **erro de compilação**. As props exclusivas são declaradas como `undefined` (não `never`) para funcionarem sob `exactOptionalPropertyTypes`.
- `type='iaSRM'` renderiza os três níveis via `BubbleContent`: `main` (13px semibold) → `text` (13px regular) → `hint` (12px secondary). Todos opcionais; nenhum é descartado.
- `type='user'` renderiza só `text`, na bolha brand à direita.
- **Timestamp automático**: com `timestamp`, o átomo `BubbleTime` exibe `nowLabel` nos primeiros 60s e transiciona sozinho para o formato `past` no exato ponto de virada (`setTimeout`). `time` e `timeVariant` são ignorados nesse modo.
- O relógio é lido apenas na inicialização do estado e no efeito — **nunca a cada render**. Para SSR sem divergência de hidratação, injete `now` com o mesmo valor no servidor e no cliente.
- `avatar` substitui o default (`IaSRMAvatar circleTint sm` para `iaSRM`, `Avatar` de iniciais para `user`) e `null` remove o slot.
- Sem `initials` e sem `avatar`, o avatar do usuário renderiza vazio — o DS **não inventa** iniciais.
- A bolha em si não é interativa. Ela repassa `...rest`, então se você precisa de clique na mensagem, passe `onClick`/`role`/`tabIndex` você mesmo — ou coloque os controles dentro de `embed`.

---

## Átomos exportados

Todos vêm do mesmo pacote e podem ser compostos avulsos:

| Átomo | Papel |
|---|---|
| `Bubble` | O balão, sem avatar/hora/conteúdo. Variantes `iaSRM` \| `user`. |
| `BubbleContent` | Bloco de texto em 3 níveis: `title` / `text` / `hint`. |
| `BubbleTime` | Timestamp com variantes `now` \| `past` e transição automática. |
| `BubbleTypingDots` | Três dots animados, sem bolha. Decorativo por default. |
| `TypingIndicator` | `Bubble` + `BubbleTypingDots` com `role="status"`. `aria-label` default `'Gerando resposta'`. |

Também exportados: `bubbleVariants` e `bubbleTimeVariants` (CVA), `NOW_WINDOW_MS`,
`DEFAULT_NOW_LABEL`, `DEFAULT_TYPING_LABEL`, `formatTimeOfDay`, `toMillis`.

---

## Exemplos

```tsx
import { IaSRMChatBubble, TypingIndicator } from '@srm/diamond';

// Assistente — os três níveis de texto
<IaSRMChatBubble main="Confirmação de TED" text="R$ 1.500,00 para Fulano." hint="Autorize abaixo." />

// Assistente — só o corpo (type default)
<IaSRMChatBubble text="Como posso ajudar?" />

// Usuário
<IaSRMChatBubble type="user" text="Quero ver meu extrato" initials="LO" />

// Timestamp automático: "agora" por 60s, depois HH:mm
<IaSRMChatBubble main="Mensagem recém-enviada" timestamp={Date.now()} />

// Timestamp literal
<IaSRMChatBubble main="Olá" time="10:42" />

// i18n do label recente + formatador próprio
<IaSRMChatBubble
  text="Just sent"
  timestamp={sentAt}
  nowLabel="just now"
  formatPast={(d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
/>

// SSR determinístico
<IaSRMChatBubble text="Olá" timestamp={sentAt} now={serverNow} />

// Com embed (card visual dentro da bolha)
<IaSRMChatBubble
  main="Confirme o pagamento"
  embed={<IaSRMChatEmbed><MeuCard onConfirm={confirm} /></IaSRMChatEmbed>}
/>

// Avatar próprio / sem avatar
<IaSRMChatBubble type="user" text="Oi" avatar={<Avatar name="Luiz Otávio" size="md" />} />
<IaSRMChatBubble text="Sem avatar" avatar={null} />

// ERRO de compilação — o tipo rejeita
<IaSRMChatBubble type="user" text="Oi" main="não existe em user" />
```

---

## Acessibilidade

- O avatar (assistente ou usuário) é decorativo — o texto da mensagem é o conteúdo.
- `TypingIndicator` expõe `role="status"` + `aria-live="polite"` no balão externo, com os dots decorativos por dentro, então o leitor de tela anuncia o status uma vez, sem soletrar a animação.
- Ao usar `embed` com controles, garanta que **eles** tenham nome acessível — a bolha não os descreve.
- Se você tornar a bolha clicável via `...rest`, adicione `role` e suporte a teclado; o componente não faz isso por você.

## Armadilhas comuns

- Não tente passar `main`/`hint`/`embed` numa bubble `user` (nem `initials` numa `iaSRM`) — a union rejeita, e é intencional.
- `time` e `timeVariant` são **ignorados** quando `timestamp` está presente. Escolha um dos dois modos.
- Não confie no timestamp automático em SSR sem passar `now` — o relógio do servidor e do cliente diferem.
- Não use este componente em loop para montar uma conversa; use [`IaSRMConversationFeed`](./IaSRMConversationFeed.md), que ainda adiciona scroll e `role="log"`.
