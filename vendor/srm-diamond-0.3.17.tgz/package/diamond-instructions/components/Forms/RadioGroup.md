# RadioGroup

Contêiner de seleção exclusiva para vários [`Radio`](./Radio.md), construído diretamente
sobre `RadioGroup` do `react-aria-components`. Renderiza um rótulo do grupo (`Label`), a
lista de `Radio` filhos e um texto de ajuda opcional (`Text` no slot `description`); propaga
`value`/`onChange`/`isDisabled` para os itens via contexto do react-aria — os `Radio` filhos
não precisam saber que estão dentro de um grupo.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Radio/` (arquivo `RadioGroup.tsx`)
- **Export:** `import { RadioGroup } from '@srm/diamond';`
- **Relacionados/Base:** [Radio](./Radio.md) (item individual — obrigatório como filho)

---

## Quando usar

- Sempre que houver **duas ou mais** opções de escolha única e mutuamente exclusivas:
  plano de conta, forma de resgate, perfil de risco, frequência de aporte, tipo de pessoa
  (física/jurídica).
- Quando precisar de navegação por teclado (setas) entre as opções e anúncio correto do
  conjunto para leitores de tela — o `RadioGroup` cuida disso automaticamente.
- Quando quiser desabilitar **todas** as opções de uma vez (`isDisabled` no grupo, em vez
  de repetir em cada `Radio`).

## Quando **não** usar

- Uma única opção booleana isolada, sem outras opções relacionadas → use
  [`Radio`](./Radio.md) avulso (fora de um grupo), com semântica `isSelected`/`onChange(boolean)`.
- Seleção múltipla (mais de uma opção marcada ao mesmo tempo) → use `CheckboxGroup`
  (sem doc publicado ainda neste índice).
- Opções com área clicável grande em formato de cartão → use o par `OptionCard` +
  `OptionCardGroup`.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { RadioGroupProps as AriaRadioGroupProps } from 'react-aria-components';

interface RadioGroupProps extends Omit<AriaRadioGroupProps, 'className' | 'children'> {
  label?: ReactNode;         // rótulo do grupo, renderizado acima dos itens
  helperText?: ReactNode;    // texto de ajuda abaixo dos itens (slot="description")
  children?: ReactNode;      // os <Radio value="..."> filhos
  className?: string;
}
```

### Props herdadas de `AriaRadioGroupProps` (react-aria-components / react-stately)

| Prop                  | Tipo                                  | Descrição                                                                 |
|-----------------------|----------------------------------------|-----------------------------------------------------------------------------|
| `value`               | `string \| null`                       | Valor selecionado (modo controlado) — deve casar com o `value` de um `Radio` filho. |
| `defaultValue`        | `string`                               | Valor inicial (modo não controlado).                                        |
| `onChange`            | `(value: string) => void`              | Disparado ao trocar a seleção; recebe o **`value`** (string) do `Radio` escolhido. |
| `isDisabled`          | `boolean`                               | Desabilita **todos** os `Radio` filhos.                                     |
| `isReadOnly`          | `boolean`                               | Impede alteração da seleção mantendo o visual habilitado.                   |
| `isRequired`          | `boolean`                               | Marca o grupo como obrigatório para validação.                              |
| `orientation`         | `'horizontal' \| 'vertical'`            | Orientação de navegação por teclado (default do react-aria: `'vertical'`).  |
| `name`                | `string`                                 | Nome do campo em submissão de formulário HTML nativo.                       |
| `aria-label` / `aria-labelledby` | `string`                     | Nome acessível alternativo, quando `label` não é usado.                     |

### Notas de comportamento

- `label`, quando presente, é renderizado como `<Label>` do react-aria (associado
  automaticamente ao grupo) — **prefira `label` a `aria-label`** sempre que houver espaço
  visual para um rótulo.
- `helperText` é renderizado como `<Text slot="description">`, associado ao grupo via
  `aria-describedby` automaticamente pelo react-aria.
- O layout dos itens é uma coluna (`display: flex; flex-direction: column; gap: var(--space-3)`)
  — não há variante horizontal própria no CSS; `orientation="horizontal"` do react-aria
  ajusta a navegação por teclado, mas o layout visual continua em coluna a menos que você
  sobrescreva via `className`.
- Cada `Radio` filho precisa de um `value` próprio e distinto — é o que o `onChange` do
  grupo devolve ao selecionar aquele item.

---

## Exemplos

```tsx
import { useState } from 'react';
import { Radio, RadioGroup } from '@srm/diamond';

// Controlado
function PerfilRisco() {
  const [perfil, setPerfil] = useState('moderado');
  return (
    <RadioGroup label="Perfil de risco" value={perfil} onChange={setPerfil} helperText="Você pode alterar isso depois.">
      <Radio value="conservador">Conservador</Radio>
      <Radio value="moderado">Moderado</Radio>
      <Radio value="agressivo">Agressivo</Radio>
    </RadioGroup>
  );
}

// Não controlado, com valor inicial
<RadioGroup label="Plano" defaultValue="pro" helperText="Escolha o plano da sua conta.">
  <Radio value="basic">Básico</Radio>
  <Radio value="pro">Pro</Radio>
  <Radio value="enterprise">Enterprise</Radio>
</RadioGroup>

// Grupo inteiro desabilitado
<RadioGroup label="Frequência de aporte" isDisabled defaultValue="mensal">
  <Radio value="mensal">Mensal</Radio>
  <Radio value="trimestral">Trimestral</Radio>
</RadioGroup>

// Tamanho e tema propagados manualmente para os itens (RadioGroup não gerencia size/theme)
<RadioGroup label="Forma de resgate" defaultValue="ted">
  <Radio value="ted" size="sm" theme="dark">TED</Radio>
  <Radio value="pix" size="sm" theme="dark">PIX</Radio>
</RadioGroup>

// Sem label visível (usar aria-label)
<RadioGroup aria-label="Tipo de pessoa" defaultValue="fisica">
  <Radio value="fisica">Pessoa física</Radio>
  <Radio value="juridica">Pessoa jurídica</Radio>
</RadioGroup>
```

### Integração com React Hook Form

```tsx
<Controller
  name="perfil"
  control={control}
  rules={{ required: 'Selecione um perfil.' }}
  render={({ field, fieldState }) => (
    <RadioGroup
      label="Perfil de risco"
      value={field.value}
      onChange={field.onChange}
      isRequired
      helperText={fieldState.error?.message}
    >
      <Radio value="conservador">Conservador</Radio>
      <Radio value="moderado">Moderado</Radio>
      <Radio value="agressivo">Agressivo</Radio>
    </RadioGroup>
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label` (visível, recomendado) ou `aria-label`/`aria-labelledby` — sem
  um dos dois, o `role="radiogroup"` fica sem nome acessível para tecnologia assistiva.
- Navegação por setas (`ArrowUp`/`ArrowDown`, ou `ArrowLeft`/`ArrowRight` conforme
  `orientation`) move o foco **e já seleciona** o item focado — comportamento nativo de
  radio group, herdado do react-aria, sem necessidade de lógica extra.
- `helperText` é associado ao grupo via `aria-describedby`, então é lido junto com o
  nome do grupo por leitores de tela.
- `isDisabled` no grupo remove todos os itens da ordem de tabulação de forma consistente
  (nenhum radio fica "meio habilitado").

## Armadilhas comuns

- Esquecer o `value` único em algum `Radio` filho — sem ele, a seleção daquele item não
  é distinguível das demais (todos caem no valor padrão `'on'`).
- Esperar que `onChange` do grupo receba um `boolean` — ele recebe o **`value` (string)**
  do item selecionado; a assinatura booleana só existe no `Radio` avulso (fora de grupo).
- Repetir `isDisabled` em cada `Radio` filho quando o grupo inteiro deve ficar desabilitado
  — basta `isDisabled` no `RadioGroup`.
- Misturar `Radio`s com `value`s duplicados entre grupos diferentes na mesma tela esperando
  isolamento automático — cada `RadioGroup` já isola sua própria seleção; valores repetidos
  entre grupos distintos não causam conflito, mas dentro do **mesmo** grupo, `value`s
  duplicados tornam duas opções indistinguíveis para o `onChange`.
