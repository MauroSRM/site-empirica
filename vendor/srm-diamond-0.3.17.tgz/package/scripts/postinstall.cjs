'use strict';

const fs   = require('fs');
const path = require('path');

const pkgDir    = path.resolve(__dirname, '..');
const targetDir = process.env.INIT_CWD || process.cwd();

// Quando rodando dentro do próprio repositório da lib, não faz nada
if (path.resolve(targetDir) === path.resolve(pkgDir)) {
  process.exit(0);
}

const srcDir  = path.join(pkgDir, 'diamond-instructions');
const destDir = path.join(targetDir, 'diamond-instructions');

try {
  if (!fs.existsSync(srcDir)) process.exit(0);

  // Copia recursivamente toda a árvore diamond-instructions/ (AGENTS.md, design.md,
  // components/index.md + docs por componente organizados em subpastas por categoria).
  function copyTree(from, to) {
    const stat = fs.statSync(from);
    if (stat.isDirectory()) {
      fs.mkdirSync(to, { recursive: true });
      for (const entry of fs.readdirSync(from)) {
        copyTree(path.join(from, entry), path.join(to, entry));
      }
    } else {
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(from, to);
    }
  }

  copyTree(srcDir, destDir);

  console.log('\x1b[36m[@srm/diamond]\x1b[0m diamond-instructions/ atualizado na raiz do projeto');
  console.log('\x1b[36m[@srm/diamond]\x1b[0m   → diamond-instructions/AGENTS.md            (protocolo p/ agentes de IA — leia 1º)');
  console.log('\x1b[36m[@srm/diamond]\x1b[0m   → diamond-instructions/components/index.md  (roteador de componentes)');
  console.log('\x1b[36m[@srm/diamond]\x1b[0m   → diamond-instructions/components/**/*.md   (doc detalhado por componente)');
  console.log('\x1b[36m[@srm/diamond]\x1b[0m   → diamond-instructions/design.md            (tokens de design)');
} catch {
  // Nunca quebrar o install do consumidor por causa disto
}
