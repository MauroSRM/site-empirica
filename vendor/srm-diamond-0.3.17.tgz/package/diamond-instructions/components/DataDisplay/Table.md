# Table

Tabela de dados genérica (`TRow`) do Diamond, construída sobre `Table` do
`react-aria-components`. Colunas são 100% declarativas (`TableColumn<TRow>[]`);
ordenação, seleção e paginação são **controladas e server-side** — a Table só emite
eventos, quem consulta o back-end (ou reordena/filtra) é a tela que a usa. Suporta
resize de colunas por arraste, coluna fixa à direita (`pinnedRight`), densidade,
zebra, e estados de loading/vazio/erro.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/Table/` (`Table.tsx`, `Table.cells.tsx`,
  `Table.utils.tsx`, `Table.constants.ts`, `Table.variants.ts`, `TablePagination.tsx`)
- **Export:** `import { Table, CellCurrency, CellNumber, CellPercent, CellDate } from '@srm/diamond';`
  (tipos `TableProps`, `TableColumn`, `TableCellRenderProps`, `TableSortState`,
  `TableSortDirection`, `TableDensity`, `TablePaginationState`, `TableRowKey`,
  `TableColumnAlign`, `TableCellFormat`, `CellCurrencyProps`, `CellNumberProps`,
  `CellPercentProps`, `CellDateProps` também exportados pelo barrel). `TablePagination`
  **não é exportado** — é peça interna, renderizada automaticamente pela `Table`
  quando a prop `pagination` é passada; não há como usá-la isolada.
- **Relacionados:** [Chart](./Chart.md) (visualização em vez de dado tabular),
  [Tag](./Tag.md) (comum em `cellComponent` de status)

---

## Quando usar

- Listagens tabulares com colunas heterogêneas (texto, moeda, percentual, data, tags,
  ações) que precisam de ordenação, seleção em massa e/ou paginação vindas do back-end.
- Telas com muitas linhas onde resize de coluna e coluna de ações fixa (`pinnedRight`)
  importam para a usabilidade (scroll horizontal com contexto).
- Estados de carregamento/erro/vazio precisam de um padrão visual único do DS.

## Quando **não** usar

- Visualização de série/tendência/composição → família [`Chart`](./Chart.md).
- Lista simples sem cabeçalho tabular, ordenação ou seleção (ex.: histórico de itens
  em card) → considere `ListLabel`/`ListLabelGroup` antes de trazer o peso de uma Table.
- Ordenação/paginação **no cliente** sem back-end — a Table não faz isso por você;
  se o dado é pequeño e estático, ordene/pagine você mesmo antes de passar `rows`
  (como a story `Ordenavel` faz para simular localmente).

---

## Interface

```ts
type TableRowKey = string | number
type TableColumnAlign = 'start' | 'center' | 'end'
type TableSortDirection = 'ascending' | 'descending'
type TableDensity = 'default' | 'compact'
type TableCellFormat = 'currency' | 'percent' | 'number' | 'date'

interface TableSortState {
  column: string
  direction: TableSortDirection
}

/** Props recebidas por um `cellComponent` — tem a LINHA inteira em mãos. */
interface TableCellRenderProps<TRow> {
  row: TRow
  value: TRow[keyof TRow] | undefined  // row[field] quando `field` definido; senão undefined
  rowId: TableRowKey
  column: TableColumn<TRow>
}

interface TableColumn<TRow> {
  id: string                                   // key única (sort, resize, react key)
  header: ReactNode
  field?: keyof TRow & string                  // chave de TRow exibida na célula
  cell?: (row: TRow) => ReactNode              // render inline; PRIORIDADE MÁXIMA
  cellComponent?: ComponentType<TableCellRenderProps<TRow>>  // recebe row/value/rowId/column
  format?: TableCellFormat                     // aplicado a `field` (se sem cell/cellComponent)
  accessor?: (row: TRow) => ReactNode          // alternativa a `field`
  align?: TableColumnAlign                     // default 'start'
  sortable?: boolean                           // habilita onSortChange
  resizable?: boolean                          // default true; false trava resize só desta coluna
  pinnedRight?: boolean                        // fixa a coluna à direita (sticky)
  width?: number | string                      // px (number) ou string ('120px', '%')
  minWidth?: number                            // limite inferior do arraste
  maxWidth?: number                            // limite superior do arraste
  isRowHeader?: boolean                        // a11y — no máximo uma coluna por tabela
}

interface TablePaginationState {
  page: number                                 // 1-based
  pageSize: number
  total: number                                // total no servidor
  pageSizeOptions?: readonly number[]          // default [5, 10, 25, 50]
}

interface TableProps<TRow> {
  columns: readonly TableColumn<TRow>[]
  rows: readonly TRow[]                        // linhas DA PÁGINA ATUAL — não pagina sozinha
  getRowId: (row: TRow) => TableRowKey
  'aria-label'?: string                        // default 'Tabela de dados'
  sort?: TableSortState | null                  // controlado
  onSortChange?: (sort: TableSortState) => void
  selectable?: boolean                          // default false
  selectedKeys?: 'all' | ReadonlySet<TableRowKey>  // controlado
  onSelectionChange?: (keys: 'all' | Set<TableRowKey>) => void
  pagination?: TablePaginationState             // omitir = sem paginação (nem renderiza a UI)
  onPageChange?: (page: number) => void
  onPageSizeChange?: (pageSize: number) => void
  resizable?: boolean                           // default false
  density?: TableDensity                        // default 'default'
  striped?: boolean                             // default false
  loading?: boolean                             // default false — skeleton no corpo
  error?: boolean | string | ReactNode          // true=EmptyState padrão; string=customBody; ReactNode=escape-hatch
  emptyState?: ReactNode                        // default EmptyState 'default' do DS
  className?: string
}
```

### Células prontas (`Table.cells.tsx`)

```ts
interface CellCurrencyProps {
  value: number | null | undefined   // null/undefined → '—'
  currency?: string                  // default 'BRL'
  locale?: string                    // default 'pt-BR'
  fractionDigits?: number            // default 0
  colorNegative?: boolean            // default false — vermelho se negativo
}

interface CellNumberProps {
  value: number | null | undefined
  locale?: string                    // default 'pt-BR'
  fractionDigits?: number            // default 0
}

interface CellPercentProps {
  value: number | null | undefined   // já em pontos percentuais (12.4 → "12,4%")
  fractionDigits?: number            // default 1
  signed?: boolean                   // default false — prefixa '+' em positivos
  colorSign?: boolean                // default false — verde/vermelho por sinal
}

interface CellDateProps {
  value: Date | string | number | null | undefined
  locale?: string                                    // default 'pt-BR'
  options?: Intl.DateTimeFormatOptions                // default { day: '2-digit', month: '2-digit', year: 'numeric' }
}
```
`format: 'currency' | 'percent' | 'number' | 'date'` na coluna usa exatamente estes
componentes com os defaults acima (sem as demais props) — para customizar formatação
(ex.: `fractionDigits`, `colorSign`), use `cell={(r) => <CellPercent value={r.x} colorSign />}`
em vez de `format`.

### Notas de comportamento

- **Resolução da célula, em ordem de prioridade:** `cell(row)` > `cellComponent` >
  `field` (+ `format`, senão `String(value)`) > `accessor(row)` > `null`. Definir
  `cell` **e** `cellComponent`/`field` na mesma coluna faz os últimos serem ignorados.
- **Ordenação, seleção e paginação são 100% controladas e server-side** — a Table
  nunca ordena/filtra/pagina `rows` internamente. `sort`/`selectedKeys`/`pagination`
  refletem apenas o que a tela passa; os `on*Change` só **emitem intenção**.
- **`rows` já deve vir só com a página atual** — passar todas as linhas junto com
  `pagination` não corta automaticamente; quem pagina é o back-end (ou você, se
  simular localmente, como a story faz com `.slice()`).
- **Resize é literal e por coluna:** arrastar uma borda muda **só** aquela coluna
  (respeitando `minWidth`/`maxWidth`, default mínimo 64px), as demais mantêm a
  largura. Se a soma ultrapassar o container, surge scroll horizontal; se sobrar
  espaço com `resizable=false`, a última coluna não fixada absorve o espaço
  restante (coluna "filler").
- **`pinnedRight`** empilha as colunas marcadas na borda direita (sticky), na ordem
  em que aparecem em `columns`; o deslocamento (`right`) de cada uma é calculado a
  partir da largura das que ficam à direita dela.
- **Precedência de estados do corpo:** `error` (se definido) > `loading` > vazio
  (`rows.length === 0`) > dados. `error === true` usa `EmptyState variant="error"`
  default; `error` string vira `customBody` do mesmo `EmptyState`; `error` ReactNode
  substitui tudo (escape-hatch). Paginação (`TablePagination`) só renderiza quando
  há `pagination` **e** não há `loading` **nem** `error`.
- **Coluna de seleção** (`selectable`) é sempre fixa à esquerda (`pinnedLeft`), largura
  fixa 44px, e não conta como uma `TableColumn` — não inclua uma coluna de checkbox
  manualmente.
- `density`/`striped` são puramente visuais (classes CVA) — não alteram comportamento.

---

## Exemplos

```tsx
import { useState } from 'react'
import {
  Table,
  Tag,
  IconButton,
  type TableColumn,
  type TableSortState,
  type TableRowKey,
  type TableCellRenderProps,
} from '@srm/diamond'

interface Fund {
  id: string
  name: string
  status: 'active' | 'pending' | 'inactive'
  value: number
}

// cellComponent recebe a LINHA inteira (tags, ações, campos editáveis, etc.)
function StatusCell({ row }: TableCellRenderProps<Fund>) {
  return <Tag variant={row.status === 'active' ? 'success' : 'warning'} size="sm">{row.status}</Tag>
}
function ActionsCell({ row }: TableCellRenderProps<Fund>) {
  return (
    <IconButton
      size="sm"
      variant="ghost"
      aria-label={`Ações de ${row.name}`}
      icon={<Icon icon="more-horizontal" />}
    />
  )
}

const columns: TableColumn<Fund>[] = [
  { id: 'name', header: 'Fundo', field: 'name', isRowHeader: true, sortable: true, minWidth: 180 },
  { id: 'status', header: 'Status', cellComponent: StatusCell, width: 140 },
  { id: 'value', header: 'Patrimônio', field: 'value', format: 'currency', align: 'end', sortable: true, width: 160 },
  // coluna de ações: largura fixa (resizable:false), fixa à direita (pinnedRight)
  { id: 'actions', header: '', pinnedRight: true, width: 72, resizable: false, align: 'center', cellComponent: ActionsCell },
]

export function FundsTable({ rows, total, page, pageSize, isLoading, refetch, goToPage, setPageSize }: Props) {
  const [sort, setSort] = useState<TableSortState | null>({ column: 'name', direction: 'ascending' })
  const [selectedKeys, setSelectedKeys] = useState<'all' | Set<TableRowKey>>(new Set())

  return (
    <Table<Fund>
      columns={columns}
      rows={rows}
      getRowId={(r) => r.id}
      aria-label="Carteira de fundos"
      // Ordenação (controlada, server-side): a Table só emite o evento
      sort={sort}
      onSortChange={(s) => { setSort(s); refetch(s) }}
      // Seleção (controlada)
      selectable
      selectedKeys={selectedKeys}
      onSelectionChange={setSelectedKeys}
      // Paginação (controlada, server-side)
      pagination={{ page, pageSize, total, pageSizeOptions: [10, 25, 50] }}
      onPageChange={goToPage}
      onPageSizeChange={setPageSize}
      // Interação e estados
      resizable
      density="default"
      striped
      loading={isLoading}
    />
  )
}

// Estado de erro
<Table<Fund>
  columns={columns}
  rows={[]}
  getRowId={(r) => r.id}
  aria-label="Erro ao carregar"
  error="Falha ao carregar os dados. Tente novamente."
/>

// Estado vazio (default EmptyState do DS)
<Table<Fund> columns={columns} rows={[]} getRowId={(r) => r.id} aria-label="Sem fundos" />
```

---

## Acessibilidade

- Construída sobre `Table`/`TableHeader`/`TableBody`/`Column`/`Row`/`Cell` do
  `react-aria-components` — navegação por teclado, roles ARIA de grid e anúncio de
  ordenação/seleção já vêm da biblioteca.
- `isRowHeader` marca a coluna que identifica a linha para leitores de tela — defina
  **no máximo uma** por tabela (tipicamente a coluna de nome/identificador principal).
- O checkbox de seleção (linha e "selecionar todas") sempre recebe `aria-label`
  explícito (`"Selecionar linha"` / `"Selecionar todas as linhas"`) e usa estado
  `isIndeterminate` do react-aria quando a seleção é parcial.
- O indicador de ordenação (`SortIndicator`) é `aria-hidden` — o estado de ordenação
  em si é comunicado via `allowsSorting`/`sortDirection` do `Column` (react-aria), não
  pelo ícone.
- `aria-label` da `Table` tem default genérico (`"Tabela de dados"`) — sempre
  sobrescreva com o contexto real (ex.: `"Carteira de fundos"`).

## Armadilhas comuns

- Não espere ordenação/paginação automáticas: **toda** a Table é controlada. Sem
  `onSortChange`/`onPageChange` implementados (chamando o back-end ou reordenando
  `rows` você mesmo), a UI reage (ícone, página ativa) mas os dados não mudam.
- `pagination` omitido **não renderiza** nenhuma UI de paginação (não é "paginação
  desabilitada", é ausente). Se `pagination` é passado mas `onPageChange`/
  `onPageSizeChange` não, a UI (botões, select de itens por página) aparece normalmente
  mas clicar não faz nada — os handlers são opcionais e viram no-op via `?.()`.
- `cell` tem prioridade sobre `cellComponent` e `field`/`format` — se uma coluna
  parecer "ignorar" o `format` ou o `cellComponent`, verifique se não há também um
  `cell` definido na mesma coluna.
- `format` nos cells prontos usa sempre os defaults (`pt-BR`, `BRL`, 0/1 casas) — não
  há como passar `fractionDigits`/`colorSign`/`signed` via `format`; para isso use
  `cell={(r) => <CellPercent value={...} signed colorSign />}`.
- `resizable` colunas sem `minWidth` caem no mínimo global (`MIN_COL = 64`), que pode
  truncar cabeçalhos longos — defina `minWidth` explícito em colunas com texto extenso.
- `TablePagination` **não é exportado** — não tente importá-lo para montar paginação
  fora de uma `Table`; ele só existe acoplado a `pagination` na própria `Table`.
- Múltiplas colunas com `isRowHeader: true` violam a a11y esperada (só a última
  prevalece na prática do react-aria, mas o padrão é uma só).
