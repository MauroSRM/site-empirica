# Textarea

Campo de texto multilinha para observações, comentários e descrições longas. É uma
implementação **independente** (não herda de `InputBase`) construída diretamente sobre
`TextField`, `TextArea`, `Label`, `Text` e `FieldError` do `react-aria-components`, com
suporte a contador de caracteres, altura inicial em linhas, redimensionamento configurável
e altura máxima com scroll interno.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Textarea/`
- **Export:** `import { Textarea } from '@srm/diamond';`
- **Relacionados:** [FieldGroup](./FieldGroup.md) (agrupar com outros campos) · [TextInput](./Inputs/TextInput.md) (texto de uma linha)

> **Nota de arquitetura:** ao contrário dos componentes em `Forms/Inputs/*`, `Textarea`
> **não** estende `InputBaseProps` — tem sua própria interface (`TextareaProps`), com
> formato semelhante (label, state, theme, helperText, errorText, required, className)
> mas **sem** prop `size`, e com adições específicas de área de texto (`rows`, `resize`,
> `maxHeight`, `maxLength`, `showCounter`).

---

## Quando usar

- Campos de observação, comentário ou justificativa em formulários (ex.: motivo de resgate,
  observações de um pedido de aporte, notas internas de atendimento).
- Textos longos com contagem de caracteres visível (limite de campo em integrações externas).
- Descrições em cadastros (produto, política de investimento, ocorrência de compliance).

## Quando **não** usar

- Texto de uma linha (nome, e-mail, código) → use [`TextInput`](./Inputs/TextInput.md).
- Valores monetários ou percentuais → use [`CurrencyInput`](./Inputs/CurrencyInput.md) /
  `PercentInput`.
- Múltiplos campos relacionados lado a lado → componha com [`FieldGroup`](./FieldGroup.md).

---

## Interface

```ts
import type { CSSProperties, ReactNode, Ref } from 'react';

type TextareaState = 'default' | 'error' | 'disabled' | 'read-only';
type TextareaTheme = 'default' | 'dark';

interface TextareaProps {
  theme?: TextareaTheme;               // default: 'default'
  label?: ReactNode;
  placeholder?: string;                // default: 'Digite aqui...'

  value?: string;                      // controlado
  defaultValue?: string;               // não controlado

  onChange?: (value: string) => void;
  onBlur?: () => void;
  state?: TextareaState;               // default: 'default'
  helperText?: ReactNode;
  errorText?: ReactNode;
  rows?: number;                       // default: 3 — altura inicial em linhas
  required?: boolean;                  // default: false
  maxLength?: number;                  // limite nativo de caracteres; ativa contador automaticamente
  showCounter?: boolean;               // default: false — força exibir contador sem maxLength

  resize?: CSSProperties['resize'];    // default: 'vertical'
  maxHeight?: CSSProperties['maxHeight']; // default: 320 (px)
  className?: string;
  ref?: Ref<HTMLTextAreaElement>;      // encaminhado ao <textarea> nativo
}
```

### Notas de comportamento

- `state='disabled'` mapeia para `isDisabled`; `state='read-only'` mapeia para `isReadOnly`;
  `state='error'` **ou** a simples presença de `errorText` marcam `isInvalid`.
- Quando `disabled` ou `read-only`, o `resize` é forçado para `'none'` independentemente do
  valor passado (via `style` inline e também via CSS `!important` no módulo).
- O contador aparece se `showCounter` for `true` **ou** se `maxLength` estiver definido. Com
  `maxLength`, o formato é `"{count}/{maxLength}"`; sem `maxLength`, mostra só a contagem
  bruta. Ao atingir o limite, o contador ganha destaque de erro (cor `--feedback-error`).
- `maxLength` é aplicado como atributo nativo do `<textarea>` — o navegador impede digitar
  além do limite; o componente não trunca valores já existentes que excedam o limite.
- A contagem de caracteres é derivada de `value.length` quando controlado, ou de um estado
  interno (`internalCount`) atualizado a cada `onChange` quando não controlado.
- `errorText` só é exibido quando **também** há `isError` verdadeiro (isto é, quando
  `state='error'` ou `errorText` está presente — na prática, basta passar `errorText` para
  que ambos os efeitos ocorram). Se `isError` for verdadeiro mas `errorText` estiver vazio,
  cai para exibir `helperText` (se houver) em vez do erro.
- `theme='dark'` aplica `data-theme="dark"` no wrapper (`TextField`), acionando as variáveis
  de tema escuro do CSS Module — use sobre fundos escuros (headers, cards brand).
- Sem `label`, o `<Label>` simplesmente não é renderizado — garanta um `aria-label` externo
  nesse caso (a prop não está na interface pública; passar via spread não é suportado, pois
  `TextareaProps` não estende `AriaTextFieldProps`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { Textarea } from '@srm/diamond';

// Básico (controlado)
function ObservacoesField() {
  const [texto, setTexto] = useState('');
  return (
    <Textarea
      label="Observações"
      value={texto}
      onChange={setTexto}
      placeholder="Digite aqui..."
    />
  );
}

// Com contador e limite de caracteres
<Textarea label="Motivo do resgate" maxLength={200} showCounter required />

// Contador sem limite (apenas informativo)
<Textarea label="Notas internas" showCounter rows={5} />

// Estado de erro
<Textarea
  label="Justificativa"
  state="error"
  errorText="Este campo é obrigatório."
  value={texto}
  onChange={setTexto}
/>

// Somente leitura
<Textarea label="Descrição da política" state="read-only" value="Texto fixo carregado da API." />

// Desabilitado
<Textarea label="Comentário" state="disabled" />

// Sem redimensionamento, altura máxima customizada
<Textarea label="Log de atendimento" resize="none" maxHeight={200} rows={6} />

// Tema escuro (sobre header brand)
<Textarea label="Observações" theme="dark" value={texto} onChange={setTexto} />
```

### Integração com React Hook Form

```tsx
<Controller
  name="observacoes"
  control={control}
  render={({ field, fieldState }) => (
    <Textarea
      label="Observações"
      value={field.value}
      onChange={field.onChange}
      onBlur={field.onBlur}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
      maxLength={500}
      showCounter
    />
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label` — ela é associada ao `<textarea>` via `Label`/`TextField` do
  react-aria (label implícito por contexto, sem necessidade de `htmlFor` manual).
- Mensagens de erro são renderizadas com `FieldError`, associadas automaticamente ao campo
  (`aria-describedby`) e acompanhadas de ícone `AlertCircle` (`aria-hidden`).
- O contador de caracteres tem `aria-live="polite"`, anunciando a contagem atualizada para
  leitores de tela sem interromper a digitação.
- Em `state="disabled"`, o `<textarea>` recebe o atributo nativo `disabled`, removendo-o da
  ordem de tabulação — não use para campos apenas "visualmente" inativos.

## Armadilhas comuns

- Não confunda com os componentes de `Forms/Inputs/*`: `Textarea` **não** aceita `size`
  nem outras props de `InputBaseProps` (ex.: `forceFocus`) — sua interface é própria.
- `showCounter={false}` com `maxLength` definido **ainda assim exibe o contador** — a
  condição é `showCounter || maxLength !== undefined`. Para esconder completamente, não
  passe `maxLength` e mantenha `showCounter` como `false` (default).
- Passar `resize` diferente de `'none'` em campos `disabled`/`read-only` não tem efeito —
  o componente força `'none'` nesses estados.
- `maxLength` limita apenas a digitação futura; se o `value` inicial já exceder o limite,
  o excesso não é cortado automaticamente.
