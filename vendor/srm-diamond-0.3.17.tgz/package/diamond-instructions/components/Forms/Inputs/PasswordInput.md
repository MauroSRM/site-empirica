# PasswordInput

Campo de entrada de senha com alternância de visibilidade (mostrar/ocultar). Construído
sobre `InputBase` (herda label, estados, temas e mensagens) e sobre `Input`/`Button` do
`react-aria-components`. O botão de alternância usa os ícones `Eye`/`EyeOff` (lucide-react)
e fica embutido dentro do wrapper do campo.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/PasswordInput/`
- **Export:** `import { PasswordInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [TextInput](./TextInput.md)

---

## Quando usar

- Captura de senha de acesso: login, cadastro, troca/confirmação de senha.
- Qualquer campo sensível em que o usuário deva poder conferir o que digitou antes de
  enviar (ex.: senha de transação, PIN alfanumérico, chave de acesso).

## Quando **não** usar

- Texto livre sem sigilo (nome, e-mail, observações) → use [`TextInput`](./TextInput.md).
- Códigos numéricos fixos (OTP/2FA) exibidos em caixas segmentadas → prefira um componente
  dedicado de código, se existir na família; não force o `PasswordInput` para esse padrão.
- Quando o valor precisa de máscara numérica (moeda, percentual) → use `CurrencyInput`/`PercentInput`.

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface PasswordInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (texto puro, sem máscara)
  placeholder?: string;                    // default: '••••••••'
  onChange?: (value: string) => void;      // recebe o valor bruto do <input>
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `onBlur`, `onFocus` e atributos `aria-*`.

### Comportamento de visibilidade

- O estado `showPass` é **interno** (`useState`) — não é controlável de fora; cada instância
  do componente gerencia sua própria alternância mostrar/ocultar.
- O `<input>` alterna `type="password"` ↔ `type="text"` conforme `showPass`.
- O botão de alternância troca automaticamente o `aria-label` entre `"Mostrar senha"` e
  `"Ocultar senha"`, e o ícone entre `Eye`/`EyeOff` (16px, `aria-hidden`).
- `value`/`onChange` sempre carregam o **texto puro** digitado — não há máscara aplicada.

---

## Exemplos

```tsx
import { useState } from 'react';
import { PasswordInput } from '@srm/diamond';

// Básico (controlado)
function SenhaField() {
  const [senha, setSenha] = useState('');
  return <PasswordInput label="Senha" value={senha} onChange={setSenha} />;
}

// Com ajuda e obrigatório
<PasswordInput label="Nova senha" required helperText="Mínimo de 8 caracteres." />

// Estado de erro
<PasswordInput
  label="Senha"
  state="error"
  errorText="Senha incorreta."
  value={senha}
  onChange={setSenha}
/>

// Somente leitura
<PasswordInput label="Senha temporária" state="read-only" value="********" />

// Tema escuro (sobre header brand)
<PasswordInput label="Senha" theme="dark" value={senha} onChange={setSenha} />

// Placeholder customizado
<PasswordInput label="Confirmar senha" placeholder="Digite novamente" />
```

### Integração com React Hook Form

```tsx
<Controller
  name="senha"
  control={control}
  render={({ field, fieldState }) => (
    <PasswordInput
      label="Senha"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- O botão de alternância já expõe `aria-label` dinâmico (`"Mostrar senha"`/`"Ocultar senha"`)
  — não é necessário (nem recomendado) sobrescrevê-lo.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label` no próprio campo.
- Considere `autoComplete="current-password"` (login) ou `autoComplete="new-password"`
  (cadastro/troca) — a prop é passthrough de `TextFieldProps`.

## Armadilhas comuns

- **Não** existe prop para controlar `showPass` de fora — é estado interno do componente;
  não tente forçar o campo a abrir/fechar via props.
- **Não** espere máscara ou transformação no valor — `onChange` entrega exatamente o que
  foi digitado.
- Cuidado com `state="read-only"` mostrando senha em texto puro (`value="********"` no
  exemplo é ilustrativo) — evite expor senhas reais em modo leitura.
- O clique no wrapper foca o `<input>`, exceto quando o clique é no próprio botão de
  alternância (comportamento herdado de `InputBase`).
