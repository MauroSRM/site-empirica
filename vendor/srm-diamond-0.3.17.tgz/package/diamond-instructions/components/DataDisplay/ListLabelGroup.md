# ListLabelGroup

Agrupador de pares label/value a partir de `items[]`, renderizando um [`ListLabel`](./ListLabel.md)
por item. Quatro `layout`s: `horizontal` (uma linha por item), `vertical-left`/`vertical-right`
(empilhado) e `paired` (dois itens por linha). Opcionalmente envolto num card (`card`).
A mesma pasta exporta dois presets prontos sobre `ListLabelGroup`: `ReceiptPix` e
`ReceiptTed` — comprovantes de transferência PIX/TED que montam `items[]` a partir de props
nomeadas e só exibem os campos fornecidos (sem valores forjados).

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/ListLabelGroup/`
- **Export:** `import { ListLabelGroup, ReceiptPix, ReceiptTed } from '@srm/diamond';`
- **Relacionados:** [ListLabel](./ListLabel.md) (átomo usado internamente por cada item)

---

## Quando usar

- Lista de pares label/value que sempre aparecem juntos (detalhe de operação, resumo de
  fundo, dados cadastrais) — evita repetir `ListLabel` manualmente com espaçamento próprio.
- Comprovante de transferência PIX ou TED, com header (ícone + valor + título + status) e
  corpo de detalhes → use `ReceiptPix`/`ReceiptTed` diretamente, sem montar `items[]` à mão.
- Grade de 2 colunas para dados relacionados (ex.: CNPJ + Categoria, Patrimônio + Valor da
  cota) → `layout="paired"`.

## Quando **não** usar

- Um único par label/value → use [`ListLabel`](./ListLabel.md) diretamente.
- Comprovante de um tipo de operação diferente de PIX/TED (ex.: boleto, câmbio) → não force
  `ReceiptPix`/`ReceiptTed`; monte a composição com `ListLabelGroup` + `items[]` próprios.
- Necessidade de itens interativos (edição inline, remoção por item) → `ListLabelGroup` é
  puramente apresentacional; não expõe callbacks por item.

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';

type ListLabelGroupLayout = 'horizontal' | 'vertical-left' | 'vertical-right' | 'paired';

interface ListLabelGroupItem {
  label: ReactNode;      // rótulo do par
  value: ReactNode;      // valor do par
  highlight?: boolean;   // true = value ganha destaque de cor de marca (ex.: protocolo)
}

interface ListLabelGroupProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  items: ListLabelGroupItem[];    // pares, na ordem fornecida
  layout?: ListLabelGroupLayout;  // default: 'horizontal'
  card?: boolean;                 // default: false — envolve num card com borda + padding
  className?: string;
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children): id, aria-*, data-*, ...
}

// Presets sobre ListLabelGroup — mesma pasta, index.ts

interface ReceiptPixProps {
  amount: string;          // obrigatório — valor formatado da transferência
  to?: string;              // nome do favorecido
  toDocument?: string;      // CPF/CNPJ do favorecido
  toBank?: string;          // instituição do favorecido
  keyType?: string;         // tipo da chave PIX (ex.: "E-mail") — só exibe se keyType E keyValue
  keyValue?: string;        // valor da chave PIX
  from?: string;            // nome do pagador
  fromDocument?: string;    // CPF/CNPJ do pagador
  fromBank?: string;        // banco do pagador
  date?: string;             // data e hora da operação
  protocol?: string;         // protocolo — exibido com highlight
  status?: string;           // selo de status — sem default, só exibe se fornecido
}

interface ReceiptTedProps {
  amount: string;          // obrigatório — valor formatado da transferência
  to?: string;              // nome do favorecido
  toDocument?: string;      // CPF/CNPJ do favorecido
  bank?: string;            // banco do favorecido
  agency?: string;          // agência do favorecido
  account?: string;         // conta do favorecido
  accountType?: string;     // tipo de conta (ex.: "Conta Corrente") — sem default
  from?: string;            // nome do pagador
  fromDocument?: string;    // CPF/CNPJ do pagador
  fromBank?: string;        // banco do pagador
  date?: string;             // data e hora da operação
  protocol?: string;         // protocolo TED — exibido com highlight
  status?: string;           // selo de status — sem default
}
```

### Notas de comportamento

**`ListLabelGroup`**
- `layout="paired"` agrupa os itens dois a dois em linhas (`chunk` manual em pares, não
  `grid-template` responsivo): o primeiro item de cada par usa `align="left"` e o segundo
  `align="right"`, ambos com `format="stacked"`. Se o total de itens for ímpar, a última
  linha renderiza só o item da esquerda (o slot direito fica vazio).
- `layout="vertical-left"`/`"vertical-right"` usa `format="stacked"` em cada `ListLabel`,
  com `align` derivado do layout (`"right"` só para `vertical-right`).
- `layout="horizontal"` (default) usa `format="horizontal"` em cada `ListLabel` — label à
  esquerda, value à direita, na mesma linha.
- `item.highlight` repassa `highlight="brand"` ao `ListLabel` correspondente — mesma regra
  do átomo: só tem efeito se `value` for conteúdo textual (não `ReactNode`).
- `card` adiciona borda + padding ao redor do grupo (classe `styles.card`) — não altera o
  `layout` em si.

**`ReceiptPix` / `ReceiptTed`**
- Ambos montam `items: ListLabelGroupItem[]` **condicionalmente**: cada campo só entra na
  lista se estiver definido (`if (to) items.push(...)`) — nenhum valor é forjado ou exibido
  como vazio/placeholder.
- `keyType`/`keyValue` em `ReceiptPix` só formam um item se **ambos** estiverem presentes
  (`if (keyType && keyValue)`), usando `keyType` como label do par (ex.: "E-mail").
- `protocol` sempre entra com `highlight: true` — herda o destaque de cor de marca do
  `ListLabelGroup`/`ListLabel`.
- O header (`ReceiptHeader`) mostra um círculo de ícone (`ReceiptCheckIcon`, ícone `check`
  fixo — não configurável), o `amount` em destaque e o título fixo ("Transferência PIX" /
  "Transferência TED"); `status` só aparece como selo textual se fornecido.
- O corpo é sempre um `ListLabelGroup` no `layout="horizontal"` (default) — não há prop para
  trocar o layout do corpo do comprovante.

---

## Exemplos

```tsx
import { ListLabelGroup, ReceiptPix, ReceiptTed } from '@srm/diamond';

// Horizontal (default)
<ListLabelGroup
  items={[
    { label: 'Origem', value: 'Conta Corrente · 12345-6' },
    { label: 'Destino', value: 'João da Silva' },
    { label: 'Data', value: '30/06/2026' },
    { label: 'Valor', value: 'R$ 2.500,00', highlight: true },
  ]}
/>

// Paired, como card
<ListLabelGroup
  layout="paired"
  card
  items={[
    { label: 'CNPJ', value: '12.345.678/0001-99' },
    { label: 'Categoria', value: 'Renda Fixa' },
    { label: 'Patrimônio', value: 'R$ 1.245.860' },
    { label: 'Valor cota', value: 'R$ 50,70' },
  ]}
/>

// Comprovante PIX (campos omitidos não aparecem)
<ReceiptPix
  amount="R$ 2.500,00"
  to="João da Silva"
  toDocument="123.456.789-00"
  toBank="Banco XPTO"
  keyType="E-mail"
  keyValue="joao@exemplo.com"
  from="Maria Souza"
  date="30/06/2026 14:32"
  protocol="E1234567890"
  status="Concluído"
/>

// Comprovante TED sem status (não exibe selo)
<ReceiptTed
  amount="R$ 10.000,00"
  to="João da Silva"
  toDocument="123.456.789-00"
  bank="Banco XPTO"
  agency="0001"
  account="12345-6"
  accountType="Conta Corrente"
  from="Maria Souza"
  date="30/06/2026 14:32"
  protocol="TED987654321"
/>
```

---

## Acessibilidade

- `ListLabelGroup` delega toda a semântica ao `ListLabel` interno — não adiciona `role` ou
  landmarks próprios; para uma lista longa de pares, considere envolver o grupo com um
  título/heading visível no componente pai, já que o grupo em si não anuncia contexto.
- `ReceiptPix`/`ReceiptTed` não têm heading semântico próprio no corpo — o título da
  operação ("Transferência PIX"/"Transferência TED") é um `<p>`, não `<h1>`-`<h6>`; se o
  comprovante for a única informação da tela/modal, considere adicionar um heading externo.
- Cor de destaque (`highlight`) no protocolo reforça visualmente, mas o texto do protocolo
  já é lido normalmente por leitores de tela — não depende da cor para ser compreendido.

## Armadilhas comuns

- `layout="paired"` com número ímpar de itens deixa a última linha com só um item à
  esquerda — não é um bug, mas planeje os dados em pares quando esse layout for usado.
- `ReceiptPix`/`ReceiptTed` não validam formato de `amount`/`date`/documentos — são
  `string`s livres; formate os valores antes de passar (sem máscara automática).
- Omitir `amount` (única prop obrigatória de `ReceiptPix`/`ReceiptTed`) quebra o
  TypeScript — todo o resto é opcional e condicionalmente exibido.
- Não confundir `ListLabelGroupItem.highlight` (`boolean`, aplica `highlight="brand"` fixo)
  com o `highlight` de [`ListLabel`](./ListLabel.md) (enum de 5 cores) — no grupo, só existe
  a opção binária de destaque de marca.
