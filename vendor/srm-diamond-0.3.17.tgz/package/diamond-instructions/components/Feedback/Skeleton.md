# Skeleton

Placeholder animado de carregamento (*loading state*). Renderiza formas atômicas
(linha, bloco, círculo) ou composições prontas (grupo de texto, formulário, item de
lista, card) que imitam o layout do conteúdo real enquanto ele carrega. Não depende de
nenhuma biblioteca externa de acessibilidade (não é construído sobre
`react-aria-components`) — usa CVA (`class-variance-authority`) para as variantes
visuais e `role="status"` + `aria-busy` nativos, aplicados **uma única vez no
container**, para o anúncio a leitores de tela. É consumido internamente por
componentes de dados do DS (ex.: `Table`, `KPICard`, gráficos) via as props
`shape` + `width` + `height`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Skeleton/`
- **Export:** `import { Skeleton } from '@srm/diamond';` (tipos `SkeletonProps`,
  `SkeletonShape` também exportados pelo barrel)
- **Relacionados:** [EmptyState](./EmptyState.md) (estado vazio/erro — **não** é o mesmo
  componente que `Skeleton`)

---

## Quando usar

- Enquanto dados assíncronos carregam: listas de posições, extratos, cards de carteira,
  formulários pré-preenchidos vindos de API.
- Para reduzir *layout shift* — o skeleton ocupa o espaço aproximado do conteúdo final
  antes dele chegar.
- Composições prontas (`textGroup`, `form`, `listItem`, `card`) quando o layout de
  carregamento corresponde a um desses padrões comuns, evitando montar a mão com `line`/`block`.
- Compor loading de células/áreas de `Table`, `KPICard` ou gráficos, passando
  `shape`/`width`/`height` para casar com as dimensões reais do conteúdo final.

## Quando **não** usar

- Estado vazio (sem dados) ou estado de erro → [`EmptyState`](./EmptyState.md). `Skeleton`
  é exclusivamente para a fase de *carregamento*, não para "não há nada aqui".
- Indicador de carregamento pontual dentro de um botão → prop `loading` do `Button`
  (spinner interno), não `Skeleton`.
- Ícone giratório isolado (ex.: refresh de um card) → use [`Spinner`](./Spinner.md), não `Skeleton`.

---

## Interface

```ts
type SkeletonLeafShape = 'line' | 'block' | 'circle';
type SkeletonShape =
  | SkeletonLeafShape  // 'line' | 'block' | 'circle' — formas atômicas
  | 'textGroup'        // composição: 3 linhas (100%, 80%, 60% de largura)
  | 'form'             // composição: 2 campos, cada um com label (line) + input (block)
  | 'listItem'         // composição: círculo + 2 linhas de texto ao lado
  | 'card';            // composição: card com "imagem" + 3 linhas de texto, largura fixa 313px

interface SkeletonProps {
  shape?: SkeletonShape;        // default: 'line'
  animated?: boolean;           // default: true — shimmer animado; false = cor estática
  width?: number | string;      // só se aplica às formas atômicas ('line' | 'block' | 'circle')
  height?: number | string;     // idem
  className?: string;           // classe extra; só tem efeito no elemento raiz de cada shape
}
```

> A variante `avatar` foi **removida** — para avatar/foto de perfil, use `shape="circle"`
> (visualmente idêntico ao antigo `avatar`, 40×40px).

### Notas de comportamento

- **`width`/`height` só têm efeito nas formas atômicas** (`line`, `block`, `circle`).
  Nas composições (`textGroup`, `form`, `listItem`, `card`) essas props são **ignoradas**
  — o layout interno já define suas próprias larguras/alturas fixas via SCSS (ex.: `card`
  tem `width: 313px` fixo).
- **`role="status"` + `aria-busy="true"` + `aria-label="Carregando…"` são emitidos uma
  única vez, no elemento raiz de cada `Skeleton`** (a forma atômica quando `shape` é
  `line`/`block`/`circle`, ou o `<div>` wrapper quando `shape` é uma composição). As
  formas internas de uma composição (`Leaf`) recebem `aria-hidden` e **não** duplicam o
  `role="status"` — não há mais regiões de status aninhadas.
- `animated={false}` troca o *shimmer* (gradiente animado) por uma cor estática
  (`var(--surface-muted)`) — útil para reduzir movimento ou economia de performance em
  listas muito longas.
- A animação já respeita `prefers-reduced-motion: reduce` no CSS (desliga a animação
  automaticamente), independente da prop `animated`.
- `className` é aplicado ao elemento raiz de cada shape (via `clsx`) — em formas atômicas,
  vai direto no `<span>`; em composições, no `<div>` wrapper externo.

---

## Exemplos

```tsx
import { Skeleton } from '@srm/diamond';

// Linha de texto simples
<Skeleton shape="line" width="100%" height={16} />

// Bloco (ex.: placeholder de gráfico)
<Skeleton shape="block" width="100%" height={200} />

// Círculo (avatar/ícone)
<Skeleton shape="circle" />

// Grupo de texto (3 linhas decrescentes) — parágrafo carregando
<Skeleton shape="textGroup" />

// Formulário (2 campos: label + input)
<Skeleton shape="form" />

// Item de lista (círculo + 2 linhas) — ex.: linha de posição em carteira
<Skeleton shape="listItem" />

// Card (imagem + 3 linhas) — ex.: card de fundo/ativo
<Skeleton shape="card" />

// Sem animação (cor estática)
<Skeleton shape="block" width="100%" height={120} animated={false} />
```

### Uso condicional típico (fetch de dados)

```tsx
import { Skeleton } from '@srm/diamond';

function PosicaoCard({ isLoading, posicao }: { isLoading: boolean; posicao?: Posicao }) {
  if (isLoading) {
    return <Skeleton shape="card" />;
  }
  return <CardPosicaoReal data={posicao} />;
}
```

### Lista com múltiplos itens carregando

```tsx
import { Skeleton } from '@srm/diamond';

function ListaExtratoSkeleton({ linhas = 5 }: { linhas?: number }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {Array.from({ length: linhas }).map((_, i) => (
        <Skeleton key={i} shape="listItem" />
      ))}
    </div>
  );
}
```

---

## Acessibilidade

- Cada `Skeleton` emite `role="status"`, `aria-busy="true"` e `aria-label="Carregando…"`
  **uma única vez**, no elemento raiz — mesmo em composições (`textGroup`, `form`,
  `listItem`, `card`), as formas internas são `aria-hidden` e não geram anúncios
  duplicados/aninhados.
- O rótulo de "Carregando…" é fixo (`SKELETON_LOADING_LABEL`) e **não é customizável**
  via prop — não há `label`/`aria-label` exposto em `SkeletonProps`.
- Respeita `prefers-reduced-motion` automaticamente (desliga o shimmer), sem necessidade
  de lógica adicional no app consumidor.

## Armadilhas comuns

- Passar `width`/`height` esperando efeito em `shape="card"` (ou outras composições) —
  essas props são **ignoradas** nas composições; ajuste o layout via CSS externo no
  container, se necessário.
- Procurar por `shape="avatar"` — foi **removida**; use `shape="circle"` no lugar (mesmo
  resultado visual).
- Usar `Skeleton` para representar "sem dados" ou "erro na requisição" — isso é
  responsabilidade do [`EmptyState`](./EmptyState.md), não do `Skeleton`.
- Esperar múltiplas regiões `role="status"` aninhadas em composições — hoje há apenas
  uma, no container; não construa lógica de teste/anúncio assumindo o comportamento antigo.
