# Button

Botão de ação principal do Diamond. Suporta variantes semânticas (primária, secundária,
destrutiva, accent, link), três tamanhos, ícone em quatro modos, estado de `loading` com
spinner automático e tema claro/escuro. Construído sobre `Button` do `react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Button/`
- **Export:** `import { Button } from '@srm/diamond';`
- **Relacionados:** [IconButton](./IconButton.md) (só-ícone), [DoubleButton](./DoubleButton.md) (par de ações)

---

## Quando usar

- Ação primária de um formulário, modal, card ou tela (salvar, confirmar, entrar).
- Ações secundárias/terciárias, ajustando `variant` (`secondary`, `ghost`, `link`).
- Ações destrutivas (`destructive` e derivadas).

## Quando **não** usar

- Botão exclusivamente de ícone → [`IconButton`](./IconButton.md).
- Navegação que é semanticamente um link → use `variant="link"` **ou** um anchor real.
- Duas ações lado a lado com hierarquia fixa → [`DoubleButton`](./DoubleButton.md).

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { ButtonProps as AriaButtonProps } from 'react-aria-components';

type ButtonVariant =
  | 'primary'                // azul sólido — ação principal
  | 'secondary'              // contorno azul — ação secundária
  | 'ghost'                  // sem contorno — ação terciária
  | 'destructive'            // vermelho sólido — ação destrutiva
  | 'secondary-destructive'
  | 'ghost-destructive'
  | 'accent'                 // laranja sólido — destaque especial
  | 'secondary-accent'
  | 'ghost-accent'
  | 'link'                   // aparência de link
  | 'link-accent';

type ButtonSize = 'sm' | 'md' | 'lg';
type ButtonIconMode = 'none' | 'left' | 'right' | 'only';
type ButtonTheme = 'light' | 'dark';

interface ButtonProps extends Omit<AriaButtonProps, 'className' | 'children'> {
  variant?: ButtonVariant;      // default: 'primary'
  size?: ButtonSize;            // default: 'md'
  loading?: boolean;            // default: false — exibe spinner e desabilita
  icon?: ButtonIconMode;        // default: 'none'
  iconEl?: ReactNode;           // ícone custom; fallback: <ChevronRight />
  fullWidth?: boolean;          // default: false
  theme?: ButtonTheme;          // default: 'light'
  loadingLabel?: string;        // texto exibido durante loading (default interno)
  className?: string;
  children?: ReactNode;
  ref?: Ref<HTMLButtonElement>;
  // Herdado de AriaButtonProps: onPress, isDisabled, isPending, type, form, aria-*, ...
}
```

### Notas de comportamento

- `loading` **desabilita** o botão e troca o conteúdo por `loadingLabel` + spinner.
- `icon="only"` renderiza apenas o ícone (sem `children`) — **exige `aria-label`**.
- Sem `iconEl`, o ícone padrão é `<ChevronRight />` dimensionado por `size`.
- Prefira **`onPress`** (react-aria) a `onClick` — cobre teclado e toque de forma consistente.

---

## Exemplos

```tsx
import { Button } from '@srm/diamond';
import { Plus, Trash } from 'lucide-react';

// Básico
<Button onPress={handleSave}>Salvar</Button>

// Loading
<Button variant="primary" loading={isSubmitting}>Confirmar</Button>

// Ícone à esquerda
<Button variant="secondary" icon="left" iconEl={<Plus size={16} />}>Adicionar</Button>

// Ícone apenas (aria-label obrigatório)
<Button icon="only" iconEl={<Trash />} aria-label="Remover" />

// Destrutivo
<Button variant="destructive" onPress={handleDelete}>Excluir conta</Button>

// Tema escuro (sobre header brand)
<Button variant="secondary" theme="dark">Sair</Button>

// Largura total (mobile / rodapé de modal)
<Button fullWidth>Entrar</Button>
```

---

## Acessibilidade

- `icon="only"` **sem** `aria-label` deixa o botão sem nome acessível — sempre rotule.
- Em `loading`, o botão fica desabilitado; considere manter `loadingLabel` descritivo
  para leitores de tela.
- Use `type="submit"` dentro de formulários; o disparo por Enter/Espaço já é tratado pelo react-aria.

## Armadilhas comuns

- Não use `Button` só-ícone para navegação densa (toolbars) — prefira [`IconButton`](./IconButton.md).
- `variant="link"` mantém semântica de **botão**; para navegação real use um `<a>`.
- `className` é mesclado às variantes (CVA) — evite sobrescrever cor/estado por CSS ad-hoc.
