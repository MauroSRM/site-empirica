# SheetContent

Preset pronto de sheet mobile: header (título + botão fechar) + corpo com scroll + footer
de ações, construído sobre o shell do [`BottomSheet`](./BottomSheet.md). Suporta seis
variantes semânticas (`default | success | error | warning | info | destructive`) — nas
não-`default`, o header ganha um ícone de status ([`Icon`](../Icons/Icon.md)) e título/subtítulo
centralizados, no mesmo vocabulário visual do [`ContentModal`](./ContentModal.md).
`destructive` é um alias visual de `error` (mesmo ícone) que também troca o par de botões do
footer para a combinação destrutiva. **MOBILE-ONLY** — o equivalente para desktop é o
`ContentModal`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/SheetContent/`
- **Export:** `import { SheetContent } from '@srm/diamond';`
- **Relacionados/Base:** [BottomSheet](./BottomSheet.md) (shell sem opinião de conteúdo sobre o qual este componente é construído), [ContentModal](./ContentModal.md) (equivalente desktop), [Callout](./Callout.md) (usado internamente quando `showCallout`), [Button](../Forms/Button.md) e [DoubleButton](../Forms/DoubleButton.md) (footer de ações)

---

## Quando usar

- Confirmação de ação mobile com até duas ações no rodapé (confirmar/cancelar, aplicar/cancelar).
- Feedback de resultado de uma operação financeira mobile: sucesso de transferência/aporte
  (`variant="success"`), falha de pagamento (`variant="error"`), aviso de operação em lote
  (`variant="warning"`), aviso regulatório (`variant="info"`).
- Confirmação de ação irreversível em mobile (excluir registro, cancelar operação) →
  `variant="destructive"`, que já usa o par de botões `destructive-ghost`.
- Quando o conteúdo precisa de um aviso de atenção fixo logo no topo do corpo →
  `showCallout` (mensagem fixa de "operação afetará todos os itens selecionados").

## Quando **não** usar

- Em **desktop** — nunca. Use [`ContentModal`](./ContentModal.md), o equivalente para telas largas.
- Sheet totalmente livre, sem título/ícone/footer no formato deste preset → use
  [`BottomSheet`](./BottomSheet.md) diretamente e componha o `children` à mão.
- Mensagem transiente que fecha sozinha (toast) → não é uma sheet; use o `Toastr`.
- Painel lateral persistente (desktop) → [`Drawer`](./Drawer.md).

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonVariant } from '@srm/diamond'; // reexportado de Button
import type { CalloutVariant } from '@srm/diamond'; // reexportado de Callout — 'info' | 'success' | 'warning' | 'error' | 'ai' | 'neutral'

type SheetContentVariant = 'default' | 'success' | 'error' | 'warning' | 'info' | 'destructive';

interface SheetContentAction {
  label: string;
  onClick: () => void;
  variant?: ButtonVariant;   // sobrescreve o variant padrão do botão de ação
  loading?: boolean;         // default: false
}

interface SheetContentProps {
  isOpen: boolean;
  onClose: () => void;
  variant?: SheetContentVariant;      // default: 'default'
  showCallout?: boolean;              // default: false
  calloutText?: string;               // corpo do Callout quando showCallout=true; default: copy de atenção genérica
  calloutVariant?: CalloutVariant;    // variante visual do Callout quando showCallout=true; default: 'warning'
  title?: string;
  subtitle?: string;
  align?: 'left' | 'center';          // default: 'left' — só tem efeito quando variant === 'default'
  children?: ReactNode;
  primaryAction?: SheetContentAction;
  secondaryAction?: SheetContentAction;
  maxHeight?: string;                 // default: '80vh'
  height?: string;
  /** Escopa o portal a um contêiner (ex.: moldura de celular numa demo) em vez de document.body. */
  container?: HTMLElement;
  dismissible?: boolean;              // default: true
}
```

### Notas de comportamento

- **Header — três layouts possíveis**, escolhidos automaticamente:
  1. `variant !== 'default'` (`success`/`error`/`warning`/`info`/`destructive`): header
     centralizado com botão fechar (`IconButton` ghost, canto superior direito), `Icon` de
     status (29px) e título/subtítulo centralizados abaixo. O ícone é resolvido por
     `SHEET_CONTENT_FEEDBACK_ICON` (`SheetContent.constants.ts`): `success→success`,
     `error→error`, `warning→warning`, `info→default` (o `info` do `Icon` é cinza; o azul de
     marca vem do `type="default"`), `destructive→error`.
  2. `variant === 'default'` **e** `align === 'center'`: mesmo layout centralizado do item 1,
     mas **sem** ícone de status.
  3. `variant === 'default'` **e** `align === 'left'` (padrão): usa o
     [`PageHeader`](../Navigation/PageHeader.md) (`size="md"`, `showDivider`, `fullWidthDivider`),
     título alinhado à esquerda com botão fechar embutido no próprio `PageHeader`.
- `title` é opcional em todos os layouts, mas sem ele o header fica sem heading visível — o
  `id` do `<h2>` (via `useId`) só é usado como `aria-labelledby` implícito quando presente.
- `showCallout` renderiza, **antes** do `children`, um [`Callout`](./Callout.md) com
  `variant={calloutVariant}` (default `'warning'`) e `body={calloutText}` (default: *"Atenção:
  esta operação afetará todos os itens selecionados e não poderá ser revertida após a
  confirmação."*) — ambos os defaults podem ser sobrescritos por prop; sem `showCallout=true`
  nenhum dos dois tem efeito.
- **Footer de ações** — três combinações possíveis:
  - Nenhuma ação → footer não é renderizado.
  - Apenas `primaryAction` **ou** apenas `secondaryAction` → um único `Button` `size="lg"`
    `fullWidth`; variant default é `destructive` quando `variant === 'destructive'`, senão
    `primary` (para `primaryAction`) ou `ghost` (para `secondaryAction`) — sobrescrevível via
    `action.variant`.
  - **Ambas** as ações → renderiza um [`DoubleButton`](../Forms/DoubleButton.md) `layout="vertical"`
    `size="lg"`, com `pair="destructive-ghost"` se `variant === 'destructive'`, senão
    `pair="primary-ghost"`. **Atenção**: neste caminho, `primaryAction.variant` e
    `secondaryAction.variant` são **ignorados** — só `primaryAction.loading` é repassado
    (via `primaryLoading`); `secondaryAction.loading` também é ignorado.
- `dismissible`, `maxHeight`, `height`, `container` são repassados diretamente ao
  [`BottomSheet`](./BottomSheet.md) subjacente — mesmo comportamento e defaults documentados lá
  (conversão automática de `vh`→`%` quando `container` é usado, foco preso, etc.).
- `ariaLabel` do `BottomSheet` interno é fixado como `title ?? 'Conteúdo'` — não há prop própria
  para customizá-lo separadamente do `title`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { SheetContent, Button } from '@srm/diamond';

// Confirmação básica (variant default, alinhado à esquerda)
function ConfirmarAlteracao() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onPress={() => setIsOpen(true)}>Alterar configuração</Button>
      <SheetContent
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Confirmar alteração"
        subtitle="Você tem certeza que deseja atualizar as configurações da conta?"
        primaryAction={{ label: 'Confirmar', onClick: () => setIsOpen(false) }}
        secondaryAction={{ label: 'Cancelar', onClick: () => setIsOpen(false) }}
      />
    </>
  );
}

// Sucesso de transferência (ícone + centralizado automaticamente)
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  variant="success"
  title="Transferência enviada"
  subtitle="R$ 50.000 foram transferidos para Fundo Multimercado Estratégico."
  primaryAction={{ label: 'Concluir', onClick: onClose }}
/>

// Falha de pagamento
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  variant="error"
  title="Falha no pagamento"
  subtitle="Não foi possível concluir a transferência. Verifique os dados e tente novamente."
  primaryAction={{ label: 'Tentar novamente', onClick: handleRetry, loading: isRetrying }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
/>

// Aviso em lote, com callout de atenção (texto default)
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  variant="warning"
  showCallout
  title="Aplicar a todos?"
  subtitle="Esta operação será aplicada em todos os títulos do lote."
  primaryAction={{ label: 'Sim, aplicar', onClick: handleApply }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
/>

// Callout customizado (texto e variante próprios)
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  showCallout
  calloutVariant="info"
  calloutText="Esta alteração só será aplicada após a confirmação do e-mail."
  title="Atualizar e-mail cadastrado"
  primaryAction={{ label: 'Confirmar', onClick: handleConfirm }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
/>

// Ação irreversível — destructive (footer vira par destructive-ghost)
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  variant="destructive"
  title="Excluir registro"
  subtitle="Esta ação é irreversível. O registro será permanentemente removido."
  primaryAction={{ label: 'Excluir', onClick: handleDelete }}
  secondaryAction={{ label: 'Cancelar', onClick: onClose }}
/>

// Aviso regulatório informativo (info) sem segunda ação
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  variant="info"
  title="Regulamento atualizado"
  subtitle="A CVM publicou novos requisitos de suitability. Revise antes de continuar."
  primaryAction={{ label: 'Entendi', onClick: onClose }}
/>

// Conteúdo customizado com scroll (formulário, lista) + variant default centralizado
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  align="center"
  title="Selecionar conta"
  primaryAction={{ label: 'Confirmar', onClick: handleConfirm }}
>
  {/* lista de contas — cresce e rola dentro do corpo, footer permanece fixo */}
  <ListaContas onSelect={setContaSelecionada} />
</SheetContent>

// Não dismissível — exige ação explícita (ex.: processamento em andamento)
<SheetContent
  isOpen={isOpen}
  onClose={onClose}
  dismissible={false}
  title="Confirmando transação"
  subtitle="Não feche esta tela enquanto processamos seu Pix…"
  primaryAction={{ label: 'Aguardar', onClick: () => {}, loading: true }}
/>

// Escopado a um contêiner (specimen de moldura de celular numa demo)
function MobileSpecimen() {
  const [container, setContainer] = useState<HTMLElement | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div ref={(el) => { if (el && !container) setContainer(el); }} style={{ position: 'relative', width: 390, height: 760 }}>
      <Button onPress={() => setIsOpen(true)}>Abrir sheet</Button>
      <SheetContent
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        container={container}
        title="Conteúdo"
        primaryAction={{ label: 'Fechar', onClick: () => setIsOpen(false) }}
      />
    </div>
  );
}
```

---

## Acessibilidade

- O `Dialog` interno do `BottomSheet` recebe `aria-label={title ?? 'Conteúdo'}` — sempre
  forneça `title` (ou aceite o rótulo genérico `'Conteúdo'`).
- O botão de fechar (`X`, canto superior) já vem com `aria-label="Fechar"` fixo em todos os
  layouts de header — não precisa (nem pode) ser customizado via prop.
- O ícone de status (`Icon`) é puramente ilustrativo — a informação semântica de
  sucesso/erro/aviso deve estar no texto de `title`/`subtitle`, não apenas no ícone.
- Foco é preso dentro do sheet e retorna ao elemento disparador ao fechar (comportamento
  herdado do `ModalOverlay`/`Modal` do react-aria, via `BottomSheet`).
- Com `dismissible={false}`, backdrop e `Esc` são bloqueados — garanta sempre uma
  `primaryAction`/`secondaryAction` (ou fechamento programático) como saída explícita.

## Armadilhas comuns

- Esperar que `primaryAction.variant`/`secondaryAction.variant` funcionem quando **ambas** as
  ações estão presentes — nesse caso o footer vira um `DoubleButton` com `pair` fixo
  (`primary-ghost` ou `destructive-ghost` conforme `variant`), e os `variant` individuais das
  ações são **ignorados**. Para controlar variantes de botão por ação, use **apenas uma** das
  duas props de ação.
- Esperar `secondaryAction.loading` funcionar junto com `primaryAction` — no caminho de
  `DoubleButton`, só `primaryAction.loading` é propagado.
- Usar `align="center"` esperando efeito quando `variant !== 'default'` — variantes de
  feedback **já são** centralizadas por padrão; `align` só altera o layout de `default`.
- Usar em telas desktop — este preset é mobile-only; em desktop use
  [`ContentModal`](./ContentModal.md).
- Achar que o texto do `showCallout` só pode ser o default — `calloutText` e `calloutVariant`
  permitem customizar corpo e cor; o texto de atenção genérico é apenas o valor inicial, não um
  conteúdo fixo/hardcoded.
- Confundir com [`BottomSheet`](./BottomSheet.md): se precisar de um layout de header/footer
  diferente deste preset, use o `BottomSheet` diretamente em vez de tentar forçar `children`
  dentro do `SheetContent`.
