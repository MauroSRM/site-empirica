# IaSRMHero

Organismo hero de entrada do iaSRM: card brand escuro com avatar + saudação, o átomo
`MessageComposer` (`anexar / texto / gravar / enviar`) e chips de sugestão rápida. Uso
típico no topo da coluna principal de uma home. É **agnóstico de persona** — não injeta
nome, valores financeiros ou copy de negócio por conta própria.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMHero/`
- **Export:** `import { IaSRMHero } from '@srm/diamond';`
- **Relacionados:** [IaSRMAvatar](./IASRMAvatar.md) (avatar `circleGlass`/`lg` no header), [IaSRMFab](./IASRMFab.md) (entrada alternativa, flutuante), `MessageComposer` (o pill de input, compartilhado com `IaSRMTray`), [Chip](../Forms/Chip.md) (sugestões rápidas)

---

## Quando usar

- Card hero de entrada do assistente no topo da Home (ou tela equivalente), com largura total da coluna principal.
- Quando a aplicação já resolve a personalização (nome, saudação com contexto) e passa isso via `greeting`.
- Quando quiser oferecer sugestões clicáveis de pergunta pronta (`chips`) junto ao input livre.
- Em modo controlado (`value`/`onChange`), quando a aplicação precisa manipular o texto externamente (preencher a partir de um chip externo, ditado por voz, etc.).

## Quando **não** usar

- Dentro de modal ou drawer — é um hero standalone. Para painel use `IaSRMDrawer`/`IaSRMOverlay` com `IaSRMTray`.
- Como substituto do `IaSRMFab` — para ponto de entrada flutuante persistente, use [`IaSRMFab`](./IASRMFab.md).
- Com mais de ~5 `chips` — quebra em múltiplas linhas e prejudica a hierarquia (diretriz de uso, não validada em código).

---

## Interface

```ts
import type { HTMLAttributes, ReactNode, Ref } from 'react';
import type { ChipSize, ChipTheme } from '@srm/diamond';

/** Tupla [linha1, linha2] da saudação: linha1 é destaque, linha2 é subtítulo. */
type IaSRMHeroGreeting = readonly [string, string];

interface IaSRMHeroChip {
  id?: string;     // chave estável; default = label
  label: string;   // texto exibido
  value?: string;  // texto emitido; default = label
}

/** Forma curta (string → { label, value }) ou objeto completo. */
type IaSRMHeroChipInput = string | IaSRMHeroChip;

interface IaSRMHeroProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'onSubmit' | 'onChange' | 'defaultValue'> {
  greeting?: IaSRMHeroGreeting;                 // default: derivada da hora do dia (neutra)
  avatar?: ReactNode | null;                    // null remove o slot
  chips?: readonly IaSRMHeroChipInput[];         // default: []
  chipTheme?: ChipTheme;                        // default: 'dark'
  chipSize?: ChipSize;                          // default: 'md'
  onChipPress?: (chip: IaSRMHeroChip) => void;  // substitui onSendMessage para chips
  placeholder?: string;                         // default: 'Pergunte algo ou escolha abaixo...'
  value?: string;                               // presente + onChange => controlado
  defaultValue?: string;                        // não-controlado; não combine com value
  onChange?: (value: string) => void;           // valor cru
  onSendMessage?: (text: string) => void;       // texto já trimado
  onAttach?: () => void;                        // sem handler, o botão não renderiza
  onRecordAudio?: () => void;                   // sem handler, o botão não renderiza
  inputLabel?: string;                          // default: 'Mensagem'
  attachLabel?: string;                         // default: 'Anexar arquivo'
  recordLabel?: string;                         // default: 'Gravar áudio'
  sendLabel?: string;                           // default: 'Enviar mensagem'
  isDisabled?: boolean;                         // desabilita composer e chips
  ref?: Ref<HTMLDivElement>;
  // Herdado: id, className, style, data-*, aria-*, …
}
```

### Notas de comportamento

- **Saudação default é neutra**: sem `greeting`, o componente deriva `['Bom dia.'|'Boa tarde.'|'Boa noite.'|'Olá.', 'Como posso ajudar?']` da hora local (manhã 6–12h, tarde 12–18h, noite 18–23h, madrugada demais). **Não** inclui nome, saldo ou dado de negócio — isso é da aplicação, via `greeting`.
- O **fallback** de hora é calculado uma única vez na montagem (a saudação não deve mudar enquanto o usuário lê a tela), mas a prop `greeting` é **reativa**: trocá-la atualiza a UI. Em SSR, informe `greeting` para render determinístico.
- **Input controlado ou não-controlado**: com `value` + `onChange`, a aplicação é a fonte de verdade; sem `value`, o componente mantém estado interno partindo de `defaultValue`. `onSendMessage` recebe o texto **trimado**; em modo não-controlado o campo é limpo após o envio.
- O botão de enviar fica **desabilitado** enquanto o texto está em branco — `onSendMessage` nunca recebe string vazia. Enter em texto vazio também não dispara nada.
- Envio dispara por: Enter no input, clique no botão enviar, ou (quando `onChipPress` está ausente) clique num chip.
- **Chips emitem sua própria intenção**: com `onChipPress`, o handler recebe o chip normalizado (`{ id, label, value }`) e `onSendMessage` **não** é chamado — assim o pai distingue sugestão clicada de texto digitado. Sem `onChipPress`, o chip cai em `onSendMessage(chip.value)`.
- `onAttach` e `onRecordAudio` **condicionam a renderização** dos botões — sem handler, o botão não existe no DOM (não é só desabilitado).
- `chips` só renderiza a linha quando há ao menos um item.
- Todos os rótulos acessíveis são props com default em português — sobrescreva para outro idioma ou copy mais específico.
- Composição interna: [`IaSRMAvatar`](./IASRMAvatar.md) `circleGlass`/`lg` (substituível via `avatar`, removível com `avatar={null}`), `MessageComposer` (o mesmo átomo do `IaSRMTray`) e [`Chip`](../Forms/Chip.md) com `chipTheme`/`chipSize` configuráveis.

---

## Exemplos

```tsx
import { IaSRMHero } from '@srm/diamond';

// Básico, saudação neutra automática (sem persona)
<IaSRMHero onSendMessage={(text) => sendToAssistant(text)} />

// Saudação personalizada pela aplicação
<IaSRMHero
  greeting={['Bom dia, Ana.', 'Tenho 3 alertas financeiros para você revisar.']}
  chips={['Ver contas a pagar', 'Analisar caixa', 'Simular aplicação']}
  onSendMessage={(text) => sendToAssistant(text)}
/>

// Chips com value distinto do label + intenção própria
<IaSRMHero
  chips={[
    { id: 'payables', label: 'Ver contas a pagar', value: 'listar_contas_a_pagar' },
    { id: 'cash', label: 'Analisar caixa', value: 'analisar_fluxo_de_caixa' },
  ]}
  onChipPress={(chip) => dispatchIntent(chip.value)}
  onSendMessage={(text) => sendToAssistant(text)}
/>

// Controlado
<IaSRMHero value={draft} onChange={setDraft} onSendMessage={send} />

// Com anexo e áudio
<IaSRMHero onAttach={openFilePicker} onRecordAudio={startRecording} onSendMessage={send} />

// Enquanto a resposta está em voo
<IaSRMHero isDisabled={isPending} onSendMessage={send} />

// Avatar próprio / sem avatar
<IaSRMHero avatar={<MinhaMarca />} onSendMessage={send} />
<IaSRMHero avatar={null} onSendMessage={send} />
```

---

## Acessibilidade

- O campo de texto não tem label visível: o nome acessível vem de `inputLabel` (default `'Mensagem'`), aplicado no `TextField` do React Aria.
- Attach/mic/send são [`IconButton`](../Forms/IconButton.md) só-ícone, cada um com seu `aria-label` configurável.
- O avatar default é decorativo (`aria-hidden`) — a saudação em texto já dá o contexto.
- O botão enviar usa `isDisabled` (React Aria) quando não há texto, então leitores de tela anunciam o estado em vez de o clique falhar em silêncio.

## Armadilhas comuns

- Não passe `value` **e** `defaultValue` juntos — escolha controlado ou não-controlado.
- Em modo controlado, o componente não limpa o campo por conta própria: trate `onChange('')` no envio.
- Não confie na saudação default para SSR — passe `greeting` para evitar divergência servidor/cliente.
- Se precisa distinguir chip de digitação em telemetria, use `onChipPress`; caso contrário ambos chegam por `onSendMessage`.
