# CpfInput

Campo de entrada para CPF (Cadastro de Pessoas Físicas) brasileiro. Aplica máscara fixa
`000.000.000-00` enquanto o usuário digita. Construído sobre `InputBase` (herda label,
estados, temas e mensagens) e sobre a ponte de máscara `IMaskBridge` (imask/react-imask).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/CpfInput/`
- **Export:** `import { CpfInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [CnpjInput](./CnpjInput.md),
  [CepInput](./CepInput.md), [TextInput](./TextInput.md)

---

## Quando usar

- Captura de CPF em cadastro de cliente/cotista, formulários de KYC/suitability,
  identificação de beneficiário, procurador, sócio ou responsável em fluxos da SRM Asset.
- Sempre que o valor precise ser exibido com a formatação `000.000.000-00` enquanto o
  usuário digita.
- Em conjunto com validação de dígito verificador feita pelo formulário (o componente
  **não** valida CPF, só aplica a máscara — veja "Armadilhas comuns").

## Quando **não** usar

- CNPJ → use [`CnpjInput`](./CnpjInput.md).
- CEP → use [`CepInput`](./CepInput.md).
- Documento genérico sem máscara fixa de CPF (RG, passaporte) → use [`TextInput`](./TextInput.md).

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface CpfInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (string com apenas os dígitos do CPF)
  placeholder?: string;                    // default: '000.000.000-00'
  onChange?: (value: string) => void;      // recebe a string SEM máscara (só dígitos)
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor é formatado por imask com estas opções fixas (`CpfInput.constants.ts`):

```ts
{ mask: '000.000.000-00' }
```

A ponte `IMaskBridge` usa `unmask={true}` para **todos** os inputs mascarados do Diamond
(inclusive `CpfInput`). Isso significa, especificamente aqui:

- `value` e o retorno de `onChange` trafegam **sem** a máscara — apenas os dígitos do CPF
  (ex.: `"11122233344"`), **não** `"111.222.333-44"`. A exibição visual no campo (com pontos
  e hífen) é responsabilidade interna do `IMaskBridge`/imask; o dado que você controla por
  fora é sempre "cru".
- Ao popular `value` a partir de dados vindos de API/banco, passe os dígitos diretamente
  (`"11122233344"`) — não pré-formate.
- Passar `value=""` limpa o campo de forma controlada. Esse comportamento é coberto por
  teste: o componente reflete corretamente a transição de um `value` preenchido para vazio
  (útil em `reset()` do React Hook Form).
- Não há validação do dígito verificador do CPF embutida — o componente só aplica a máscara
  de digitação, nunca verifica se o CPF é matematicamente válido.

---

## Exemplos

```tsx
import { useState } from 'react';
import { CpfInput } from '@srm/diamond';

// Básico (controlado) — value/onChange trafegam só dígitos
function CpfField() {
  const [cpf, setCpf] = useState('');
  return <CpfInput label="CPF" value={cpf} onChange={setCpf} />;
}

// Com ajuda e obrigatório
<CpfInput label="CPF do cotista" required helperText="Digite apenas os números do CPF." />

// Estado de erro
<CpfInput label="CPF" state="error" errorText="CPF inválido." value={cpf} onChange={setCpf} />

// Somente leitura (valor vindo da API já são os dígitos)
<CpfInput label="CPF" state="read-only" value="11122233344" />

// Desabilitado
<CpfInput label="CPF" state="disabled" />

// Tema escuro (sobre header brand)
<CpfInput label="CPF" theme="dark" value={cpf} onChange={setCpf} />
```

### Integração com React Hook Form (+ validação de dígito verificador via Zod)

```tsx
import { z } from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { CpfInput } from '@srm/diamond';

function isValidCpf(cpf: string): boolean {
  // implemente (ou importe de uma lib como cpf-cnpj-validator) o cálculo
  // do dígito verificador — o CpfInput não faz essa checagem.
  return cpf.length === 11; // placeholder ilustrativo
}

const schema = z.object({
  cpf: z.string().refine(isValidCpf, { message: 'CPF inválido.' }),
});

function CadastroForm() {
  const { control } = useForm({ resolver: zodResolver(schema) });

  return (
    <Controller
      name="cpf"
      control={control}
      render={({ field, fieldState }) => (
        <CpfInput
          label="CPF"
          value={field.value}
          onChange={field.onChange}
          state={fieldState.error ? 'error' : 'default'}
          errorText={fieldState.error?.message}
        />
      )}
    />
  );
}
```

---

## Acessibilidade

- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Considere `inputMode="numeric"` (herdado via `InputBaseProps`/`TextFieldProps`) para reforçar
  o teclado numérico em dispositivos móveis, embora a máscara já restrinja a entrada a dígitos.

## Armadilhas comuns

- **Não** espere receber `"111.222.333-44"` em `onChange` — o valor entregue é **só dígitos**
  (`"11122233344"`); quem precisar exibir formatado fora do input reaplica a máscara manualmente.
- **Não** valide o CPF (dígito verificador) esperando que o componente faça isso — ele só
  aplica a máscara de digitação, a validação semântica é responsabilidade do formulário.
- Ao inicializar `value` a partir de dados já formatados (ex.: `"111.222.333-44"` vindos de
  legado), remova a pontuação antes (`value.replace(/\D/g, '')`) para manter o contrato de
  "só dígitos" consistente com o que `onChange` devolve.
- `placeholder` custom substitui o default `'000.000.000-00'` — se você trocar, mantenha um
  placeholder que comunique o formato esperado.
