# Stepper

Indicador de progresso em etapas (wizard) para fluxos multi-step de desktop. Renderiza uma
sequência de indicadores (bolinha numerada, check animado, erro, aviso ou cadeado) ligados por
conectores, em três variantes de layout: `default` (horizontal com labels), `no-labels`
(horizontal compacto, só indicadores) e `vertical` (coluna, com labels ao lado). Não é
construído sobre `react-aria-components` — é HTML semântico simples (`role="list"` /
`role="listitem"`, presente em **todas** as três variantes) com `clsx` + `class-variance-
authority` (CVA) para composição de classes e o `Icon` do design system para os ícones de
estado. O texto acessível de cada etapa é gerado por uma função injetável (`formatStepLabel`),
não por uma string hardcoded. Tipos vivem em `Stepper.types.ts`. Para o equivalente compacto de
telas mobile, veja [`MobileStepper`](./MobileStepper.md).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/Stepper/` (`Stepper.tsx`, `Stepper.types.ts`,
  `Stepper.constants.ts`, `StepIndicator.tsx`, `StepConnector.tsx`)
- **Export:** `import { Stepper } from '@srm/diamond';` (também exporta `StepIndicator`,
  `StepConnector`, e os tipos `StepItem`, `StepState`, `StepVariant`, `StepSize`,
  `StepAriaInfo`, `FormatStepLabel`)
- **Relacionados:** [MobileStepper](./MobileStepper.md) (mesmo modelo de dados, layout compacto para mobile)

---

## Quando usar

- Fluxos de onboarding ou cadastro em várias telas: KYC, abertura de conta, criação de perfil de
  investidor, formulário de aporte guiado.
- Processos financeiros sequenciais com etapas que podem ficar bloqueadas até validação anterior
  (ex.: "Documentos" só libera após "Dados pessoais" ser aprovado — use `completed-locked`).
- Layout `vertical` para telas com mais espaço vertical que horizontal (painéis laterais, sidebars
  de fluxo) ou quando os labels são longos/com subtítulo.
- Layout `no-labels` quando o espaço horizontal é escasso mas ainda é desktop (ex.: dentro de um
  modal estreito) — os labels viram `title` (tooltip nativo) no hover.
- Fluxos com requisitos de auditoria/rastreabilidade no `aria-label` de cada etapa (ex.: incluir
  um código interno) → forneça `formatStepLabel` customizado (ver Interface).

## Quando **não** usar

- Layout mobile / viewport estreito → use [`MobileStepper`](./MobileStepper.md), que já renderiza
  só os indicadores em uma faixa compacta pensada para telas pequenas.
- Navegação entre seções irmãs sem noção de progresso sequencial → use [`TabBar`](./TabBar.md).
- Trilha de posição hierárquica (não sequencial/wizard) → use [`Breadcrumb`](./Breadcrumb.md).
- Etapas com quantidade dinâmica muito grande (10+) em `default`/`no-labels` — o layout horizontal
  não tem scroll ou colapso automático; para muitas etapas prefira `variant="vertical"`.

---

## Interface

```ts
export type StepState =
  | 'active'            // etapa atual — indicador com "bolinha" central destacada
  | 'completed'          // etapa concluída — check animado, conector seguinte preenchido
  | 'error'              // etapa com erro — ícone X vermelho
  | 'warn'               // etapa com aviso — ícone de alerta
  | 'completed-locked'   // concluída mas bloqueada para navegação — ícone de cadeado
  | 'inactive';          // etapa futura ainda não alcançada — número

export type StepVariant = 'default' | 'no-labels' | 'vertical';
export type StepSize    = 'sm' | 'md';

export interface StepItem {
  label?:    string;
  subtitle?: string;    // só é exibido em default/vertical (ignorado em no-labels, exceto no title/tooltip)
  state?:    StepState; // default runtime: 'inactive'
}

// Dados passados para formatStepLabel — não inclui o StepItem completo, só o necessário
// para montar o texto acessível, evitando "vazar" o objeto inteiro do consumidor.
export interface StepAriaInfo {
  index: number;
  total: number;
  state: StepState;
  label?: string | undefined;
}

export type FormatStepLabel = (info: StepAriaInfo) => string;

export interface StepperProps {
  variant?:         StepVariant;      // default: 'default'
  steps:            StepItem[];
  size?:            StepSize;         // default: 'md'
  className?:       string;           // aceito no tipo, mas NÃO é aplicado no <div> raiz atual (ver Armadilhas)
  formatStepLabel?: FormatStepLabel;  // default: defaultFormatStepLabel (ver abaixo)
}

function Stepper(props: StepperProps): JSX.Element;
```

O default exportado em `Stepper.constants.ts`:

```ts
export const defaultFormatStepLabel: FormatStepLabel = ({ index, total, label }) =>
  `Etapa ${index + 1} de ${total}${label ? `: ${label}` : ''}`;
```

Note que o `state` **não** entra no texto por padrão (ex.: `"Etapa 2 de 4: Documentos"`) —
o estado é comunicado ao invés disso via `aria-current="step"` (quando `active`) e pelos
ícones/cores semânticas, não por uma palavra em inglês (`active`, `error`...) dentro do
`aria-label`. Se precisar incluir o estado no texto, forneça seu próprio `formatStepLabel`
recebendo `info.state` e traduzindo/formatando como desejar.

### Comportamento por variante (não-óbvio)

- **`default`**: horizontal, `role="list"`; cada etapa é `role="listitem"` com
  `aria-label={formatStepLabel({ index, total, state, label })}` e `aria-current="step"`
  somente quando `state === 'active'`. Quando o step está `completed`, o bloco de label
  some visualmente (`opacity: 0`) para dar lugar à transição — o texto continua no DOM.
- **`no-labels`**: mesma estrutura horizontal e mesmo `aria-label`/`aria-current`, mas o
  bloco de label visível nunca é renderizado; em vez disso o `<div>` do item ganha
  `title={label — subtitle}` (tooltip nativo do navegador no hover).
- **`vertical`**: layout de coluna próprio (`VerticalStepper`), **também** com `role="list"`
  no container e `role="listitem"` + `aria-current` + `aria-label` (via `formatStepLabel`)
  em cada linha — a mesma semântica de lista/estado das outras duas variantes. Cada linha é
  um `<div role="listitem">` com indicador + conector vertical à esquerda e label/subtítulo
  à direita.
- **Conector "ativo" (preenchido)**: um `StepConnector` só é desenhado como preenchido
  (`isConnectorActive`) quando o step **anterior** a ele está `completed` ou `completed-locked` —
  o estado do próprio conector não depende do próximo step.
- **`state` ausente** em qualquer `StepItem` é tratado como `'inactive'` em tempo de execução
  (`step.state ?? 'inactive'`), mesmo que o tipo marque a prop como opcional sem default explícito.
- **Tamanho `sm` vs `md`** ajusta simultaneamente: diâmetro do indicador, tamanho da
  bolinha ativa, do número, da fonte do label/subtítulo e o alinhamento do conector
  horizontal com o centro do indicador.
- **Sem prop de tema**: o componente não recebe `theme` — todas as cores vêm de variáveis CSS de
  design token (`--brand-primary`, `--feedback-error-bg`, `--text-*`, etc.) que já respondem ao
  tema claro/escuro no nível do design system, sem necessidade de prop explícita.

### Componentes auxiliares exportados: `StepIndicator` e `StepConnector`

O barrel também exporta as duas peças internas que compõem o `Stepper`, úteis para montar layouts
customizados que não se encaixam em nenhuma das três variantes prontas.

```ts
interface StepIndicatorProps {
  step:       StepItem;
  index:      number;   // usado para o número exibido quando state === 'inactive' (index + 1)
  size?:      StepSize; // default: 'md'
  className?: string;
}
function StepIndicator(props: StepIndicatorProps): JSX.Element;

interface StepConnectorProps {
  active:     boolean;    // preenche a barra de progresso do conector
  size?:      StepSize;   // default: 'md' — só afeta a variante horizontal
  vertical?:  boolean;    // default: false — troca para o traço vertical (flex:1, min-height 16px)
  className?: string;
}
function StepConnector(props: StepConnectorProps): JSX.Element;
```

- `StepIndicator` sozinho não é `role="listitem"` nem tem `aria-*` — essas semânticas são
  adicionadas pelo componente pai (`Stepper`/`MobileStepper`). Se compuser um layout customizado,
  você é responsável por embrulhar cada indicador com a marcação de lista/estado acessível.
- O ícone de `completed` é um SVG customizado com animação de "desenho" (stroke-dashoffset) —
  respeita `prefers-reduced-motion: reduce` automaticamente (desliga a animação).

---

## Exemplos

```tsx
import { Stepper } from '@srm/diamond';
import type { StepItem, StepAriaInfo } from '@srm/diamond';

// Básico — horizontal com labels, 4 etapas, uma ativa
const steps: StepItem[] = [
  { label: 'Dados',       state: 'completed' },
  { label: 'Documentos',  state: 'active' },
  { label: 'Revisão',     state: 'inactive' },
  { label: 'Conclusão',   state: 'inactive' },
];

<Stepper steps={steps} />

// Com subtítulos
<Stepper
  steps={[
    { label: 'Perfil',      subtitle: 'Dados pessoais', state: 'completed' },
    { label: 'Suitability', subtitle: 'Perfil de risco', state: 'active' },
    { label: 'Assinatura',  subtitle: 'Contrato digital', state: 'inactive' },
  ]}
/>

// Compacto, sem labels (tooltip no hover)
<Stepper variant="no-labels" steps={steps} size="sm" />

// Vertical — painel lateral de um fluxo de abertura de conta
<Stepper
  variant="vertical"
  steps={[
    { label: 'Identificação',    state: 'completed' },
    { label: 'Documentos',       state: 'completed-locked' }, // bloqueada até revisão manual
    { label: 'Perfil de investidor', state: 'active' },
    { label: 'Assinatura',       state: 'inactive' },
  ]}
/>

// Etapa com erro (ex.: falha de validação de documento)
<Stepper
  steps={[
    { label: 'Dados',      state: 'completed' },
    { label: 'Documentos', state: 'error' },
    { label: 'Revisão',    state: 'inactive' },
  ]}
/>

// formatStepLabel customizado — inclui o estado traduzido no aria-label
const traduzEstado: Record<string, string> = {
  active: 'em andamento', completed: 'concluída', error: 'com erro',
  warn: 'com aviso', 'completed-locked': 'concluída e bloqueada', inactive: 'pendente',
};
<Stepper
  steps={steps}
  formatStepLabel={({ index, total, state, label }: StepAriaInfo) =>
    `Etapa ${index + 1} de ${total}${label ? `: ${label}` : ''} — ${traduzEstado[state]}`
  }
/>

// Compondo indicadores customizados (layout que não é nenhuma das 3 variantes)
import { StepIndicator, StepConnector } from '@srm/diamond';

function CustomStepRow({ step, index }: { step: StepItem; index: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <StepIndicator step={step} index={index} size="sm" />
      <StepConnector active={step.state === 'completed'} size="sm" />
    </div>
  );
}
```

---

## Acessibilidade

- Nas três variantes (`default`, `no-labels` e `vertical`), cada etapa é `role="listitem"`
  dentro de um `role="list"`, com `aria-label` gerado por `formatStepLabel` (default:
  `"Etapa N de Total: label"`, sem o estado em texto) e `aria-current="step"` na etapa
  ativa — leitores de tela anunciam posição e nome sem depender de cor.
- O `state` não é exposto como palavra literal no `aria-label` por padrão — é comunicado
  via `aria-current` (para `active`) e visualmente via ícone/cor; se seu fluxo exigir o
  estado explícito no texto para leitores de tela, forneça um `formatStepLabel` próprio.
- Os ícones de estado (`X`, `AlertTriangle`, `Lock`, o check animado) são `aria-hidden="true"` —
  o estado semântico é comunicado pelo `aria-label` do item pai, não pelo ícone isoladamente.
- A animação de "desenhar" o check respeita `prefers-reduced-motion: reduce`.

## Armadilhas comuns

- `className` está no tipo `StepperProps`, mas **o componente atual não o aplica** em nenhum
  elemento — passar `className` não tem efeito. Não dependa dele para customização visual.
- Não confunda `warn` com `error`: ambos têm indicador de destaque, mas só `error` usa a cor
  semântica de erro (`--feedback-error-bg`) e ícone de X; `warn` usa o ícone de alerta sobre a
  cor de marca (fallback para `--brand-primary` se não houver token de warning).
- O conector entre a etapa N e N+1 reflete o estado da etapa N (anterior), não da etapa N+1 —
  se você espera "conector aceso quando a próxima etapa começou", releia a regra: ele acende
  quando a etapa **atual** foi concluída/bloqueada.
- Se você fornece `formatStepLabel`, ele é chamado para **todas** as etapas, nas três
  variantes — garanta que a função trate bem `label === undefined` (etapas sem título).
- Na variante `vertical`, o espaçamento entre linhas (`padding-bottom` do label) é fixo por
  `size` e não se adapta a labels multilinha muito longos — teste com o texto real do seu fluxo.
- Passar `state` inválido (fora de `StepState`) não gera erro em runtime — cai no ramo `inactive`
  do `IndicatorContent` (renderiza o número), pois nenhuma das checagens `if` bate.
