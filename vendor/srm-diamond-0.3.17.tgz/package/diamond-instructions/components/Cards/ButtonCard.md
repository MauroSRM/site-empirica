# ButtonCard

Card compacto de ação rápida, renderizado como `<button>` nativo — toda a área é clicável.
Suporta dois `format`s: `square` (120×120 ou 156×156, layout empilhado ícone + label) e
`rectangle` (linear, com `subtitle` opcional e chevron indicando navegação). Composto pelos
átomos `Icon` (`Icons`) e `Tag` (`DataDisplay`) sobre a superfície compartilhada
`Cards/cardSurface` (CVA `appearance="outlined"` × `interactive=true`, sempre).

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/ButtonCard/`
- **Export:** `import { ButtonCard } from '@srm/diamond';`
- **Relacionados:** [Card](./Card.md) (card genérico não-ação), [Icon](../Icons/Icon.md),
  [Tag](../DataDisplay/Tag.md), [Button](../Forms/Button.md) (CTA de página, não card)

---

## Quando usar

- Grid de ações rápidas no dashboard (transferir, ver extrato, pagar, Pix) →
  `format="square"`, 120×120 (`size="sm"`) ou 156×156 (`size="md"`).
- Lista de ações com contexto adicional, quando o usuário se beneficia de um `subtitle`
  explicativo ou o padrão visual pede afordance de navegação (chevron) → `format="rectangle"`.
- Sinalizar novidade ou atalho na própria ação → `tag` (renderiza `Tag` `variant="brandAccent"`).

## Quando **não** usar

- CTA principal de página/formulário → use [`Button`](../Forms/Button.md) `variant="primary"`.
- Card informativo sem ação de clique única (título + descrição + ação no rodapé) →
  use [`Card`](./Card.md).
- Não coloque `IconButton` ou qualquer outro elemento interativo dentro do `ButtonCard` —
  o próprio card já é um `<button>`; interativo-dentro-de-interativo quebra teclado e
  gera HTML inválido (`<button>` dentro de `<button>`).
- `subtitle` só faz sentido em `format="rectangle"` — em `square` a prop é ignorada
  (layout empilhado não a renderiza).

---

## Interface

```ts
import type { ButtonHTMLAttributes } from 'react';
import type { IconType } from '@srm/diamond'; // Icons/Icon

type ButtonCardSize = 'sm' | 'md';
type ButtonCardFormat = 'square' | 'rectangle';

interface ButtonCardProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick' | 'type'> {
  icon?: string;                 // nome do glifo (ICON_GLYPH_NAMES), via átomo Icon
  iconType?: IconType;           // default: 'default'
  label?: string;
  subtitle?: string;             // só renderizado em format='rectangle'
  onClick?: () => void;          // ignorado quando disabled
  disabled?: boolean;            // default: false
  tag?: string;                  // texto exibido como Tag no canto superior direito
  size?: ButtonCardSize;         // default: 'md'
  format?: ButtonCardFormat;     // default: 'square'
  // Demais atributos de <button> (exceto onClick/type): id, aria-*, data-*, name, form, ...
}
```

### Notas de comportamento

- O elemento raiz é sempre `<button type="button">` — `type` não é configurável (fixo em
  `"button"`, nunca `"submit"`), evitando submit acidental dentro de formulários.
- **`disabled`** zera o handler: `onClick={disabled ? undefined : onClick}`, além do
  atributo HTML `disabled` no `<button>` (bloqueio nativo de foco/clique/teclado).
- **Tamanho do ícone é derivado de `size`**, não configurável separadamente:
  `size="sm"` → 18px; `size="md"` → 22px (`Icon` com `circle={false}`, cor herdada de
  `--text-primary` via CSS, `--text-disabled` quando `disabled`).
- **`format="square"`**: layout em coluna (`justify-content: space-between`), ícone no
  topo e `label` na base; `subtitle` **não é renderizado** neste format mesmo se
  informado. Dimensões fixas: 120×120 (`sm`) ou 156×156 (`md`).
- **`format="rectangle"`**: layout em linha; `label`+`subtitle` ficam num `textStack`
  (coluna) à direita do ícone; sempre ganha um chevron (`chevron-right`, 16px `sm` /
  18px `md`) ao final, `aria-hidden="true"` — é puramente indicativo, não um botão
  aninhado. `min-width` 200px (`sm`) ou 240px (`md`).
- **Posição da `tag`** muda por `format`: em `square` é `position: absolute` no canto
  superior direito; em `rectangle` é inline (`order: 3` no flex), antes do chevron
  (`order: 4`), sem `position: absolute` — evita colisão com o texto.
- A superfície (`cardSurface`) é aplicada com `interactive: true` sempre — hover
  (`--surface-hover` + `--border-medium`), pressed/focus (`--brand-primary` border +
  `--focus-ring`) e disabled (`--opacity-disabled` + `cursor: not-allowed`) já vêm do
  módulo compartilhado, sem necessidade de estilizar estados manualmente.
- `className` é mesclado via `clsx` às classes de variante (CVA); demais props HTML
  (`id`, `name`, `form`, `aria-*`, `data-*`, ...) passam via `...rest` direto ao `<button>`.

---

## Exemplos

```tsx
import { ButtonCard } from '@srm/diamond';

// Square — grid de ações rápidas (padrão)
<ButtonCard icon="arrow-left-right" label="Transferir" onClick={handleTransfer} />

// Square — tamanho pequeno
<ButtonCard icon="file-text" label="Extrato" size="sm" onClick={handleExtract} />

// Square — com tag de destaque
<ButtonCard icon="arrow-left-right" label="Transferir" tag="PIX" onClick={handlePix} />

// Rectangle — com subtitle e chevron
<ButtonCard
  icon="arrow-left-right"
  label="Transferir"
  subtitle="Envie ou receba pelo Pix"
  format="rectangle"
  onClick={handlePix}
/>

// Rectangle — com tag (inline antes do chevron)
<ButtonCard
  icon="landmark"
  label="Investimentos"
  subtitle="Fundos e renda fixa"
  tag="Novo"
  format="rectangle"
  onClick={handleInvest}
/>

// Desabilitado
<ButtonCard icon="arrow-left-right" label="Transferir" disabled />

// Grid típico de dashboard
<div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
  <ButtonCard icon="arrow-left-right" label="Transferir" onClick={handleTransfer} />
  <ButtonCard icon="file-text" label="Extrato" onClick={handleExtract} />
  <ButtonCard icon="credit-card" label="Pagar" onClick={handlePay} />
  <ButtonCard icon="landmark" label="Investir" tag="Novo" onClick={handleInvest} />
</div>
```

---

## Acessibilidade

- O nome acessível do botão vem do texto renderizado (`label`, e `subtitle` quando
  presente em `rectangle`) — garanta sempre um `label` textual; sem ele, o card fica
  sem nome acessível (apenas ícone visual, que é decorativo).
- `disabled` usa o atributo nativo do `<button>` — foco, clique e leitura por teclado já
  ficam bloqueados sem necessidade de `aria-disabled` manual.
- O ícone (`Icon`) e o chevron (`rectangle`) são puramente decorativos — a semântica da
  ação está inteiramente no `label`/`subtitle`.
- Foco visível e ativação por Enter/Espaço vêm gratuitamente do `<button>` nativo — não
  há necessidade de `useButton`/react-aria aqui.

## Armadilhas comuns

- Esperar `subtitle` aparecer em `format="square"` — é ignorado nesse format; use
  `rectangle` quando precisar de texto secundário.
- Colocar um elemento interativo (`IconButton`, `Button`, link) dentro do `ButtonCard` —
  gera `<button>` dentro de `<button>` (HTML inválido) e quebra a navegação por teclado.
- Usar `onClick` esperando comportamento condicional em `disabled` — o componente já
  neutraliza o handler quando `disabled` é `true`; não é necessário checar isso no callback.
- Esperar `tag` posicionado igual entre os dois formats — em `square` é absoluto no canto;
  em `rectangle` é inline antes do chevron. Ajuste o texto da tag para caber em ambos os
  contextos se o componente for usado nos dois formats no mesmo fluxo.
- Passar `type` via `...rest` esperando sobrescrever `"button"` — a prop `type` é excluída
  do tipo (`Omit<..., 'type'>`); não é possível transformar o `ButtonCard` em `submit`.
