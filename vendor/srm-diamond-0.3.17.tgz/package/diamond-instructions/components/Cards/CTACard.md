# CTACard

Card visual para oferta de produto, divulgação de feature ou benefício, com header
dinâmico (cor, ícone, bancos, imagem) e corpo combinável (tag, eyebrow, título,
descrição, stats/KPIs, highlights e ações). Suporta duas direções: `vertical` (padrão,
para grids de colunas) e `horizontal` (fullwidth, feature-banner). Composto pelos átomos
`Tag` (`DataDisplay`), `Button`/`DoubleButton` (`Forms`), `Icon` (`Icons`),
`BankAvatarGroup` (`Identity`) e `ListLabelGroup` (`DataDisplay`, para os `stats`).

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/CTACard/`
- **Export:** `import { CTACard } from '@srm/diamond';`
- **Relacionados:** [Card](./Card.md) (card simples, sem header dinâmico), [Tag](../DataDisplay/Tag.md),
  [Button](../Forms/Button.md), [DoubleButton](../Forms/DoubleButton.md), [Icon](../Icons/Icon.md),
  [BankAvatarGroup](../Identity/BankAvatarGroup.md)

---

## Quando usar

- Divulgar uma oferta/produto com apelo visual forte: header colorido (`tone`) ou com
  imagem, título/descrição de venda e um ou dois CTAs (`action.primary`/`action.secondary`).
- Feature-banner fullwidth no topo de uma página/hub → `direction="horizontal"`, com
  `stats` (KPIs) na coluna dedicada entre o corpo e as ações.
- Hero de Insights/Analytics que precisa de dois blocos de conteúdo lado a lado
  (texto principal + conteúdo lateral) → `direction="horizontal"` + `layout="analytics"`
  com `sideContent`.
- Comunicar integração com bancos (Open Finance) no header → `header.banks` (lista de
  slugs BACEN, renderizado via `BankAvatarGroup`).
- Card sobre fundo escuro dedicado (dark hero) → `theme="dark"` (os botões internos
  permanecem em paleta clara para manter contraste do CTA).

## Quando **não** usar

- Card informativo neutro sem apelo de oferta/venda (título + descrição + ação simples)
  → use [`Card`](./Card.md), mais leve e sem header dinâmico.
- Mais de duas ações → o componente só suporta `primary` + `secondary` via `DoubleButton`;
  para mais opções, use um Modal/Drawer.
- `title`/`subtitle` esperando aparecer no corpo do card — eles são **sempre** movidos
  para o header (ver Notas de comportamento); se não há header configurado (`header`
  ausente ou vazio), nada é renderizado no lugar do título.
- `layout="analytics"` em `direction="vertical"` — a prop só tem efeito no horizontal.

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';
import type { IconType } from '@srm/diamond';   // Icons/Icon
import type { TagVariant } from '@srm/diamond'; // DataDisplay/Tag

type CTACardDirection = 'vertical' | 'horizontal';

// 'analytics' só tem efeito quando direction='horizontal' (4 painéis 25/25/25/25
// em vez dos 3 painéis 25/50/25 do 'default').
type CTACardLayout = 'default' | 'analytics';

// Tons semânticos + 2 gradients pré-definidos.
type CTACardTone =
  | 'brand' | 'accent' | 'success' | 'warning' | 'info' | 'error' | 'neutral'
  | 'gradient-brand' | 'gradient-prime';

// Shade da escala --brand-blue-*; só aplica com tone='brand'. Default efetivo: 500.
type CTACardBrandShade = 500 | 600 | 700 | 800 | 900;

// Controla bg/border/texto do próprio card via [data-theme="dark"]. Os botões
// internos SEMPRE usam paleta clara (buttonTheme 'default' | 'dark' baseado no theme).
type CTACardTheme = 'light' | 'dark'; // default: 'light'

interface CTACardHeader {
  tone?: CTACardTone;
  brandShade?: CTACardBrandShade;    // só com tone='brand'
  icon?: string;
  iconType?: IconType;
  banks?: string[];                  // slugs BACEN, via BankAvatarGroup
  image?: string;
  imageAlt?: string;
  imagePlaceholder?: boolean;        // placeholder quando não há `image` ainda
  title?: string;                    // título dentro do header (não do body)
  subtitle?: string;                 // subtítulo dentro do header
}

interface CTACardAction {
  label: string;
  onClick?: () => void;
}

type CTACardActionSize = 'md' | 'lg';
type CTACardActionLayout = 'horizontal' | 'vertical';
type CTACardActionWidth = 'auto' | 'full';

interface CTACardActions {
  primary: CTACardAction;            // obrigatório
  secondary?: CTACardAction;         // presença vira DoubleButton
  size?: CTACardActionSize;          // default: 'md'
  layout?: CTACardActionLayout;      // default: 'horizontal' — só relevante com secondary
  width?: CTACardActionWidth;        // default: 'auto'
  divider?: boolean;                 // linha entre os 2 botões (relevante no vertical)
}

interface CTACardStat {
  label: string;
  value: string;
}

interface CTACardTag {
  label: string;
  variant?: TagVariant;              // default: 'brandPrimary'
}

interface CTACardProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
  header?: CTACardHeader;
  tag?: CTACardTag | string;         // string vira { label, variant: 'brandPrimary' }
  title?: string;                    // sempre movido pro header, nunca renderiza no body
  eyebrow?: string;                  // acima do title, uppercase
  subtitle?: string;                 // só visível quando header.image existe (sobreposto)
  description?: string;
  action?: CTACardActions;
  direction?: CTACardDirection;      // default: 'vertical'
  layout?: CTACardLayout;            // default: 'default' — só com direction='horizontal'
  sideContent?: ReactNode;           // só com layout='analytics'
  stats?: CTACardStat[];
  children?: ReactNode;              // highlights, entre description e stats/actions
  theme?: CTACardTheme;              // default: 'light'
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto title): className, style, id,
  // aria-*, data-*, onClick, ...
}
```

### Notas de comportamento

- **`title`/`subtitle` nunca renderizam no body** — são sempre "movidos" para o header
  via merge (`effectiveHeader`): se `header.title`/`header.subtitle` não estiverem
  definidos, os valores das props de nível superior (`title`/`subtitle`) são usados no
  header. Sem `header` (prop ausente/undefined), **nenhum header é renderizado** e,
  portanto, `title`/`subtitle` **não aparecem em lugar nenhum** — apenas `tag`, `eyebrow`
  e `description` (e `children`/`stats`) ficam visíveis no body.
- **Header — prioridade de conteúdo**: se `header.image` ou `header.imagePlaceholder` for
  informado, o header renderiza **só** a imagem/placeholder (+ overlay com gradiente e
  título/subtítulo sobrepostos, se houver texto) — `tone`/`icon`/`banks` do header são
  ignorados nesse caminho. Sem imagem, o header combina livremente `tone` (cor de fundo),
  `icon` (círculo do átomo `Icon` — chip clássico se `tone` ausente/`'neutral'`, ou wrapper
  translúcido herdando `currentColor` se `tone` colorido), `banks` (`BankAvatarGroup`
  `size="lg"` `overlap` `max={4}`) e `title`/`subtitle`. Se não houver `tone` **nem**
  nenhum conteúdo (`icon`/`banks`/`title`/`subtitle`), o header não renderiza nada
  (retorna `null`).
- **`brandShade`** só tem efeito com `header.tone === 'brand'`: define `data-shade` no
  header, que a folha de estilo usa para escolher o tom da escala `--brand-blue-*`
  (500 default visual, 900 mais escuro).
- **`tag`** (do body, não confundir com `header`) aceita string simples ou objeto
  `{ label, variant }`; sem `variant`, o default é `'brandPrimary'`.
- **`stats` tem dois destinos conforme `direction`**:
  - `vertical`: renderizado dentro do body, antes das ações (`CTACardStatsBlock`, via
    `ListLabelGroup` `layout="horizontal"`).
  - `horizontal` com `stats` não-vazio: vira um painel dedicado (`bodySecondary`, ~25%
    da largura) fora do bloco de texto principal — ativa o layout de split
    (`useSplit`/`statsAsColumn`), mesmo sem `layout="analytics"`.
- **`layout="analytics"`** só tem efeito com `direction="horizontal"`: adiciona um
  segundo painel secundário (`bodySecondary`) com `sideContent`, totalizando 4 painéis
  (aside colorido + body-primário + body-secundário + actions) em vez dos 3 painéis
  padrão (aside + body + actions). Se `stats` e `layout="analytics"` coexistirem, o
  card ainda ativa o split (`isAnalytics || statsAsColumn`), mas o painel de `stats`
  e o de `sideContent` são blocos distintos (`statsAsColumn` renderiza o de stats;
  `isAnalytics` renderiza o de `sideContent` — ambos podem aparecer juntos).
- **Ações**: sem `action.secondary`, renderiza um único [`Button`](../Forms/Button.md)
  `variant="primary"` (`size`/`theme` herdados de `action.size`/`theme` do card). Com
  `action.secondary`, renderiza [`DoubleButton`](../Forms/DoubleButton.md)
  `pair="primary-ghost"` — `action.layout` (horizontal/vertical) e `action.divider` só
  fazem sentido nesse caminho. Sem `action`, nenhum bloco de ações é renderizado.
- **`theme="dark"`** aplica `data-theme="dark"` no elemento raiz do card, mas os botões
  internos usam `buttonTheme = theme === 'dark' ? 'dark' : 'default'` — a intenção de
  design é o CTA permanecer com contraste de botão consistente mesmo em cards claros
  aninhados em contexto escuro (ou vice-versa); não é um espelho 1:1 do `theme` do card.
- `className`/`...rest` são aplicados no elemento raiz do card (não no header nem no
  body) via `clsx`.

---

## Exemplos

```tsx
import { CTACard } from '@srm/diamond';

// Vertical básico — header colorido + título/descrição + ação única
<CTACard
  header={{ tone: 'brand', icon: 'zap' }}
  title="Invista com liquidez diária"
  description="Fundos de renda fixa com resgate em D+0."
  action={{ primary: { label: 'Investir agora', onClick: handleInvest } }}
/>

// Vertical — duas ações (DoubleButton) com divisor
<CTACard
  header={{ tone: 'accent', icon: 'gift' }}
  title="Indique e ganhe"
  description="R$ 50 de bônus para você e seu indicado."
  action={{
    primary: { label: 'Indicar agora', onClick: handleInvite },
    secondary: { label: 'Saber mais', onClick: handleLearnMore },
    divider: true,
  }}
/>

// Vertical — header com imagem (título/subtítulo sobrepostos)
<CTACard
  header={{ image: '/hero-relatorios.jpg', imageAlt: 'Relatórios SRM', title: 'Relatórios completos', subtitle: 'Performance em tempo real' }}
  description="Acompanhe seus fundos com dashboards personalizados."
  action={{ primary: { label: 'Ver relatórios', onClick: handleReports } }}
/>

// Vertical — banks (Open Finance) + tag + stats
<CTACard
  header={{ tone: 'neutral', banks: ['itau', 'bradesco', 'santander'] }}
  tag="Novo"
  eyebrow="OPEN FINANCE"
  title="Conecte suas contas"
  description="Veja o saldo consolidado de todos os seus bancos em um só lugar."
  stats={[{ label: 'Bancos conectados', value: '3' }, { label: 'Saldo total', value: 'R$ 1,9M' }]}
  action={{ primary: { label: 'Conectar conta', onClick: handleConnect } }}
/>

// Horizontal — feature-banner com stats em painel dedicado
<CTACard
  direction="horizontal"
  header={{ tone: 'gradient-brand', icon: 'shield-check' }}
  title="Conta Garantida"
  description="Proteção do seu patrimônio com garantia SRM."
  stats={[{ label: 'Clientes protegidos', value: '12.400' }, { label: 'Patrimônio garantido', value: 'R$ 3,1 bi' }]}
  action={{ primary: { label: 'Saber mais', onClick: handleLearnMore } }}
/>

// Horizontal + analytics — dois blocos de conteúdo
<CTACard
  direction="horizontal"
  layout="analytics"
  header={{ tone: 'gradient-prime', icon: 'bar-chart-2' }}
  title="Insights de carteira"
  description="Análise de risco e diversificação em tempo real."
  sideContent={<div>Conteúdo lateral customizado (mini-chart, tags, etc.)</div>}
  action={{ primary: { label: 'Ver análise completa', onClick: handleAnalytics } }}
/>

// Dark theme — hero escuro (botões mantêm contraste)
<CTACard
  theme="dark"
  header={{ tone: 'brand', brandShade: 800, icon: 'sparkles' }}
  title="Novidade: SRM Prime"
  description="Benefícios exclusivos para clientes com mais de R$ 5M sob gestão."
  action={{ primary: { label: 'Conhecer', onClick: handlePrime } }}
/>

// Highlights customizados via children
<CTACard
  header={{ tone: 'success', icon: 'check-circle-2' }}
  title="Plano recomendado"
  action={{ primary: { label: 'Assinar', onClick: handleSubscribe } }}
>
  <ul>
    <li>Rebalanceamento automático</li>
    <li>Suporte dedicado</li>
  </ul>
</CTACard>
```

---

## Acessibilidade

- O card raiz é um `<div>` sem semântica própria de landmark — quando usado como hero de
  página, considere envolvê-lo em `<section aria-label="...">` no consumidor.
- Ícones do header e o overlay de imagem são decorativos (`aria-hidden`); o texto
  (`title`/`subtitle`/`description`) carrega a informação.
- `header.image` exige `imageAlt` significativo — sem ele, o `alt` cai em string vazia
  (`''`), tratando a imagem como puramente decorativa (correto apenas se o
  título/subtítulo sobreposto já repetir toda a informação da imagem).
- Ações (`Button`/`DoubleButton`) já carregam foco e ativação por teclado padrão desses
  componentes — não é necessário tratamento extra no `CTACard`.
- Em `theme="dark"`, confirme que o contraste do texto sobre `tone` claro (se algum tom
  específico for usado sobre fundo escuro) ainda atende WCAG AA — a combinação
  tone × theme não é auto-validada pelo componente.

## Armadilhas comuns

- Esperar `title`/`subtitle` aparecerem no body quando **não** há `header` configurado —
  eles só são renderizados dentro do header; sem `header`, ficam invisíveis (só
  `tag`/`eyebrow`/`description`/`children`/`stats` aparecem no body).
- Definir `header.image` **e** `header.tone`/`header.icon`/`header.banks` esperando que
  coexistam — com imagem presente, os demais slots do header são ignorados.
- Usar `layout="analytics"` em `direction="vertical"` esperando efeito — a prop só altera
  o layout horizontal (3 vs. 4 painéis).
- Usar `sideContent` sem `layout="analytics"` — a prop só é lida quando
  `direction="horizontal"` **e** `layout="analytics"` juntos.
- Passar `action.divider` ou `action.layout` sem `action.secondary` — ambos só têm
  efeito visual quando existe um `DoubleButton` (ou seja, com `secondary` definido).
- Esperar `theme="dark"` escurecer os botões internos também — a paleta dos botões segue
  `buttonTheme` (`'default' | 'dark'`), pensada para manter contraste do CTA, não um
  espelho automático de toda a paleta do card.
- Passar `title` como prop nativa de `HTMLAttributes` (tooltip HTML) — `title` é
  sobrescrito pelo tipo próprio do componente (`Omit<HTMLAttributes<...>, 'title'>`);
  não use `title` esperando o tooltip nativo do browser.
