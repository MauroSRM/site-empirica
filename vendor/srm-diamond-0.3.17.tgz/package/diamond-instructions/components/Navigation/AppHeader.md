# AppHeader

Header principal de aplicação (pós-login), **sticky** no topo da página, com tema `brand`
(fundo navy) ou `light` (fundo branco com borda inferior). Orquestra logo, busca, saldo,
avatar do usuário, notificações e um mega menu expansível — delegando cada peça a um
componente dedicado do Diamond. Construído sobre `@floating-ui/react` (posicionamento e
dismissal do painel do mega menu) e `Button` do `react-aria-components` (logo clicável).

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/AppHeader/`
- **Export:** `import { AppHeader } from '@srm/diamond';`
- **Composto por:** `NavIconButton` (hambúrguer e sino), `NavBalanceChip` (saldo),
  [`SearchInput`](../Forms/Inputs/SearchInput.md) (busca), `MegaMenu` (painel de navegação),
  `AvatarDropdown` / `AvatarColaborador` (menu do usuário), [`Logo`](../Brand/Logo.md).
  Nenhum desses sub-componentes é configurável via props soltas do `AppHeader` além do que
  está listado na interface abaixo — eles são montados internamente.

---

## Quando usar

- Como **header fixo único** de uma aplicação autenticada (portal, backoffice, app do
  cliente) — ele já é `position: sticky; top: 0`, não precise envolver em wrapper próprio.
- Quando a navegação principal precisa de um mega menu por categorias (usuários, alçadas,
  movimentações, compliance) acessado por um botão hambúrguer.
- Quando o cabeçalho precisa exibir saldo consolidado (`NavBalanceChip`), busca global e/ou
  notificações, sem montar cada peça manualmente.
- Tanto em telas com fundo navy institucional (`theme="brand"`) quanto em contextos mais
  neutros/administrativos (`theme="light"`).
- Quando a busca precisa ser **controlada** pela tela consumidora (limpar após submit,
  pré-popular a partir da URL, sincronizar com outro campo) → use `searchValue` + `onSearch`.

## Quando **não** usar

- Página de login/onboarding (pré-autenticação) → normalmente não há `AppHeader`; use
  o `Logo` isolado.
- Precisa apenas do avatar com dropdown, sem o restante do header → use `AvatarDropdown`
  ou `AvatarColaborador` diretamente (`@srm/diamond`, pasta `Identity/Avatar`).
- Precisa apenas do painel de navegação por categorias, fora do contexto do header (ex.:
  sidebar) → use `MegaMenu` diretamente.
- Precisa de um botão de ícone avulso fora do contexto de navegação → use
  [`IconButton`](../Forms/IconButton.md), não `NavIconButton` (interno do Navigation).

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { AvatarMenuOption } from '@srm/diamond'; // re-exportado de Identity/Avatar
import type { MegaMenuSection } from '@srm/diamond';   // re-exportado de Navigation/MegaMenu

type AppHeaderTheme      = 'brand' | 'light' | 'dark';
type AppHeaderSize       = 'default' | 'compact';
type AppHeaderAvatarType =
  | 'role'                 // AvatarDropdown, variant="role", appearance="outlined"
  | 'role-ghost'           // AvatarDropdown, variant="role", appearance="ghost"
  | 'company'              // AvatarDropdown, variant="company", appearance="outlined"
  | 'company-ghost'        // AvatarDropdown, variant="company", appearance="ghost"
  | 'colaborador'          // AvatarColaborador
  | 'colaborador-ghost';   // AvatarColaborador, logoAppearance="sutil"
type AppHeaderSearchSize = 'sm' | 'md';

interface AppHeaderUser {
  email?:       string;  // usado por avatarType colaborador/colaborador-ghost
  company?:     string;  // idem
  name?:        string;  // usado por AvatarDropdown (userName)
  role?:        string;  // usado por AvatarDropdown (userRole)
  initials?:    string;  // usado por AvatarDropdown
  companyName?: string;  // usado por AvatarDropdown
  companyCnpj?: string;  // usado por AvatarDropdown
}

interface AppHeaderBalance {
  value:  string;   // valor já formatado, ex.: "R$ 1.245.860,32"
  label?: string;   // rótulo acima do valor, ex.: "SALDO SRM"
}

interface AppHeaderProps {
  user?:                AppHeaderUser;
  balance?:             AppHeaderBalance;
  showBalance?:         boolean;                // default: false (via ?? ao renderizar)
  showAvatar?:          boolean;                 // default: true
  avatarType?:          AppHeaderAvatarType;     // default: 'role'
  showNotification?:    boolean;                 // default: true
  notificationCount?:   number;                  // default: 0 (via ??)
  megaMenuSections?:    MegaMenuSection[];        // default: [] — [] ou undefined = sem mega menu
  megaMenuFluid?:       boolean;                  // default: false — repassado ao MegaMenu
  showMenuButton?:      boolean;                  // default: hasMega || onMenuToggle definido
  size?:                AppHeaderSize;            // default: 'default' (80px) | 'compact' (62px)
  showSearch?:          boolean;                  // default: false
  searchSize?:          AppHeaderSearchSize;      // default: 'sm'
  searchValue?:         string;                   // valor controlado do SearchInput interno
  searchPlaceholder?:   string;                   // default: 'Buscar...'
  avatarMenuItems?:     AvatarMenuOption[];       // repassado a AvatarDropdown/AvatarColaborador
  navAriaLabel?:        string;                   // default: 'Navegação principal' — aria-label do <nav>
  notificationLabel?:   string;                   // default: 'Notificações' — texto base (sem contagem)
  openMenuLabel?:       string;                   // default: 'Abrir menu' — aria-label do hambúrguer fechado
  closeMenuLabel?:      string;                   // default: 'Fechar menu' — aria-label do hambúrguer aberto
  onLogoClick?:         () => void;               // se ausente, logo não é clicável
  onMenuToggle?:        () => void;               // disparado sempre, com ou sem mega menu
  onNotificationClick?: () => void;
  onSearch?:            (value: string) => void;  // disparado a cada mudança do SearchInput
  theme?:               AppHeaderTheme;           // default: 'brand'
  className?:           string;                   // default: ''
  defaultMenuOpen?:     boolean;                   // default: false — abre o mega menu já montado
}
```

### `MegaMenuSection` / `MegaLinkItem` (de `MegaMenu.types.ts`, usado em `megaMenuSections`)

```ts
interface MegaLinkItem {
  label:        string;
  description?: string;
  icon?:        ReactNode;
  onClick?:     () => void;
}

interface MegaMenuSection {
  title?:  string;          // omitir = seção sem cabeçalho (layout "single column")
  icon?:   ReactNode;       // exibido junto ao title, se ambos presentes
  wide?:   boolean;         // seção ocupa 2 colunas (legado; prefira `cols`)
  cols?:   number;          // nº de colunas de largura da seção
  links:   MegaLinkItem[];
}
```

### `AvatarMenuOption` (de `Identity/Avatar`, usado em `avatarMenuItems`)

```ts
interface AvatarMenuOption {
  id:        string;
  label:     string;
  icon?:     ReactNode;
  onSelect:  () => void;
  danger?:   boolean;   // estiliza o item como ação destrutiva (ex.: "Sair")
}
```

### Notas de comportamento

- **`theme` controla tema em cascata.** `theme="brand"` (dark) propaga tema escuro para
  `Logo`, `SearchInput`, `NavBalanceChip`, `NavIconButton` e avatares (`isDark`/`theme="dark"`
  internamente). `theme="light"` propaga tema claro. Não confunda com o `theme` de outros
  componentes Diamond (`'light' | 'dark'`) — aqui a semântica é `'brand' | 'light'`.
- **Mega menu só existe se houver seções.** `hasMega = megaMenuSections.length > 0`. Sem
  seções, o painel não abre e o hambúrguer **não** recebe `aria-expanded`.
- **O hambúrguer é opcional.** `showMenu = showMenuButton ?? (hasMega || onMenuToggle !== undefined)`
  — sem `megaMenuSections` e sem `onMenuToggle` o botão **não é renderizado** e o logo assume
  a extremidade esquerda. `showMenuButton` força o comportamento nas duas direções (`true`
  mostra mesmo sem nada para abrir; `false` esconde mesmo havendo seções).
- **`size` controla só a altura da barra.** `'default'` = 80px, `'compact'` = 62px (com gap
  interno menor). O conteúdo (logo, busca, avatar, ícones) mantém o mesmo tamanho nas duas.
- **Posicionamento do painel via floating-ui.** O painel do `MegaMenu` é renderizado em um
  `FloatingPortal`, ancorado no `<nav>` (`placement: 'bottom-start'`, `strategy: 'fixed'`),
  com a largura forçada a igualar a largura do `<nav>` (middleware `size`). Fecha ao clicar
  fora ou `Escape` (`useDismiss`).
- **`showBalance` exige `balance`.** O chip só renderiza se `showBalance` for `true` **e**
  `balance` estiver definido — passar só `showBalance` sem `balance` não mostra nada.
- **Busca pode ser controlada ou não.** Sem `searchValue`, o `SearchInput` interno mantém
  seu próprio estado e `onSearch` apenas observa cada mudança. Passando `searchValue`, o
  valor do campo passa a ser espelhado por essa prop — nesse caso, forneça também `onSearch`
  para atualizar o estado externo a cada digitação; sem ele, o campo fica travado no valor
  passado (o usuário digita, mas o valor exibido não muda).
- **Logo condicional.** Com `onLogoClick`, o logo é envolto num `Button` do react-aria
  (focável, `onPress`); sem ele, é um `<div>` estático — decorativo, não focável.
- **Rótulo do sino é dinâmico e em pt-BR, com base em `notificationLabel`.**
  `notificationCount` ausente/`0` → usa `notificationLabel` (default "Notificações");
  `1` → "1 notificação não lida"; `>1` → "N notificações não lidas". O texto customizado em
  `notificationLabel` só se aplica ao caso de contagem zero/ausente — a pluralização com
  contagem é sempre em pt-BR fixo, não parametrizável.
- **Campos do `user` têm fallback silencioso para `''` — nunca para dado de exemplo.**
  Se `user` ou seus campos estiverem ausentes, o `AppHeader` **não** lança erro nem injeta
  nenhum valor de exemplo (não há mais e-mail/empresa hardcoded como fallback): os avatares
  recebem strings vazias (`initials=''`, `userName=''`, `email=''`, etc.), o que pode
  renderizar iniciais/nome/e-mail em branco. Sempre valide os dados antes de passar ao
  componente.

---

## Exemplos

```tsx
import { AppHeader } from '@srm/diamond';

// Mínimo — sem mega menu, sem busca, sem saldo
<AppHeader
  user={{ initials: 'CM', name: 'Carlos Mendes', role: 'CEO · Master' }}
  onMenuToggle={() => console.log('toggle')}
/>
```

```tsx
// Com saldo, busca não-controlada e notificações
<AppHeader
  theme="brand"
  user={{ initials: 'CM', name: 'Carlos Mendes', role: 'CEO · Master' }}
  showBalance
  balance={{ label: 'SALDO SRM', value: 'R$ 1.245.860,32' }}
  showSearch
  searchSize="md"
  searchPlaceholder="Buscar fundos, contas ou operações..."
  onSearch={(value) => setQuery(value)}
  showNotification
  notificationCount={3}
  onNotificationClick={() => openNotifications()}
/>
```

```tsx
// Busca controlada — sincronizada com estado externo (ex.: filtro por query string)
const [query, setQuery] = useState(initialQueryFromUrl);

<AppHeader
  showSearch
  searchValue={query}
  onSearch={setQuery}
  onMenuToggle={() => {}}
/>
```

```tsx
// Rótulos e aria-labels customizados (i18n / copy institucional específica)
<AppHeader
  navAriaLabel="Menu principal do portal"
  notificationLabel="Avisos"
  openMenuLabel="Abrir navegação"
  closeMenuLabel="Fechar navegação"
  onMenuToggle={() => {}}
/>
```

```tsx
// Mega menu com seções verticais (título + ícone + 2 colunas cada)
import { Users, SlidersHorizontal, UserPlus, KeyRound } from 'lucide-react';
import type { MegaMenuSection } from '@srm/diamond';

const sections: MegaMenuSection[] = [
  {
    title: 'Usuários & Perfis',
    icon: <Users size={20} />,
    cols: 2,
    links: [
      {
        label: 'Novo usuário',
        description: 'Cadastrar e definir perfil de acesso',
        icon: <UserPlus size={20} />,
        onClick: () => router.push('/usuarios/novo'),
      },
      {
        label: 'Redefinir acesso',
        description: 'Senha, MFA e certificados',
        icon: <KeyRound size={20} />,
        onClick: () => router.push('/usuarios/reset'),
      },
    ],
  },
];

<AppHeader
  megaMenuSections={sections}
  onMenuToggle={() => {}}
/>
```

```tsx
// Layout horizontal — uma única seção sem title, links em grid
const sections: MegaMenuSection[] = [
  {
    links: [
      { label: 'Transferências', icon: <ArrowLeftRight size={20} />, onClick: () => {} },
      { label: 'Extrato', icon: <Receipt size={20} />, onClick: () => {} },
    ],
  },
];

<AppHeader megaMenuSections={sections} megaMenuFluid onMenuToggle={() => {}} />
```

```tsx
// Avatar tipo "colaborador" (interno SRM) + menu customizado
import { User, LogOut } from 'lucide-react';
import type { AvatarMenuOption } from '@srm/diamond';

const avatarMenuItems: AvatarMenuOption[] = [
  { id: 'profile', label: 'Meu perfil', icon: <User size={14} />, onSelect: () => router.push('/perfil') },
  { id: 'logout',  label: 'Sair',       icon: <LogOut size={14} />, danger: true, onSelect: () => logout() },
];

<AppHeader
  avatarType="colaborador"
  user={{ email: 'carlos.mendes@srmasset.com.br', company: 'SRM' }}
  avatarMenuItems={avatarMenuItems}
  onMenuToggle={() => {}}
/>
```

```tsx
// Tema light (contexto administrativo, fundo branco)
<AppHeader
  theme="light"
  user={{ initials: 'CM', name: 'Carlos Mendes', role: 'Analista' }}
  avatarType="company-ghost"
  onMenuToggle={() => {}}
/>
```

```tsx
// Logo clicável (navega para home) vs. logo estático
<AppHeader onLogoClick={() => router.push('/')} onMenuToggle={() => {}} />   // clicável
<AppHeader onMenuToggle={() => {}} />                                        // estático (sem onLogoClick)
```

---

## Acessibilidade

- `<nav>` interno tem `role="navigation"` e `aria-label` configurável via `navAriaLabel`
  (default "Navegação principal").
- O botão hambúrguer expõe `aria-label` dinâmico via `openMenuLabel`/`closeMenuLabel`
  (defaults "Abrir menu"/"Fechar menu") e só recebe `aria-expanded` quando há mega menu
  (`hasMega`) — evita semântica de "expansível" em botão que não expande nada.
- O sino de notificações sempre tem `aria-label` calculado (nunca fica sem nome acessível),
  combinando `notificationLabel` com a contagem de não lidas quando houver.
- Fechamento do painel do mega menu por `Escape` e clique fora é tratado pelo `useDismiss`
  do `floating-ui` — não precisa implementar isso na tela consumidora.
- O logo só é focável/acionável por teclado quando `onLogoClick` é fornecido (via
  `Button` do react-aria); sem o handler, é puramente decorativo.
- Avatares (`AvatarDropdown`/`AvatarColaborador`) e `SearchInput` carregam suas próprias
  garantias de acessibilidade internas — consulte a documentação de `Identity/Avatar` e
  [`SearchInput`](../Forms/Inputs/SearchInput.md) para o contrato detalhado de cada um.

## Armadilhas comuns

- Passar `showBalance` sem `balance` (ou vice-versa) — **nenhum dos dois isoladamente**
  renderiza o `NavBalanceChip`; ambos são exigidos.
- Passar `searchValue` sem `onSearch` — o campo fica visualmente editável, mas o valor
  exibido não muda ao digitar (fica travado no `searchValue` fornecido); trate os dois
  como um par obrigatório ao controlar a busca.
- Confundir `theme="brand"` com "tema escuro" de outros componentes — aqui `'brand'` é o
  valor que ativa o modo escuro; não existe `theme="dark"` neste componente.
- Omitir `megaMenuSections` mas manter `onMenuToggle` esperando que o hambúrguer suma —
  `onMenuToggle` sozinho já justifica o botão (drawer próprio do consumidor). Para esconder
  mesmo assim, passe `showMenuButton={false}`.
- Usar `avatarType="colaborador"`/`"colaborador-ghost"` mas preencher `user.name`/`user.role`
  em vez de `user.email`/`user.company` — esses dois tipos leem apenas `email` e `company`.
- Esperar que campos ausentes de `user` gerem algum valor de exemplo — eles **não geram
  erro nem dado fake**, apenas avatares com iniciais/nome/e-mail vazios; valide os dados
  antes de passar ao componente.
- Assumir que `notificationLabel` altera o texto de contagem plural ("N notificações não
  lidas") — ele só substitui o texto usado quando a contagem é zero/ausente.
- `className` é aplicado ao contêiner raiz (fora do `<nav>`) — não use para sobrescrever
  estilos internos do `<nav>`, `leftSection`, etc. (módulos SCSS `AppHeader.module.scss`
  não são expostos como classes públicas).
