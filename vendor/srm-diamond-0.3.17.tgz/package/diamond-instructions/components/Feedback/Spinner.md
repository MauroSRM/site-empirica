# Spinner

Indicador de carregamento standalone — um único ícone giratório (`loader-circle`, via
`Icon` do próprio Diamond) com anúncio acessível via `role="status"` + `aria-label`.
Usado para estados de carregamento de seção, card ou tela inteira; **não** é o loader
interno do `Button` (que já embute seu próprio spinner via a prop `loading`). Construído
com CSS puro (`Spinner.module.scss`, `@keyframes dsSpin`) e variantes de cor via
`class-variance-authority` (CVA).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Spinner/`
- **Export:** `import { Spinner } from '@srm/diamond';` (tipos `SpinnerProps`, `SpinnerSize`,
  `SpinnerVariant` também exportados pelo barrel)
- **Relacionados:** [Button](../Forms/Button.md) (tem `loading` embutido — não componha `Spinner` dentro dele)

---

## Quando usar

- Carregamento de uma seção, card, tabela ou área da tela enquanto dados são buscados
  (ex.: aguardando resposta de uma API de posições, extratos, cotações).
- Estado de carregamento de tela inteira (splash/overlay) antes do conteúdo principal montar.
- Qualquer lugar onde você precise de um indicador de progresso indeterminado, fora de um botão.

## Quando **não** usar

- Dentro de um `Button` — use a prop `loading` do próprio [`Button`](../Forms/Button.md),
  que já renderiza o spinner interno e desabilita o clique.
- Progresso determinado (porcentagem conhecida, ex.: upload de arquivo) — um `Spinner` é
  sempre indeterminado; para progresso mensurável não force esta semântica aqui.
- Placeholder de layout (linhas/blocos de texto/imagem enquanto carrega) → use
  [`Skeleton`](./Skeleton.md).

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

type SpinnerSize = 'sm' | 'md' | 'lg';
type SpinnerVariant = 'brand' | 'white' | 'muted';

interface SpinnerProps extends ComponentPropsWithoutRef<'span'> {
  size?: SpinnerSize;        // default: 'md'
  variant?: SpinnerVariant;  // default: 'brand'
  label?: string;            // default: 'Carregando' — rótulo acessível anunciado por leitores de tela
  ref?: Ref<HTMLSpanElement>;
  // Herdado de ComponentPropsWithoutRef<'span'>: className, style, id, aria-*, data-*, ...
}
```

### Notas de comportamento

- Renderiza um único `<span role="status" aria-label={label}>` envolvendo o ícone
  (`Icon icon="loader-circle"`) — não há mais um segundo `<span>` de texto visualmente
  oculto; o anúncio a leitores de tela vem inteiramente de `role="status"` + `aria-label`.
- `role="status"` e `aria-label={label}` são aplicados **depois** do spread de
  `{...props}` no JSX — props externas (`role`, `aria-label`) passadas pelo consumidor
  **não conseguem sobrescrever** esses dois atributos.
- Tamanho do ícone é resolvido por `size` via `SPINNER_SIZE_PX`: `sm` → `24px`,
  `md` → `32px`, `lg` → `40px` (valores em pixel fixo, não tokens de ícone).
- Espessura do traço (`strokeWidth`) por `size` via `SPINNER_STROKE_WIDTH`: `sm` → `2.5`,
  `md`/`lg` → `2`.
- Cor resolvida por `variant` via `spinnerGlyphVariants` (CVA): `brand` → `var(--brand-primary)`,
  `white` → `var(--text-on-brand)` (para uso sobre fundos escuros/coloridos), `muted` →
  `var(--text-tertiary)` (para uso discreto, ex.: dentro de listas).
  ATENÇÃO: apesar do nome, `white` mapeia para o token `--text-on-brand`, não literalmente branco.
- Animação de rotação (`dsSpin`, 0.8s linear infinite) é desativada automaticamente quando o
  usuário tem `prefers-reduced-motion: reduce` ativo no sistema.
- `className` é concatenado (via `clsx`, não mesclado por CVA) ao wrapper externo (`.wrap`)
  — cuidado ao passar classes que colidam com `display`/`align-items` do wrapper.
- Demais props (`{...props}`) fazem passthrough direto para o `<span>` raiz (ex.: `id`,
  `data-*`, `style`).

---

## Exemplos

```tsx
import { Spinner } from '@srm/diamond';

// Básico
<Spinner />

// Tamanho pequeno, dentro de uma linha de texto
<Spinner size="sm" label="Atualizando saldo" />

// Tamanho grande, carregamento de tela cheia
<div style={{ display: 'grid', placeItems: 'center', minHeight: '60vh' }}>
  <Spinner size="lg" label="Carregando carteira" />
</div>

// Variante discreta (muted), dentro de uma lista/tabela
<Spinner variant="muted" size="sm" />

// Variante para fundo escuro/colorido (ex.: dentro de um card com background brand)
<div style={{ background: 'var(--brand-primary)', padding: 24, borderRadius: 8 }}>
  <Spinner variant="white" label="Processando resgate" />
</div>

// Estado de carregamento condicional de uma seção
function PosicoesCard({ isLoading, data }: { isLoading: boolean; data: Posicao[] }) {
  if (isLoading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: 32 }}>
        <Spinner label="Carregando posições" />
      </div>
    );
  }
  return <PosicoesTable data={data} />;
}
```

---

## Acessibilidade

- `role="status"` faz o `<span>` raiz ser anunciado como uma live region polida — leitores
  de tela informam a mudança sem interromper o usuário.
- O nome acessível vem exclusivamente de `aria-label={label}` no próprio `role="status"`
  — não há mais texto visualmente oculto duplicando o rótulo.
- **Sempre** customize `label` para descrever o que está carregando quando o contexto não for
  óbvio (ex.: `"Carregando extrato"` em vez do genérico `"Carregando"`) — melhora a experiência
  de quem usa leitor de tela em telas com múltiplos spinners simultâneos.
- O ícone é puramente visual; não dependa dele para transmitir significado — o significado
  está no `role="status"` + `label`.
- A animação respeita `prefers-reduced-motion` automaticamente — não é necessário tratamento
  adicional no código consumidor.

## Armadilhas comuns

- Não use `Spinner` dentro de um `Button` para simular loading — use a prop `loading` nativa
  do [`Button`](../Forms/Button.md), que já cuida de desabilitar o clique e trocar o label.
- Não assuma que `variant="white"` produz branco puro — é o token semântico `--text-on-brand`;
  valide contra o fundo real antes de usar.
- Não tente sobrescrever `role`/`aria-label` via props — eles são fixados internamente após o
  spread de `{...props}` e vencem qualquer valor externo.
- `size="lg"` usa um valor de pixel fixo (`40px`), não um token de ícone — se o design system
  introduzir um novo token de ícone maior, este valor não acompanha automaticamente.
- Vários `Spinner`s na mesma tela com o `label` genérico padrão (`"Carregando"`) podem confundir
  usuários de leitor de tela — prefira labels específicos por contexto.
