# KPICard

Card compacto para exibir uma métrica KPI: ícone semântico circular, label curto, valor
destacado, `TrendIndicator` opcional, hint de contexto e uma `Tag` de período no canto
superior direito. Pensado para grids de dashboard com múltiplos indicadores lado a lado
(patrimônio sob gestão, rentabilidade, posições em risco etc.). É **polimórfico**: sem
`onPress` renderiza um `<div>` estático; com `onPress` renderiza um `<Button>` de
**react-aria-components** (clicável, com chevron à direita). Usa a superfície compartilhada
`Cards/cardSurface` (CVA `appearance` × `interactive`) e compõe `Tag`/`TrendIndicator`
(`DataDisplay`), `Icon` (`Icons`) e `Skeleton` (`Feedback`).

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/KPICard/`
- **Export:** `import { KPICard } from '@srm/diamond';`
- **Relacionados:** [Card](./Card.md) (card genérico, sem semântica de KPI), [Icon](../Icons/Icon.md),
  [Tag](../DataDisplay/Tag.md), [TrendIndicator](../DataDisplay/TrendIndicator.md),
  [Skeleton](../Feedback/Skeleton.md)

---

## Quando usar

- Dashboards financeiros com múltiplos indicadores numéricos em grid (patrimônio sob
  gestão, rentabilidade mensal, número de posições em risco, ordens com falha).
- Quando o valor precisa de destaque visual forte (`value` grande) acompanhado de um
  rótulo curto (`label`) e, opcionalmente, variação percentual (`trend` + `trendLabel`).
- Quando o período/contexto da métrica precisa ficar visualmente separado do valor
  (prop `tag`, ex.: "Mês", "YTD", "D-1"), com a cor da tag ajustável via `tagVariant`.
- KPI que também é ponto de navegação (ex.: abrir detalhamento da métrica) → passe
  `onPress` e o card vira botão acessível com chevron indicando affordance de clique.
- Estados de carregamento de dados assíncronos (`loading`), exibindo skeleton no lugar
  do ícone, da tag e dos textos.

## Quando **não** usar

- Card genérico com título/descrição/ação (não é uma métrica numérica) → use
  [`Card`](./Card.md).
- Texto narrativo ou conteúdo longo — o KPICard é estritamente compacto, para
  números/métricas curtas; `label` longo quebra o layout.
- Tendência sem valor de variação — não use `trend` sem `trendLabel`: o ícone sozinho
  não comunica quanto mudou (ver Armadilhas comuns).
- Precisa de `<div>` clicável sem virar `<button>` semântico — não é suportado; ao
  passar `onPress` o card sempre é um `<Button>` de react-aria (ver Notas de comportamento).

---

## Interface

```ts
import type { HTMLAttributes, ReactNode } from 'react';
import type { ButtonProps as AriaButtonProps } from 'react-aria-components';
import type { TrendDirection } from '@srm/diamond';  // reexportado por TrendIndicator
import type { CardVariant } from '@srm/diamond';     // reexportado por Card ('outlined' | 'elevated' | 'ghost')

type KPICardVariant = 'default' | 'success' | 'warning' | 'error' | 'info';
type KPICardAppearance = CardVariant; // 'outlined' | 'elevated' | 'ghost'

type KPICardTagVariant =
  | 'brandPrimary'
  | 'brandAccent'
  | 'success'
  | 'warning'
  | 'error'
  | 'info';

interface KPICardBase {
  variant?: KPICardVariant;         // default: 'default' — estilo semântico do ícone
  appearance?: KPICardAppearance;   // default: 'outlined'
  label: ReactNode;                 // obrigatório — rótulo curto acima do valor
  value: ReactNode;                 // obrigatório — valor destacado
  hint?: ReactNode;                 // texto complementar
  loading?: boolean;                // default: false — renderiza skeleton
  valueFontSize?: string;           // override via CSS var; default visual: 'var(--text-24)'
  maxWidth?: number | string;       // largura máxima do card; número vira px
  tag?: ReactNode;                  // tag opcional no canto superior direito
  tagVariant?: KPICardTagVariant;   // default: 'brandAccent'
  trend?: TrendDirection;           // 'up' | 'down' | 'neutral' | 'none'
  trendLabel?: string;              // label do TrendIndicator (ex.: "+3,2%")
  icon?: string;                    // nome do glifo (ICON_MAP, kebab-case) — sobrepõe o default do variant
}

// Estática (sem onPress): renderiza <div>. `onPress` é proibido (never).
type KPICardStaticProps = KPICardBase &
  Omit<HTMLAttributes<HTMLDivElement>, 'children' | keyof KPICardBase> & {
    onPress?: never;
  };

// Interativa (com onPress): renderiza <Button> de react-aria-components.
// `onPress` é obrigatório nesse ramo.
type KPICardInteractiveProps = KPICardBase &
  Omit<AriaButtonProps, 'children' | keyof KPICardBase> & {
    onPress: NonNullable<AriaButtonProps['onPress']>;
  };

type KPICardProps = KPICardStaticProps | KPICardInteractiveProps;
```

### Notas de comportamento

- **Polimorfismo por `onPress`**: `KPICard` verifica `'onPress' in props && typeof
  props.onPress === 'function'` para decidir entre `StaticKPICard` (`<div>`) e
  `InteractiveKPICard` (`<Button>` de react-aria-components). Não há uma prop `interactive`
  explícita — a interatividade é **inferida** pela presença de `onPress`.
  - Estático: aceita `HTMLAttributes<HTMLDivElement>` (`id`, `data-*`, `aria-*`, `onClick` nativo, etc.).
  - Interativo: aceita `AriaButtonProps` (`isDisabled`, `autoFocus`, `form`, `excludeFromTabOrder`, etc.)
    e ganha automaticamente um chevron (`chevron-right`) alinhado à direita, cuja cor muda
    para `--text-brand` no hover (`[data-hovered]`).
- **Ícone por `variant`**: cada `variant` tem um glifo default definido em
  `KPICard.constants.ts` (`VARIANT_ICON`) — `default` → `file-text`, `success` →
  `check-circle-2`, `warning` → `alert-triangle`, `error` → `x-circle`, `info` → `shield`.
  A prop `icon` (nome do glifo, kebab-case) substitui esse default. O ícone é renderizado
  via `Icon` com `type={variant}`, `circle`, `tint="chip"`, `size={18}`, `circleSize={36}`.
- **`appearance`** espelha as variantes visuais do `cardSurface` compartilhado: `outlined`
  (borda), `elevated` (sombra), `ghost` (transparente, sem borda). Combinado com
  `interactive` (derivado de `onPress`) via `cardSurfaceVariants({ appearance, interactive })`.
- **`loading`**: substitui ícone, tag e textos por blocos de `Skeleton` (`Feedback/Skeleton`)
  — círculo 36×36 para o ícone, bloco 40×20 para a tag (se houver `tag`), e três linhas
  (label/value/hint) no corpo. Diferente de versões anteriores, **não é** um early-return
  de card inteiro: a estrutura (tag/ícone/corpo/chevron) permanece, só o conteúdo interno
  de cada bloco é substituído por skeleton — e o chevron (interativo) **não** aparece
  durante `loading` (`interactive && !loading`).
- **Layout condicional de `trend`/`hint`**:
  - Se há `trend` **e** `hint` → o `hint` vai para uma linha abaixo do `TrendIndicator` (`hintBelow`).
  - Se há **apenas** `hint` (sem `trend`) → aparece inline na mesma linha do trend (`hintInline`).
  - Sem `trend` nem `hint`, nenhuma linha extra é renderizada.
  - `trend` sem `trendLabel` renderiza só o ícone de direção no `TrendIndicator` (`size="sm"`).
- **`tag`**: renderizado com `Tag` (`variant={tagVariant}`, default `'brandAccent'`, `size="sm"`),
  posicionado `absolute` no canto superior direito. O padding extra no corpo
  (`bodyWithTag`, 56px) só é aplicado quando o card é **estático** — em modo interativo
  (`bodyNeedsRightPad = Boolean(tag) && !interactive`), o corpo não reserva esse espaço
  extra, pois o chevron já ocupa a extremidade direita.
- **Truncamento de `label` e `value`**: ambos são renderizados em uma única linha via
  `TruncatedText` (`Cards/_shared`) — `white-space: nowrap` + `text-overflow: ellipsis`.
  Quando o conteúdo não cabe na largura disponível, o componente monta um `Tooltip` com o
  texto completo (gatilho não-interativo: responde a hover, fica fora da ordem de
  tabulação e não vira widget para leitores de tela, que já leem o texto integral no DOM).
  Texto que cabe não monta o tooltip nem registra listeners. Consequência: `label`/`value`
  nunca vazam para fora do card, mas também **nunca quebram em duas linhas**.
- **`maxWidth`**: injetado como custom property `--kpi-card-max-width`. O piso de largura
  usa `min(var(--width-card-min), 100%)`, então um `maxWidth` menor que `--width-card-min`
  (220px) é respeitado sem estourar a caixa. Aceita número (vira px) ou string CSS.
- **`valueFontSize`**: injetado como custom property `--kpi-value-size` no `style` do
  container; o `.value` consome via `font-size: var(--kpi-value-size, var(--text-24))`.
  No ramo interativo, se `style`/`className` vierem como função (render props de
  react-aria), eles são ignorados para o cálculo do CSS var (fallback `undefined`).
- Props herdadas (`HTMLAttributes<HTMLDivElement>` no estático, `AriaButtonProps` no
  interativo) são repassadas via `...rest` para o elemento raiz.

---

## Exemplos

```tsx
import { KPICard } from '@srm/diamond';

// Básico — estático
<KPICard label="Total de ativos" value="247" />

// Com variante semântica e ícone default correspondente
<KPICard variant="info" label="Patrimônio sob gestão" value="R$ 8,4 bi" />

// Com trend e trendLabel (recomendado: sempre usar os dois juntos)
<KPICard
  variant="info"
  label="Patrimônio sob gestão"
  value="R$ 8,4 bi"
  trend="up"
  trendLabel="+12,4%"
  tag="Mês"
  tagVariant="brandPrimary"
/>

// Variante de alerta
<KPICard variant="warning" label="Posições em risco" value="3" hint="Acima do limite de 2" />

// Variante de erro, sem trend (hint inline)
<KPICard variant="error" label="Ordens com falha" value="12" hint="Últimas 24h" />

// Appearance elevated (sombra em vez de borda)
<KPICard
  variant="success"
  appearance="elevated"
  label="Rentabilidade mensal"
  value="+2,8%"
  trend="up"
  trendLabel="+0,4pp"
/>

// Appearance ghost (sem borda/fundo — compor sobre superfície já destacada)
<KPICard appearance="ghost" label="Total de ativos" value="247" />

// Ícone customizado (nome do glifo, substitui o default do variant)
<KPICard variant="info" icon="landmark" label="Fundos ativos" value="18" />

// Estado de loading (skeleton)
<KPICard loading label="Patrimônio sob gestão" value="R$ 8,4 bi" />

// Tamanho de valor customizado
<KPICard label="Ticket médio" value="R$ 42.500" valueFontSize="var(--text-32)" />

// Interativo — clicável, ganha chevron e semântica de <Button>
<KPICard
  variant="info"
  label="Patrimônio sob gestão"
  value="R$ 8,4 bi"
  trend="up"
  trendLabel="+12,4%"
  tag="Mês"
  onPress={() => abrirDetalhamento()}
/>

// Grid de múltiplos KPIs (uso típico em dashboard)
<div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
  <KPICard variant="info" label="Patrimônio sob gestão" value="R$ 8,4 bi" trend="up" trendLabel="+12,4%" tag="Mês" />
  <KPICard variant="success" label="Rentabilidade mensal" value="+2,8%" trend="up" trendLabel="+12,4%" tag="Mês" />
  <KPICard variant="warning" label="Posições em risco" value="3" trend="up" trendLabel="+12,4%" tag="Mês" />
  <KPICard variant="error" label="Ordens com falha" value="12" trend="up" trendLabel="+12,4%" tag="Mês" />
</div>
```

> KPICard exibe apenas dados já resolvidos (`ReactNode`) — não há integração direta
> com React Hook Form; ele não é um campo de formulário.

---

## Acessibilidade

- **Estático** (sem `onPress`): `label`/`value` são texto simples (`<p>`), sem semântica
  de heading; se o KPICard estiver dentro de uma seção, considere um heading visualmente
  oculto no container pai identificando o grupo de indicadores.
- **Interativo** (com `onPress`): o card é um `<Button>` de react-aria-components — foco,
  ativação por Enter/Espaço e `:focus-visible` já tratados. Como `label`/`value` compõem
  o conteúdo do botão, garanta que a combinação seja um nome acessível suficiente (ex.:
  "Patrimônio sob gestão" + "R$ 8,4 bi"); se não for, use `aria-label` via `...rest`.
- O ícone circular e o chevron são sempre decorativos (ícone via `Icon` sem
  `aria-label`; chevron com `aria-hidden="true"`) — a informação semântica está em
  `label`/`value`/`hint`, nunca no ícone.
- O skeleton de `loading` não tem `role="status"` nem anúncio para leitor de tela — se o
  carregamento for relevante, envolva o card em uma região com `aria-live`/`aria-busy`
  gerenciada pelo consumidor.
- No modo estático, `...rest` aceita `aria-*`/`role` livremente; no modo interativo, use
  as props de `AriaButtonProps` (`aria-label`, `aria-describedby`, etc.).

## Armadilhas comuns

- **Não** use `trend` sem `trendLabel`: o ícone de direção sozinho não comunica a
  magnitude da variação.
- **Não** coloque texto longo em `label` — o card é compacto (`min-width` via
  `--width-card-min`); rótulos longos não quebram o layout (truncam com tooltip), mas
  ficam ilegíveis sem hover.
- Esperar que `label`/`value` quebrem em múltiplas linhas — eles truncam em uma linha só.
  Para texto multi-linha, use [`Card`](./Card.md).
- Passar `style={{ maxWidth }}` em vez da prop `maxWidth` — o `min-width` do card venceria
  e a caixa estouraria; a prop ajusta os dois limites de uma vez.
- Esperar que `icon` aceite um componente Lucide (`ComponentType<LucideProps>`) — a API
  atual usa **nome de glifo em string** (kebab-case, resolvido pelo átomo `Icon`), não um
  componente React.
- Passar `onPress` como `undefined`/omitir e esperar que o card ainda vire botão — a
  checagem é `typeof props.onPress === 'function'`; sem essa função, o card **sempre**
  renderiza como `<div>` estático, mesmo que outras props de `AriaButtonProps` estejam
  presentes.
- Esperar `bodyWithTag` (padding-right reservado para a tag) no modo **interativo** — esse
  padding só é aplicado quando o card é estático; no interativo, o espaço à direita já é
  ocupado pelo chevron.
- Em `loading`, todas as demais props visuais (`icon`, `trend`, `hint`, `tag`, `tagVariant`)
  são ignoradas visualmente — o skeleton não reflete `variant` ou conteúdo real.
- Esquecer `tagVariant` esperando que a tag sempre saia com a mesma cor do `variant` do
  card — são props independentes; o default de `tagVariant` é `'brandAccent'`, não o
  `variant` semântico do KPI.
