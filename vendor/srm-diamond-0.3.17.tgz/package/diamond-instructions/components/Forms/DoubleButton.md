# DoubleButton

Par de ações (primária + secundária) para rodapés de modal, dialogs de confirmação e
formulários com "salvar/cancelar". Não é um botão novo — é um wrapper de layout que
renderiza **dois** [`Button`](./Button.md) internos, já com combinações de variante
(`pair`) e rótulos padrão pré-configurados, e cuida da ordem visual correta conforme o
`layout`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/DoubleButton/`
- **Export:** `import { DoubleButton } from '@srm/diamond';`
- **Relacionados/Base:** [Button](./Button.md) (usado internamente, duas instâncias)

---

## Quando usar

- Rodapé de modal com ação de confirmar + cancelar (`pair="primary-secondary"` ou `"primary-ghost"`).
- Diálogo de confirmação de exclusão (`pair="destructive-ghost"`) — ex.: excluir conta,
  remover carteira, cancelar ordem.
- Formulários curtos onde as duas ações finais devem ter hierarquia visual fixa e
  espaçamento consistente (sem montar o par manualmente com dois `<Button>` + flex).
- Layout empilhado em mobile/rodapé estreito (`layout="vertical"`), onde os botões
  ocupam a largura total (`fullWidth`) automaticamente.

## Quando **não** usar

- Uma única ação → use [`Button`](./Button.md) diretamente.
- Mais de duas ações, ou ações com pesos semânticos que não se encaixam nos três pares
  predefinidos → componha `Button`s manualmente.
- Botão isolado só de ícone → [`IconButton`](./IconButton.md).

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonSize } from '../Button';

type DoubleButtonLayout = 'horizontal' | 'vertical';
type DoubleButtonPair = 'primary-secondary' | 'primary-ghost' | 'destructive-ghost';
type DoubleButtonTheme = 'default' | 'dark';

interface DoubleButtonProps {
  layout?: DoubleButtonLayout;        // default: 'horizontal'
  pair?: DoubleButtonPair;            // default: 'primary-ghost'
  size?: ButtonSize;                  // default: 'md' — repassado aos dois Buttons
  theme?: DoubleButtonTheme;          // default: 'default' (repassa theme="light" ao Button)
  primaryLabel?: ReactNode;           // sobrescreve o label padrão do par
  secondaryLabel?: ReactNode;         // sobrescreve o label padrão do par
  onPrimary?: () => void;             // chamado via onPress do Button primário
  onSecondary?: () => void;           // chamado via onPress do Button secundário
  primaryLoading?: boolean;           // default: false
  secondaryLoading?: boolean;         // default: false
  primaryDisabled?: boolean;          // default: false
  secondaryDisabled?: boolean;        // default: false
  className?: string;                // aplicado ao container (via CVA)
}
```

### `pair` — combinações pré-configuradas (`DoubleButton.constants.ts`)

| `pair`                 | Ação primária                         | Ação secundária                |
|------------------------|----------------------------------------|---------------------------------|
| `primary-secondary`    | `variant="primary"` — "Confirmar"      | `variant="secondary"` — "Cancelar" |
| `primary-ghost` (default) | `variant="primary"` — "Salvar"      | `variant="ghost"` — "Cancelar"  |
| `destructive-ghost`    | `variant="destructive"` — "Sim, excluir" | `variant="ghost"` — "Cancelar" |

`primaryLabel`/`secondaryLabel` sobrescrevem apenas o **texto**; a variante do botão
continua vindo do `pair` escolhido (não é possível trocar a variante isoladamente —
escolha o `pair` que já produz a combinação de cores desejada).

### Notas de comportamento

- **Ordem visual não é a ordem dos props**: no `layout="horizontal"` (default), a ação
  **secundária** é renderizada primeiro no DOM e a **primária** por último — ou seja,
  primária fica à **direita**. No `layout="vertical"`, a primária vem primeiro (em cima)
  e a secundária depois (embaixo). Isso é intencional e não configurável.
- `layout="vertical"` aplica `fullWidth` automaticamente aos dois `Button`s internos e
  empilha em coluna com `width: 100%`.
- `size` e `theme` são propagados aos dois `Button`s filhos — não há como ter tamanhos
  ou temas diferentes entre a ação primária e a secundária.
- `theme="dark"` marca o container com `data-theme="dark"` e força `theme="light"` a
  virar `theme="dark"` nos `Button`s internos (necessário porque `.ghost`/`.secondary`
  usam tokens do tema claro por padrão, que ficam incorretos sobre fundo escuro).
- `primaryDisabled`/`secondaryDisabled` mapeiam para `isDisabled` do `Button`
  (react-aria) — não existe uma prop `disabled` simples aqui.
- `primaryLoading`/`secondaryLoading` acionam o spinner interno do `Button` (ver
  [Button](./Button.md)), desabilitando aquele botão especificamente.
- O espaçamento (`gap`) entre os botões vem do CSS Module: `16px` no horizontal
  padrão (`md`/`lg`), `12px` no horizontal com `size="sm"`, e `12px` fixo no vertical.

---

## Exemplos

```tsx
import { DoubleButton } from '@srm/diamond';

// Rodapé de modal padrão (Salvar / Cancelar)
<DoubleButton
  onPrimary={handleSave}
  onSecondary={handleClose}
/>

// Confirmar / Cancelar
<DoubleButton
  pair="primary-secondary"
  onPrimary={handleConfirm}
  onSecondary={handleCancel}
/>

// Confirmação de exclusão
<DoubleButton
  pair="destructive-ghost"
  onPrimary={handleDeleteAccount}
  onSecondary={handleCancel}
/>

// Rótulos customizados
<DoubleButton
  primaryLabel="Enviar proposta"
  secondaryLabel="Voltar"
  onPrimary={handleSubmit}
  onSecondary={handleBack}
/>

// Layout vertical (mobile / rodapé estreito) — botões full width
<DoubleButton
  layout="vertical"
  pair="primary-ghost"
  onPrimary={handleSave}
  onSecondary={handleClose}
/>

// Tamanho pequeno
<DoubleButton size="sm" onPrimary={handleSave} onSecondary={handleClose} />

// Estado de carregamento na ação primária
<DoubleButton
  onPrimary={handleSubmit}
  onSecondary={handleClose}
  primaryLoading={isSubmitting}
  secondaryDisabled={isSubmitting}
/>

// Tema escuro (sobre header/hero brand)
<DoubleButton theme="dark" onPrimary={handleConfirm} onSecondary={handleCancel} />
```

---

## Acessibilidade

- Cada ação é um `Button` (react-aria) real, com foco, `Enter`/`Espaço` e leitura de
  nome acessível já cobertos — o `children`/label vira o nome acessível do botão.
- Em diálogos de confirmação destrutiva (`pair="destructive-ghost"`), garanta que o
  container (modal/dialog) já anuncie o contexto da ação (ex.: `aria-describedby` com o
  texto de confirmação) — o `DoubleButton` não adiciona semântica de diálogo por si só.
- `primaryLoading`/`secondaryLoading` desabilitam o botão correspondente (herdado do
  `Button`); mantenha os rótulos padrão ou customizados descritivos o suficiente para
  leitores de tela durante o carregamento.

## Armadilhas comuns

- Assumir que a ordem dos props (`primaryLabel` antes de `secondaryLabel`) reflete a
  ordem visual — no layout horizontal (o default) é o contrário: primária fica à
  direita, secundária à esquerda.
- Tentar trocar só a cor de uma das ações via `className` — as variantes vêm do `pair`;
  se a combinação desejada não existir em `PAIR_CONFIG`, monte os dois `Button`s
  manualmente em vez de forçar estilo por cima.
- Esperar tamanhos/temas independentes entre as duas ações — `size` e `theme` são únicos
  para o par inteiro.
- Usar `disabled` em vez de `primaryDisabled`/`secondaryDisabled` — essas props não
  existem; o componente expõe apenas os nomes prefixados.
