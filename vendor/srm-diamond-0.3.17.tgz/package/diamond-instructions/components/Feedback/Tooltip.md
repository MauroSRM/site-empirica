# Tooltip

Dica textual contextual que aparece ao focar ou passar o mouse (hover) sobre um elemento
disparador. Construído sobre `TooltipTrigger`, `Tooltip` (aliasado como `AriaTooltip`),
`OverlayArrow` e `Focusable` do **react-aria-components** — o RAC cuida do delay de
"warmup" no hover, do dismiss (Esc/blur/click-fora) e do posicionamento (engine de overlay
própria do RAC; Floating UI só é usado para flutuantes 100% custom no Diamond).

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/Tooltip/`
- **Export:** `import { Tooltip } from '@srm/diamond';`
- **Relacionados:** [TooltipSheet](./TooltipSheet.md) (popover disparado por clique, com
  título, ações e variantes semânticas — para conteúdo mais rico que um texto curto)

---

## Quando usar

- Explicar o significado de um ícone, sigla ou campo sem poluir o layout com texto fixo
  (ex.: ícone de informação ao lado de uma taxa, badge de status, abreviação financeira).
- Dar contexto adicional a uma ação (ex.: por que um botão está desabilitado, o que uma
  ação vai fazer) sem exigir interação de clique.
- Exibir textos curtos e não-interativos que aparecem e somem de forma transitória ao
  hover/foco.

## Quando **não** usar

- Conteúdo mais longo, com título e/ou ações (botões "Entendi", "Saiba mais") →
  [`TooltipSheet`](./TooltipSheet.md).
- Conteúdo que precisa permanecer visível após o mouse sair ou que exige interação
  (formulários, listas clicáveis) → um popover/dialog dedicado, não `Tooltip`.
- Informação crítica para completar uma tarefa — tooltips não são lidos por padrão em
  touch/mobile sem foco explícito; não esconda ali algo indispensável.

---

## Interface

```ts
import type { ReactElement, ReactNode } from 'react';

type TooltipPlacement = 'top' | 'bottom' | 'left' | 'right';

interface TooltipProps {
  /** Elemento que dispara o tooltip, deve ser focável (Button/Link do RAC, ou DOM nativo). */
  children: ReactElement;
  content: ReactNode;
  placement?: TooltipPlacement;   // default: 'top'
  delay?: number;                 // default: 300 (TOOLTIP_DEFAULT_DELAY_MS) — warmup (ms) antes de mostrar no hover
  maxWidth?: number | string;     // default: 240px (via var CSS --tooltip-max-width)
  isDisabled?: boolean;
  className?: string;             // mesclado à classe do overlay do tooltip
  /**
   * Container onde o portal do tooltip é renderizado. @default document.body
   * Necessário quando o tooltip precisa herdar contexto CSS de um subtree
   * (ex.: `[data-theme="dark"]` de um wrapper local em stories dark) —
   * sem isso o portal fica no body e resolve tokens do `:root` (light).
   */
  portalContainer?: Element;

  /**
   * Trata `children` como conteúdo não-interativo (ex.: texto truncado).
   * default: false
   */
  nonInteractiveTrigger?: boolean;
}
```

### Notas de comportamento

- **`content` vazio ou `null`/`undefined` desliga o tooltip por completo** — nesse caso o
  componente retorna só `children`, sem envolver em `TooltipTrigger`. Isso permite usar
  `content={mensagemCondicional}` para ligar/desligar o tooltip dinamicamente sem precisar
  gerenciar `isDisabled` manualmente.
- **`nonInteractiveTrigger`** troca o wrapper `<Focusable>` do RAC por `useFocusable` com
  `excludeFromTabOrder`. Use quando o gatilho é conteúdo, não widget — texto truncado é o
  caso canônico (ver `Cards/_shared/TruncatedText`). Diferenças: o gatilho responde a hover
  mas **não entra na ordem de tabulação**, e o RAC deixa de exigir role de widget no filho
  (com `<Focusable>`, um `<span>` sem `role` dispara `console.warn` em dev). Só é apropriado
  quando o texto completo já está no DOM — leitores de tela leem o conteúdo integral mesmo
  com o corte visual, então nenhuma informação depende do tooltip.
- `isDisabled` só é repassado ao `TooltipTrigger` quando explicitamente definido (`!== undefined`)
  — permite deixar o RAC no comportamento padrão quando a prop não é usada.
- `delay` controla apenas o **warmup do hover**; o foco por teclado mostra o tooltip
  imediatamente (validado no teste: `delay={0}` não é nem necessário para foco).
  O default vem da constante interna `TOOLTIP_DEFAULT_DELAY_MS` (300ms, não exportada pelo
  barrel) — para customizar, passe `delay` explicitamente.
- `children` é tipado como `ReactElement` (não `ReactNode`) e envolvido internamente em
  `<Focusable>` do RAC — então o disparador **não precisa** ser nativamente focável (ex.:
  uma `<div>` funciona), mas precisa ser um único elemento React (não use texto solto ou
  fragmentos com múltiplos filhos como `children`).
- `maxWidth` é aplicado via `style` inline no overlay; sem essa prop, o CSS usa a variável
  `--tooltip-max-width` com fallback de `240px`.
- Posicionamento do overlay usa `offset` e `containerPadding` fixos vindos de constantes
  internas: `TOOLTIP_OFFSET` (8px, distância do trigger) e `TOOLTIP_VIEWPORT_PADDING` (8px,
  margem mínima até a borda da viewport) — não são customizáveis via prop.
- A seta (`OverlayArrow`) é um SVG com bounding box real de `TOOLTIP_ARROW_WIDTH` × `TOOLTIP_ARROW_HEIGHT`
  (8×4), rotacionado via CSS conforme `data-placement` (`top`/`bottom`/`left`/`right`).
- `portalContainer`, quando passado, é repassado ao RAC como `UNSTABLE_portalContainer` —
  use para escopar o portal a um subtree com `data-theme` próprio (ex.: preview dark isolado
  do `:root`).
- Visual: fundo `--ai-surface` / texto `--core-neutral-0` no tema claro; no tema escuro
  (`[data-theme="dark"]`) fundo `--surface-inverse` / texto `--text-on-inverse`; `12px`/peso
  500, cantos `--radius-md`, sombra `--shadow-md`; entrada anima com scale+fade (`120ms`),
  respeitando `prefers-reduced-motion` (animação desabilitada). Não há prop de tema
  (`theme`) — a cor resolve automaticamente pelo `data-theme` do ancestral mais próximo.

---

## Exemplos

```tsx
import { Tooltip, Button, IconButton } from '@srm/diamond';
import { Info } from 'lucide-react';

// Básico
<Tooltip content="Taxa de administração anual">
  <IconButton icon={<Info size={16} />} aria-label="Mais informações" variant="ghost" />
</Tooltip>

// Posicionamento
<Tooltip content="Aparece à direita" placement="right">
  <Button variant="secondary" size="sm">Direita</Button>
</Tooltip>

// Delay customizado (aparece mais rápido no hover)
<Tooltip content="Resposta rápida" delay={100}>
  <Button variant="ghost" size="sm">Hover rápido</Button>
</Tooltip>

// Largura máxima customizada para textos mais longos
<Tooltip
  content="Este é um texto de ajuda um pouco mais longo, explicando uma regra de negócio."
  maxWidth={320}
>
  <Button variant="secondary" size="sm">Regra de negócio</Button>
</Tooltip>

// Desligado condicionalmente (sem tooltip quando não há mensagem)
function CampoComAjuda({ mensagem }: { mensagem?: string }) {
  return (
    <Tooltip content={mensagem}>
      <Button variant="ghost" size="sm">Campo</Button>
    </Tooltip>
  );
}

// isDisabled explícito (mantém o trigger, mas nunca abre)
<Tooltip content="Não exibido" isDisabled>
  <Button variant="secondary" size="sm">Desabilitado</Button>
</Tooltip>

// portalContainer — escopa o portal a um wrapper com data-theme próprio (ex.: preview dark)
function TooltipDarkDemo() {
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  return (
    <div ref={setContainer} data-theme="dark">
      <Tooltip content="Aparece herdando o tema dark" {...(container ? { portalContainer: container } : {})}>
        <Button variant="secondary" theme="dark" size="sm">Tema escuro</Button>
      </Tooltip>
    </div>
  );
}
```

---

## Acessibilidade

- O disparador (`children`) precisa ser focável — o wrapper `Focusable` do RAC garante
  isso, mas o próprio conteúdo (ex.: `Button`/`IconButton`) deve ter seu próprio nome
  acessível (`aria-label` quando for só-ícone).
- O overlay é renderizado com `role="tooltip"` (padrão RAC) e é anunciado por leitores de
  tela ao focar o disparador via teclado — **não depende de hover com mouse** para ser
  acessível.
- Dismiss automático: Esc, blur ou perda de hover fecham o tooltip — nenhum gerenciamento
  manual de estado é necessário.
- Evite colocar informação **essencial** apenas no tooltip: usuários em touch/mobile podem
  não conseguir disparar hover; garanta que a informação crítica também exista de forma
  visível ou acessível por outro caminho.

## Armadilhas comuns

- Passar `content=""` (string vazia) ou `content={undefined}` desliga silenciosamente o
  tooltip — se o tooltip "não aparece", confira se `content` está de fato preenchido antes
  de suspeitar de bug de posicionamento.
- `children` deve ser um único elemento — não passe múltiplos irmãos ou texto solto
  diretamente; envolva em um elemento único (botão, span, ícone).
- Não use `Tooltip` para conteúdo com botões de ação ou título — isso é o caso de uso do
  [`TooltipSheet`](./TooltipSheet.md).
- Não há prop `theme`; se o tooltip precisar de outra paleta de cor em um contexto muito
  específico, ajuste via `className` (mesclada, não substitui as classes do módulo).
