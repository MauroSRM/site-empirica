# RiskBadge

Selo (badge) textual para classificação de risco. Renderiza um `<span>` simples com
cor semântica de fundo/texto de acordo com o `level` informado, sem ícone e sem
interatividade — é puramente apresentacional. Construído com `class-variance-authority`
(CVA) sobre CSS Modules, sem dependência de `react-aria-components`.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/RiskBadge/`
- **Export:** `import { RiskBadge } from '@srm/diamond';`
- **Relacionados:** [Tag](./Tag.md) (etiqueta genérica com mais variantes/ícone/remoção;
  `RiskBadge` é específico do domínio de risco, sem essas capacidades)

---

## Quando usar

- Classificar visualmente o nível de risco de um ativo, carteira, cliente ou operação
  (ex.: "Risco alto", "Risco médio", "Risco baixo") em tabelas, cards e listas.
- Indicar ausência de classificação/dados com `level="unknown"` (ex.: "Não classificado",
  "Aguardando análise").
- Compor com outras informações em uma linha de tabela ou cabeçalho de card, onde o selo
  é só um rótulo visual de apoio (não é clicável nem focável).

## Quando **não** usar

- Necessidade de ação (clique, remoção, seleção) → um badge não é botão; use `Button`
  com `icon="only"` ou um componente interativo apropriado.
- Status de processo/fluxo (pendente, aprovado, cancelado) sem semântica de **risco**,
  ou necessidade de mais variantes/ícone/remoção → use [`Tag`](./Tag.md), que cobre esses
  casos.
- Múltiplos badges cujo estado deriva de lógica de negócio complexa e precisa de
  tooltip/detalhe → considere envolver o `RiskBadge` com um componente de tooltip externo,
  já que ele mesmo não expõe essa capacidade.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

type RiskLevel = 'high' | 'medium' | 'low' | 'unknown';
type RiskBadgeSize = 'sm' | 'md' | 'lg';

interface RiskBadgeProps extends ComponentPropsWithoutRef<'span'> {
  level: RiskLevel;         // obrigatório — define a cor semântica
  label: string;            // obrigatório — texto exibido dentro do selo
  size?: RiskBadgeSize;     // default: 'sm'
  className?: string;
  ref?: Ref<HTMLSpanElement>;
  // Herdado de ComponentPropsWithoutRef<'span'>: id, style, aria-*, data-*, onClick, etc.
}
```

### Notas de comportamento

- `level` e `label` são **obrigatórios** — não há defaults para eles (diferente de `size`,
  que assume `'sm'` via `defaultVariants` do CVA).
- `label` é renderizado como `children` do `<span>` — é o único conteúdo visual do badge;
  não há slot de ícone.
- Cores por nível (definidas em `RiskBadge.module.scss`, via variáveis de tema):
  - `high` → fundo `--error-subtle` / texto `--error-strong`
  - `medium` → fundo `--warning-subtle` / texto `--warning-strong`
  - `low` → fundo `--success-subtle` / texto `--success-strong`
  - `unknown` → fundo `--border-default` / texto `--tag-neutral-color`
- Tamanhos (`sm`, `md`, `lg`) alteram apenas altura, padding e `font-size` — não existe
  prop de tema claro/escuro dedicada; as cores vêm de variáveis CSS que já respondem ao
  tema global da aplicação.
- `className` externo é **mesclado** às classes do CVA (não substitui) — confirmado pelo
  teste `RiskBadge.test.tsx` (`aceita className externa sem perder as classes próprias`).

---

## Exemplos

```tsx
import { RiskBadge } from '@srm/diamond';

// Básico
<RiskBadge level="high" label="Risco alto" />

// Todos os níveis
<div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
  <RiskBadge level="high" label="Risco alto" />
  <RiskBadge level="medium" label="Risco médio" />
  <RiskBadge level="low" label="Risco baixo" />
  <RiskBadge level="unknown" label="Não classificado" />
</div>

// Tamanhos
<div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
  <RiskBadge level="medium" size="sm" label="sm" />
  <RiskBadge level="medium" size="md" label="md" />
  <RiskBadge level="medium" size="lg" label="lg" />
</div>

// Em uma célula de tabela, a partir de dado vindo da API
function RiskCell({ level, label }: { level: RiskLevel; label: string }) {
  return <RiskBadge level={level} label={label} size="md" />;
}

// Ausência de classificação
<RiskBadge level="unknown" label="Aguardando análise" />
```

---

## Acessibilidade

- É um `<span>` de conteúdo textual — o `label` já é lido por leitores de tela como
  texto normal; não é necessário `aria-label` adicional na maioria dos casos.
- Não é focável nem interativo (sem `role`, `tabIndex` ou handlers de teclado) — não use
  para transmitir uma ação; use apenas como rótulo informativo.
- Se o badge for o único indicador de risco em uma linha (sem texto equivalente ao lado),
  garanta que o `label` por si só seja compreensível fora de contexto visual (evite
  labels genéricos como apenas "Alto" sem a palavra "Risco", dependendo do layout).
- As cores por `level` reforçam a semântica visualmente, mas **não substituem** o texto —
  o componente já segue esse princípio ao sempre exibir `label`, evitando depender só de cor.

## Armadilhas comuns

- Esquecer `label` ou `level` — ambos são obrigatórios; sem eles o badge não tem sentido
  semântico (TypeScript já bloqueia a omissão).
- Tentar tornar o badge clicável passando `onClick` — funciona tecnicamente (props de
  `span` são repassadas), mas não há estilos de foco/hover/estado ativo; para ação real,
  use um componente interativo.
- Usar `level="unknown"` para significar "risco desconhecido mas não zero" — a cor
  neutra pode ser confundida com "sem risco"; prefira um `label` explícito
  ("Não classificado", "Sem dados") para não induzir o usuário a erro de leitura.
- Passar `size` fora de `'sm' | 'md' | 'lg'` — não há fallback visual definido para
  valores fora do enum do CVA.
