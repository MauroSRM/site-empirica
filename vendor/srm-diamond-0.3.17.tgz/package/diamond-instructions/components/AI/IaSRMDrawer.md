# IaSRMDrawer

Painel lateral direito do assistente. Construído sobre `ModalOverlay` / `Modal` / `Dialog`
do **React Aria**, então portal, focus trap, restauração de foco, dismiss por ESC e
clique-fora, scroll lock e isolamento do conteúdo externo vêm da biblioteca — não de
código nosso.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMDrawer/`
- **Export:** `import { IaSRMDrawer } from '@srm/diamond';`
- **Relacionados:** [IaSRMOverlay](./IaSRMOverlay.md) (mesma base, modal centralizado), [PanelHeader](./PanelHeader.md) (o header), [IaSRMConversationFeed](./IaSRMConversationFeed.md) (body típico), [IaSRMTray](./IaSRMTray.md) (slot `tray`), [Drawer](../Feedback/Drawer.md) (drawer genérico do DS, sem contexto de IA)

---

## Quando usar

- Superfície lateral do assistente sobre a página, sem tirar o contexto de vista.
- Como view "reduzida", com `onExpand` transicionando para o [`IaSRMOverlay`](./IaSRMOverlay.md).
- Quando o conteúdo é uma conversa: `IaSRMConversationFeed` no body + `IaSRMTray` no tray.

## Quando **não** usar

- Drawer genérico de formulário/detalhe → [`Drawer`](../Feedback/Drawer.md) de `Feedback`.
- Diálogo curto de confirmação → [`Modal`](../Feedback/Modal.md).
- Entrada persistente na tela → [`IaSRMFab`](./IASRMFab.md) ou [`IaSRMHero`](./IASRMHero.md).

---

## Interface

```ts
import type { ReactNode } from 'react';

type IaSRMDrawerSize = 'sm' | 'md' | 'lg';

interface IaSRMDrawerProps {
  isOpen: boolean;
  onClose: () => void;                          // X, ESC ou backdrop
  onOpenChange?: (isOpen: boolean) => void;     // toda mudança de estado
  size?: IaSRMDrawerSize;                       // default: 'md'
  label: ReactNode;                             // OBRIGATÓRIO — nomeia o diálogo
  subtitle?: ReactNode;
  avatar?: ReactNode | null;                    // null remove o slot
  tone?: 'default' | 'brand';                   // tom do header; default 'default'
  headerActions?: ReactNode;                    // ações extras, antes dos botões padrão
  showCloseButton?: boolean;                    // default: true
  onMinimize?: () => void;                      // sem handler, botão não renderiza
  onExpand?: () => void;                        // sem handler, botão não renderiza
  closeAriaLabel?: string;                      // default: 'Fechar'
  minimizeAriaLabel?: string;                   // default: 'Diminuir'
  expandAriaLabel?: string;                     // default: 'Expandir'
  isDismissable?: boolean;                      // clique fora fecha; default true
  isKeyboardDismissDisabled?: boolean;          // desliga ESC; default false
  children?: ReactNode;                         // body
  tray?: ReactNode;                             // rodapé fixo
  className?: string;                           // painel
  overlayClassName?: string;                    // scrim/backdrop
}
```

### Notas de comportamento

- **`label` é obrigatório.** O nome acessível do diálogo vem do `Heading slot="title"` dentro do [`PanelHeader`](./PanelHeader.md). Um diálogo sem nome não é anunciável.
- `onClose` cobre as três vias de fechamento. Use `onOpenChange` quando o pai também precisa reagir à **abertura** (telemetria, foco, lock de rota); para só fechar, `onClose` basta. Ambos disparam no fechamento.
- **Toda ação do header é opt-in por handler**: sem `onExpand`/`onMinimize`, o botão não existe no DOM. O X sai com `showCloseButton={false}` — ESC e backdrop continuam chamando `onClose`.
- `isDismissable={false}` bloqueia o clique-fora; `isKeyboardDismissDisabled` bloqueia ESC. Use para fluxos que não podem ser abandonados no meio.
- Sizes via tokens `--iasrm-drawer-*`: `sm` 30vw, `md` 40vw, `lg` 55vw, com piso em px e full-width abaixo de 480px. Resolvidos com **CVA** (`iaSRMDrawerPanelVariants`, exportado).
- Animação dirigida pelos data attributes `[data-entering]`/`[data-exiting]` do React Aria em CSS — sem estado de animação em JS. Respeita `prefers-reduced-motion`.
- `className` mira o **painel**; `overlayClassName` mira o **scrim**.

---

## Exemplos

```tsx
import { IaSRMDrawer, IaSRMConversationFeed, IaSRMTray } from '@srm/diamond';

// Mínimo
<IaSRMDrawer isOpen={open} onClose={close} label="Assistente">
  <MeuConteudo />
</IaSRMDrawer>

// Conversa completa
<IaSRMDrawer
  isOpen={open}
  onClose={close}
  label="Assistente"
  subtitle="Online agora"
  size="md"
  onExpand={() => transitionToOverlay()}
  tray={<IaSRMTray onSend={sendMessage}>{contextualUI}</IaSRMTray>}
>
  <IaSRMConversationFeed messages={messages} thinking={isPending} userInitials="LO" />
</IaSRMDrawer>

// Reagindo também à abertura
<IaSRMDrawer
  isOpen={open}
  onClose={close}
  onOpenChange={(next) => track(next ? 'drawer_open' : 'drawer_close')}
  label="Assistente"
>
  …
</IaSRMDrawer>

// Fluxo que não pode ser abandonado
<IaSRMDrawer
  isOpen={open}
  onClose={close}
  label="Autorização"
  isDismissable={false}
  isKeyboardDismissDisabled
  showCloseButton={false}
>
  <FluxoDeAutorizacao />
</IaSRMDrawer>

// Header com ação de domínio + tom brand
<IaSRMDrawer
  isOpen={open}
  onClose={close}
  label="Assistente"
  tone="brand"
  headerActions={<IconButton variant="ghost" size="sm" aria-label="Nova conversa" icon={<Icon icon="plus" circle={false} size={14} />} onPress={newChat} />}
>
  …
</IaSRMDrawer>

// Estilo estendido
<IaSRMDrawer isOpen={open} onClose={close} label="Assistente" className={styles.painel} overlayClassName={styles.scrim}>
  …
</IaSRMDrawer>
```

---

## Acessibilidade

Entregue pelo React Aria, sem configuração:

- `role="dialog"` no painel, com nome acessível vindo do heading do header.
- **Focus trap** enquanto aberto e **restauração de foco** no elemento anterior ao fechar.
- Conteúdo de fora recebe `aria-hidden` enquanto o diálogo está aberto. (React Aria **não** usa `aria-modal`, por bugs conhecidos de leitores de tela — o isolamento é feito por `aria-hidden`.)
- Scroll do body travado, evitando scroll fantasma atrás do painel.
- ESC fecha por padrão; desligue só com motivo (`isKeyboardDismissDisabled`).

## Armadilhas comuns

- Não omita `label` — é obrigatório justamente porque o diálogo precisa de nome.
- Não renderize um `PanelHeader` dentro de `children`: o Drawer já tem um, e dois `slot="title"` quebram o nome acessível.
- Não use `className` esperando estilizar o backdrop — é `overlayClassName`.
- Não desabilite ESC e clique-fora **e** o botão X ao mesmo tempo sem oferecer outra saída no conteúdo: o usuário fica preso.
- O body (`children`) precisa lidar com a própria altura; `IaSRMConversationFeed` já espera o contrato flex que o painel fornece.
