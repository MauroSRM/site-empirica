# Card

Card é um contêiner de destaque visual para agrupar ícone, título, descrição e uma ação
opcional — usado para comunicar features, categorias, diferenciais ou pontos de entrada de
navegação (dashboards, hubs de conteúdo, seleção de opções). Composto internamente pelos
átomos `Icon` (Icons/Icon), `Tag` (DataDisplay/Tag), `Button` e `DoubleButton` (Forms). Quando
clicável, usa `useButton` do **react-aria** para expor semântica de botão (`role="button"`,
foco, ativação por Enter/Espaço) sobre uma `<div>` — sem depender de nenhum componente de
botão do react-aria-components para o próprio card.

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/Card/`
- **Export:** `import { Card } from '@srm/diamond';`
- **Relacionados:** [Icon](../Icons/Icon.md), [Tag](../DataDisplay/Tag.md), [Button](../Forms/Button.md), [DoubleButton](../Forms/DoubleButton.md)

---

## Quando usar

- Pontos de entrada de navegação em grid (hub/dashboard): "Para Designers", "Para Devs",
  "Governança", "Compliance", "Riscos" etc. — um conjunto de 3–4 colunas de cards `outlined`.
- Destacar **uma única** opção mais relevante de um conjunto, usando `variant="elevated"`
  nesse card específico (nunca em mais de um do mesmo conjunto).
- Card individual ou em composições mais livres de layout → `direction="horizontal"`, com
  ícone decorativo e o conteúdo textual como protagonista.
- Card já aninhado dentro de outro container com contorno próprio → `variant="ghost"`.
- Ações de confirmação diretamente no card (ex.: "Confirmar" / "Cancelar") via `action.secondary`.

## Quando **não** usar

- Container genérico de conteúdo sem a anatomia ícone/título/descrição/ação → use um `div`
  simples ou o componente de layout apropriado; não force a semântica de Card.
- Mais de 2 ações no rodapé → use Modal ou Drawer.
- Cards aninhados dentro de Cards → não suportado pelo padrão visual (evite).
- `ghost` sobre fundo branco sem outro elemento de separação visual (perde contraste).
- Formulário ou campo de dados → não é um input; veja os componentes de Forms/Inputs.

---

## Interface

```ts
import type { HTMLAttributes } from 'react';
import type { IconType } from '@srm/diamond'; // Icons/Icon
import type { TagVariant } from '@srm/diamond'; // DataDisplay/Tag

type CardVariant = 'outlined' | 'elevated' | 'ghost';
type CardDirection = 'vertical' | 'horizontal';

interface CardAction {
  label: string;
  onClick?: () => void;
  variant?: 'primary' | 'link';                 // default efetivo: 'link'
  secondary?: { label: string; onClick?: () => void };
}

interface CardTag {
  label: string;
  variant?: TagVariant;                          // default: 'neutral-brand1'
}

interface CardProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onClick'> {
  icon?: string;                 // nome do glifo (ICON_GLYPH_NAMES) — só tem efeito com iconType 'default'/'accent'
  iconType?: IconType;           // default: 'default' — 'accent' | 'success' | 'warning' | 'error' | 'info'
  title?: string;
  description?: string;
  tag?: CardTag | string;        // string vira { label: string, variant: 'brandPrimary' }
  variant?: CardVariant;         // default: 'outlined'
  direction?: CardDirection;     // default: 'vertical'
  action?: CardAction;
  isHoverable?: boolean;         // default: false — aplica estilo hover sem exigir onClick
  onClick?: () => void;          // presença ativa o card inteiro como botão acessível
  children?: React.ReactNode;
  className?: string;
  // Demais atributos HTML nativos (data-*, style, id, ...) passam direto para o <div> raiz.
}
```

### Notas de comportamento

- **Interatividade é derivada, não configurada por variante própria**: `isInteractive = !!(onClick || isHoverable)`.
  - Com `onClick`: o `<div>` raiz recebe `role="button"`, `tabIndex`, e os handlers de teclado
    (Enter/Espaço) via `useButton` do react-aria — sem `onClick` **não** há `role="button"`
    (confirmado em teste: card estático não expõe `getByRole('button')`).
  - Com `isHoverable` (sem `onClick`): aplica só o estilo visual de hover/cursor pointer, **sem**
    tornar o card focável/ativável por teclado. Use quando o card é clicável por outro meio
    (ex.: um link/anchor que o envolve) e você só precisa do feedback visual.
- **Ícone é renderizado mesmo sem `icon`**: a condição é `icon || iconType !== 'default'` — ou
  seja, um `iconType` de feedback (`success`, `warning`, `error`, `info`) já é suficiente para
  desenhar o círculo com o glifo semântico padrão, mesmo sem passar `icon`. A prop `icon`
  (nome do glifo Lucide) só tem efeito quando `iconType` é `'default'` ou `'accent'`; nos tipos
  de feedback ela é ignorada de propósito (glifo fixo por semântica, ver `Icon`).
- O ícone é sempre `aria-hidden="true"` e renderizado em tamanho fixo `20`.
- `tag` aceita **string simples** (`tag="Novo"`) ou objeto `{ label, variant }`. Sem `variant`
  explícito (string simples ou objeto sem `variant`), o default é `'brandPrimary'`. Visualmente
  é posicionado absoluto no canto superior direito do card (não ocupa espaço no fluxo do corpo).
- **`action` sem `action.secondary`**: renderiza um único `Button` (`size="sm"`,
  `variant={action.variant ?? 'link'}` — só aceita `'primary'` ou `'link'`).
- **`action` com `action.secondary`**: renderiza um `DoubleButton` (`layout="horizontal"`,
  `pair="primary-ghost"`, `size="sm"`) em vez do `Button` único — `action.label`/`action.onClick`
  viram o botão primário, `action.secondary.label`/`.onClick` o botão ghost. `action.variant`
  é **ignorado** nesse caminho (o par é sempre `primary-ghost`).
- O bloco de ação usa `margin-top: auto` — em um card de altura fixa/esticada (ex.: grid com
  `align-items: stretch`), a ação é empurrada para o rodapé; em um card de altura natural, gera
  apenas o espaçamento visual padrão.
- `children` é renderizado **entre** a descrição e o bloco de ação — útil para conteúdo custom
  (listas, métricas) sem perder a ação no rodapé.
- Demais atributos HTML (`style`, `data-*`, `id`, etc.) são repassados via `...rest` diretamente
  ao `<div>` raiz — inclusive `style={{ height: '100%' }}` para acompanhar a altura de uma row
  de grid flex com `align-items: stretch`.

---

## Exemplos

```tsx
import { Card } from '@srm/diamond';

// Básico — outlined, vertical (padrão)
<Card
  icon="layers"
  title="Para Designers"
  description="Tokens, componentes e variações prontas para uso."
/>

// Card elevado — destaque de UMA opção em um conjunto
<Card
  variant="elevated"
  icon="code-2"
  iconType="accent"
  title="Para Devs"
  description="React, Angular e HTML/CSS. Props tipadas."
/>

// Ghost — já aninhado em outro container
<Card variant="ghost" icon="compass" title="Para Produto" description="Padrões de fluxo e formulários." />

// Direction horizontal — ícone decorativo, texto protagonista
<Card
  direction="horizontal"
  icon="shield-check"
  iconType="success"
  title="Governança"
  description="Papéis, aprovações e trilhas de auditoria."
/>

// Feedback semântico sem ícone custom — glifo padrão de 'warning'
<Card iconType="warning" title="Riscos" description="Monitoramento e alertas em tempo real." />

// Com tag (string simples)
<Card icon="file-text" title="Relatórios" description="Performance e extratos." tag="Novo" />

// Com tag (objeto com variante)
<Card
  icon="lock"
  title="Segurança"
  description="Políticas de acesso e autenticação forte."
  tag={{ label: 'Beta', variant: 'info' }}
/>

// Ação única (link)
<Card
  icon="layers"
  title="Para Designers"
  description="Tokens, componentes e variações prontas para uso."
  action={{ label: 'Ver biblioteca' }}
/>

// Ação única (primary)
<Card
  icon="layers"
  title="Para Designers"
  description="Tokens, componentes e variações prontas para uso."
  action={{ label: 'Ver biblioteca', variant: 'primary', onClick: handleOpen }}
/>

// Duas ações (primary + ghost) — confirmação explícita
<Card
  title="Encerrar sessão de aporte?"
  description="As alterações não salvas serão perdidas."
  action={{
    label: 'Confirmar',
    onClick: handleConfirm,
    secondary: { label: 'Cancelar', onClick: handleCancel },
  }}
/>

// Card inteiro clicável (navegação de hub)
<Card
  icon="user-plus"
  title="Onboarding"
  description="Cadastro e verificação de novos clientes."
  onClick={() => navigate('/onboarding')}
/>

// Apenas feedback visual de hover, sem tornar o card focável (ex.: dentro de <a>)
<a href="/relatorios">
  <Card icon="file-text" title="Relatórios" description="Performance e extratos." isHoverable />
</a>

// Conteúdo custom entre description e action
<Card title="Alçadas" description="Limites de aprovação por perfil.">
  <ul>
    <li>Até R$ 50.000 — Analista</li>
    <li>Até R$ 500.000 — Gerente</li>
  </ul>
</Card>

// Grid — conjunto padrão (outlined, 3 colunas, 1 card elevated de destaque)
<div style={{ display: 'flex', gap: 24 }}>
  <Card variant="elevated" icon="layers" title="Para Designers" description="..." style={{ width: 320 }} />
  <Card icon="code-2" iconType="accent" title="Para Devs" description="..." style={{ width: 320 }} />
  <Card icon="compass" title="Para Produto" description="..." style={{ width: 320 }} />
</div>
```

---

## Acessibilidade

- **Só há `role="button"`, foco por teclado e ativação por Enter/Espaço quando `onClick` é
  fornecido.** Sem `onClick`, o card é puramente apresentacional (mesmo com `isHoverable`).
- Card interativo sem `title` visível textual fica sem nome acessível — garanta `title` ou
  passe `aria-label`/`aria-labelledby` via `...rest`.
- O ícone (`Icon`) é sempre `aria-hidden="true"` — é puramente decorativo; nunca carrega
  informação exclusiva não repetida em `title`/`description`.
- `isHoverable` **não substitui** semântica de link/botão real: se o card representa navegação,
  use `onClick` (ou envolva em `<a>` real) — não deixe uma área "clicável" apenas visualmente.
- Ações no rodapé (`Button`/`DoubleButton`) já carregam sua própria acessibilidade de foco —
  não são afetadas pelo `role="button"` do card pai, mas evite aninhar interativo dentro de
  interativo sem necessidade real (card clicável **e** botão de ação dentro dele é um padrão
  válido, mas exige teste de navegação por teclado no seu fluxo específico).

## Armadilhas comuns

- Usar `variant="elevated"` em mais de um card do mesmo conjunto — quebra a hierarquia visual
  (elevated é para **1** destaque, não um estilo alternativo geral).
- Esperar que `icon="algum-glifo"` apareça com `iconType` de feedback (`success`/`warning`/
  `error`/`info`) — nesses tipos o glifo é sempre o semântico fixo; a prop `icon` é ignorada.
- Passar `action.variant` junto com `action.secondary` esperando que afete o layout —
  com `secondary` presente, o par é sempre `primary-ghost` via `DoubleButton`; `variant` é
  ignorado nesse caminho.
- Usar `isHoverable` esperando comportamento de botão (foco, Enter/Espaço) — isso só é
  ativado por `onClick`.
- Empilhar Cards dentro de Cards — não é um padrão suportado visualmente pelo design system.
- Esquecer `style={{ height: '100%' }}` (ou equivalente) em grids com `align-items: stretch`
  quando espera que a ação de todos os cards da row fique alinhada no mesmo rodapé.
