# AvatarStatic (AvatarWithLabel · AvatarCompanyCNPJStatic · AvatarColaboradorStatic)

Família de composições **não interativas** de avatar + texto: mesma estrutura visual do
`AvatarDropdown` (círculo à esquerda, duas linhas de texto à direita), mas sem trigger,
sem menu e sem estados de foco/pressed — puro `<div>`/`<p>`. Use quando precisar exibir
identidade + contexto (cargo, CNPJ, empresa) sem oferecer uma ação de menu. Os três
componentes vivem cada um no seu próprio arquivo (`AvatarWithLabel.tsx`,
`AvatarCompanyCNPJStatic.tsx`, `AvatarColaboradorStatic.tsx`) e compartilham apenas o
arquivo de tipos (`AvatarStatic.types.ts`) e o padrão de props (`isDark` para tema escuro).

- **Categoria:** Identity
- **Fonte:** `src/components/Identity/Avatar/AvatarStatic/` (`AvatarWithLabel.tsx`, `AvatarCompanyCNPJStatic.tsx`, `AvatarColaboradorStatic.tsx`)
- **Export:** `import { AvatarWithLabel, AvatarCompanyCNPJStatic, AvatarColaboradorStatic } from '@srm/diamond';`
- **Relacionados:** [Avatar](./Avatar.md) (círculo usado internamente), [AvatarSRM](./AvatarSRM.md) (`ColabCircle` usado por `AvatarColaboradorStatic`), [AvatarDropdown](./AvatarDropdown.md) (mesma composição visual, **com** menu)

---

## Quando usar

- Listagem de usuários/contatos onde cada linha mostra avatar + nome + cargo, sem ação
  de menu por item (`AvatarWithLabel`).
- Cabeçalho ou card de empresa exibindo razão social + CNPJ ao lado do avatar/sigla
  (`AvatarCompanyCNPJStatic`).
- Identificação de um colaborador SRM (e-mail + empresa) em contextos read-only, como
  rodapé de card, comentário de sistema ou item de auditoria (`AvatarColaboradorStatic`).

## Quando **não** usar

- Precisa que o bloco abra um menu de ações → use os equivalentes em
  [`AvatarDropdown`](./AvatarDropdown.md) (`AvatarDropdown`/`AvatarColaborador`).
- Precisa só do círculo, sem texto → [`Avatar`](./Avatar.md) ou [`AvatarSRM`](./AvatarSRM.md).

---

## Interface

```ts
import type { ReactNode } from 'react';

type ColaboradorAppearance = 'circular' | 'sutil';

interface AvatarWithLabelProps {
  initials: string;      // obrigatório
  bg?: string;           // default efetivo: 'var(--brand-primary)' quando !isDark
  line1: ReactNode;      // linha de destaque (ex.: nome)
  line2: ReactNode;      // linha secundária (ex.: cargo)
  isDark?: boolean;      // default: false
}

interface AvatarCompanyCNPJStaticProps {
  initials: string;      // obrigatório — sem default (antes era 'SRM'; removido na consolidação)
  bg?: string;           // default efetivo: 'var(--brand-primary)' quando !isDark
  company: string;       // obrigatório
  cnpj: string;          // obrigatório
  isDark?: boolean;      // default: false
}

interface AvatarColaboradorStaticProps {
  email: string;                        // obrigatório
  company: string;                      // obrigatório — sem default (antes era 'SRM'; removido na consolidação)
  logoAppearance?: ColaboradorAppearance; // default: 'circular'
  isDark?: boolean;                     // default: false
}
```

### Notas de comportamento

- Todos os três renderizam com `size="md"` fixo no `Avatar`/`ColabCircle` interno — **não
  há prop de tamanho**; se precisar de outro tamanho, componha manualmente com
  [`Avatar`](./Avatar.md)/[`ColabCircle`](./AvatarSRM.md) e seu próprio layout de texto.
- `bg` só é repassado ao `Avatar` interno quando `isDark` é `false` — em tema escuro, o
  `Avatar` usa seu próprio estilo de contraste (`isDark`) e `bg` é ignorado.
- `AvatarColaboradorStatic` usa `ColabCircle` (logo SRM), **não** `Avatar` — não tem
  `initials`/`bg`, e sim `logoAppearance`.
- **`initials` (em `AvatarCompanyCNPJStatic`) e `company` (em `AvatarColaboradorStatic`)
  são obrigatórios** — a consolidação removeu o default `'SRM'` que existia antes. Passar
  a prop sem valor agora é erro de tipo, não um valor implícito.
- `line1`/`line2` de `AvatarWithLabel` aceitam `ReactNode` (não só `string`) — dá para
  passar um badge, um link ou texto formatado, não apenas texto puro.
- Nenhum dos três tem `className` ou `style` na interface pública — o layout (`labelGroup`,
  `companyGroup`, `colabGroup`) é fixo via CSS module; para variações de espaçamento,
  envolva o componente em um wrapper próprio.

---

## Exemplos

```tsx
import { AvatarWithLabel, AvatarCompanyCNPJStatic, AvatarColaboradorStatic } from '@srm/diamond';

// Avatar + nome + cargo
<AvatarWithLabel initials="CM" line1="Carlos Mendes" line2="CEO · Master" />

// Empresa + CNPJ, cor customizada
<AvatarCompanyCNPJStatic
  initials="SRM"
  bg="var(--avatar-navy)"
  company="SRM Asset Management"
  cnpj="12.345.678/0001-99"
/>

// Colaborador SRM (logo em vez de iniciais), aparência sutil
<AvatarColaboradorStatic
  email="carlos.mendes@srmasset.com"
  company="SRM Asset Management"
  logoAppearance="sutil"
/>

// Tema escuro (sobre header brand)
<div style={{ background: '#32353E', padding: 16 }}>
  <AvatarWithLabel initials="CM" line1="Carlos Mendes" line2="CEO · Master" isDark />
</div>
```

---

## Acessibilidade

- Sendo blocos estáticos (sem `role`/interatividade própria), o nome acessível vem do
  texto visível (`line1`/`line2`, `company`/`cnpj`, `email`/`company`) — não é necessário
  `aria-label` adicional na maioria dos casos.
- Em `AvatarWithLabel` e `AvatarCompanyCNPJStatic`, o `Avatar` interno recebe `initials`
  (sempre presente, é obrigatório) mas **não** recebe `name` — pela cadeia de fallback do
  próprio `Avatar` (`name ?? aria-label ?? initials`, ver [Avatar](./Avatar.md#notas-de-comportamento)),
  ele ainda ganha `role="img"` com `aria-label` igual às iniciais (ex.: `"CM"`), de forma
  redundante ao texto de `line1`/`company` ao lado. Isso é esperado e inofensivo (o
  círculo fica "duplamente" nomeado, mas não incorretamente).
- `AvatarColaboradorStatic` usa `ColabCircle`, que **não** tem lógica de nome acessível
  própria (não aceita `aria-label`/`name`) — o círculo fica puramente decorativo e o texto
  (`email`/`company`) ao lado é a única identificação para leitores de tela.

## Armadilhas comuns

- Esperar uma prop de tamanho — todos os três são fixos em `size="md"`; para outro
  tamanho, monte a composição manualmente.
- Tentar passar `bg` esperando efeito em tema escuro — é silenciosamente ignorado quando
  `isDark` é `true`.
- Usar estes componentes onde uma ação de menu é necessária — eles não têm nenhum
  comportamento de clique/foco; para isso, use [`AvatarDropdown`](./AvatarDropdown.md).
