# Radio

Botão de opção (círculo) para seleção única. É construído sobre `RadioField` +
`RadioButton` do `react-aria-components` e tem **modo duplo automático**: dentro de um
[`RadioGroup`](./RadioGroup.md) ele se comporta como um item comum do grupo (seleção
exclusiva controlada pelo grupo); fora de um grupo, ele **se auto-encapsula** em um
`RadioGroup` interno e funciona como um toggle booleano avulso (`isSelected`/`onChange(boolean)`).
A detecção de contexto é feita via `RadioGroupStateContext` do react-aria.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Radio/` (arquivo `Radio.tsx`)
- **Export:** `import { Radio } from '@srm/diamond';`
- **Relacionados:** [RadioGroup](./RadioGroup.md) (contêiner para seleção exclusiva entre
  vários `Radio`) · `OptionCard` (variante "cartão" do mesmo padrão radio) · `Checkbox` e
  `Switch` (sem doc publicado ainda neste índice) para seleção múltipla ou toggle on/off
  sem semântica de "opção única entre várias".

---

## Quando usar

- Dentro de um `RadioGroup`, como cada opção de um conjunto de escolha única: plano de
  conta, perfil de risco (conservador/moderado/agressivo), forma de resgate, frequência
  de aporte.
- **Avulso** (fora de um `RadioGroup`), quando você precisa de um controle visual de radio
  isolado com semântica booleana simples — ex.: um único aceite representado como radio
  em vez de checkbox, ou uma opção "sim" isolada em um formulário curto.

## Quando **não** usar

- Múltiplas opções não-exclusivas (marcar vários ao mesmo tempo) → use `Checkbox`.
- Toggle binário de configuração (ligado/desligado) sem contexto de "escolher entre
  opções" → use `Switch`.
- Área clicável grande, com título/descrição destacados em formato de cartão → use
  `OptionCard` (mesmo padrão de seleção única, aparência de cartão).
- Duas ou mais opções de radio relacionadas → **sempre** as agrupe em
  [`RadioGroup`](./RadioGroup.md); usar vários `Radio` avulsos lado a lado perde a
  exclusividade mútua e a navegação por setas do teclado.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type {
  RadioFieldProps as AriaRadioFieldProps,
  RadioButtonProps as AriaRadioButtonProps,
} from 'react-aria-components';

type RadioSize = 'sm' | 'md';        // default: 'md'
type RadioTheme = 'default' | 'dark'; // default: 'default'

interface RadioProps extends Omit<AriaRadioFieldProps, 'className' | 'children' | 'value' | 'style'> {
  value?: string;                 // default: 'on' (constante interna STANDALONE_RADIO_VALUE)
  size?: RadioSize;               // default: 'md'
  theme?: RadioTheme;             // default: 'default'
  hint?: ReactNode;               // linha de dica abaixo do rótulo
  children?: ReactNode;           // rótulo do radio
  className?: string;
  isSelected?: boolean;           // só tem efeito em modo avulso (fora de RadioGroup)
  defaultSelected?: boolean;      // default: false — só em modo avulso
  onChange?: (isSelected: boolean) => void; // só em modo avulso
  onHoverStart?: AriaRadioButtonProps['onHoverStart'];
  onHoverChange?: AriaRadioButtonProps['onHoverChange'];
  onHoverEnd?: AriaRadioButtonProps['onHoverEnd'];
  // Herdado de AriaRadioFieldProps (react-aria-components): isDisabled, aria-label,
  // aria-labelledby, id, e demais atributos DOM/ARIA de um RadioField.
}
```

### Modo duplo — comportamento não-óbvio

`Radio` detecta em tempo de render se existe um `RadioGroupStateContext` ativo
(ou seja, se há um `<RadioGroup>` ancestral):

- **Dentro de um `RadioGroup`**: `isSelected`, `defaultSelected` e `onChange` **são
  descartados silenciosamente** (o componente os remove das props antes de repassar).
  A seleção é 100% controlada pelo `value`/`onChange`/`defaultValue` do `RadioGroup` pai —
  o `value` do `Radio` é o que identifica a opção dentro do grupo.
- **Fora de um `RadioGroup`** ("avulso"/*standalone*): o próprio `Radio` monta um
  `AriaRadioGroup` interno de um único item. Nesse modo:
  - `isSelected` (controlado) ou `defaultSelected` (não controlado, default `false`)
    definem se o radio nasce marcado.
  - `onChange` recebe um **`boolean`** (`true`/`false`), não o `value` — diferente do
    `onChange` do `RadioGroup`, que recebe o `value` (`string`) selecionado.
  - `value` (default `'on'`) só importa se você precisar do valor submetido em um
    `<form>` nativo; para a maioria dos usos avulsos pode ser ignorado.
  - Se não houver `aria-label` nem `children` string, o radio avulso fica sem nome
    acessível — sempre informe um rótulo ou `aria-label`.
- `hint` renderiza uma linha secundária abaixo do rótulo (`children`), útil para uma
  descrição curta da opção (ex.: "Recomendado para o seu perfil").
- `size` (`'sm' | 'md'`) e `theme` (`'default' | 'dark'`) funcionam **nos dois modos**.

---

## Exemplos

```tsx
import { useState } from 'react';
import { Radio, RadioGroup } from '@srm/diamond';

// Avulso (standalone) — controlado, semântica booleana
function AceiteRadio() {
  const [aceito, setAceito] = useState(false);
  return (
    <Radio isSelected={aceito} onChange={setAceito}>
      Concordo em receber comunicados
    </Radio>
  );
}

// Avulso — não controlado
<Radio defaultSelected>Notificações por e-mail</Radio>

// Dentro de um RadioGroup — seleção controlada pelo grupo
function PerfilRisco() {
  const [perfil, setPerfil] = useState('moderado');
  return (
    <RadioGroup label="Perfil de risco" value={perfil} onChange={setPerfil}>
      <Radio value="conservador">Conservador</Radio>
      <Radio value="moderado" hint="Recomendado para o seu perfil">Moderado</Radio>
      <Radio value="agressivo">Agressivo</Radio>
    </RadioGroup>
  );
}

// Tamanho pequeno
<Radio size="sm" defaultSelected>Opção compacta</Radio>

// Tema escuro (sobre header/painel brand)
<Radio theme="dark" defaultSelected>Opção em fundo escuro</Radio>

// Desabilitado (herdado de AriaRadioFieldProps)
<Radio isDisabled>Indisponível no seu plano</Radio>
```

### Integração com React Hook Form (dentro de um RadioGroup)

```tsx
<Controller
  name="perfil"
  control={control}
  render={({ field }) => (
    <RadioGroup label="Perfil de risco" value={field.value} onChange={field.onChange}>
      <Radio value="conservador">Conservador</Radio>
      <Radio value="moderado">Moderado</Radio>
      <Radio value="agressivo">Agressivo</Radio>
    </RadioGroup>
  )}
/>
```

---

## Acessibilidade

- O círculo visual (`<span>` interno) é `aria-hidden` — o nome acessível vem do texto de
  `children` (rótulo) ou de `aria-label`.
- Em modo avulso, se você não passar `children` como string nem `aria-label`, o radio
  fica **sem nome acessível** para leitores de tela — sempre rotule.
- Dentro de um `RadioGroup`, o rótulo do grupo (`label` do `RadioGroup`) fornece o
  contexto do conjunto; cada `Radio` filho só precisa do próprio rótulo curto.
- Navegação por teclado (setas para mover entre opções, Espaço/click para selecionar) é
  herdada de `react-aria-components` — não é necessário implementar nada manualmente.
- `isDisabled` marca `aria-disabled`/`disabled` de forma consistente e aplica opacidade
  reduzida via `data-disabled`.

## Armadilhas comuns

- Colocar `isSelected`/`defaultSelected`/`onChange` em um `Radio` que está **dentro** de
  um `RadioGroup` — essas props são **ignoradas silenciosamente** nesse modo; a seleção
  deve ser feita via `value`/`onChange` do `RadioGroup` pai. Não há warning em runtime.
- Usar vários `Radio` avulsos (fora de `RadioGroup`) esperando exclusividade mútua entre
  eles — cada um vira seu próprio grupo de um item; nada impede dois ficarem marcados ao
  mesmo tempo. Para exclusividade, use [`RadioGroup`](./RadioGroup.md).
- Confundir a assinatura do `onChange`: no `Radio` avulso é `(isSelected: boolean) => void`;
  no `RadioGroup` é `(value: string) => void`. Trocar uma pela outra quebra a tipagem.
- Omitir `value` em um `Radio` dentro de um `RadioGroup` — sem `value` explícito, todos os
  itens do grupo compartilhariam o mesmo valor padrão (`'on'`), quebrando a seleção.
