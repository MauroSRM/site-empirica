# IaSRMFab

Botão flutuante (FAB) de entrada do iaSRM: círculo brand com a marca e um pill de label
opcional à esquerda. Ponto de entrada visual único do assistente, tipicamente ancorado
no `bottom-right` da tela.

- **Categoria:** AI
- **Fonte:** `src/components/AI/IaSRMFab/`
- **Export:** `import { IaSRMFab } from '@srm/diamond';`
- **Relacionados:** [IaSRMAvatar](./IASRMAvatar.md) (miolo default do círculo: `circleBrand`/`lg`), [IaSRMHero](./IASRMHero.md) (entrada alternativa, em card hero), [IconButton](../Forms/IconButton.md) (botão só-ícone genérico)

---

## Quando usar

- Como único ponto de entrada flutuante do assistente, ancorado ao `bottom-right` da tela.
- Quando quiser reforçar afordância com texto ao lado do círculo → passe `label`.
- Quando o contexto já deixa claro o que é o botão → omita `label` (ou passe `null`/`''`) para mostrar só o círculo.

## Quando **não** usar

- Múltiplos FABs na mesma tela — é intencionalmente um ponto de entrada único.
- Ação genérica de FAB sem relação com o assistente → use [`IconButton`](../Forms/IconButton.md) ou `Button` com `icon="only"`.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { ButtonProps as AriaButtonProps, PressEvent } from 'react-aria-components';

interface IaSRMFabProps extends Omit<AriaButtonProps, 'className' | 'children' | 'onPress'> {
  onPress?: (event: PressEvent) => void;      // acionamento do círculo
  label?: ReactNode | null;                   // sem valor / null / '' esconde o pill
  onLabelPress?: (event: PressEvent) => void; // pill; sem ele, cai no onPress
  icon?: ReactNode;                           // miolo do círculo; default IaSRMAvatar circleBrand/lg
  'aria-label': string;                       // OBRIGATÓRIO — o círculo é só-ícone
  className?: string;                         // ← RAIZ (posicionamento do FAB)
  buttonClassName?: string;                   // círculo
  labelClassName?: string;                    // pill
  ref?: Ref<HTMLButtonElement>;
  // Herdado de AriaButtonProps: isDisabled, isPending, type, form, onClick (alias legado), aria-*, …
}
```

### Notas de comportamento

- Renderiza **dois** `Button` (react-aria-components) **irmãos** dentro de um wrapper não-interativo: o pill (condicional) e o círculo (sempre presente). Nunca aninhados — Regra 18.
- `className` mira a **raiz**, porque é ali que vive o posicionamento (`position: fixed`, offsets). Para estilizar as partes use `buttonClassName` / `labelClassName`.
- `onLabelPress` tem fallback para `onPress` — passando só `onPress`, pill e círculo disparam o mesmo handler.
- A prop pública é `onPress` (React Aria) e recebe o `PressEvent` — mouse, toque, Enter e Espaço, com o gesto em `event.pointerType`. `onClick` continua funcionando como alias legado herdado de `AriaButtonProps`, mas `onPress` é o recomendado.
- O miolo do círculo é o slot `icon`; sem ele usa `IaSRMAvatar variant="circleBrand" size="lg"`, que é **decorativo** — o nome acessível vem do `aria-label` do botão.
- Hover do círculo: escala 1.06 + `--iasrm-avatar-bg` troca pra `--brand-primary-hover` via cascade CSS (o átomo não precisa saber de hover — Regra 17). Pressed: 0.98. Focus visible: ring + glow. Respeita `prefers-reduced-motion`.

---

## Exemplos

```tsx
import { IaSRMFab } from '@srm/diamond';

// Pill + círculo, mesmo handler
<IaSRMFab aria-label="Abrir Concierge SRM" label="Concierge SRM" onPress={() => open()} />

// Só o círculo
<IaSRMFab aria-label="Abrir Concierge SRM" onPress={() => open()} />

// Pill e círculo com destinos distintos (drawer vs overlay)
<IaSRMFab
  aria-label="Abrir assistente"
  label="Fale com a SRM"
  onPress={() => openOverlay()}
  onLabelPress={() => openDrawer()}
/>

// Posicionamento fixo — className vai na raiz
<IaSRMFab aria-label="Abrir assistente" className="fab-ancorado" onPress={open} />

// Miolo customizado
<IaSRMFab
  aria-label="Abrir suporte"
  icon={<Icon icon="headphones" circle={false} size={24} />}
  onPress={open}
/>

// Usando o PressEvent
<IaSRMFab
  aria-label="Abrir assistente"
  onPress={(event) => track('fab_press', { via: event.pointerType })}
/>
```

---

## Acessibilidade

- `aria-label` é **obrigatório** no tipo: o círculo é só-ícone e sem ele não há nome acessível (Regra 18) — mesma convenção do [`IconButton`](../Forms/IconButton.md).
- O pill é um botão de texto próprio (nome vem do texto). Use `label={null}` para removê-lo de fato da árvore de acessibilidade, nunca `label=""` como truque visual.
- O avatar default é decorativo (`aria-hidden`), então não há nome acessível duplicado dentro do botão.
- Ambos os botões são focáveis e disparam por Enter/Espaço (React Aria `onPress`).

## Armadilhas comuns

- Não use mais de um `IaSRMFab` na mesma tela.
- Ao passar `onLabelPress` diferente de `onPress`, garanta que ambos abrem a **mesma** feature (drawer vs overlay é aceitável; features diferentes não).
- Sem `onPress` **e** sem `onLabelPress` os botões renderizam mas não disparam nada.
- Se você espera que `className` estilize o círculo, use `buttonClassName` — `className` é a raiz.
