# OpenFinanceAccountCard

Linha compacta de conta bancária conectada via Open Finance, para listas em dashboard
ou drawers de conciliação. Discriminada por `connected`: `true` mostra saldo + tendência;
`false` mostra tag "Desconectada" + CTA "Conectar". Composto pelos átomos `BankAvatar`
(`Identity`), `ListLabel` (`DataDisplay`), `TrendIndicator` (`DataDisplay`), `Tag`
(`DataDisplay`) e `Button` (`Forms`, só na variante desconectada). Usa a superfície
compartilhada `Cards/cardSurface` (`appearance="outlined"`, `interactive: false`).

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/OpenFinanceAccountCard/`
- **Export:** `import { OpenFinanceAccountCard } from '@srm/diamond';`
- **Relacionados:** [BalanceCard](./BalanceCard.md) (conta principal do HB, não Open Finance),
  [Card](./Card.md), [Button](../Forms/Button.md), [TrendIndicator](../DataDisplay/TrendIndicator.md),
  [Tag](../DataDisplay/Tag.md)

---

## Quando usar

- Listar contas conectadas via Open Finance (bancos terceiros) em um dashboard/drawer de
  conciliação — uma linha por conta, com logo do banco, identificação, saldo e tendência.
- Sinalizar uma conta que perdeu a conexão e precisa de reautenticação → `connected={false}`
  ativa o tom cinza + tag "Desconectada" + CTA "Conectar" (`onConnect`).
- Compor uma lista vertical de múltiplas instituições (o card é uma linha, não um grid item).

## Quando **não** usar

- Conta principal/titular do HB Digital na SRM → use [`BalanceCard`](./BalanceCard.md)
  (`variant="primary"`), não este componente (que é especificamente para contas
  terceirizadas via Open Finance).
- Grid apertado (< 280px de largura) — o valor pode truncar; prefira listas ou grids
  2–3 colunas para este componente.
- Card clicável/navegável — o componente **não** tem prop `onClick` no elemento raiz e
  **não repassa `...rest`** para o `<div>` (ver Notas de comportamento); a única
  affordance interativa é o botão "Conectar" na variante desconectada.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { BankSize } from '@srm/diamond';       // Identity/BankAvatar
import type { TrendDirection } from '@srm/diamond'; // DataDisplay/TrendIndicator

type OpenFinanceBankSlug = string; // slug BACEN (ex.: 'itau'), resolvido pelo bankRegistry

interface OpenFinanceAccountCardBase {
  bank: OpenFinanceBankSlug;      // obrigatório — logo via BankAvatar (fallback: iniciais)
  name: ReactNode;                // obrigatório — nome da instituição
  account: ReactNode;              // obrigatório — descrição da conta (ex.: "Ag. 1234 · CC 56789-0")
  avatarSize?: BankSize;          // default: 'lg'
}

interface ConnectedProps extends OpenFinanceAccountCardBase {
  connected: true;                // obrigatório — discrimina a variante
  value: ReactNode;                // obrigatório — saldo formatado
  trend: TrendDirection;           // obrigatório — 'up' | 'down' | 'neutral' | 'none'
  trendLabel?: string;
  trendSuffix?: string;           // contexto do trend (ex.: "vs. mês anterior")
}

interface DisconnectedProps extends OpenFinanceAccountCardBase {
  connected: false;               // obrigatório — discrimina a variante
  onConnect?: () => void;
  value?: never;
  trend?: never;
  trendLabel?: never;
}

type OpenFinanceAccountCardProps = ConnectedProps | DisconnectedProps;
// Nota: apesar do tipo estender Omit<HTMLAttributes<HTMLDivElement>, ...>, o
// componente NÃO espalha essas props extras no <div> raiz — ver Notas de comportamento.
```

### Notas de comportamento

- **`connected` é discriminante obrigatório** — não há default; sempre informe
  explicitamente `connected={true}` ou `connected={false}` (o TypeScript já exige isso
  via union). Não existe um terceiro estado "carregando"/skeleton neste componente.
- **Conectada** (`connected: true`): renderiza `BankAvatar` + `ListLabel` (esquerda:
  `name`/`account`) + `ListLabel` (direita, `align="right"`: `value`/`TrendIndicator`
  `layout="inline"`). `trend` é obrigatório nesse ramo; `trendLabel`/`trendSuffix` são
  opcionais e passados condicionalmente ao `TrendIndicator`.
- **Desconectada** (`connected: false`): troca o `ListLabel` de saldo por um `Button`
  `variant="primary"` `size="sm"` com label fixo "Conectar" (`onPress={onConnect}`, se
  informado) e o `caption` do `ListLabel` esquerdo vira uma `Tag` `variant="info"`
  `size="sm"` com texto fixo "Desconectada" (não customizável via props). O card ganha
  a classe `cardDisconnected` (fundo `--surface-hover`, borda `--border-medium`).
- **Nenhuma prop HTML extra é repassada ao `<div>` raiz** — apesar do tipo estender
  `Omit<HTMLAttributes<HTMLDivElement>, ...>`, o componente **desestrutura só**
  `bank`/`name`/`account`/`avatarSize` e os campos discriminantes (`connected`, `value`,
  `trend`, `trendLabel`, `trendSuffix`, `onConnect`); qualquer outra prop HTML
  (`className`, `style`, `id`, `data-*`, `aria-*`) que seja passada é **silenciosamente
  ignorada** — não há `{...rest}` no JSX. Isso é uma limitação atual do componente, não
  um comportamento configurável.
- `bank` que não existir no `bankRegistry` do `BankAvatar` cai automaticamente no
  fallback de iniciais — não gera erro.

---

## Exemplos

```tsx
import { OpenFinanceAccountCard } from '@srm/diamond';

// Conectada — básico
<OpenFinanceAccountCard
  bank="itau"
  name="Itaú Unibanco"
  account="Ag. 1234 · CC 56789-0"
  connected
  value="R$ 1.250.000"
  trend="up"
  trendLabel="+2,1%"
  trendSuffix="vs. mês anterior"
/>

// Conectada — trend negativo
<OpenFinanceAccountCard
  bank="bradesco"
  name="Bradesco"
  account="Ag. 0987 · CC 12345-6"
  connected
  value="R$ 340.500"
  trend="down"
  trendLabel="-0,8%"
  trendSuffix="vs. mês anterior"
/>

// Desconectada — com CTA de reconexão
<OpenFinanceAccountCard
  bank="nubank"
  name="Nubank"
  account="Ag. 0001 · CC 12345-0"
  connected={false}
  onConnect={() => reconectarOpenFinance('nubank')}
/>

// Avatar menor, em lista densa
<OpenFinanceAccountCard
  bank="santander"
  name="Santander"
  account="Ag. 4321 · CC 98765-0"
  avatarSize="md"
  connected
  value="R$ 82.000"
  trend="neutral"
/>

// Lista de contas Open Finance
<div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
  <OpenFinanceAccountCard bank="itau" name="Itaú Unibanco" account="Ag. 1234 · CC 56789-0" connected value="R$ 1.250.000" trend="up" trendLabel="+2,1%" trendSuffix="vs. mês anterior" />
  <OpenFinanceAccountCard bank="bradesco" name="Bradesco" account="Ag. 0987 · CC 12345-6" connected={false} onConnect={handleReconnect} />
</div>
```

---

## Acessibilidade

- O botão "Conectar" (variante desconectada) é um [`Button`](../Forms/Button.md) padrão
  — já carrega foco e ativação por teclado; garanta que o texto "Conectar" seja
  suficiente no contexto (uma linha por banco deixa claro qual conta está sendo
  reconectada, mas se necessário use `aria-label` no consumidor via wrapper).
- `BankAvatar` é decorativo — a identificação textual do banco está em `name`.
- `TrendIndicator` comunica direção via ícone **e** texto (`trendLabel`) — sempre informe
  `trendLabel` para não depender só da cor/ícone de direção.
- Por não repassar `aria-*`/`role` via `...rest` (ver Notas de comportamento), não é
  possível anotar o card raiz com atributos ARIA adicionais no nível atual da API.

## Armadilhas comuns

- Passar `className`/`style`/`data-testid` esperando que cheguem ao `<div>` raiz — eles
  são **ignorados** pelo componente atual (sem `{...rest}` no JSX); não use este
  componente quando precisar de customização de estilo por instância.
- Usar este componente para a conta principal SRM do titular — é destinado a contas
  terceirizadas via Open Finance; para a conta principal use [`BalanceCard`](./BalanceCard.md).
- Esperar um estado de carregamento/skeleton nativo — não existe; trate o loading no
  nível da lista (ex.: não renderizar o card até os dados chegarem).
- Omitir `trend` na variante conectada — é campo obrigatório no tipo (`ConnectedProps`);
  o TypeScript bloqueia a omissão, mas se o dado realmente não existir, use `trend="none"`.
- Esperar `onClick` no card inteiro — não existe; a única ação é o botão "Conectar" na
  variante desconectada.
