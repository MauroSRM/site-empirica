# MessageComposer

Pill compound de composição de mensagem: `[anexar]? [texto] [gravar]? [enviar]`. É a
**fonte única** do input de chat do DS — consumido por [IaSRMHero](./IASRMHero.md) e
[IaSRMTray](./IaSRMTray.md), que antes duplicavam esta anatomia.

- **Categoria:** AI
- **Fonte:** `src/components/AI/MessageComposer/`
- **Export:** `import { MessageComposer } from '@srm/diamond';`
- **Relacionados:** [IaSRMTray](./IaSRMTray.md) (usa no topo), [IaSRMHero](./IASRMHero.md) (usa no card), [IconButton](../Forms/IconButton.md) (as 3 ações), [SearchInput](../Forms/Inputs/SearchInput.md) (input de busca, não de chat)

---

## Quando usar

- Qualquer superfície onde o usuário digita uma mensagem para o assistente.
- Solto, quando você monta uma superfície de chat própria (fora de `IaSRMHero`/`IaSRMTray`).
- Quando precisa das ações de anexar e/ou gravar áudio ao lado do campo.

## Quando **não** usar

- Campo de busca → [`SearchInput`](../Forms/Inputs/SearchInput.md).
- Campo de formulário com label, erro e validação → [`TextInput`](../Forms/Inputs/TextInput.md) + React Hook Form.
- Dentro de `IaSRMHero` ou `IaSRMTray` — eles **já** renderizam o composer internamente; use as props deles.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';

interface MessageComposerProps
  extends Omit<ComponentPropsWithoutRef<'div'>, 'children' | 'onChange' | 'defaultValue'> {
  value?: string;                          // presente => controlado
  defaultValue?: string;                   // não-controlado; não combine com value
  onChange?: (value: string) => void;      // valor cru, a cada tecla
  onSend?: (message: string) => void;      // texto TRIMADO; nunca string vazia
  onAttach?: () => void;                   // sem handler, o botão não renderiza
  onRecordAudio?: () => void;              // sem handler, o botão não renderiza
  placeholder?: string;                    // default: 'Digite sua mensagem...'
  inputLabel?: string;                     // default: 'Mensagem'
  attachLabel?: string;                    // default: 'Anexar arquivo'
  recordLabel?: string;                    // default: 'Gravar áudio'
  sendLabel?: string;                      // default: 'Enviar mensagem'
  isDisabled?: boolean;                    // default: false
  ref?: Ref<HTMLInputElement>;             // aponta pro <input> interno
  // + atributos nativos de <div> na raiz: id, className, data-*, aria-*, …
}
```

### Notas de comportamento

- Construído sobre `TextField` + `Input` do **React Aria** (Regra 27): estados de hover/focus/disabled vêm por data attributes, sem estado em JS.
- **Envio**: Enter no campo ou clique no botão enviar. `onSend` recebe o texto após `trim()`.
- O botão enviar fica **`isDisabled` enquanto o texto está em branco** — então `onSend` nunca é chamado com string vazia, e o leitor de tela anuncia o estado em vez de o clique falhar em silêncio.
- Em modo **não-controlado**, o campo é limpo após o envio. Em modo **controlado**, o componente emite `onChange('')` e o pai decide — ele é a fonte de verdade.
- `onAttach` e `onRecordAudio` **condicionam a renderização**: sem handler, o botão não existe no DOM (não é só desabilitado). Enviar é sempre visível.
- Todos os rótulos acessíveis são props. Os defaults são genéricos de propósito — o DS não embute nome de produto.
- `ref` aponta para o `<input>`, não para a raiz: o uso típico é dar foco programático ao composer.

---

## Exemplos

```tsx
import { MessageComposer } from '@srm/diamond';

// Não-controlado, só envio
<MessageComposer onSend={(text) => sendMessage(text)} />

// Com anexo e áudio
<MessageComposer
  onSend={sendMessage}
  onAttach={openFilePicker}
  onRecordAudio={startRecording}
/>

// Controlado (ex.: preencher a partir de uma sugestão externa)
<MessageComposer value={draft} onChange={setDraft} onSend={sendMessage} />

// Não-controlado com rascunho inicial
<MessageComposer defaultValue="Rascunho salvo…" onSend={sendMessage} />

// Bloqueado enquanto a resposta está em voo
<MessageComposer isDisabled={isPending} onSend={sendMessage} />

// i18n / copy própria
<MessageComposer
  placeholder="Type a message…"
  inputLabel="Message"
  sendLabel="Send"
  attachLabel="Attach file"
  onSend={sendMessage}
  onAttach={openFilePicker}
/>

// Foco programático
const inputRef = useRef<HTMLInputElement>(null);
<MessageComposer ref={inputRef} onSend={sendMessage} />
```

---

## Acessibilidade

- O campo não tem label visível: o nome acessível vem de `inputLabel`, aplicado no `TextField` do React Aria.
- As 3 ações são [`IconButton`](../Forms/IconButton.md) só-ícone, cada uma com `aria-label` configurável.
- `isDisabled` propaga para o campo e para todas as ações (React Aria, não `disabled` nativo) — o estado é anunciado corretamente.
- O botão enviar desabilitado com texto vazio é intencional: comunica a restrição em vez de aceitar o clique e não fazer nada.

## Armadilhas comuns

- Não passe `value` **e** `defaultValue` juntos — escolha controlado ou não-controlado.
- Em modo controlado, o componente **não** limpa o campo sozinho: trate `onChange('')` disparado no envio.
- Não espere `onSend` com string vazia ou só espaços — ele nunca dispara nesse caso; se você precisa reagir a "tentou enviar vazio", use `onChange` e derive.
- Não use dentro de `IaSRMHero`/`IaSRMTray` — eles já compõem o composer; passar um segundo duplica o input.
