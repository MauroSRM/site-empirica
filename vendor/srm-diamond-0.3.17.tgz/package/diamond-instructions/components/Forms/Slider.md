# Slider

Controle de seleção de valor numérico por arraste, em modo **single** (um valor) ou
**range** (intervalo mín–máx com dois thumbs). Exibe bolha de valor sobre o(s) thumb(s)
e, opcionalmente, marcas (ticks) de referência sob a trilha. Construído sobre
`Slider`, `SliderTrack`, `SliderFill` e `SliderThumb` do `react-aria-components`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Slider/`
- **Export:** `import { Slider } from '@srm/diamond';`
- **Relacionados:** nenhum componente de Forms cobre a mesma função (não é um `Input` — não usa `InputBase`).

---

## Quando usar

- Seleção de um valor numérico dentro de uma faixa conhecida com feedback visual
  contínuo: percentual de alocação, prazo em meses, tolerância a risco (1–5), taxa.
- Seleção de um **intervalo** (mín–máx) — ex.: faixa de rentabilidade esperada,
  faixa etária, faixa de aporte — usando `type="range"`.
- Contextos onde o arraste é mais natural que digitar (ajustes rápidos, dashboards
  de simulação, filtros).

## Quando **não** usar

- Entrada de valor monetário ou percentual digitado com precisão — use
  [`CurrencyInput`](./Inputs/CurrencyInput.md) ou `PercentInput`. O `Slider` não
  tem teclado numérico nem máscara; é para ajuste por arraste/setas.
- Seleção discreta entre poucas opções nomeadas (não numéricas) — use um
  `RadioGroup` ou `SegmentedControl`.
- Quando o valor exato precisa ser digitável por acessibilidade/precisão (o
  Slider aceita teclado via setas, mas não digitação direta de número).

---

## Interface

```ts
export type SliderType = 'single' | 'range';
export type SliderSize = 'sm' | 'md';
export type SliderTheme = 'default' | 'dark';

export interface SliderProps {
  type?: SliderType;        // default: 'single'
  size?: SliderSize;        // default: 'md'
  theme?: SliderTheme;      // default: 'default'

  min?: number;             // default: 0
  max?: number;             // default: 100
  step?: number;            // default: undefined (passthrough condicional ao react-aria)

  value?: number;           // valor inicial do thumb 0 — default: 30
  valueEnd?: number;        // valor inicial do thumb 1 (só usado em type="range") — default: 70

  showValue?: boolean;      // default: true — bolha com o valor atual sobre o(s) thumb(s)
  showTicks?: boolean;      // default: false — 5 marcas fixas em 0/25/50/75/100%
  disabled?: boolean;       // default: false

  onChange?: (value: number, valueEnd: number) => void;
}
```

Não há herança de `InputBaseProps` — este componente **não** é um `Input` da
família `Forms/Inputs` e não recebe `label`, `helperText`, `errorText`, `state`,
etc. Também **não** repassa props arbitrárias de `react-aria-components`: a
interface acima é a lista completa e fechada de props aceitas (sem
`aria-label`, `id`, `name` ou `aria-*` passthrough no nível do componente).

### Notas de comportamento importantes

- **Estado interno com sincronização por prop, não totalmente controlado.**
  O componente mantém `start`/`end` em `useState`, inicializados a partir de
  `value`/`valueEnd`. Um `useEffect` re-sincroniza o estado interno **sempre
  que o valor do prop muda** (`useEffect(() => setStart(valueProp), [valueProp])`).
  Isso significa:
  - Se você nunca atualizar `value` a partir do `onChange`, o Slider funciona
    como **uncontrolled** (usa `value`/`valueEnd` só como seed inicial) — arrastar
    o thumb funciona normalmente, sem re-render do pai.
  - Se você **atualizar `value` a cada `onChange`** (padrão controlado clássico),
    também funciona, pois o novo valor bate com o estado interno e o efeito é
    um no-op na prática.
  - Se o pai tentar **forçar** um valor diferente do que o usuário acabou de
    arrastar (ex.: clamps de validação), isso só se reflete no slider quando a
    prop `value` muda para um número diferente do anterior — mudanças "para o
    mesmo valor" não dispara o efeito (React não re-executa efeito com
    dependência igual).
- `step` só é passado ao `react-aria` `Slider` quando definido — se omitido,
  o comportamento padrão do react-aria (`step=1`) se aplica.
- `onChange` **sempre** recebe dois argumentos, mesmo em `type="single"`: o
  segundo argumento é o valor corrente de `end` (por padrão `70`, mesmo que a
  UI não exiba o segundo thumb). Em modo single, ignore o segundo argumento.
- `showTicks` renderiza exatamente **5** marcas fixas (0%, 25%, 50%, 75%, 100%
  da faixa), com rótulo calculado por `min + (max - min) * tick / 100` e
  arredondado — não é configurável por quantidade de ticks.
- Os `aria-label` dos thumbs são fixos e em pt-BR, sem prop de override:
  `"Valor"` (single), `"Valor mínimo"` / `"Valor máximo"` (range).
- `disabled` desabilita o slider inteiro (ambos os thumbs em modo range) via
  `isDisabled` do react-aria — não há desabilitar apenas um thumb.

---

## Exemplos

```tsx
import { useState } from 'react';
import { Slider } from '@srm/diamond';

// Básico — single, uncontrolled (seed inicial em 30)
<Slider min={0} max={100} value={30} />

// Range — faixa de rentabilidade esperada
<Slider type="range" min={0} max={30} value={5} valueEnd={15} />

// Com ticks de referência
<Slider min={0} max={100} value={50} showTicks />

// Tamanho compacto
<Slider size="sm" min={0} max={10} value={3} />

// Desabilitado
<Slider min={0} max={100} value={40} disabled />

// Tema escuro (sobre header/painel brand)
<Slider theme="dark" min={0} max={100} value={60} />

// Controlado — lendo o valor no pai
function PrazoSimulacao() {
  const [meses, setMeses] = useState(12);
  return (
    <>
      <Slider min={1} max={60} value={meses} onChange={(v) => setMeses(v)} />
      <p>{meses} meses</p>
    </>
  );
}

// Range controlado — captura os dois extremos
function FaixaAporte() {
  const [faixa, setFaixa] = useState({ min: 1000, max: 5000 });
  return (
    <Slider
      type="range"
      min={0}
      max={10000}
      step={100}
      value={faixa.min}
      valueEnd={faixa.max}
      onChange={(min, max) => setFaixa({ min, max })}
    />
  );
}
```

### Integração com React Hook Form

```tsx
<Controller
  name="prazoMeses"
  control={control}
  defaultValue={12}
  render={({ field }) => (
    <Slider
      min={1}
      max={60}
      value={field.value}
      onChange={(v) => field.onChange(v)}
    />
  )}
/>
```

> Para `type="range"`, armazene o par (`min`/`max`) em um único campo do form
> (ex.: objeto `{ min, max }`) e desestruture nos props `value`/`valueEnd` e no
> callback `onChange(min, max)`.

---

## Acessibilidade

- Cada thumb é navegável por teclado (setas para ajustar, Home/End para
  extremos) via react-aria, e já recebe `aria-label` fixo em pt-BR.
- Não há prop para customizar o `aria-label` do slider ou dos thumbs — se o
  contexto exigir um rótulo diferente (ex.: "Valor de aporte mínimo"), isso
  hoje **não é configurável** de fora; considere isso antes de usar em telas
  onde o rótulo genérico "Valor mínimo"/"Valor máximo" seja ambíguo.
- A bolha de valor (`showValue`) é `aria-hidden="true"` — é puramente visual;
  o valor real é exposto via o valor do `role="slider"` de cada thumb (lido
  pelo leitor de tela ao focar o thumb).
- Respeita `prefers-reduced-motion` (desativa transições de `box-shadow` do
  thumb e do `fill`).

## Armadilhas comuns

- Não assuma que `value`/`onChange` seguem o padrão 100% controlado de um
  `<input>`: o `useEffect` de sincronização só reage a **mudanças** na prop
  `value`/`valueEnd`, não a toda renderização. Um valor de clamp/validação que
  coincida com o valor já arrastado pelo usuário **não** vai "corrigir" o slider.
- `onChange` sempre entrega `(value, valueEnd)` — em modo `single`, não
  descarte silenciosamente o segundo argumento por engano ao tipar o handler.
- Não existe `name` nem integração nativa com `<form>` (sem input hidden
  automático) — para submissão de formulário nativo, gerencie o valor via
  estado/RHF e inclua-o você mesmo no payload.
- Não use para valores que precisam de entrada exata digitada — combine com um
  input numérico ao lado se precisão exata for um requisito, já que o Slider
  não expõe forma de digitar o valor diretamente.
- `showTicks` não aceita customização de quantidade/posição de marcas — é
  fixo em 5 posições percentuais da faixa.
