# DocumentViewer

Modal (desktop) para pré-visualização de documentos (PDF ou imagem) em tela cheia, com
controle de zoom, download e upload local opcional. Construído sobre `ModalOverlay` /
`Modal` / `Dialog` do `react-aria-components`. Exporta também `DocumentViewerSheet`, o
equivalente **mobile-only** — mesma moldura de documento e mesma barra de zoom, dentro de
um `SheetContent` (bottom sheet) ocupando 95% da altura do dispositivo. `DocumentViewerSheet`
tem story própria (`DocumentViewerSheet.stories.tsx`) e é exportado publicamente lado a lado
com `DocumentViewer`.

> **Nota sobre `@ds-ignore`:** os arquivos `.stories.tsx`/`.test.tsx` desta pasta trazem o
> cabeçalho `// @ds-ignore — engineering repo; not for the DS bundle` — mas esse comentário é
> boilerplate padrão de **todo** arquivo de story/teste do repositório (convenção descrita em
> `.claude/component-generation-prompt.md`), não uma marcação específica deste componente.
> `DocumentViewer` e `DocumentViewerSheet` são reexportados normalmente em
> `src/components/index.ts` (`export * from './Feedback/DocumentViewer'`) e fazem parte do
> bundle `@srm/diamond` como qualquer outro componente de `Feedback`.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/DocumentViewer/` (sub-arquivos: `DocumentViewer.tsx`,
  `DocumentViewerSheet.tsx`, `DocumentViewerZoomBar.tsx`, `DocumentViewerDropzone.tsx`,
  `DocumentViewer.hooks.ts` com a lógica de zoom/upload compartilhada)
- **Export:** `import { DocumentViewer, DocumentViewerSheet } from '@srm/diamond';` — o barrel
  também reexporta os tipos `DocumentViewerProps`, `DocumentViewerSheetProps`,
  `DocumentViewerAction` e `DocumentViewerFileType`
- **Relacionados:** [SheetContent](./SheetContent.md) (base do `DocumentViewerSheet`), `Button` /
  `IconButton` / `DoubleButton` (rodapé e barra de zoom)

---

## Quando usar

- Pré-visualizar um contrato, comprovante, extrato ou laudo (PDF) antes de o usuário
  assinar, baixar ou confirmar uma ação — ex.: revisão de contrato de investimento antes
  da assinatura eletrônica.
- Exibir uma imagem digitalizada (comprovante de residência, documento de identidade)
  enviada pelo usuário, com zoom para conferência de detalhes.
- Fluxos onde o usuário precisa baixar o arquivo (`downloadUrl`/`onDownload`) depois de
  revisá-lo, com ou sem uma ação de confirmação (`primaryAction`/`secondaryAction`) no rodapé.
- Em telas mobile, use `DocumentViewerSheet` para o mesmo propósito dentro de um bottom
  sheet em vez de um modal de tela cheia.

## Quando **não** usar

- Confirmação simples sem documento a exibir → use um modal genérico de confirmação, não
  este componente.
- Upload de arquivo como etapa de formulário (sem necessidade de pré-visualização em
  tela cheia) → prefira um campo de upload dedicado; o botão de upload deste componente é
  pensado para o **dev testar no Storybook com um arquivo local**, não para expor ao
  usuário final (`allowUpload` em `DocumentViewer` — vide comentário no próprio Storybook:
  "não expor ao usuário final").
- Desktop vs. mobile: não use `DocumentViewer` (modal fullscreen) em telas mobile nem
  `DocumentViewerSheet` (bottom sheet) em desktop — cada um é dedicado a um breakpoint.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { ButtonVariant } from '@srm/diamond'; // '../../Forms/Button'

type DocumentViewerFileType = 'pdf' | 'image';

interface DocumentViewerAction {
  label: string;
  onClick: () => void;
  variant?: ButtonVariant;   // default (via Button/DoubleButton): 'primary' / 'ghost'
}

// Props compartilhadas entre DocumentViewer e DocumentViewerSheet
interface DocumentViewerSharedProps {
  title?: string;
  subtitle?: string;
  src?: string;
  fileType?: DocumentViewerFileType;   // default: 'pdf'
  downloadUrl?: string;                // quando presente, o download vira <a href download> real
  onDownload?: () => void;             // handler (botão) usado quando NÃO há downloadUrl;
                                        // se ambos existirem, vira o onClick do próprio <a>
  children?: ReactNode;                // conteúdo custom exibido quando não há src/upload

  /** Nome acessível da mídia quando não há título. @default 'Documento' */
  mediaTitleFallback?: string;
  /** Sufixo do subtítulo na pré-visualização local de um arquivo enviado. @default 'pré-visualização local' */
  localPreviewLabel?: string;
  /** Label visível ao lado do ícone de download. Omitido: mostra só o ícone. */
  downloadLabel?: string;
  /** aria-label do botão de reduzir zoom. @default 'Reduzir zoom' */
  zoomOutLabel?: string;
  /** aria-label do botão de aumentar zoom. @default 'Aumentar zoom' */
  zoomInLabel?: string;
  /** aria-label do botão de download exibido só como ícone. @default 'Baixar' */
  downloadIconLabel?: string;
  /** aria-label do botão de upload local. @default 'Enviar arquivo local para pré-visualizar' */
  uploadLabel?: string;
  /** Título do estado vazio (dropzone). @default 'Nenhum arquivo carregado' */
  dropzoneTitle?: string;
  /** Instrução do estado vazio (dropzone). @default 'Clique ou arraste um PDF/imagem aqui pra pré-visualizar' */
  dropzoneHint?: string;
}

interface DocumentViewerProps extends DocumentViewerSharedProps {
  isOpen: boolean;
  onClose: () => void;
  primaryAction?: DocumentViewerAction;
  secondaryAction?: DocumentViewerAction;
  /** Exibe o botão de upload na barra de zoom. @default false */
  allowUpload?: boolean;
  /** aria-label do botão de fechar. @default 'Fechar' */
  closeLabel?: string;
}

interface DocumentViewerSheetProps extends DocumentViewerSharedProps {
  isOpen: boolean;
  onClose: () => void;
  /** Escopa o portal a um contêiner (moldura de celular numa demo) em vez de document.body. */
  container?: HTMLElement;
  // Sem allowUpload/closeLabel: o botão de upload é sempre visível e o fechar
  // vem do "X" padrão do SheetContent (aria-label "Fechar" fixo, não configurável aqui).
}
```

### Notas de comportamento

- **`src` + `fileType`**: quando `src` está definido, o conteúdo é renderizado dentro da
  moldura como `<iframe src={src}>` (quando `fileType="pdf"`, o default) ou `<img src={src}>`
  (quando `fileType="image"`). Sem `src` e sem upload local ativo, mostra `children` se
  fornecido, ou o placeholder de dropzone (`dropzoneTitle`/`dropzoneHint`).
- **Upload local embutido**: o hook interno `useDocumentUpload` (`DocumentViewer.hooks.ts`)
  sempre está ativo — o `<input type="file" accept="application/pdf,image/*">` existe mesmo
  se `allowUpload` for `false` em `DocumentViewer`, porque a dropzone do estado vazio também
  aciona o picker. Em `DocumentViewerSheet` o botão de upload na barra de zoom **é sempre
  visível** (`onUploadClick={upload.openPicker}` incondicional — não existe prop
  `allowUpload` em `DocumentViewerSheetProps`).
- **Object URL com cleanup**: ao selecionar/soltar um arquivo, `useDocumentUpload` cria a URL
  local via `useEffect` (`URL.createObjectURL(file)`), sobrepõe `src`/título/subtítulo com o
  arquivo escolhido (`título = file.name`, `subtítulo = "<tamanho> · " + localPreviewLabel`) e
  **revoga a URL anterior** no cleanup do próprio efeito (troca de arquivo ou desmontagem) —
  sem vazamento de memória.
- **Drag & drop**: a moldura (`.frame`/`.sheetFrame`) aceita arrastar-e-soltar um arquivo a
  qualquer momento (`onDragOver`/`onDrop`), independentemente de `allowUpload`.
- **Zoom**: controlado internamente (`useDocumentZoom`) — `50%` a `200%`, passo de `25%`,
  default `100%`. Não há prop para controlar o zoom de fora; o zoom só afeta a largura da
  moldura em `DocumentViewer` (`style={{ width: `${zoom}%` }}`), não em `DocumentViewerSheet`
  (o zoom bar existe, mas a moldura do sheet não muda de tamanho com ele).
- **Rodapé de ações** (`DocumentViewer` apenas — `DocumentViewerSheet` não tem rodapé):
  se ambas `primaryAction` **e** `secondaryAction` forem passadas, renderiza um
  `DoubleButton` (`pair="destructive-ghost"` se `primaryAction.variant === 'destructive'`,
  senão `"primary-ghost"`); se só uma delas, renderiza um `Button` isolado
  (`variant` default: `'ghost'` para secundária, `'primary'` para principal). Sem nenhuma
  das duas, o rodapé não é renderizado.
- **Download vira link real**: quando `downloadUrl` é informado, o botão de download é um
  `<a href={downloadUrl} download>` de verdade (antes do refactor era inerte/decorativo);
  se `onDownload` também for passado junto com `downloadUrl`, ele vira o `onClick` do próprio
  link (analytics, fechamento de modal etc., sem impedir o download nativo). Sem
  `downloadUrl`, o download cai para um `<button>`/`IconButton` cujo `onClick` é `onDownload`.
  Com `downloadLabel`, renderiza texto+ícone; sem `downloadLabel`, renderiza só o ícone
  (`aria-label` = `downloadIconLabel`). A barra de download só aparece se `downloadUrl`
  **ou** `onDownload` estiver presente.
- **Fechar**: em `DocumentViewer`, `onClose` é chamado tanto pelo `IconButton` do header
  (`aria-label={closeLabel}`, default `'Fechar'`) quanto por `onOpenChange`/dismiss do
  `ModalOverlay` (clique fora, Esc) — não há prop para desabilitar o dismiss (diferente de
  `SheetContentProps.dismissible`, que não é repassada por `DocumentViewerSheet`). Em
  `DocumentViewerSheet` não existe `closeLabel`; o fechar é o "X" padrão do `SheetContent`
  (`aria-label="Fechar"` fixo).
- **`DocumentViewerSheet`** é implementado em cima de `SheetContent` com `height="95vh"` e
  `maxHeight="95vh"` fixos (não configuráveis via prop) e repassa `container` para escopar o
  portal (ex.: moldura de celular numa demo).
- Todos os textos de rótulo/aria (`mediaTitleFallback`, `localPreviewLabel`, `zoomOutLabel`,
  `zoomInLabel`, `downloadIconLabel`, `uploadLabel`, `dropzoneTitle`, `dropzoneHint`,
  `closeLabel`) têm default em português mas são totalmente sobrescrevíveis — nenhum texto
  fica hardcoded fora de alcance do consumidor.

---

## Exemplos

```tsx
import { useState } from 'react';
import { DocumentViewer, Button } from '@srm/diamond';

// Básico — documento já carregado, com download (link real)
function ContratoViewer() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onPress={() => setOpen(true)}>Ver documento</Button>
      <DocumentViewer
        isOpen={open}
        onClose={() => setOpen(false)}
        title="Contrato de investimento.pdf"
        subtitle="3 páginas · 1,2 MB"
        src="/docs/contrato-123.pdf"
        fileType="pdf"
        downloadUrl="/docs/contrato-123.pdf"
        downloadLabel="Baixar documento"
      />
    </>
  );
}

// Com ações de confirmação (renderiza DoubleButton no rodapé)
<DocumentViewer
  isOpen={open}
  onClose={() => setOpen(false)}
  title="Termo de adesão.pdf"
  src={termoUrl}
  primaryAction={{ label: 'Assinar', onClick: handleAssinar }}
  secondaryAction={{ label: 'Cancelar', onClick: () => setOpen(false) }}
/>

// Ação destrutiva isolada (sem secondaryAction → Button único)
<DocumentViewer
  isOpen={open}
  onClose={() => setOpen(false)}
  title="Solicitação de encerramento.pdf"
  src={docUrl}
  primaryAction={{ label: 'Excluir solicitação', onClick: handleExcluir, variant: 'destructive' }}
/>

// Estado vazio com upload habilitado (dev/homolog — não expor ao usuário final)
<DocumentViewer
  isOpen={open}
  onClose={() => setOpen(false)}
  title="Novo documento"
  allowUpload
/>

// Conteúdo custom (children) quando não há src
<DocumentViewer isOpen={open} onClose={() => setOpen(false)} title="Resumo">
  <div style={{ padding: 24 }}>Conteúdo customizado sem arquivo carregado</div>
</DocumentViewer>

// Rótulos customizados (ex.: outro idioma ou copy de produto)
<DocumentViewer
  isOpen={open}
  onClose={() => setOpen(false)}
  title="Comprovante.jpg"
  src={comprovanteUrl}
  fileType="image"
  closeLabel="Fechar visualização"
  zoomInLabel="Ampliar"
  zoomOutLabel="Reduzir"
  dropzoneTitle="Nenhum comprovante enviado"
  dropzoneHint="Arraste um JPG/PNG ou clique para selecionar"
/>
```

```tsx
import { useState } from 'react';
import { DocumentViewerSheet } from '@srm/diamond';

// Equivalente mobile — bottom sheet a 95vh
function ComprovanteSheet() {
  const [open, setOpen] = useState(false);
  return (
    <DocumentViewerSheet
      isOpen={open}
      onClose={() => setOpen(false)}
      title="comprovante.jpg"
      src={comprovanteUrl}
      fileType="image"
      downloadUrl={comprovanteUrl}
    />
  );
}

// Escopando o portal a um contêiner de demo (ex.: moldura de celular)
<DocumentViewerSheet
  isOpen={open}
  onClose={() => setOpen(false)}
  title="documento.pdf"
  src={docUrl}
  container={phoneFrameRef.current ?? undefined}
/>
```

---

## Acessibilidade

- O `Dialog` (`DocumentViewer`) recebe `aria-label={displayTitle ?? mediaTitleFallback}` —
  sempre há um nome acessível, mesmo sem `title` (fallback padrão `'Documento'`,
  sobrescrevível via `mediaTitleFallback`).
- Todos os botões de ícone (fechar, zoom in/out, upload, download sem `downloadLabel`) têm
  `aria-label` com default em português (`closeLabel`, `zoomOutLabel`, `zoomInLabel`,
  `uploadLabel`, `downloadIconLabel`) — todos sobrescrevíveis por prop, nenhum hardcoded.
- `ModalOverlay`/`Modal`/`Dialog` do react-aria já cuidam de foco preso (focus trap),
  restauração de foco ao fechar e fechamento por `Esc`/clique fora.
- Em `DocumentViewerSheet`, a acessibilidade de foco/dismiss vem de `SheetContent` — verifique
  a documentação desse componente para o contrato completo do bottom sheet.
- Ao renderizar `<img>`, o `alt` é o `mediaTitle` (`displayTitle ?? mediaTitleFallback`) —
  nunca fica vazio, mesmo sem `title` e sem upload.
- Quando `downloadUrl` está presente, o download é um `<a>` real (navegável, com `download`
  no DOM) em vez de um botão sintético — melhora a semântica para tecnologia assistiva e
  permite abrir em nova aba/copiar link.

## Armadilhas comuns

- **`allowUpload` é para dev/QA, não produção**: o próprio Storybook marca a prop como "não
  expor ao usuário final" — ela existe para testar com um PDF/imagem local sem precisar
  publicar uma URL antes.
- **Zoom não é controlável de fora**: não existe prop `zoom`/`onZoomChange`; o estado é
  100% interno a cada instância do componente.
- **Não há `dismissible`/trava de fechamento** em `DocumentViewer` — diferente de outros
  componentes de overlay do design system, o usuário sempre pode fechar clicando fora ou
  com Esc.
- **`DocumentViewerSheet` não tem rodapé de ações** (`primaryAction`/`secondaryAction`) nem
  `allowUpload`/`closeLabel` — esses props existem só em `DocumentViewerProps`.
- **Drag & drop está sempre ativo na moldura**, mesmo com `allowUpload={false}` — se isso não
  for desejado, o componente atual não oferece uma prop para desabilitá-lo.
- **`onDownload` sem `downloadUrl` não gera link nenhum** — vira só um botão; se você precisa
  de comportamento nativo de download/abrir-em-nova-aba, informe `downloadUrl`.
