# EmailInput

Campo de entrada para endereços de e-mail. Construído sobre `InputBase` (herda label,
estados, temas e mensagens) e sobre a ponte de máscara `IMaskBridge` (imask/react-imask).
A "máscara" aqui é minimalista: apenas **bloqueia espaços** durante a digitação — não
força minúsculas, não valida formato de e-mail (`usuário@domínio`) e não impõe TLD.
Validação de formato e normalização (ex.: `.toLowerCase()`) são responsabilidade do
schema de validação (Zod) na camada de formulário, não do componente.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/EmailInput/`
- **Export:** `import { EmailInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [TextInput](./TextInput.md)

---

## Quando usar

- Captura de e-mail de cliente, cotista, contato comercial ou usuário em cadastros e formulários.
- Campos de login/identificação por e-mail.
- Qualquer entrada onde espaços em branco acidentais (colados de outra fonte) devem ser bloqueados
  automaticamente enquanto o usuário digita.

## Quando **não** usar

- Texto livre sem semântica de e-mail → use [`TextInput`](./TextInput.md).
- Você precisa de validação de formato de e-mail em tempo real (regex de e-mail completo) →
  isso não é feito pelo componente; implemente no schema Zod / `errorText` do formulário.
- Você precisa normalizar para minúsculas automaticamente → normalize no `onChange` do seu
  formulário ou no schema, não espere que o componente faça isso.

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface EmailInputProps extends InputBaseProps {
  value?: string;                          // valor controlado (default: '')
  placeholder?: string;                    // default: 'seu@email.com.br'
  onChange?: (value: string) => void;      // recebe a string aceita pela máscara (sem espaços)
  ref?: Ref<HTMLInputElement>;             // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Contrato de máscara

O valor passa pelo `IMaskBridge` com estas opções fixas (`EmailInput.constants.ts`):

```ts
{ mask: /^[^\s]*$/ }
```

- A única regra imposta é: **nenhum espaço em branco é aceito** — o usuário simplesmente
  não consegue digitar ou colar um espaço no campo.
- Letras maiúsculas **são aceitas normalmente** — o componente não converte para minúsculas.
  Se a semântica de negócio exige e-mail em lowercase, normalize no schema Zod ou no
  handler de `onChange` do formulário.
- Não há validação de formato de e-mail (`@`, domínio, TLD) embutida no componente —
  use `state="error"` + `errorText` orientados por validação externa (ex.: Zod
  `.email()`) para sinalizar formato inválido.
- `onChange` entrega a string já sem espaços (idêntica ao valor digitado, exceto espaços).

---

## Exemplos

```tsx
import { useState } from 'react';
import { EmailInput } from '@srm/diamond';

// Básico (controlado)
function EmailField() {
  const [email, setEmail] = useState('');
  return <EmailInput label="E-mail" value={email} onChange={setEmail} />;
}

// Com placeholder customizado e obrigatório
<EmailInput label="E-mail de contato" placeholder="nome@dominio.com" required />

// Com ajuda
<EmailInput label="E-mail" helperText="Usaremos para enviar a confirmação." value={email} onChange={setEmail} />

// Estado de erro (validado externamente, ex.: Zod .email())
<EmailInput
  label="E-mail"
  state="error"
  errorText="Informe um e-mail válido."
  value={email}
  onChange={setEmail}
/>

// Somente leitura
<EmailInput label="E-mail cadastrado" state="read-only" value="cliente@srmasset.com" />

// Tema escuro (sobre header brand)
<EmailInput label="E-mail" theme="dark" value={email} onChange={setEmail} />
```

### Integração com React Hook Form

```tsx
import { Controller } from 'react-hook-form';
import { z } from 'zod';
import { EmailInput } from '@srm/diamond';

const schema = z.object({
  email: z.string().trim().toLowerCase().email('Informe um e-mail válido.'),
});

<Controller
  name="email"
  control={control}
  render={({ field, fieldState }) => (
    <EmailInput
      label="E-mail"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

> Note que a normalização (`.trim().toLowerCase()`) e a validação de formato (`.email()`)
> ficam no schema Zod — o `EmailInput` não faz isso por conta própria.

---

## Acessibilidade

- Sempre forneça `label`. Em layouts sem rótulo visível, passe `aria-label`.
- Considere `type` semântico via passthrough de `react-aria-components` (ex.: `inputMode="email"`)
  quando precisar otimizar o teclado em dispositivos móveis.
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- Como o bloqueio de espaço acontece silenciosamente (o caractere simplesmente não é aceito),
  não há feedback assistivo dedicado para essa restrição — ela é apenas uma conveniência de
  digitação, não uma regra de validação anunciada.

## Armadilhas comuns

- **Não** assuma que o componente valida formato de e-mail — ele só bloqueia espaços.
  Sempre valide formato no schema (Zod `.email()`) e conecte o resultado a `state`/`errorText`.
- **Não** espere lowercase automático — maiúsculas passam sem alteração; normalize você mesmo.
- Não confundir com [`TextInput`](./TextInput.md) genérico: use `EmailInput` quando o campo
  semanticamente representa um e-mail, ainda que a validação completa seja externa.
