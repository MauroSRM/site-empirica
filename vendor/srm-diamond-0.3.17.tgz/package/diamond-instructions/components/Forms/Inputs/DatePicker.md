# DatePicker

Campo de data única com segmentos editáveis (dia/mês/ano) e calendário em popover
flutuante. Exibe e aceita **BR** (`dd/mm/aaaa`) na digitação, mas sempre **emite ISO**
(`YYYY-MM-DD`) no `onChange` — pronto para persistir/enviar ao backend sem conversão manual.
Construído sobre `DateField` + `Calendar` do `react-aria-components` (segmentação e grade
acessíveis nativas), `@internationalized/date` (aritmética/calendário civil) e o popover é
posicionado com `@floating-ui/react` (mesma base de `CalendarPopover` usada por
`DateRangePicker`).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/DatePicker/`
- **Export:** `import { DatePicker, getDefaultSinglePresets } from '@srm/diamond';`
- **Relacionados:** [DateRangePicker](./DateRangePicker.md) (intervalo de duas datas) ·
  base compartilhada de calendário: `_shared/Calendar` (não documentada separadamente —
  é implementação interna, não exportada no barrel)

---

## Quando usar

- Qualquer captura de **data única**: vencimento de título, data de nascimento, data de
  referência de um relatório, data de assinatura de contrato.
- Quando o usuário deve poder **digitar** a data (segmentos dd/mm/aaaa) e/ou **escolher**
  no calendário — o componente cobre os dois fluxos ao mesmo tempo.
- Quando o backend trabalha com ISO (`YYYY-MM-DD`) mas a UI deve exibir em BR — a conversão
  é automática nos dois sentidos.
- Restringir seleção a uma janela de datas (`minValue`/`maxValue`) — ex.: só permitir datas
  futuras, ou um mês fiscal específico.
- Oferecer atalhos comuns (Hoje/Ontem/Amanhã/Início do mês) via `presets`.

## Quando **não** usar

- Selecionar um **intervalo** de datas (data inicial + final) → use
  [`DateRangePicker`](./DateRangePicker.md).
- Só o mês/ano (sem dia) → não há componente dedicado hoje; considere um `Select` de mês
  e um de ano, ou escalar a necessidade ao time de design system.
- Texto livre sem validação de calendário (ex.: "referência" textual) → use `TextInput`.

---

## Interface

```ts
import type { Ref } from 'react'

type DatePickerValue = string | null

interface DatePickerPreset {
  label: string   // rótulo do atalho, ex.: 'Hoje'
  value: string    // ISO 'YYYY-MM-DD' ou BR 'dd/mm/aaaa'
}

interface DatePickerProps {
  state?: 'default' | 'error' | 'disabled' | 'read-only'; // default: 'default'
  size?: 'sm' | 'md';                                       // default: 'md'
  theme?: 'default' | 'dark';                               // default: 'default'
  label?: ReactNode;
  placeholder?: string;                                     // default: 'dd/mm/aaaa'
  helperText?: ReactNode;
  errorText?: ReactNode;
  required?: boolean;                                       // default: false
  value?: DatePickerValue;                                  // controlado — ISO ou BR na entrada
  defaultValue?: DatePickerValue;                           // não-controlado — ISO ou BR na entrada
  onChange?: (value: DatePickerValue) => void;              // sempre emite ISO (ou null)
  minValue?: string;                                        // ISO ou BR
  maxValue?: string;                                        // ISO ou BR
  presets?: DatePickerPreset[];                             // atalhos na lateral do popover
  fullWidth?: boolean;                                      // default: false
  className?: string;
  ref?: Ref<HTMLDivElement>;                                // aponta para o wrapper, não para o <input>
}

// Helper exportado junto: gera os 4 atalhos padrão (Hoje/Ontem/Amanhã/Início do mês)
function getDefaultSinglePresets(): DatePickerPreset[]

// Também exportados (utilitários de parsing/formatação usados internamente):
// parseBR, toBR, isValidBR, parseFlexible
```

> `DatePickerProps` **não** estende `InputBaseProps` (é uma interface própria) — o shape é
> parecido (`state`, `size`, `theme`, `label`, `helperText`, `errorText`, `required`,
> `className`) mas não há passthrough de `TextFieldProps`/react-aria arbitrário como em
> `TextInput`/`CurrencyInput`. Não espere props como `name`, `autoComplete` ou `onBlur`
> chegarem "de graça" — apenas o que está listado acima é suportado.

### Contrato de valor (entrada flexível, saída fixa)

- **Entrada** (`value`/`defaultValue`/`minValue`/`maxValue`/`presets[].value`): aceita
  **ISO** `YYYY-MM-DD` (ex.: vindo do backend) **ou** BR `dd/mm/aaaa`. A detecção de formato
  é automática via `parseFlexible` (tenta BR primeiro, cai para ISO).
- **Saída** (`onChange`): **sempre** ISO `YYYY-MM-DD`, ou `null` quando o campo é limpo.
  Nunca emite BR.
- Datas inválidas (ex.: `31/02/2026`, mês/dia fora de faixa) são rejeitadas silenciosamente
  pelo parser — o campo apenas não reconhece o valor como uma data válida.
- `ref` aponta para a `<div>` wrapper do campo (não para o `<input>`/segmentos internos —
  o `DateInput` do react-aria não expõe um único input nativo).

### Comportamento do popover/calendário

- Clicar em qualquer segmento (dia/mês/ano) ou no ícone de calendário abre o popover;
  `state="disabled"`/`state="read-only"` bloqueiam a abertura.
- Selecionar um dia **fecha o popover automaticamente** e dispara `onChange`.
- Dias fora do mês corrente (preenchimento da grade) são clicáveis e navegáveis — clicar
  neles seleciona a data e avança/retrocede o mês do calendário.
- O título "Mês Ano" no topo do calendário é clicável: abre a grade de meses e, ao clicar
  no ano, a grade de anos (navegável por década de 12 em 12) — útil para saltar décadas
  rapidamente (ex.: data de nascimento).
- `minValue`/`maxValue` desabilitam dias, meses e anos fora do intervalo tanto na grade
  quanto na digitação por segmentos.
- `presets` (quando fornecido) renderiza uma coluna de atalhos à esquerda do calendário;
  clicar num atalho seleciona a data e fecha o popover, igual a clicar num dia.
- O popover é um `FloatingPortal` com `role="dialog"` e foco gerenciado
  (`FloatingFocusManager`, `modal={false}`) — fecha ao clicar fora ou `Esc` (via `useDismiss`).
- **Ritmo fixo da grade de dias**: cada linha mede `var(--space-10)` (40px) com a célula em
  `var(--space-9)` (36px), independentemente de o mês ter 5 ou 6 semanas. O piso de altura
  (`--calendar-grid-height`) fica no wrapper da grade, não na `<table>` — se ficasse na
  table, o browser distribuiria a sobra entre as linhas e meses de 5 semanas ganhariam
  espaçamento maior que os de 6. A mesma altura é usada pelas grades de mês/ano, então o
  popover não salta ao trocar de visão.
- **Distribuição horizontal do campo**: as datas ficam agrupadas à esquerda e o ícone de
  calendário é empurrado para a direita (`margin-left: auto`). Alargar o campo aumenta só o
  espaço entre as datas e o ícone — o placeholder `dd/mm/aaaa` não se espalha pela largura.

---

## Exemplos

```tsx
import { useState } from 'react';
import { DatePicker, getDefaultSinglePresets } from '@srm/diamond';
import type { DatePickerValue } from '@srm/diamond';

// Básico — não controlado
<DatePicker label="Data de vencimento" />

// Recebendo ISO do backend (exibe em BR automaticamente)
<DatePicker label="Data de referência" defaultValue="2026-07-15" />

// Controlado
function VencimentoField() {
  const [data, setData] = useState<DatePickerValue>(null);
  return (
    <DatePicker
      label="Data de vencimento"
      value={data}
      onChange={setData} // recebe sempre ISO ou null
    />
  );
}

// Com min/max (restringe a um mês fiscal)
<DatePicker
  label="Data dentro do intervalo"
  minValue="2026-07-01"
  maxValue="2026-07-31"
  helperText="Apenas julho/2026 é selecionável."
/>

// Data de nascimento — usa a seleção rápida de ano do calendário
<DatePicker
  label="Data de nascimento"
  minValue="1900-01-01"
  maxValue="2026-12-31"
  helperText="Clique no mês/ano no topo do calendário para saltar anos."
/>

// Com atalhos (Hoje/Ontem/Amanhã/Início do mês)
<DatePicker label="Data com atalhos" presets={getDefaultSinglePresets()} />

// Atalhos customizados
<DatePicker
  label="Data de corte"
  presets={[
    { label: 'Fim do mês passado', value: '2026-06-30' },
    { label: 'Início do trimestre', value: '2026-07-01' },
  ]}
/>

// Estado de erro
<DatePicker
  label="Data de assinatura"
  state="error"
  errorText="Informe uma data válida."
/>

// Somente leitura
<DatePicker label="Data do lançamento" state="read-only" value="2026-07-15" />

// Tamanho compacto
<DatePicker label="Data" size="sm" />

// Tema escuro (sobre header brand) — o popover herda data-theme="dark" mesmo em portal
<DatePicker label="Data (dark)" theme="dark" />

// Largura total
<DatePicker label="Data" fullWidth />
```

### Integração com React Hook Form

```tsx
<Controller
  name="dataVencimento"
  control={control}
  render={({ field, fieldState }) => (
    <DatePicker
      label="Data de vencimento"
      value={field.value}
      onChange={field.onChange} // já entrega ISO — grava direto no form state
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Segmentos (`DateSegment`) são `role="spinbutton"` navegáveis por teclado (setas
  incrementam/decrementam, Tab move entre dia/mês/ano) — comportamento nativo do
  `DateField` do react-aria, sem código adicional.
- Cada segmento recebe `aria-label={placeholder}` — mantenha `placeholder` descritivo se
  customizá-lo (o default `'dd/mm/aaaa'` já comunica o formato esperado).
- O popover do calendário é `role="dialog"` com foco preso (`FloatingFocusManager`) e fecha
  com `Esc` ou clique fora.
- Erros são anunciados via `FieldError` do react-aria (associado ao campo); forneça
  `errorText` junto de `state="error"` para o anúncio ocorrer.
- Sempre forneça `label` — não há prop `aria-label` direta no componente; sem `label`
  visível, o campo fica sem nome acessível.
- Botões de navegação do calendário (mês/ano anterior/próximo) já têm `aria-label` em
  português fixo (ex.: "Mês anterior", "Escolher mês e ano") — não é customizável hoje.

## Armadilhas comuns

- **Não** espere `onChange` devolver BR — é sempre ISO (`"2026-07-20"`) ou `null`. Se
  precisar exibir/logar em BR, use o utilitário `toBR` exportado.
- **Não** trate `ref` como referência a um `<input>` — ele aponta para a `<div>` wrapper;
  não há um único input nativo (a data é segmentada).
- `minValue`/`maxValue` aceitam string (ISO ou BR) — não passe um objeto `Date` ou
  `CalendarDate` diretamente.
- Datas em formato inválido (`31/13/2026`, texto arbitrário) não geram erro — o parser
  apenas retorna `null`/ignora; a validação de "campo obrigatório" ou "data inválida" é
  responsabilidade do consumidor (via `state="error"` + `errorText`).
- Para **intervalo** de datas, não tente compor dois `DatePicker` manualmente para simular
  range — use [`DateRangePicker`](./DateRangePicker.md), que já trata a lógica de
  início/fim, preview de hover e validação cruzada.
- `presets` não substitui `minValue`/`maxValue`: um preset fora do intervalo permitido não
  é bloqueado automaticamente — garanta que os valores de `presets` respeitem o range.
