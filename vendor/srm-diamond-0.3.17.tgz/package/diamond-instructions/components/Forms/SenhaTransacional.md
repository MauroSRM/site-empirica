# SenhaTransacional

Campo de senha transacional (senha numérica de transação bancária) com contagem de
tentativas e estado de bloqueio total. É um **wrapper de alto nível sobre
[`OTPInput`](./Inputs/OTPInput.md)**: fixa `masked` como sempre ativo (dígitos exibidos
como `•`), resolve automaticamente a mensagem de erro por tentativa (1ª ou 2ª) e substitui
todo o campo por uma tela de bloqueio quando `state="blocked"`.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/SenhaTransacional/`
- **Export:** `import { SenhaTransacional } from '@srm/diamond';`
- **Relacionados/Base:** [OTPInput](./Inputs/OTPInput.md) (base interna) · [Button](./Button.md)
  (usado no link de bloqueio) · [Icon](../Icons/Icon.md) (ícone de erro na tela de bloqueio)

---

## Quando usar

- Confirmação de senha transacional/eletrônica em fluxos de transferência, resgate,
  pagamento ou qualquer operação financeira sensível que exija segundo fator numérico.
- Quando o produto precisa comunicar **quantas tentativas restam** antes do bloqueio
  (1ª tentativa incorreta → aviso; 2ª tentativa incorreta → aviso de bloqueio iminente).
- Quando, após esgotar as tentativas, a UI deve **substituir o campo** por uma mensagem de
  bloqueio com ação de contato (central de atendimento).

## Quando **não** usar

- Código de verificação enviado por SMS/e-mail (OTP não-secreto, com reenvio e contagem
  regressiva) → use [`OTPInput`](./Inputs/OTPInput.md) diretamente (`masked={false}`,
  com `onResend`/`resendSeconds`).
- Senha de login/acesso à conta (texto livre, não numérica) → use um input de senha padrão
  (`TextInput` com toggle de visibilidade), não este componente.
- Necessidade de customizar mensagens de erro por tentativa além de 1/2, ou de mais de
  2 tentativas antes do bloqueio → componha `OTPInput` manualmente com sua própria lógica
  de tentativas, pois `SenhaTransacional` só resolve as chaves `1` e `2`.

---

## Interface

```ts
import type { ReactNode } from 'react';

type SenhaTransacionalState = 'default' | 'error' | 'blocked';
type SenhaTransacionalTheme = 'default' | 'dark';

interface SenhaTransacionalProps {
  state?: SenhaTransacionalState;        // default: 'default'
  theme?: SenhaTransacionalTheme;        // default: 'default'
  attempt?: 1 | 2;                       // default: 1 — qual mensagem de erro exibir
  errorText?: string;                    // sobrescreve a mensagem automática de erro
  length?: number;                       // default: 4 — quantidade de dígitos
  label?: string;                        // default: 'Senha transacional'
  onComplete?: (code: string) => void;   // disparado quando todos os dígitos são preenchidos
  onChange?: (code: string) => void;     // disparado a cada dígito digitado
  blockedTitle?: ReactNode;              // default: 'Senha bloqueada por excesso de tentativas'
  blockedDescription?: ReactNode;        // default: 'Entre em contato com a central de atendimento.'
  blockedActionLabel?: ReactNode;        // default: 'Canais de atendimento'
  onBlockedAction?: () => void;          // clique/press no link de ação da tela de bloqueio
}
```

Este componente **não** herda `InputBaseProps` — sua superfície de props é própria e
independente do `InputBase` usado pelos demais campos de formulário. Internamente ele
delega para `OTPInput`, repassando `length`, `label`, `theme`, `state`/`errorText`,
`onComplete` e `onChange`; sempre com `masked` fixo em `true`.

### Comportamentos não-óbvios

- **Mensagens automáticas de erro.** Se `errorText` não for informado e `state="error"`,
  a mensagem é resolvida por uma tabela interna fixa:
  - `attempt={1}` → `"Senha incorreta, tentativa 1 de 3."`
  - `attempt={2}` (ou qualquer valor diferente de 1) → `"Senha incorreta, no próximo erro
    sua senha será bloqueada."`
  - Passar `errorText` explicitamente **sempre** tem prioridade sobre a mensagem automática.
- **`state="blocked"` substitui todo o conteúdo.** Quando bloqueado, o componente não
  renderiza mais os dígitos — mostra um ícone de erro (`Icon type="error"`), título,
  descrição e um `Button variant="link"` de ação (`blockedActionLabel` /
  `onBlockedAction`). Não há como voltar ao estado de digitação sem trocar `state`
  externamente (o controle de tentativas é responsabilidade do consumidor).
- **Máscara sempre ativa.** Diferente do `OTPInput` genérico (que tem `masked` opcional,
  default `false`), aqui os dígitos são **sempre** exibidos como `type="password"`
  (bolinhas) — coerente com o caráter secreto de uma senha transacional.
- **Sem reenvio.** `SenhaTransacional` não expõe `onResend`/`resendSeconds`/`sentMessage`
  do `OTPInput` — não é um código enviado por canal externo, é uma senha que o usuário já
  possui de cor.
- **`theme="dark"`** aplica `data-theme="dark"` tanto no wrapper de bloqueio quanto no
  `OTPInput` interno, mantendo consistência visual em fundos escuros.

---

## Exemplos

```tsx
import { SenhaTransacional } from '@srm/diamond';

// Básico — 4 dígitos, tema padrão
// Não é controlado por `value`: os dígitos são estado interno do OTPInput;
// use onChange/onComplete para observar o código digitado.
function ConfirmarTransferencia() {
  return (
    <SenhaTransacional
      onChange={(code) => console.log('Dígitos até agora:', code)}
      onComplete={(code) => console.log('Senha completa:', code)}
    />
  );
}
```

```tsx
// Fluxo completo com contagem de tentativas e bloqueio
function SenhaTransacionalFlow() {
  const [attempt, setAttempt] = useState<1 | 2>(1);
  const [state, setState] = useState<'default' | 'error' | 'blocked'>('default');

  const handleComplete = async (code: string) => {
    const ok = await validarSenha(code);
    if (ok) {
      // prosseguir com a transação
      return;
    }
    if (attempt === 2) {
      setState('blocked');
      return;
    }
    setAttempt(2);
    setState('error');
  };

  return (
    <SenhaTransacional
      state={state}
      attempt={attempt}
      onComplete={handleComplete}
      onBlockedAction={() => window.open('/atendimento', '_blank')}
    />
  );
}
```

```tsx
// Erro na 1ª tentativa
<SenhaTransacional state="error" attempt={1} />
// → "Senha incorreta, tentativa 1 de 3."

// Erro na 2ª tentativa (aviso de bloqueio iminente)
<SenhaTransacional state="error" attempt={2} />
// → "Senha incorreta, no próximo erro sua senha será bloqueada."

// Mensagem de erro customizada (sobrepõe a automática)
<SenhaTransacional state="error" errorText="Senha temporariamente indisponível." />

// Bloqueado — substitui o campo pela tela de bloqueio
<SenhaTransacional
  state="blocked"
  blockedTitle="Conta bloqueada"
  blockedDescription="Fale com o seu assessor para desbloquear."
  blockedActionLabel="Falar com assessor"
  onBlockedAction={() => abrirChat()}
/>

// Comprimento customizado (senha de 6 dígitos) e tema escuro
<SenhaTransacional length={6} theme="dark" label="Senha de 6 dígitos" />
```

---

## Acessibilidade

- Cada dígito recebe `aria-label="Dígito N de {length}"` automaticamente (herdado do
  `OTPInput`) — não é necessário (nem possível) customizar esse rótulo.
- Em `state="error"`, os inputs recebem `aria-invalid` e a mensagem de erro é renderizada
  como texto associado visualmente (ícone `AlertCircle` + texto) logo abaixo dos dígitos.
- Na tela de bloqueio, o ícone (`Icon type="error"`) é puramente visual; título e descrição
  são texto real (`<p>`), lidos normalmente por leitores de tela.
- O botão de ação de bloqueio é um `Button variant="link"` real — navegável por teclado
  (Tab/Enter) e com foco visível.
- Como o campo é sempre mascarado (`type="password"`), oriente o usuário via `label`/
  `helperText` externo de que os dígitos digitados não ficam visíveis — não há toggle de
  "mostrar senha" neste componente.

## Armadilhas comuns

- **Não** existe controle interno de tentativas: `attempt` e `state="blocked"` precisam
  ser geridos pelo componente pai (ex.: contador de erros vindo da API). O componente só
  *exibe* a mensagem certa para o `attempt` informado.
- `attempt` só aceita `1 | 2` — para políticas de mais de 2 tentativas antes do bloqueio,
  este componente não é adequado; use `OTPInput` com mensagens próprias.
- Ao passar `errorText`, a tabela automática de mensagens é ignorada — útil para erros que
  não são "senha incorreta" (ex.: erro de rede), mas tome cuidado para não perder a
  contagem de tentativas na comunicação ao usuário.
- Depois de `state="blocked"`, o componente **não** renderiza mais nenhum input — não
  tente ler `onChange`/`onComplete` nesse estado, eles simplesmente não disparam mais.
- `onBlockedAction` é opcional: se omitido, o botão "Canais de atendimento" (ou label
  customizado) é renderizado mas não faz nada ao ser pressionado — sempre forneça essa
  prop em produção.
