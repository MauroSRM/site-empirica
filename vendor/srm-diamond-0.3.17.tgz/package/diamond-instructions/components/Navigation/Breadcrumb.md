# Breadcrumb

Trilha de navegação hierárquica (breadcrumbs). Renderiza HTML semântico —
`<nav><ol><li>` — com separador visual (`Icon` `chevron-right`) entre os itens, onde
todos os itens exceto o último são links clicáveis e o último é sempre estático com
`aria-current="page"`. Não é construído sobre `react-aria-components`. O truncamento é
modelado internamente como uma lista de nós tipados (`{ kind: 'item' }` |
`{ kind: 'ellipsis' }`) — não há um item "sentinela" artificial inserido no array de
`items` recebido via props.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/Breadcrumb/`
- **Export:** `import { Breadcrumb } from '@srm/diamond';` (também exporta os tipos `BreadcrumbItem` e `BreadcrumbProps`)
- **Relacionados:** nenhum componente de navegação equivalente na mesma pasta; para abas de navegação use `TabBar`, para menu lateral use os componentes de `Sidebar`.

---

## Quando usar

- Indicar a posição atual do usuário em uma hierarquia de navegação profunda (ex.:
  `Início > Minha Carteira > Investimentos > Renda Fixa > Tesouro Direto > Tesouro IPCA+ > IPCA+ 2035 > Comprar`).
- Permitir voltar rapidamente a níveis anteriores em fluxos de várias etapas (ex.: drill-down
  de carteira → classe de ativo → produto → tela de compra).
- Telas com estrutura de árvore fixa e previsível (relatórios, catálogos de produtos,
  configurações aninhadas).

## Quando **não** usar

- Navegação entre seções irmãs do mesmo nível (abas) → use [`TabBar`](./TabBar.md).
- Histórico de navegação livre do navegador (back/forward) → isso é responsabilidade do router,
  não do Breadcrumb.
- Menu de ações ou dropdown para os itens ocultos pelo truncamento — o Breadcrumb **não** oferece
  isso; o nó `···` é puramente visual (veja Armadilhas comuns).

---

## Interface

```ts
interface BreadcrumbItem {
  label:    string;
  href?:    string;
  onClick?: () => void;
}

interface BreadcrumbProps {
  items:      BreadcrumbItem[];
  truncated?: boolean;  // default: false — colapsa manualmente para [primeiro, '···', último]
  ariaLabel?: string;   // default: 'breadcrumb' — rótulo acessível do <nav>
}

function Breadcrumb({ items, truncated = false, ariaLabel = 'breadcrumb' }: BreadcrumbProps): JSX.Element;
```

### Estrutura semântica

O componente sempre renderiza `<nav aria-label={ariaLabel}><ol><li>...</li></ol></nav>` —
cada item visível (real ou `···`) é um `<li>`; dentro do `<li>` vem o conteúdo (`<a>` ou
`<span>`) seguido, quando não é o último nó, de um `<span aria-hidden="true">` com o
separador (`Icon` `chevron-right`, `size={12}`).

### Comportamento de truncamento (não-óbvio)

O componente decide o que exibir com esta ordem de prioridade, construindo internamente
uma lista de `BreadcrumbNode` (`{ kind: 'item', item, index }` | `{ kind: 'ellipsis' }`):

1. **`items.length > 4`** → truncamento **automático e incondicional** (ignora `truncated`):
   exibe `[primeiro, '···', penúltimo, último]` — 4 nós visíveis no total.
2. Senão, se **`truncated === true` e `items.length > 2`** → exibe `[primeiro, '···', último]`.
3. Senão → exibe todos os `items` sem alteração, cada um como seu próprio nó `item`.

O nó `ellipsis` não corresponde a nenhum `BreadcrumbItem` real — é inserido pela função
`buildNodes` apenas para fins de render; não existe um item fake com `label: '···'` sendo
adicionado ao array de `items` original.

### Regras de renderização por item

- O **último item do array original** (`index === items.length - 1`) é sempre um
  `<span aria-current="page">` — nunca um link, mesmo que o item original tenha
  `href`/`onClick`. Essa checagem é feita pelo índice original do item, não pela posição
  do nó truncado.
- O nó `ellipsis` é renderizado como `<span aria-hidden="true">···</span>`, sem interação,
  com `key="ellipsis"`.
- Os demais itens são `<a>`: se o item tiver `href`, o link navega normalmente; se **não**
  tiver `href`, o clique chama `event.preventDefault()` e depois `item.onClick?.()` — ou
  seja, o `href` ausente vira `"#"` mas a navegação de página é bloqueada, delegando 100%
  ao `onClick` (padrão para integração com SPA routers).
- O separador (`Icon` `chevron-right`, `size={12}`, `aria-hidden`) aparece após todo nó
  que não é o último da lista renderizada (item ou ellipsis).
- `nav` tem `aria-label={ariaLabel}`, com default `'breadcrumb'` — customizável via prop
  (ver Interface).

---

## Exemplos

```tsx
import { Breadcrumb } from '@srm/diamond';

// Básico — sem truncamento, 3 itens
<Breadcrumb
  items={[
    { label: 'Início', href: '/' },
    { label: 'Minha Carteira', href: '/carteira' },
    { label: 'Investimentos' }, // último — sempre estático
  ]}
/>

// Truncamento manual (3–4 itens) — vira [primeiro ··· último]
<Breadcrumb
  truncated
  items={[
    { label: 'Início', href: '/' },
    { label: 'Investimentos', href: '/investimentos' },
    { label: 'Renda Fixa', href: '/investimentos/renda-fixa' },
    { label: 'Tesouro IPCA+' },
  ]}
/>

// Truncamento automático — com 5+ itens, colapsa sozinho independente de `truncated`
<Breadcrumb
  items={[
    { label: 'Início', href: '#' },
    { label: 'Minha Carteira', href: '#' },
    { label: 'Investimentos', href: '#' },
    { label: 'Renda Fixa', href: '#' },
    { label: 'Tesouro Direto', href: '#' },
    { label: 'Tesouro IPCA+', href: '#' },
    { label: 'IPCA+ 2035', href: '#' },
    { label: 'Comprar' },
  ]}
/>
// Resultado exibido: [Início, ···, Tesouro IPCA+ (penúltimo), Comprar (último)]

// Rótulo acessível customizado (mais de um Breadcrumb na mesma tela)
<Breadcrumb
  ariaLabel="Navegação: produto"
  items={[{ label: 'Produtos', href: '/produtos' }, { label: 'Tesouro IPCA+' }]}
/>

// Integração com SPA router (sem href, apenas onClick)
import { useNavigate } from 'react-router-dom';

function CarteiraBreadcrumb() {
  const navigate = useNavigate();
  return (
    <Breadcrumb
      items={[
        { label: 'Início', onClick: () => navigate('/') },
        { label: 'Minha Carteira', onClick: () => navigate('/carteira') },
        { label: 'Renda Fixa' }, // atual — sem onClick necessário
      ]}
    />
  );
}
```

---

## Acessibilidade

- O `<nav>` usa `aria-label={ariaLabel}` (default `'breadcrumb'`) — customize via prop
  quando houver mais de um `Breadcrumb`/landmark de navegação na mesma tela, para que
  leitores de tela distingam qual trilha está sendo anunciada.
- O item atual (último do array original) recebe `aria-current="page"`, sinalizando a
  leitores de tela qual é a localização corrente.
- O separador é `aria-hidden`, então não é lido pelo leitor de tela.
- Os links (`<a>`) usam `href` real quando disponível — favoreça sempre fornecer `href`
  além de `onClick` quando a rota existir, para manter navegação por teclado, abrir em
  nova aba (Ctrl/Cmd+clique) e indexação correta.
- A estrutura `<nav><ol><li>` comunica a leitores de tela quantos itens existem na trilha
  e a posição relativa de cada um, mesmo com o truncamento visual ativo.

## Armadilhas comuns

- **O nó `'···'` não é um menu** — os itens ocultos pelo truncamento (automático ou
  manual) não ficam acessíveis em lugar nenhum da UI. Se o usuário precisa navegar para
  um nível intermediário oculto, o Breadcrumb não é a ferramenta certa sozinho; considere
  manter a lista completa (sem truncar) ou complementar com outra navegação.
- **O truncamento automático (`length > 4`) prevalece sobre `truncated={false}`** — não é
  possível forçar a exibição de todos os itens quando há mais de 4; isso é uma decisão de
  design fixa no componente.
- **O último item nunca é clicável**, mesmo que você passe `href`/`onClick` nele — é
  sempre renderizado como texto estático. Não dependa de interação no item final.
- **`href` ausente não gera link real** — sem `href`, o componente usa `"#"` e bloqueia a
  navegação padrão via `preventDefault()`, esperando que `onClick` cuide da navegação
  (roteador SPA). Se esquecer o `onClick`, o item vira um link morto.
- Os `key`s dos itens reais são o índice original do array; evite reordenar `items`
  dinamicamente de forma que quebre a identidade visual/A11y esperada entre renders.
