# DateRangePicker

Seletor de **intervalo** de datas (início e fim) com campos segmentados (dia/mês/ano) e
calendário em popover ancorado via **floating-ui**. Construído sobre `DateRangePicker` +
`RangeCalendar` do `react-aria-components`, com o mesmo "chrome" de calendário
(navegação, seleção rápida de mês/ano, tema) compartilhado com o `DatePicker`.
Datas internas são manipuladas com `@internationalized/date` (`CalendarDate`).

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/DateRangePicker/`
- **Export:** `import { DateRangePicker, getDefaultRangePresets } from '@srm/diamond';`
- **Relacionados:** [DatePicker](./DatePicker.md) (data única) · base visual dos campos
  compartilhada com `_shared/Calendar` (não documentada isoladamente — é implementação interna)

---

## Quando usar

- Filtros de período em relatórios, extratos, históricos de transações (ex.: "movimentações
  entre 01/07 e 15/07").
- Definição de janelas de análise (competência, vigência de contrato, período de apuração).
- Reservas ou agendamentos com estadia/vigência de N dias (`minRangeDays`/`maxRangeDays`).
- Quando o usuário precisa escolher **duas** datas relacionadas (início e fim) como uma
  única unidade de valor.

## Quando **não** usar

- Uma única data (nascimento, vencimento, data de referência) → use [`DatePicker`](./DatePicker.md).
- Duas datas **independentes** sem relação de intervalo (ex.: "data de emissão" e "data de
  entrega" em contextos não sequenciais) → prefira dois [`DatePicker`](./DatePicker.md) separados.
- Seleção de hora → nenhum dos dois componentes cobre horário; seria necessário um campo à parte.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';
import type { InputSize, InputState, InputTheme } from '@srm/diamond'; // vocabulário compartilhado dos Inputs

/**
 * Range de datas — ou `null` quando vazio. Cada ponta é uma string:
 * na ENTRADA aceita ISO `YYYY-MM-DD` ou BR `dd/mm/aaaa`; na SAÍDA
 * (onChange) sempre ISO `YYYY-MM-DD`.
 */
type DateRangeValue = { start: string; end: string } | null;

/** Preset exibido como atalho no painel lateral do popover. */
interface DateRangePreset {
  label: string;                          // ex.: 'Últimos 7 dias'
  value: { start: string; end: string };   // ISO ou BR em cada ponta
}

interface DateRangePickerProps {
  state?: InputState;                     // default: 'default' ('default' | 'error' | 'disabled' | 'read-only')
  size?: InputSize;                       // default: 'md' ('sm' | 'md')
  theme?: InputTheme;                     // default: 'default' ('default' | 'dark')
  label?: ReactNode;
  placeholder?: string;                   // default: 'dd/mm/aaaa' — aria-label de cada segmento vazio
  helperText?: ReactNode;
  errorText?: ReactNode;
  required?: boolean;                     // default: false
  value?: DateRangeValue;                 // controlado
  defaultValue?: DateRangeValue;          // não-controlado
  onChange?: (value: DateRangeValue) => void; // sempre emite ISO em start/end (ou null)
  minValue?: string;                      // data absoluta mínima (ISO ou BR) — limita o calendário
  maxValue?: string;                      // data absoluta máxima (ISO ou BR) — limita o calendário
  minRangeDays?: number;                  // tamanho MÍNIMO do intervalo (dias corridos, inclusive)
  maxRangeDays?: number;                  // tamanho MÁXIMO do intervalo (dias corridos, inclusive)
  presets?: DateRangePreset[];            // atalhos no painel lateral — ver getDefaultRangePresets()
  visibleMonths?: 1 | 2 | 3;              // default: 1
  fullWidth?: boolean;                    // default: false
  className?: string;
  ref?: Ref<HTMLDivElement>;              // encaminhado ao wrapper externo (não ao input)
}

/** Fábrica dos presets padrão em pt-BR (Hoje, Últimos 7/30 dias, Este mês, Mês passado, Este ano). */
function getDefaultRangePresets(): DateRangePreset[];
```

> **Nota:** diferente dos demais campos de texto (`CurrencyInput`, `TextInput` etc.),
> `DateRangePickerProps` **não estende** `InputBaseProps` — é uma interface própria (o
> componente não é um `<input>` de texto simples, e sim um par de `DateInput` segmentados +
> um `RangeCalendar`). Ainda assim replica o mesmo vocabulário visual (`state`, `size`,
> `theme`, `label`, `helperText`, `errorText`, `required`) para consistência com o restante
> dos Inputs. Não há `forceFocus` nem passthrough de `TextFieldProps` — apenas as props
> listadas acima existem.

### Comportamentos não-óbvios

- **Ritmo fixo da grade de dias**: cada linha mede `var(--space-10)` (40px) com a célula em
  `var(--space-9)` (36px), independentemente de o mês ter 5 ou 6 semanas — a faixa do range
  fica com a mesma folga vertical entre semanas em qualquer mês. O piso de altura
  (`--calendar-grid-height`) fica no wrapper da grade, não na `<table>`: na table o browser
  distribuiria a sobra entre as linhas e o espaçamento variaria de mês para mês.
- **Distribuição horizontal do campo**: `dd/mm/aaaa – dd/mm/aaaa` fica agrupado à esquerda e
  o ícone de calendário é empurrado para a direita (`margin-left: auto`). Alargar o campo
  aumenta só o espaço entre as datas e o ícone — os dois inputs não se espalham pela largura.

- **Entrada flexível, saída fixa**: `value`/`defaultValue`/`minValue`/`maxValue`/`presets`
  aceitam cada ponta em ISO (`YYYY-MM-DD`) **ou** BR (`dd/mm/aaaa`) — útil para consumir
  direto do backend (ISO) sem conversão. `onChange` **sempre** emite ISO nas duas pontas.
- **`minValue`/`maxValue` vs. `minRangeDays`/`maxRangeDays`**: os dois primeiros limitam
  **datas absolutas** que existem no calendário (ex.: não deixar escolher o passado); os
  dois últimos limitam o **tamanho do intervalo** em relação à primeira data clicada (ex.:
  reserva de 3 a 30 noites). São independentes e podem ser combinados.
- **`maxRangeDays` é bloqueio visual e ativo**: assim que a 1ª ponta é escolhida, os dias que
  excederiam o limite já aparecem riscados/indisponíveis no calendário (`isDateUnavailable`
  do RAC) — o usuário não precisa tentar clicar para descobrir.
- **`minRangeDays` só é validado no commit (2º clique)**: por limitação do algoritmo de
  seleção do react-aria-components (tratar "mínimo" como parede monotônica travaria o
  calendário inteiro no 1º clique — ver JSDoc de `createMaxRangeUnavailable` no fonte), um
  intervalo mais curto que o mínimo **não dispara `onChange`** — o valor simplesmente não
  muda e o usuário seleciona de novo (o RAC já limpa a âncora internamente).
- **`presets`**: cada item é `{ label, value: { start, end } }`; ao clicar, aplica o range e
  **fecha o popover automaticamente**. Use `getDefaultRangePresets()` para o conjunto padrão
  em pt-BR (Hoje / Últimos 7 dias / Últimos 30 dias / Este mês / Mês passado / Este ano) ou
  passe uma lista própria.
- **Contagem de dias é inclusiva**: `minRangeDays`/`maxRangeDays` contam as duas pontas — um
  range de 10 a 13 tem "span" de 4 dias, não 3.
- **`visibleMonths`**: 1, 2 ou 3 meses lado a lado no calendário (útil para intervalos que
  cruzam a virada do mês).
- **Título do calendário abre seleção rápida de mês/ano**: clicar no cabeçalho (ex.: "Julho
  2026") troca para uma grade de meses e depois de anos — não precisa navegar mês a mês.
- **`ref`** aponta para o `<div>` wrapper externo do campo, não para um `<input>` (o
  componente não expõe um elemento DOM único de input — são dois `DateSegment` internos).
- **Erro força `isInvalid`**: `state="error"` **ou** presença de `errorText` já marcam o
  campo como inválido (`isError = state === 'error' || Boolean(errorText)`).

---

## Exemplos

```tsx
import { useState } from 'react';
import { DateRangePicker, getDefaultRangePresets } from '@srm/diamond';
import type { DateRangeValue } from '@srm/diamond';

// Básico (não-controlado)
<DateRangePicker label="Período" />

// Valor inicial vindo do backend (ISO), controlado
function FiltroPeriodo() {
  const [periodo, setPeriodo] = useState<DateRangeValue>({ start: '2026-07-01', end: '2026-07-15' });
  return (
    <DateRangePicker
      label="Período de apuração"
      value={periodo}
      onChange={setPeriodo}
    />
  );
}

// Dois meses lado a lado (facilita intervalos que cruzam o mês)
<DateRangePicker label="Período" visibleMonths={2} />

// Com atalhos padrão (Hoje, Últimos 7 dias, Este mês, ...)
<DateRangePicker
  label="Período com atalhos"
  presets={getDefaultRangePresets()}
  visibleMonths={2}
/>

// Limitando datas absolutas (só o trimestre atual é selecionável)
<DateRangePicker
  label="Período dentro do trimestre"
  minValue="2026-07-01"
  maxValue="2026-09-30"
  visibleMonths={2}
/>

// Reserva com no máximo 14 noites (dias excedentes já aparecem riscados)
<DateRangePicker
  label="Reserva"
  maxRangeDays={14}
  helperText="Selecione até 14 dias corridos."
/>

// Estadia mínima de 3 noites (intervalo curto demais não confirma)
<DateRangePicker
  label="Estadia"
  minRangeDays={3}
  helperText="Selecione pelo menos 3 dias corridos."
/>

// Janela combinada: de 3 a 30 dias
<DateRangePicker
  label="Período"
  minRangeDays={3}
  maxRangeDays={30}
  helperText="Selecione entre 3 e 30 dias corridos."
/>

// Estado de erro
<DateRangePicker
  label="Período"
  state="error"
  errorText="Selecione um intervalo válido."
/>

// Somente leitura / desabilitado
<DateRangePicker label="Período" state="read-only" defaultValue={{ start: '2026-01-01', end: '2026-01-31' }} />
<DateRangePicker label="Período" state="disabled" />

// Tema escuro (sobre header brand) — o popover herda data-theme="dark" mesmo em portal
<DateRangePicker label="Período" theme="dark" />

// Largura total
<DateRangePicker label="Período" fullWidth />
```

### Integração com React Hook Form

```tsx
import { Controller } from 'react-hook-form';
import { DateRangePicker } from '@srm/diamond';

<Controller
  name="periodo"
  control={control}
  render={({ field, fieldState }) => (
    <DateRangePicker
      label="Período"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Cada ponta (`start`/`end`) é um `DateInput` com segmentos (`DateSegment`) navegáveis por
  teclado (setas, dígitos) — comportamento nativo do react-aria-components.
- O `placeholder` é usado como `aria-label` de cada segmento vazio — mantenha-o descritivo
  (`'dd/mm/aaaa'` por padrão já comunica o formato esperado).
- O calendário abre em um `role="dialog"` via popover; erros são anunciados por `FieldError`
  associado ao campo (react-aria-components).
- O separador visual (`–`) entre os dois `DateInput` é `aria-hidden` — decorativo.
- O `<div role="group">` que envolve os dois inputs recebe o clique que abre o calendário —
  clicar em qualquer parte do grupo (não só no ícone) abre o popover.
- Sempre forneça `label`; é o rótulo semântico do campo como um todo (associado via
  `Label` do react-aria-components).

## Armadilhas comuns

- **Não** assuma que `value`/`defaultValue` precisam estar em ISO — aceitam BR também; mas
  **`onChange` sempre devolve ISO**, então trate o retorno de forma consistente (não espere
  BR de volta).
- **`minRangeDays`** não bloqueia visualmente nenhum dia (diferente de `maxRangeDays`) — um
  intervalo curto demais simplesmente não confirma; se o usuário não perceber, pode parecer
  que "nada aconteceu". Combine com `helperText` explicando o mínimo exigido (ver stories
  **Com range mínimo**).
- Não confunda `minValue`/`maxValue` (datas absolutas) com `minRangeDays`/`maxRangeDays`
  (tamanho do intervalo) — são mecanismos independentes e resolvem problemas diferentes.
- `ref` aponta para o wrapper (`<div>`), não para um `<input>` — não tente chamar `.focus()`
  ou ler `.value` diretamente nele.
- Ao usar `presets`, lembre que o clique já fecha o popover e aplica `onChange` — não é
  necessário nenhum passo de confirmação adicional.
