# Tag

Etiqueta compacta (`<span>`) para rotular, classificar ou filtrar informações — status,
categorias, filtros ativos. Suporta 6 variantes semânticas de cor, 3 tamanhos, ícone
decorativo opcional e um modo removível com botão de fechar acessível. Construído sobre
`Button` do `react-aria-components` (apenas para o botão de remoção) e `class-variance-authority`
(CVA) para as variantes de estilo.

- **Categoria:** Data Display
- **Fonte:** `src/components/DataDisplay/Tag/`
- **Export:** `import { Tag } from '@srm/diamond';`
- **Relacionados:** [RiskBadge](./RiskBadge.md) (selo específico de risco, sem
  ícone/remoção); usado internamente por [ApprovalRow](./ApprovalRow.md),
  [DocumentRow](./DocumentRow.md), [PermissionRow](./PermissionRow.md) e
  [AuditLine](./AuditLine.md) para os selos de status/prioridade.

---

## Quando usar

- Rotular status de um registro (ex.: `success` para "Ativo", `error` para "Inadimplente",
  `warning` para "Pendente").
- Exibir categorias/classificações em listas, cards ou tabelas (ex.: tipo de fundo, classe de
  ativo, segmento de cliente).
- Filtros ativos removíveis em uma barra de busca/listagem (`removable` + `onRemove`).
- Destacar marca/produto com as variantes `brandPrimary` / `brandAccent`.

## Quando **não** usar

- Ação clicável com propósito próprio (não é apenas remover um filtro) → use
  [`Button`](../Forms/Button.md) ou [`IconButton`](../Forms/IconButton.md).
- Notificação de contagem sobreposta a um ícone (badge numérico) → não é o propósito do `Tag`;
  procure um componente de badge/contador se existir no design system.
- Texto longo ou descritivo → `Tag` é para rótulos curtos (`white-space: nowrap`, `max-width: fit-content`);
  conteúdo extenso quebra o layout.
- Selo específico de nível de risco → prefira [`RiskBadge`](./RiskBadge.md), que já fixa o
  vocabulário `high`/`medium`/`low`/`unknown`.

---

## Interface

```ts
import type { ComponentPropsWithoutRef, Ref } from 'react';
import type { VariantProps } from 'class-variance-authority';

type TagVariant =
  | 'brandPrimary' // fundo --tag-brand-bg, texto --text-brand — default do CVA
  | 'brandAccent'  // fundo --brand-accent-light, texto --text-accent
  | 'success'      // fundo --success-subtle, texto --success-strong
  | 'warning'      // fundo --warning-subtle, texto --warning-strong
  | 'error'        // fundo --error-subtle, texto --error-strong
  | 'info';        // fundo --feedback-info-bg, texto --tag-neutral-color

type TagSize = 'sm' | 'md' | 'lg';

interface TagProps extends ComponentPropsWithoutRef<'span'>, VariantProps<typeof tagVariants> {
  variant?: TagVariant;         // default: 'brandPrimary' (defaultVariants do CVA)
  size?: TagSize;               // default: 'md'
  removable?: boolean;          // default: false — exibe botão de remoção (X)
  icon?: boolean;                // default: false — exibe ícone decorativo "tag" (átomo Icon)
  onRemove?: () => void;        // chamado ao ativar o botão de remoção
  removeLabel?: string;         // default: 'Remover' — aria-label do botão de remoção
  className?: string;           // mesclado às classes do CVA
  ref?: Ref<HTMLSpanElement>;
  // Herdado de ComponentPropsWithoutRef<'span'>: id, style, aria-*, data-*, onClick, ...
}
```

### Notas de comportamento

- O elemento raiz é um `<span>`, não um `<button>` — o `Tag` em si **não é interativo**;
  apenas o botão de remoção (quando `removable`) é focável e acionável via `react-aria-components`.
- `icon` é booleano e **não aceita ícone customizado**: quando `true`, sempre renderiza o
  ícone `"tag"` do átomo `Icon` (`circle={false}`, `size=8`, via `TAG_ICON_SIZE`),
  puramente decorativo.
- `removable` adiciona um `AriaButton` interno com o ícone `"x"` do átomo `Icon`
  (`size=10`, via `TAG_REMOVE_ICON_SIZE`) e `aria-label={removeLabel}`. O clique/Enter/Espaço
  disparam `onRemove`.
- Se `removable` for `true` mas `onRemove` não for passado, o botão aparece e é focável, porém
  não faz nada ao ser acionado (`onRemove?.()` é um no-op silencioso).
- `size` controla altura (20/22/24px) e tipografia (`--text-10` em `sm`/`md`, `--text-11` em
  `lg`), não o ícone — os ícones têm tamanho fixo (8px decorativo, 10px de remoção)
  independente de `size`.
- Não há prop `theme` — ao contrário de inputs/botões do Diamond, `Tag` não tem variante dark
  explícita; as cores vêm de tokens (`--success-*`, `--warning-*`, `--error-*`, `--tag-*`,
  `--brand-*`) que já respondem ao tema global.
- `className` é mesclado pelo CVA às classes de variante/tamanho — não sobrescreve, soma-se.
- Não existe mais a variante `'neutral'` (removida na uniformização da Fase 4) — para o
  antigo uso de "categoria neutra sem semântica forte", use `variant="info"`.

---

## Exemplos

```tsx
import { Tag } from '@srm/diamond';

// Básico (variant default: 'brandPrimary')
<Tag>Novo</Tag>

// Status semânticos
<Tag variant="success">Ativo</Tag>
<Tag variant="warning">Pendente</Tag>
<Tag variant="error">Inadimplente</Tag>
<Tag variant="info">Em análise</Tag>

// Marca
<Tag variant="brandPrimary">Diamond</Tag>
<Tag variant="brandAccent">Premium</Tag>

// Tamanhos
<Tag size="sm">Pequena</Tag>
<Tag size="md">Média</Tag>
<Tag size="lg">Grande</Tag>

// Com ícone decorativo
<Tag icon>Categoria</Tag>

// Removível (filtro ativo)
function FiltroAtivo() {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;
  return (
    <Tag removable onRemove={() => setVisible(false)} removeLabel="Remover filtro de status">
      Status: Ativo
    </Tag>
  );
}

// Lista de filtros removíveis
function FiltrosAplicados({ filtros, onRemoveFiltro }) {
  return (
    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
      {filtros.map((f) => (
        <Tag key={f.id} variant="info" removable onRemove={() => onRemoveFiltro(f.id)}>
          {f.label}
        </Tag>
      ))}
    </div>
  );
}
```

---

## Acessibilidade

- O botão de remoção usa `AriaButton` do `react-aria-components`, logo cobre teclado
  (Enter/Espaço) e foco visível (`data-focus-visible` com outline via `--focus-ring`)
  nativamente.
- **Sempre** informe `removeLabel` descritivo quando houver múltiplos `Tag` removíveis na
  mesma tela (ex.: `"Remover filtro de status"` em vez do genérico `"Remover"` padrão) —
  leitores de tela anunciarão apenas o `aria-label`, sem o texto do `Tag` associado.
- Os ícones decorativo (`"tag"`) e de remoção (`"x"`) são renderizados via átomo `Icon` —
  não carregam significado semântico próprio; o rótulo acessível do botão vem inteiramente
  de `removeLabel`.
- Como o `Tag` em si é um `<span>` não interativo, não use `onClick` nele esperando
  comportamento de foco/teclado — não há tratamento de teclado no elemento raiz.

## Armadilhas comuns

- Não confundir `icon` (booleano, ícone fixo `"tag"`) com uma prop de ícone customizável —
  não existe `iconEl` como em `Button`; para outro ícone, não use esta prop.
- Não esperar que `Tag` sozinho seja clicável/navegável — apenas o botão de remoção é
  interativo; para um chip clicável use `Button` com estilo customizado.
- Ao renderizar uma lista de `Tag` removíveis, lembre-se de tratar a remoção no estado do pai
  (`onRemove` não remove o elemento do DOM sozinho — é só um callback).
- Evite texto longo dentro do `Tag`: `white-space: nowrap` e `max-width: fit-content` fazem o
  conteúdo transbordar/cortar visualmente em vez de quebrar linha.
- `variant="neutral"` **não existe mais** — código legado com esse valor não compila; migre
  para `variant="info"`.
