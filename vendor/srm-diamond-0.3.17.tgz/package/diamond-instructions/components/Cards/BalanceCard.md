# BalanceCard

Card de saldo financeiro com duas variantes semânticas: **`primary`** (saldo de uma
conta única do titular na SRM) e **`consolidated`** (soma de saldos de múltiplas
contas, típico de agregação via Open Finance). Compartilha uma mesma anatomia base
(header → caption/balance → footer), mas cada variante troca header e footer e ganha
comportamentos próprios: `consolidated` expõe tendência (`TrendIndicator`), uma lista
de contas em `Overlay` e um estado de **NoConnection** (CTA para conectar contas via
`Callout`). Não é construído sobre `react-aria-components` diretamente — compõe outros
componentes Diamond (`Callout`, `IconButton`, `Button`, `DoubleButton`, `Overlay`,
`Tag`, `TrendIndicator`, `LogoIcon`) e mantém sua própria shell via CSS Modules + CVA.

- **Categoria:** Cards
- **Fonte:** `src/components/Cards/BalanceCard/`
- **Export:** `import { BalanceCard } from '@srm/diamond';`
- **Relacionados:** [Card](./Card.md) (shell visual espelhada em `appearance`), [Callout](../Feedback/Callout.md) (estado NoConnection), [DoubleButton](../Forms/DoubleButton.md) (footer `primary`), [Button](../Forms/Button.md) (footer `consolidated` e trigger do overlay), [IconButton](../Forms/IconButton.md) (toggle de visibilidade), [Overlay](../Feedback/Overlay.md) (lista "Saldo por conta"), [TrendIndicator](../DataDisplay/TrendIndicator.md), [Tag](../DataDisplay/Tag.md)

---

## Quando usar

- Exibir o saldo disponível de **uma conta única** do titular na SRM → `variant="primary"`.
- Exibir a **soma consolidada** de saldos de duas ou mais contas conectadas (ex.: contas
  externas via Open Finance) → `variant="consolidated"`, com `trend`/`trendLabel` e a
  lista detalhada por conta (`accounts`) acessível via overlay "Saldo por conta".
- Telas de dashboard/home onde o usuário precisa ocultar valores monetários rapidamente
  (compliance visual em ambientes compartilhados) — o toggle de olho é nativo do componente.
- Incentivar o usuário a conectar contas externas quando `consolidated` ainda não tem
  nenhuma conta conectada → `connected={false}` ativa o estado NoConnection com CTA.

## Quando **não** usar

- Card genérico sem semântica de saldo (título + conteúdo livre) → use [`Card`](./Card.md).
- Exibição de uma métrica numérica isolada sem contexto de conta/saldo → considere um
  card de métrica/estatística dedicado, não `BalanceCard`.
- Duas variantes na mesma tela ao ponto de confundir a origem do valor — mantenha
  `primary` para conta única SRM e `consolidated` só para agregação multi-conta.
- Substituir o CTA de conexão por um placeholder genérico de "estado vazio" — no
  `NoConnection`, o `Callout` com copy fixa (`NO_CONNECTION_COPY`) é o padrão esperado.

---

## Interface

```ts
import type { HTMLAttributes } from 'react';
import type { CardVariant } from '@srm/diamond'; // reexportado como BalanceCardAppearance

type BalanceCardVariant = 'primary' | 'consolidated';
type BalanceCardAppearance = CardVariant; // 'outlined' | 'elevated' | 'ghost'
type BalanceCardTrend = 'up' | 'down' | 'none';

interface BalanceCardAccount {
  label: string;
  value: string;
}

interface BalanceCardAction {
  label: string;
  onClick?: () => void;
}

interface BalanceCardProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  variant?: BalanceCardVariant;           // default: 'primary'
  appearance?: BalanceCardAppearance;     // default: 'elevated' — borda/sombra/fundo do shell
  maxWidth?: number | string;             // largura máxima do card; número vira px

  loading?: boolean;                      // default: false — troca todo o conteúdo por skeleton
  defaultHidden?: boolean;                // default: false — estado inicial não controlado do toggle
  masked?: boolean;                       // controlado — quando definido, sobrepõe o estado interno
  onToggleVisibility?: () => void;        // chamado a cada clique no ícone de olho

  balance: string;                        // obrigatório — valor já formatado (ex.: "R$ 1.245.860,32")
  balanceLabel: string;                   // obrigatório — rótulo acima do valor (ex.: "Saldo disponível")

  // variant="primary"
  company?: string;
  companyDetail?: string;
  /** @deprecated use companyDetail */
  account?: string;
  primaryAction?: BalanceCardAction;      // sem isso, footer não é renderizado
  secondaryAction?: BalanceCardAction;    // opcional; só some sentido junto de primaryAction

  // variant="consolidated"
  accountCount?: number;                  // default: accounts?.length ?? 0
  accounts?: BalanceCardAccount[];        // default: []
  trend?: BalanceCardTrend;               // default: 'up'
  trendLabel?: string;
  manageAction?: BalanceCardAction;       // sem isso, footer não é renderizado
  defaultAccountsOpen?: boolean;          // abre o overlay "Saldo por conta" por padrão (docs/demo)
  accountsOpen?: boolean;                 // controla o overlay (docs/demo)

  // consolidated — NoConnection
  connected?: boolean;                    // default: true — false ativa o callout de conexão
  onConnectClick?: () => void;            // handler do clique no Callout de NoConnection
  // Herdado de HTMLAttributes<HTMLDivElement> (exceto children): className, style, id, aria-*, ...
}
```

### Notas de comportamento

- **Truncamento de `balance` e `balanceLabel`**: ambos são renderizados em uma única linha
  via `TruncatedText` (`Cards/_shared`) — `white-space: nowrap` + `text-overflow: ellipsis`.
  Quando o conteúdo não cabe, o componente monta um `Tooltip` com o valor completo (gatilho
  não-interativo: hover apenas, fora da ordem de tabulação; leitores de tela já leem o texto
  integral no DOM). O ícone de olho nunca é empurrado para fora do card.
- **`maxWidth`**: injetado como custom property `--balance-card-max-width`. O piso de
  largura usa `min(var(--width-card-min), 100%)`, então um `maxWidth` menor que
  `--width-card-min` (220px) é respeitado sem estourar a caixa. Aceita número (vira px) ou
  string CSS.
- **`loading`** substitui **todo** o conteúdo por `BalanceCardSkeleton`, que já varia o
  layout entre `primary`, `consolidated` (conectado) e `consolidated` NoConnection —
  não é preciso montar skeleton próprio.
- **Visibilidade do saldo** é semi-controlada: existe um `useState` interno inicializado
  por `defaultHidden`, mas se `masked` for passado (`!== undefined`), ele **sempre**
  prevalece sobre o estado interno (`isHidden = masked ?? hidden`). Em uso totalmente
  controlado, atualize `masked` dentro do seu próprio `onToggleVisibility` — o clique no
  ícone sempre dispara `onToggleVisibility` e também alterna o estado interno (que fica
  ignorado enquanto `masked` estiver definido).
- Quando oculto, o valor recebe `visibility: hidden` e uma "pastilha" cinza
  (`.hiddenShape`) cobre visualmente a área — o número não é removido do DOM, apenas
  ocultado visualmente (ainda presente para leitores de tela, ver Acessibilidade).
- **`account` é depreciado** — internamente `companyDetail ?? account ?? ''` é usado
  como segunda linha do header `primary`; prefira sempre `companyDetail`.
- **Footer é opcional e condicional por variante**: em `primary`, só renderiza se
  `primaryAction` for informado (usa [`DoubleButton`](../Forms/DoubleButton.md)
  `pair="primary-ghost"` com `primaryAction`/`secondaryAction`); em `consolidated`, só
  renderiza se `manageAction` for informado (usa [`Button`](../Forms/Button.md)
  `variant="secondary"`). Sem essas actions, o footer simplesmente não existe — não
  há texto/botão padrão hardcoded.
- **NoConnection** (`variant="consolidated"` + `connected={false}`): esconde
  `TrendIndicator`, o botão "Saldo por conta" e a `Tag` de contagem no header; o corpo
  vira um [`Callout`](../Feedback/Callout.md) `variant="ai"` com copy fixa
  (`NO_CONNECTION_COPY`, não customizável via props) e `onClick={onConnectClick}`; o
  footer inteiro não é renderizado (nem que `manageAction` esteja setado).
- **Lista "Saldo por conta"** (`consolidated`, conectado): o botão `variant="link"` abre
  um [`Overlay`](../Feedback/Overlay.md) com uma linha por item de `accounts`
  (`label` + `value`); quando o saldo está oculto (`isHidden`), cada valor vira um bloco
  de skeleton estático (`animated={false}`) em vez do texto real — os valores nunca
  vazam pela lista quando o olho está fechado.
- `accountCount` tem fallback para `accounts.length` — informe explicitamente apenas se
  a contagem divergir da lista completa (ex.: paginação).
- `defaultAccountsOpen`/`accountsOpen` existem para fixar o overlay aberto em
  documentação/demonstração; em produção normalmente não são necessários.
- `className` é mesclado às classes de variante (CVA) no elemento raiz (`<div>`); demais
  props HTML (`style`, `id`, `aria-*`, `data-*`, ...) são espalhadas no mesmo `<div>`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { BalanceCard } from '@srm/diamond';

// Primary — básico, não controlado (toggle interno)
<BalanceCard
  balance="R$ 1.245.860,32"
  balanceLabel="Saldo disponível"
  company="SRM Asset"
  companyDetail="Ag. 0001 · CC 12345-6"
  primaryAction={{ label: 'Transferir', onClick: handleTransfer }}
  secondaryAction={{ label: 'Ver extrato', onClick: handleExtract }}
/>

// Primary — appearance outlined, começa oculto
<BalanceCard
  appearance="outlined"
  balance="R$ 8.400,00"
  balanceLabel="Saldo disponível"
  company="SRM Asset"
  companyDetail="Ag. 0002 · CC 98765-4"
  defaultHidden
  primaryAction={{ label: 'Transferir' }}
/>

// Primary — loading
<BalanceCard
  loading
  balance="R$ 0,00"
  balanceLabel="Saldo disponível"
/>

// Consolidated — conectado, com tendência e lista de contas
<BalanceCard
  variant="consolidated"
  balance="R$ 1.968.975,72"
  balanceLabel="Total consolidado"
  accountCount={2}
  accounts={[
    { label: 'SRM Asset', value: 'R$ 1.245.860,32' },
    { label: 'Open Finance', value: 'R$ 723.115,40' },
  ]}
  trend="up"
  trendLabel="+3,2% no mês"
  manageAction={{ label: 'Gerenciar contas', onClick: handleManage }}
/>

// Consolidated — sem contas conectadas (CTA de Open Finance)
<BalanceCard
  variant="consolidated"
  balance=""
  balanceLabel=""
  connected={false}
  onConnectClick={handleOpenFinanceConnect}
/>

// Consolidated — visibilidade controlada externamente
function ConsolidatedControlled() {
  const [masked, setMasked] = useState(false);
  return (
    <BalanceCard
      variant="consolidated"
      balance="R$ 1.968.975,72"
      balanceLabel="Total consolidado"
      accounts={[{ label: 'SRM Asset', value: 'R$ 1.245.860,32' }]}
      masked={masked}
      onToggleVisibility={() => setMasked((prev) => !prev)}
      manageAction={{ label: 'Gerenciar contas' }}
    />
  );
}
```

---

## Acessibilidade

- O ícone de visibilidade ([`IconButton`](../Forms/IconButton.md)) já traz
  `aria-label` dinâmico ("Exibir saldo" / "Ocultar saldo") — não precisa ser passado.
- Quando oculto, o valor numérico permanece no DOM (`visibility: hidden` + shape por
  cima) — leitores de tela ainda podem anunciá-lo dependendo da implementação; se o
  saldo for realmente sensível, trate a ocultação também na camada de dados (não envie
  o valor real ao client quando não for necessário).
- O botão "Saldo por conta" ganha `aria-label` com a contagem embutida (ex.:
  `"Ver saldo por conta (2 contas)"`), útil quando o texto visível é curto.
- O ícone decorativo do header (`Layers` no `consolidated`) é `aria-hidden`; o título
  textual "Saldo Consolidado" carrega a semântica.
- No estado NoConnection, o CTA é veiculado pelo [`Callout`](../Feedback/Callout.md),
  que já trata foco/role adequados — não sobrescreva com wrappers customizados.

## Armadilhas comuns

- Esperar um footer "padrão" sem passar `primaryAction` (primary) ou `manageAction`
  (consolidated) — sem essas props, **nenhum footer é renderizado**, mesmo que
  `secondaryAction` esteja presente.
- Usar `masked` e depois só atualizar o estado local dentro de `onToggleVisibility`
  esquecendo de também setar `masked` — como `masked` sobrepõe o estado interno, o
  olho vai parecer "não fazer nada" se você não atualizar o valor controlado.
- Passar `connected={false}` em `variant="primary"` esperando o estado NoConnection —
  esse estado só existe para `variant="consolidated"` (`isNoConnection = variant ===
  'consolidated' && !connected`).
- Confiar em `account` (prop depreciada) para novos usos — sempre prefira
  `companyDetail`.
- Customizar a copy do `Callout` de NoConnection via props — o texto é fixo
  (`NO_CONNECTION_COPY`); só o `onConnectClick` é customizável.
- Esquecer que `accountCount` não filtra `accounts` — se as contagens divergirem por
  design, isso não muda quantas linhas aparecem no overlay "Saldo por conta".
