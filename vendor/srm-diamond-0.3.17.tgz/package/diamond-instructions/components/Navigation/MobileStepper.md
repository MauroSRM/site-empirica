# MobileStepper

Versão compacta do [`Stepper`](./Stepper.md) para telas estreitas (mobile): renderiza **apenas**
os indicadores (sem labels visíveis) em uma faixa horizontal, com a opção de derivar o `state`
de cada etapa automaticamente a partir de um índice `current`, dispensando o consumidor de montar
o array de estados manualmente. Reaproveita as mesmas peças internas do `Stepper`
(`StepIndicator`, `StepConnector`), o mesmo modelo de dados `StepItem` e o mesmo mecanismo de
`formatStepLabel` para o texto acessível de cada etapa. Tipos vivem em `Stepper.types.ts`.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/Stepper/MobileStepper.tsx` (tipos em `Stepper.types.ts`)
- **Export:** `import { MobileStepper } from '@srm/diamond';`
- **Relacionados/Base:** [Stepper](./Stepper.md) (variante desktop, tipos `StepItem`/`StepState`/
  `StepSize`/`FormatStepLabel`/`StepAriaInfo` compartilhados)

---

## Quando usar

- Mesmo fluxo multi-step do `Stepper` (onboarding, KYC, abertura de conta, aporte guiado), mas em
  viewport mobile ou qualquer container estreito onde labels de texto não cabem.
- Quando você já sabe apenas o **índice da etapa atual** (`current`) e quer que completed/active/
  inactive sejam inferidos automaticamente, sem montar `state` por etapa.
- Cabeçalho fixo de wizard mobile, acima do conteúdo da etapa, como indicador de progresso puramente
  visual.

## Quando **não** usar

- Desktop / espaço horizontal amplo, onde labels devem ficar visíveis → use
  [`Stepper`](./Stepper.md) (`variant="default"` ou `"vertical"`).
- Quando você precisa que o usuário veja o **nome** de cada etapa, não só a posição — o
  `MobileStepper` nunca renderiza texto de label/subtítulo, mesmo que `StepItem.label` esteja
  preenchido.
- Quando cada etapa já vem com `state` explícito de uma fonte de verdade diferente de `current`
  (ex.: backend informando quais etapas têm erro) — nesse caso prefira sempre passar `state` em
  cada `StepItem` e ignorar a derivação automática (ver Interface).

---

## Interface

```ts
export interface MobileStepperProps {
  steps?:           StepItem[];       // default: []
  current?:         number;           // default: 0 — índice da etapa "atual" para derivação automática de state
  size?:            StepSize;         // default: 'sm' (nota: diferente do Stepper, cujo default é 'md')
  formatStepLabel?: FormatStepLabel;  // default: defaultFormatStepLabel (mesmo default do Stepper)
}

function MobileStepper(props: MobileStepperProps): JSX.Element;
```

`StepItem`, `StepSize`, `FormatStepLabel` e `StepAriaInfo` são os mesmos tipos usados pelo
`Stepper` — veja [Stepper → Interface](./Stepper.md#interface). O default de `formatStepLabel`
gera `"Etapa N de Total: label"` (sem o estado em texto — ver nota de acessibilidade no
`Stepper`).

### Regra de derivação de `state` (não-óbvia)

Para **cada** etapa, o componente decide entre usar o `state` explícito ou derivá-lo de `current`:

```ts
step.state ? step : { ...step, state: i < current ? 'completed' : i === current ? 'active' : 'inactive' }
```

- Se `step.state` já estiver preenchido (qualquer valor truthy, incluindo `'inactive'`, mas
  **não** `undefined`), ele é respeitado **como está** — `current` é ignorado para essa etapa
  específica.
- Se `step.state` estiver ausente, o estado é calculado por comparação de índice com `current`:
  índices menores viram `completed`, o índice igual a `current` vira `active`, os posteriores
  ficam `inactive`.
- Isso permite **misturar** os dois modos no mesmo array: etapas sem `state` seguem `current`,
  etapas com `state` explícito (ex.: `'error'`, `'warn'`, `'completed-locked'`) sobrepõem a
  derivação automática.
- A derivação **não** produz `'error'`, `'warn'` ou `'completed-locked'` automaticamente — esses
  três estados só aparecem se você os definir explicitamente em `StepItem.state`.

### Estrutura de renderização

- Container com `role="list"`; cada etapa é `role="listitem"` com `aria-label` gerado por
  `formatStepLabel({ index, total, state, label })` e `aria-current="step"` quando o `state`
  (explícito ou derivado) é `'active'`.
- `key` de cada item é `step.label ?? i` — etapas sem `label` caem para o índice; evite reordenar
  dinamicamente etapas sem `label` únicos.
- Conectores usam a mesma regra do `Stepper`: preenchido quando a etapa anterior é `completed` ou
  `completed-locked`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { MobileStepper } from '@srm/diamond';
import type { StepItem } from '@srm/diamond';

// Derivação automática por current — forma mais simples
function OnboardingMobile() {
  const [current, setCurrent] = useState(0);
  const steps: StepItem[] = [
    { label: 'Dados' },
    { label: 'Documentos' },
    { label: 'Revisão' },
    { label: 'Conclusão' },
  ];
  return <MobileStepper steps={steps} current={current} />;
}

// Tamanho md (default é 'sm')
<MobileStepper steps={steps} current={1} size="md" />

// Estado explícito para uma etapa com erro, resto derivado de current
<MobileStepper
  current={1}
  steps={[
    { label: 'Dados' },                    // vira 'completed' (índice 0 < current 1)
    { label: 'Documentos', state: 'error' }, // explícito — ignora a derivação
    { label: 'Revisão' },                  // vira 'inactive' (índice 2 > current 1)
  ]}
/>

// Etapa bloqueada explicitamente, sem depender de current
<MobileStepper
  current={2}
  steps={[
    { label: 'Identificação' },
    { label: 'Documentos', state: 'completed-locked' },
    { label: 'Perfil' },
    { label: 'Assinatura' },
  ]}
/>

// formatStepLabel customizado, compartilhando a mesma função usada no Stepper desktop
<MobileStepper
  steps={steps}
  current={1}
  formatStepLabel={({ index, total, label }) => `${index + 1}/${total}${label ? ` · ${label}` : ''}`}
/>
```

---

## Acessibilidade

- Mesmo sem exibir texto visível, cada etapa carrega `aria-label` (via `formatStepLabel`) com
  posição, nome (se houver) e — por padrão — **sem** o estado em texto (ver nota em
  [Stepper → Acessibilidade](./Stepper.md#acessibilidade)); leitores de tela têm informação
  equivalente à versão desktop.
- `aria-current="step"` marca a etapa ativa (explícita ou derivada), permitindo que tecnologia
  assistiva identifique o progresso sem depender de cor/ícone.
- Como não há texto visível, garanta que o **conteúdo da etapa atual** (fora do `MobileStepper`,
  na tela) deixe claro o nome/contexto da etapa para usuários videntes — o indicador sozinho é
  só um resumo de progresso.

## Armadilhas comuns

- **Confundir o default de `size`**: `MobileStepper` usa `'sm'` por padrão, enquanto `Stepper` usa
  `'md'` — se estiver migrando um `Stepper` para `MobileStepper` e quiser manter o tamanho visual,
  passe `size="md"` explicitamente.
- **Esperar que `label`/`subtitle` apareçam**: eles nunca são renderizados como texto; se a tela
  precisa mostrar o nome da etapa atual, renderize esse texto separadamente (ex.: um `<h2>` acima
  do `MobileStepper` com `steps[current].label`).
- **Misturar `state` parcial sem perceber a precedência**: uma etapa com `state: 'inactive'`
  explícito **não** será recalculada por `current`, mesmo que o índice dela seja menor que
  `current` — o valor explícito sempre vence.
- **`current` fora do intervalo de `steps`**: não há checagem de limites; um `current` maior que
  `steps.length` simplesmente faz todas as etapas caírem no ramo `completed` (todo índice é menor
  que `current`), sem erro nem aviso.
- **Esperar o estado no `aria-label` por padrão**: assim como no `Stepper`, o `formatStepLabel`
  default não inclui o `state` como palavra — se seu fluxo depende disso para acessibilidade,
  forneça um `formatStepLabel` customizado (mesmo tipo `FormatStepLabel` do `Stepper`).
