# Diamond Design System — Instruções para Agentes de IA

> **Leia este arquivo primeiro.** Ele define o protocolo de consulta à documentação do
> `@srm/diamond`. O objetivo é você carregar **apenas** a documentação do componente que
> vai implementar — nunca a biblioteca inteira — economizando contexto e tokens.

## Protocolo de consulta (obrigatório)

1. **Precisa usar/implementar um componente?** Abra `components/index.md`.
   É um roteador leve: uma tabela `componente → caminho do doc`, com aliases
   (ex.: "input de dinheiro" → `CurrencyInput`).

2. **Localize a linha** do componente pelo nome ou por um alias descritivo.

3. **Abra somente o `.md` daquele componente** (ex.:
   `components/Forms/Inputs/CurrencyInput.md`). Cada doc é autocontido: import,
   interface de props, tipos, quando usar, quando **não** usar, exemplos, acessibilidade
   e armadilhas.

4. **Precisa de tokens de design** (cores, espaçamento, tipografia, temas)?
   Consulte `design.md`.

**Não** leia `components/index.md` inteiro procurando código — ele só roteia.
**Não** carregue múltiplos docs de componente "por garantia" — carregue sob demanda.

## Estrutura

```
diamond-instructions/
├── AGENTS.md            ← você está aqui (protocolo)
├── design.md            ← tokens de design globais
└── components/
    ├── index.md         ← roteador (comece por aqui ao implementar componentes)
    └── <Categoria>/<Componente>.md
```

A hierarquia de `components/` espelha `src/components/` da biblioteca.

## Regras ao gerar código com Diamond

- Importe sempre de `@srm/diamond` (barrel único). Nunca de caminhos internos.
- Importe os estilos uma vez na raiz da app: `import '@srm/diamond/styles';`.
- Prefira as props documentadas. Se uma prop não está no doc do componente, ela
  provavelmente é um passthrough para `react-aria-components` — confirme antes de usar.
- Respeite os requisitos de acessibilidade marcados em cada doc (ex.: `aria-label`
  obrigatório em botões só-ícone).
