# SearchInput

Campo de busca com ícone de lupa fixo à esquerda e botão de limpar (`X`) que aparece
automaticamente quando há texto digitado. Construído sobre `InputBase` (herda label,
estados, tamanhos e temas) e sobre `Input`/`Button` do `react-aria-components`.

- **Categoria:** Forms / Inputs
- **Fonte:** `src/components/Forms/Inputs/SearchInput/`
- **Export:** `import { SearchInput } from '@srm/diamond';`
- **Base compartilhada:** [InputBase](./_shared.md) · relacionados: [TextInput](./TextInput.md)

---

## Quando usar

- Campo de filtro/busca em listas, tabelas, autocomplete simples, comandos de pesquisa.
- Sempre que o usuário precisar de um jeito rápido de limpar o termo digitado (botão `X`
  aparece sozinho quando `value` não está vazio).
- Buscas dentro de telas internas (fundos claros ou escuros via `theme`).

## Quando **não** usar

- Entrada de texto genérica sem semântica de busca → use [`TextInput`](./TextInput.md).
- Busca com sugestões/autocomplete rico (lista de opções navegável por teclado) → prefira
  um componente de combobox/autocomplete dedicado, se existir no design system; `SearchInput`
  não gerencia lista de sugestões.
- Campos numéricos, monetários ou percentuais → use os inputs mascarados específicos
  ([`CurrencyInput`](./CurrencyInput.md), [`PercentInput`](./PercentInput.md)).

---

## Interface

```ts
import type { Ref } from 'react';
import type { InputBaseProps } from '@srm/diamond'; // herdado internamente

interface SearchInputProps extends InputBaseProps {
  value?: string;                      // valor controlado (default: '')
  placeholder?: string;                // default: 'Pesquisar...'
  onChange?: (value: string) => void;  // recebe o texto puro do <input>
  onClear?: () => void;                // chamado quando o botão "Limpar" é pressionado
  ref?: Ref<HTMLInputElement>;         // encaminhado ao <input> nativo
}
```

### Props herdadas de `InputBaseProps`

| Prop         | Tipo                                                | Default     | Descrição                                                    |
|--------------|-----------------------------------------------------|-------------|--------------------------------------------------------------|
| `label`      | `ReactNode`                                         | —           | Rótulo do campo.                                             |
| `state`      | `'default' \| 'error' \| 'disabled' \| 'read-only'` | `'default'` | Estado visual/funcional do campo.                            |
| `size`       | `'sm' \| 'md'`                                       | `'md'`      | Tamanho.                                                     |
| `theme`      | `'default' \| 'dark'`                                | `'default'` | Use `'dark'` sobre fundos escuros.                          |
| `helperText` | `ReactNode`                                         | —           | Texto de ajuda abaixo do campo.                             |
| `errorText`  | `ReactNode`                                         | —           | Mensagem de erro (exibida quando presente; força `error`).  |
| `required`   | `boolean`                                           | `false`     | Marca o campo como obrigatório (adiciona `*` ao label).     |
| `forceFocus` | `boolean`                                           | `false`     | Força o anel de foco visual (útil em demos/validação).      |
| `className`  | `string`                                            | —           | Classe extra no wrapper do `TextField`.                     |

> Além dessas, `InputBaseProps` estende `TextFieldProps` do `react-aria-components`
> (omitindo o que é gerenciado internamente). Você recebe de graça: `name`, `id`,
> `autoComplete`, `inputMode`, `onBlur`, `onFocus` e atributos `aria-*`.

### Comportamento do botão de limpar

- O botão `X` só é renderizado **quando `value` é truthy** (string não vazia).
- Ao ser pressionado, ele chama, nessa ordem: `onChange?.('')` **e depois** `onClear?.()`.
  Isso significa que `onClear` é útil para efeitos colaterais adicionais (ex.: resetar
  resultados de busca, refazer uma query), não para limpar o próprio valor — isso já é
  feito via `onChange('')`.
- Diferente de `CurrencyInput`/`PercentInput`, **não há máscara**: `onChange` entrega o
  texto cru digitado no `<input>` (`e.target.value`), sem transformação.
- O ícone de lupa (`Search`) é sempre exibido e é `aria-hidden`.

---

## Exemplos

```tsx
import { useState } from 'react';
import { SearchInput } from '@srm/diamond';

// Básico (controlado)
function ListaClientesBusca() {
  const [termo, setTermo] = useState('');
  return (
    <SearchInput
      label="Buscar cliente"
      value={termo}
      onChange={setTermo}
    />
  );
}

// Com onClear (ex.: resetar resultados de uma tabela)
function BuscaComReset() {
  const [termo, setTermo] = useState('');
  return (
    <SearchInput
      label="Buscar"
      value={termo}
      onChange={setTermo}
      onClear={() => console.log('resultados resetados')}
    />
  );
}

// Com ajuda e obrigatório
<SearchInput label="Buscar ativo" required helperText="Digite o ticker ou nome." />

// Estado de erro
<SearchInput
  label="Buscar"
  state="error"
  errorText="Nenhum resultado encontrado."
  value={termo}
  onChange={setTermo}
/>

// Somente leitura
<SearchInput label="Filtro aplicado" state="read-only" value="renda fixa" />

// Desabilitado
<SearchInput label="Buscar" state="disabled" />

// Tema escuro (sobre header/sidebar brand)
<SearchInput label="Buscar" theme="dark" value={termo} onChange={setTermo} />

// Placeholder customizado
<SearchInput label="Buscar fundo" placeholder="Digite o nome do fundo..." />
```

### Integração com React Hook Form

```tsx
<Controller
  name="busca"
  control={control}
  render={({ field, fieldState }) => (
    <SearchInput
      label="Buscar"
      value={field.value}
      onChange={field.onChange}
      onClear={() => field.onChange('')}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

> `SearchInput` é tipicamente usado como campo **não controlado por formulário** (filtro
> de lista, busca instantânea). O exemplo acima é útil quando o termo de busca precisa
> ser validado ou enviado junto de um formulário maior.

---

## Acessibilidade

- O ícone de lupa é `aria-hidden` — o nome acessível do campo vem do `label`. Sempre
  forneça `label` (ou `aria-label`, herdado de `TextFieldProps`) em layouts sem rótulo
  visível.
- O botão de limpar já nasce com `aria-label="Limpar busca"` fixo (não configurável) —
  garanta que essa string faça sentido no idioma/contexto da tela (o componente é pt-BR).
- Erros são anunciados via `FieldError` do `react-aria-components` (associado ao input).
- O botão de limpar é focável e operável por teclado (é um `Button` do react-aria).

## Armadilhas comuns

- Não confunda `onClear` com "limpar o valor" — o próprio componente já limpa via
  `onChange('')` antes de chamar `onClear`. Usar `onClear` para setar `value=''` de novo
  é redundante, não incorreto.
- O botão `X` só aparece com `value` não vazio — se o campo parecer "sem botão de limpar",
  confira se `value` está de fato sendo passado/controlado.
- Não há máscara nem debounce embutidos: se a busca dispara uma chamada de rede a cada
  tecla, implemente debounce no consumidor (ex.: no `onChange` externo).
- `aria-label="Limpar busca"` é fixo em português; não há prop para traduzi-lo.
