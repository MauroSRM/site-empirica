# NavIconButton

Botão de ícone para áreas de navegação (`AppHeader`, barras internas, toolbars). **Compõe**
o [`IconButton`](../Forms/IconButton.md) de `Forms` (herda foco visível, estados de
hover/pressed e a base de acessibilidade) e adiciona um badge numérico posicionado no canto,
com a contagem anunciada no nome acessível do botão.

- **Categoria:** Navigation
- **Fonte:** `src/components/Navigation/NavIconButton/`
- **Export:** `import { NavIconButton } from '@srm/diamond';`
- **Relacionados/Base:** [IconButton](../Forms/IconButton.md) (primitivo composto internamente;
  ícone genérico fora de contexto de navegação)

---

## Quando usar

- Ícones de ação dentro de uma barra de navegação/topo (sino de notificações, busca,
  configurações, menu, avatar/usuário).
- Quando é preciso exibir um contador (badge) sobre o ícone — ex.: número de notificações
  não lidas, mensagens pendentes — com a contagem anunciada para leitores de tela.
- Sobre fundo brand/navy (`theme="brand"`, default) ou sobre fundo claro (`theme="light"`),
  como em barras internas de página.

## Quando **não** usar

- Botão de ícone fora de um contexto de navegação (ex.: ação dentro de um card ou form) →
  use [`IconButton`](../Forms/IconButton.md) diretamente.
- Botão com texto/label visível → use [`Button`](../Forms/Button.md) com `icon="left"`/`"right"`.
- Item de menu de navegação com texto (não apenas ícone) → procure o componente de menu/nav
  apropriado, não force conteúdo textual dentro do `NavIconButton`.

---

## Interface

```ts
import type { ReactNode } from 'react';
import type { IconButtonProps } from '../Forms/IconButton';

type NavIconButtonSize = 'sm' | 'md' | 'lg';
type NavIconButtonTheme = 'brand' | 'light';

interface NavIconButtonProps
  extends Omit<IconButtonProps, 'icon' | 'size' | 'theme' | 'variant' | 'aria-label'> {
  children: ReactNode;              // obrigatório — conteúdo do botão (tipicamente um ícone)
  badge?: number;                   // contador; ausente ou 0 oculta; acima de 9 exibe "9+"
  size?: NavIconButtonSize;         // default: 'md' — repassado ao IconButton primitivo
  theme?: NavIconButtonTheme;       // default: 'brand'
  'aria-label': string;             // obrigatório — nome acessível base (sem a contagem)
  badgeLabel?: (count: number) => string; // default: (count) => `${count} não lidas`
  // Herdado de IconButtonProps (menos icon/size/theme/variant/aria-label):
  // onPress, isDisabled, isPending, type, form, aria-expanded, className, ref, ...
}
```

### Notas de comportamento

- **Composição, não reimplementação.** `NavIconButton` renderiza um `IconButton` internamente
  (`variant="ghost"` fixo, não configurável) passando `children` como `icon`. Isso significa que
  foco visível, estados de hover/pressed e a semântica de botão vêm inteiramente do
  [`IconButton`](../Forms/IconButton.md) — o `NavIconButton` só adiciona o wrapper posicional do
  badge e a tradução do `theme`.
- **`aria-label` é obrigatório na tipagem** (não opcional) — o TypeScript falha a build sem ele.
  Diferente do `IconButton`, aqui ele é o rótulo **base**: quando há badge, o componente compõe
  automaticamente `"${aria-label}, ${badgeLabel(badge)}"` e passa esse texto composto como
  `aria-label` real do `IconButton` interno — não é possível sobrescrever o resultado final via
  prop, apenas ajustar as duas partes (`aria-label` base e `badgeLabel`).
- **Tema:** `theme="brand"` (default) mapeia para `theme="dark"` do `IconButton` — pensado para
  fundo navy/brand. `theme="light"` mapeia para `theme="default"` do `IconButton` — pensado para
  fundo branco/claro. Não há `SIZE_MAP`/estilo inline próprio: os tamanhos de botão vêm dos
  tokens de tamanho do próprio `IconButton` (ver [IconButton](../Forms/IconButton.md)).
- **Badge**: só é renderizado quando `badge !== undefined && badge > 0`. Valores acima de 9
  exibem `"9+"` visualmente (não há truncamento configurável), mas o `badgeLabel` recebe sempre
  a contagem **real** (ex.: `12`, não `"9+"`). O badge visual é `aria-hidden="true"` — a
  contagem só é anunciada via composição no `aria-label`.
- `badgeLabel` permite localizar/customizar o sufixo anunciado (ex.:
  `badgeLabel={(count) => \`${count} novas\`}` → `"Mensagens, 5 novas"`). O default é
  ``(count) => `${count} não lidas` ``.
- O tamanho do badge (`sm`/`md`/`lg`) é resolvido via CVA (`navIconButtonBadgeVariants`,
  exportado do barrel) sobre classes do módulo SCSS — sem variáveis CSS inline.
- O **ícone em si não é dimensionado automaticamente** pelo componente — `size` só afeta as
  dimensões do botão/badge (herdadas do `IconButton`). Cabe ao consumidor passar o ícone já no
  tamanho adequado (convenção usada na story: `sm: 14`, `md: 18`, `lg: 24`).

---

## Exemplos

```tsx
import { NavIconButton } from '@srm/diamond';
import { Bell, Search, Settings, Menu, MessageCircle } from 'lucide-react';

// Básico — sobre header brand/navy (default)
<NavIconButton aria-label="Notificações" onPress={() => navigate('/notificacoes')}>
  <Bell size={18} />
</NavIconButton>

// Com badge de contagem — aria-label anunciado: "Notificações, 3 não lidas"
<NavIconButton badge={3} aria-label="Notificações" onPress={openNotifications}>
  <Bell size={18} />
</NavIconButton>

// Mais de 9 itens — exibe "9+" visualmente, anuncia a contagem real (12)
<NavIconButton badge={12} aria-label="Mensagens" onPress={openMessages}>
  <MessageCircle size={18} />
</NavIconButton>

// badgeLabel customizado
<NavIconButton
  badge={5}
  aria-label="Mensagens"
  badgeLabel={(count) => `${count} novas`}
  onPress={openMessages}
>
  <MessageCircle size={18} />
</NavIconButton>

// Tema light — sobre fundo branco (barra interna de página)
<NavIconButton theme="light" aria-label="Buscar" onPress={openSearch}>
  <Search size={18} />
</NavIconButton>

// Tamanho pequeno
<NavIconButton size="sm" theme="light" aria-label="Configurações" onPress={openSettings}>
  <Settings size={14} />
</NavIconButton>

// Controlando um menu/popover (aria-expanded)
function MenuTrigger() {
  const [open, setOpen] = useState(false);
  return (
    <NavIconButton
      aria-label="Abrir menu"
      aria-expanded={open}
      onPress={() => setOpen((v) => !v)}
    >
      <Menu size={18} />
    </NavIconButton>
  );
}
```

---

## Acessibilidade

- `aria-label` é **obrigatório na tipagem** — o botão não tem texto visível; a build falha em
  tempo de compilação sem ele.
- Quando há `badge`, a contagem é **anunciada** automaticamente compondo o `aria-label`
  (ex.: `"Notificações, 3 não lidas"`) — não é preciso (nem é possível) embutir a contagem
  manualmente no texto do `aria-label` base; use `badgeLabel` para customizar o sufixo.
- O badge visual (`span` com o número/"9+") é `aria-hidden="true"` — o nome acessível vem
  inteiramente do `aria-label` composto, não do conteúdo visual do badge.
- Use `aria-expanded` sempre que o `NavIconButton` for gatilho de um menu, dropdown ou
  painel colapsável, sincronizado com o estado real de aberto/fechado.
- O foco visível e os estados de hover/pressed vêm do `IconButton` primitivo (react-aria) —
  não sobrescreva via CSS customizado.

## Armadilhas comuns

- Esquecer `aria-label` quebra a build (TypeScript) — é intencional, não um bug.
- Tentar passar `variant` — não existe essa prop aqui; o `NavIconButton` fixa
  `variant="ghost"` internamente no `IconButton` composto.
- Esperar que o `aria-label` final seja exatamente o texto passado quando há badge — ele é
  **composto** com `badgeLabel(badge)`; ajuste o sufixo via `badgeLabel`, não tente sobrescrever
  o resultado final.
- Passar texto em `children` — o componente não foi desenhado para isso (sem espaçamento de
  texto/ícone); para ação com rótulo visível use [`Button`](../Forms/Button.md).
- Usar o `theme` errado para o fundo (ex.: `theme="brand"` sobre fundo branco) — o contraste
  de cor foi calibrado para cada combinação de fundo específica.
- Esperar que `size` redimensione o ícone filho automaticamente — não redimensiona; ajuste o
  `size` do ícone manualmente (referência: `sm=14`, `md=18`, `lg=24`, usada na story).
- Confundir com [`IconButton`](../Forms/IconButton.md) — este é uma composição específica para
  contexto de navegação (badge acessível, temas de header), não um primitivo independente.
