# BottomSheet

Shell de sheet mobile que sobe a partir da borda inferior da tela. É um contêiner **livre**
— sem título, ícone ou footer pré-definidos: você compõe o conteúdo via `children`. Construído
sobre `ModalOverlay` + `Modal` + `Dialog` do `react-aria-components`, com um "handle" (barra de
arraste) visual fixo no topo e animações de slide-up/fade via CSS Modules.

- **Categoria:** Feedback
- **Fonte:** `src/components/Feedback/BottomSheet/`
- **Export:** `import { BottomSheet } from '@srm/diamond';`
- **Relacionados:** [SheetContent](./SheetContent.md) (preset estruturado com título/ícone/ações sobre este shell), [Drawer](./Drawer.md) (painel lateral com título/ações prontos), [Modal](./Modal.md) (dialog centralizado)

---

## Quando usar

- Como **base** para construir uma sheet mobile totalmente customizada, quando o preset
  [`SheetContent`](./SheetContent.md) (título/ícone/callout/ações) não atende ao layout.
- Fluxos financeiros mobile-first: comprovante de Pix, detalhe de transação, seletor de opções,
  formulário curto que precisa de foco total sem sair da tela.
- Demos/specimens que rodam dentro de uma moldura de celular embutida na página (via prop
  `container`), em vez de usar o `document.body` inteiro.

## Quando **não** usar

- Precisa de título, ícone de status (sucesso/erro/aviso), callout e botões de ação prontos →
  use [`SheetContent`](./SheetContent.md), que já é construído sobre este `BottomSheet`.
- Painel lateral (desktop) com título e ações → [`Drawer`](./Drawer.md).
- Dialog centralizado (não vinculado à borda inferior) → [`Modal`](./Modal.md).
- Mensagem de fechamento automático/transiente (toast) → não é uma sheet; use o `Toastr`.

---

## Interface

```ts
import type { ReactNode } from 'react';

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  dismissible?: boolean;       // default: true — permite fechar por backdrop/Esc
  maxHeight?: string;          // default: '80vh'
  height?: string;             // default: undefined (altura definida pelo conteúdo, até maxHeight)
  container?: HTMLElement | null; // escopa o portal (specimen mobile) em vez de document.body
  ariaLabel?: string;          // default: 'Conteúdo' — nome acessível do dialog
  children?: ReactNode;
}
```

### Notas de comportamento

- **Shell puro**: não renderiza título, ícone, callout ou botões — apenas o overlay, o
  contêiner do sheet e uma barrinha de "handle" decorativa no topo. Todo o conteúdo visível
  vem de `children`.
- `dismissible = false` desabilita tanto o clique no backdrop quanto o `Esc`
  (`isKeyboardDismissDisabled`) — use para fluxos que exigem uma ação explícita do usuário
  antes de fechar (ex.: confirmação de transação em andamento).
- `maxHeight`/`height` aceitam qualquer string CSS (ex.: `'80vh'`, `'480px'`). Quando `container`
  é fornecido, unidades `vh` são **automaticamente convertidas para `%`**
  (`BottomSheet.constants.ts` → `toContainerUnit`), já que a viewport real da página não é a
  referência de altura dentro de um contêiner escopado.
- `container`: quando definido, o portal do `ModalOverlay` é escopado a esse elemento
  (`UNSTABLE_portalContainer` do react-aria) e o sheet passa a `position: absolute` dentro dele
  — usado para specimens que simulam uma moldura de celular na própria página, em vez de cobrir
  a viewport inteira.
- `ariaLabel` **só é necessário customizar** quando não há um `<Heading slot="title">` visível
  dentro de `children`; caso contrário o default `'Conteúdo'` é usado como nome acessível do
  `Dialog`.
- Animações de entrada/saída (slide-up do sheet, fade do overlay, 280ms,
  `cubic-bezier(0.32, 0, 0.15, 1)`) respeitam `prefers-reduced-motion: reduce` (desabilitadas).

---

## Exemplos

```tsx
import { useState } from 'react';
import { BottomSheet, Button, IconButton } from '@srm/diamond';
import { X } from 'lucide-react';

// Básico — conteúdo livre, fechar via IconButton próprio
function ComprovantePix() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      <Button onPress={() => setIsOpen(true)}>Ver comprovante</Button>
      <BottomSheet isOpen={isOpen} onClose={() => setIsOpen(false)} ariaLabel="Comprovante Pix">
        <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '12px 16px 0' }}>
          <IconButton
            icon={<X size={16} strokeWidth={2} />}
            size="sm"
            variant="ghost"
            aria-label="Fechar"
            onPress={() => setIsOpen(false)}
          />
        </div>
        <div style={{ padding: '12px 24px 32px' }}>
          <h3>Pix enviado</h3>
          <p>R$ 250,00 para Maria Silva.</p>
        </div>
      </BottomSheet>
    </>
  );
}

// Não dismissível — exige ação explícita (ex.: processamento em andamento)
<BottomSheet isOpen={isOpen} onClose={onClose} dismissible={false} ariaLabel="Confirmando transação">
  <p>Não feche esta tela enquanto processamos seu Pix…</p>
</BottomSheet>

// Altura fixa
<BottomSheet isOpen={isOpen} onClose={onClose} height="480px" ariaLabel="Selecionar conta">
  {/* lista de contas */}
</BottomSheet>

// Escopado a um contêiner (specimen de moldura de celular numa demo)
function MobileSpecimen() {
  const [container, setContainer] = useState<HTMLElement | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div ref={(el) => { if (el && !container) setContainer(el); }} style={{ position: 'relative', width: 390, height: 760 }}>
      <Button onPress={() => setIsOpen(true)}>Abrir sheet</Button>
      <BottomSheet isOpen={isOpen} onClose={() => setIsOpen(false)} container={container} ariaLabel="Conteúdo">
        {/* '80vh' vira '80%' automaticamente por estar escopado ao container */}
      </BottomSheet>
    </div>
  );
}
```

> Para o caso comum (título + subtítulo opcional + ícone de status + callout + até duas
> ações), prefira o preset [`SheetContent`](./SheetContent.md), que já entrega esse layout
> pronto sobre este mesmo `BottomSheet`.

---

## Acessibilidade

- O `Dialog` interno recebe `aria-label` (default `'Conteúdo'`) como nome acessível — se o
  `children` já contém um `<Heading slot="title">` visível, considere passar um `ariaLabel`
  mais descritivo (ex.: "Comprovante Pix") em vez de depender do default genérico.
- `dismissible={true}` (default) permite fechar via `Esc` e clique no backdrop — comportamento
  padrão de dialog modal do react-aria. Com `dismissible={false}`, o teclado e o backdrop são
  bloqueados; garanta que exista **outra** forma de fechar (botão explícito) ou que o
  fechamento seja programático (ex.: ao concluir uma operação).
- O foco é preso dentro do `Dialog` (focus trap) enquanto aberto, e retorna ao elemento
  disparador ao fechar — comportamento padrão do `Modal`/`ModalOverlay` do react-aria.
- A barra de "handle" no topo é puramente decorativa (`div`), sem papel semântico — não
  interfere na leitura por leitores de tela.

## Armadilhas comuns

- Não espere título, ícone ou botões prontos — este é um **shell sem opinião de conteúdo**;
  se precisar desse preset, use [`SheetContent`](./SheetContent.md) em vez de recriá-lo à mão.
- Esquecer de fornecer uma forma de fechar quando `dismissible={false}` deixa o usuário preso
  na sheet (sem backdrop, sem Esc, sem botão) — sempre inclua uma ação de saída explícita.
- Usar `maxHeight`/`height` em `vh` esperando o comportamento de viewport da página mesmo
  dentro de um `container` escopado — a conversão para `%` já é automática, não precisa (nem
  deve) ser feita manualmente na prop.
- Passar `container` mas esquecer que o sheet passa a `position: absolute` relativo a ele — o
  elemento passado como `container` deve ter `position: relative` (ou equivalente) para o
  posicionamento funcionar como esperado.
