# Select

Campo de seleção única (dropdown) baseado em uma lista fixa de strings. Suporta busca
client-side opcional, estados de erro/desabilitado/aberto, dois tamanhos e tema
claro/escuro. Construído sobre `Select`, `ListBox`, `ListBoxItem` e `Popover` do
`react-aria-components` — o posicionamento do overlay é gerenciado inteiramente pelo RAC.

- **Categoria:** Forms
- **Fonte:** `src/components/Forms/Select/`
- **Export:** `import { Select } from '@srm/diamond';`
- **Relacionados:** [MultiSelect](./MultiSelect.md) (mesma anatomia de campo, seleção
  múltipla); nenhum sub-componente acoplado (export único); para múltiplos campos
  lado a lado, componha com [`FieldGroup`](./FieldGroup.md) se existir no seu layout.

---

## Quando usar

- Escolha única entre um conjunto **pequeno a médio** de opções textuais conhecidas —
  ex.: categoria de fundo, classe de ativo, tipo de operação, status de um cadastro.
- Quando a lista pode crescer o suficiente para justificar filtro por texto → ative
  `withSearch`.
- Formulários financeiros/bancários da SRM: seleção de classe de ativo (o próprio
  fallback padrão do componente é uma lista de categorias de fundos — Renda Fixa,
  Multimercado, Fundos de Ações, FIDC, Securitização, CRI & CRA, Debêntures).

## Quando **não** usar

- Múltiplas opções selecionáveis ao mesmo tempo → use [`MultiSelect`](./MultiSelect.md).
  Este `Select` é **single-value** (uma `string` por vez, sem modo multi-seleção); o
  `MultiSelect` reproduz a mesma anatomia de campo, então a troca é visualmente neutra
  quando o campo está fechado e vazio.
- Opções que precisam de um **valor interno diferente do texto exibido** (ex.: `id`
  numérico com label textual) → o componente aceita apenas `options: string[]`, onde o
  próprio texto é o valor. Se você precisa separar `value`/`label`, monte um `Select`
  do `react-aria-components` diretamente ou mapeie os IDs para strings de exibição e
  reverta na hora de persistir.
- Texto livre digitado pelo usuário → use `TextInput`/`Autocomplete` (se existir), não
  `Select`.

---

## Interface

```ts
import type { ReactNode, Ref } from 'react';

type SelectState = 'default' | 'error' | 'disabled' | 'open';
type SelectSize  = 'sm' | 'md';
type SelectTheme = 'default' | 'dark'; // definido no fonte, mas NÃO exportado no barrel

interface SelectProps {
  state?: SelectState;                     // default: 'default'
  size?: SelectSize;                       // default: 'md'
  theme?: SelectTheme;                     // default: 'default'
  label?: ReactNode;
  placeholder?: string;                    // default: 'Selecione...'
  helperText?: ReactNode;
  errorText?: ReactNode;
  options?: string[];                      // default: DEFAULT_OPTIONS (categorias de fundos SRM)
  withSearch?: boolean;                    // default: false

  value?: string;                          // controlado; string igual ao item de `options`

  onChange?: (value: string) => void;
  fullWidth?: boolean;                     // default: false
  ref?: Ref<HTMLDivElement>;               // encaminhado ao componente raiz (AriaSelect)
}
```

> `index.ts` exporta apenas os tipos `SelectProps`, `SelectState` e `SelectSize`.
> `SelectTheme` existe no arquivo de tipos mas **não é exportado** — para tipar a prop
> `theme` externamente, use `'default' | 'dark'` literal ou `SelectProps['theme']`.

### Notas de comportamento

- **`options` é `string[]` simples** — cada string é ao mesmo tempo o valor (`id` do
  item na `ListBox`) e o texto exibido. Não há suporte nativo a par `value`/`label`
  distintos.
- Sem `options`, o componente usa `DEFAULT_OPTIONS` (`Select.constants.ts`): `'Renda
  Fixa'`, `'Multimercado'`, `'Fundos de Ações'`, `'FIDC'`, `'Securitização'`, `'CRI &
  CRA'`, `'Debêntures'`.
- **Controlado vs. não controlado**: se `value` for `undefined`, o componente gerencia
  a seleção internamente (`internalKey`). Se `value` for passado, ele sempre vence
  (`selectedKey = value !== undefined ? value : internalKey`).
- **`onChange` só dispara com valor não nulo.** Internamente, quando a chave
  selecionada volta a `null` (ex.: limpeza programática do RAC), o estado interno é
  atualizado mas `onChange` **não** é chamado — o callback nunca recebe `null`/`undefined`.
  Não existe, portanto, uma forma de "limpar" a seleção via UI que dispare `onChange`.
- `state="error"` **ou** simplesmente passar `errorText` já marca o campo como inválido
  (`isError = state === 'error' || Boolean(errorText)`) — não é preciso setar os dois.
- `state="disabled"` desabilita o trigger (`isDisabled`); a `ListBox` não abre.
- `state="open"` usa `defaultOpen` do RAC — **abre apenas ao montar** (não controlado);
  não force reabertura depois via re-render com `state="open"`.
- `withSearch` filtra `options` **no cliente**, por `includes` case-insensitive sobre o
  texto (sem debounce, sem busca assíncrona). Quando o filtro não encontra nada, exibe
  um item desabilitado "Nenhuma opção encontrada". O campo de busca ganha foco
  automaticamente ao abrir o popover e faz `stopPropagation` de teclado para não
  conflitar com o typeahead nativo da `ListBox`. O texto de busca é resetado sempre que
  o popover fecha.
- `theme="dark"` seta `data-theme="dark"` no elemento raiz; com `theme="default"`
  nenhum atributo de tema é adicionado (o CSS assume o tema claro por padrão).
- A largura do `Popover` acompanha a largura do trigger automaticamente
  (`var(--trigger-width)`, mecanismo do próprio RAC) — sem `getBoundingClientRect`
  manual.

---

## Exemplos

```tsx
import { useState } from 'react';
import { Select } from '@srm/diamond';

// Básico (controlado)
function CategoriaField() {
  const [categoria, setCategoria] = useState('');
  return (
    <Select
      label="Categoria"
      value={categoria}
      onChange={setCategoria}
    />
  );
}

// Opções customizadas
<Select
  label="Tipo de operação"
  options={['Aporte', 'Resgate', 'Transferência']}
  placeholder="Selecione o tipo"
  value={tipo}
  onChange={setTipo}
/>

// Com busca (listas maiores)
<Select
  label="Fundo"
  options={listaDeFundos}
  withSearch
  value={fundoSelecionado}
  onChange={setFundoSelecionado}
/>

// Estado de erro
<Select
  label="Classe de ativo"
  state="error"
  errorText="Selecione uma classe de ativo."
  value={classe}
  onChange={setClasse}
/>

// Desabilitado
<Select label="Categoria" state="disabled" value="Renda Fixa" />

// Tamanho pequeno + largura total
<Select label="Status" size="sm" fullWidth options={['Ativo', 'Inativo']} />

// Tema escuro (sobre header brand)
<Select label="Categoria" theme="dark" value={categoria} onChange={setCategoria} />
```

### Integração com React Hook Form

```tsx
<Controller
  name="categoria"
  control={control}
  render={({ field, fieldState }) => (
    <Select
      label="Categoria"
      value={field.value}
      onChange={field.onChange}
      state={fieldState.error ? 'error' : 'default'}
      errorText={fieldState.error?.message}
    />
  )}
/>
```

---

## Acessibilidade

- Sempre forneça `label` — ele renderiza um `<Label>` associado ao trigger pelo RAC.
- O trigger é um `<button>` real (`AriaButton`), navegável e ativável por teclado
  (Enter/Espaço/setas cuidados pelo `react-aria-components`).
- Erros são expostos via `FieldError` do RAC, associado ao campo — anunciado por
  leitores de tela quando `isInvalid` é verdadeiro.
- O campo de busca interno já tem `aria-label="Buscar opção"` fixo (não é configurável
  via props); se precisar de outro texto, isso exigiria alterar o componente-fonte.
- Ícones (`ChevronDown`, `Check`, `Search`, `AlertCircle`) são todos `aria-hidden`.

## Armadilhas comuns

- Não passe uma lista de objetos em `options` — a prop é `string[]`; se seus dados
  vierem como `{ id, label }`, mapeie para `string[]` antes e resolva o `id`
  correspondente ao receber o `onChange`.
- Não espere que `onChange` seja chamado com `null`/string vazia ao "desselecionar" —
  isso não acontece (ver nota de comportamento acima); se precisar de um estado
  "nenhuma seleção", trate isso fora do componente (ex.: botão de limpar separado).
- `state="open"` não é um jeito de controlar abertura/fechamento em tempo real — serve
  apenas para abrir por padrão na montagem (útil em Storybook/demos).
- Duas opções com o mesmo texto colidem, pois o texto **é** a chave (`id={option}`) —
  garanta valores únicos em `options`.
